import { createReadStream } from 'node:fs'
import { mkdir, readFile, readdir, lstat, chmod } from 'node:fs/promises'
import { join } from 'node:path'
import { createGunzip } from 'node:zlib'
import { pipeline } from 'node:stream/promises'
import { Transform } from 'node:stream'
import { extract } from 'tar'
import { digest, regular, syncDirectory } from './files.js'
import { safePath, MAX_EXPANDED } from './manifest.js'

export async function verifyDirectory(directory, release, raw) {
  const expected = new Set(['manifest.json', ...Object.keys(release.files)])
  async function walk(root, prefix = '') {
    for (const name of await readdir(root)) {
      const path = prefix + name, full = join(root, name), stat = await lstat(full)
      if (!safePath(path) || stat.isSymbolicLink()) throw Error('CONTROL_PACKAGE_CORRUPT')
      if (stat.isDirectory()) { await walk(full, path + '/'); continue }
      if (!stat.isFile() || !expected.delete(path)) throw Error('CONTROL_PACKAGE_CORRUPT')
      const bytes = await readFile(full)
      if (path === 'manifest.json') {
        if (!bytes.equals(raw)) throw Error('CONTROL_PACKAGE_CORRUPT')
      } else if (bytes.length !== release.files[path].size || digest(bytes) !== release.files[path].sha256) throw Error('CONTROL_PACKAGE_CORRUPT')
    }
  }
  await walk(directory)
  if (expected.size) throw Error('CONTROL_PACKAGE_CORRUPT')
}
export async function unpack(archive, directory, release, raw) {
  await mkdir(directory, { recursive: true, mode: 0o700 })
  const compressed = (await regular(archive)).size
  let expanded = 0, invalid = false
  const seen = new Set()
  const limiter = new Transform({ transform(chunk, _encoding, done) {
    expanded += chunk.length
    done(expanded > MAX_EXPANDED || expanded > Math.max(1048576, compressed * 40) ? Error('CONTROL_PACKAGE_TOO_LARGE') : null, chunk)
  } })
  const extraction = extract({ cwd: directory, strict: true, preservePaths: false, noChmod: true,
    filter: (name, entry) => {
      const path = name.replace(/\/$/, '')
      if (!safePath(path) || seen.size >= 8192 || seen.has(path.toLowerCase()) || !['File', 'Directory'].includes(entry.type)) { invalid = true; return false }
      seen.add(path.toLowerCase())
      if (entry.type === 'Directory') {
        if (!Object.keys(release.files).some(file => file.startsWith(path + '/'))) { invalid = true; return false }
        return true
      }
      const size = path === 'manifest.json' ? raw.length : release.files[path]?.size
      if (size === undefined || size !== entry.size || seen.size > 8192) { invalid = true; return false }
      return true
    } })
  await pipeline(createReadStream(archive), createGunzip(), limiter, extraction, { signal: AbortSignal.timeout(60000) })
  if (invalid) throw Error('CONTROL_PACKAGE_CORRUPT')
  await verifyDirectory(directory, release, raw)
  for (const path of ['manifest.json', ...Object.keys(release.files)]) {
    const full = join(directory, path)
    // FlushFileBuffers requires write access on Windows, including read-only tar entries.
    await chmod(full, 0o600)
    const { open } = await import('node:fs/promises'), fd = await open(full, 'r+')
    try { await fd.sync() } finally { await fd.close() }
    await chmod(full, 0o400)
  }
  await syncDirectory(directory)
}
