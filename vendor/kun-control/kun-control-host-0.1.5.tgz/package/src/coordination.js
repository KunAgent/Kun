import fs from 'node:fs'
import { randomUUID } from 'node:crypto'
import { join } from 'node:path'
import { mkdir } from 'node:fs/promises'
import lockfile from 'proper-lockfile'
const processStart = performance.timeOrigin
function alive(owner) {
  if (!Number.isSafeInteger(owner?.pid) || owner.pid <= 0) return true
  if (owner.pid === process.pid) return owner.startedAt === processStart
  try { process.kill(owner.pid, 0); return true }
  catch (error) { return error.code !== 'ESRCH' }
}
/** A live owner never expires during suspend; a verified dead owner is recoverable immediately. */
export async function locked(home, operation) {
  await mkdir(home, { recursive: true, mode: 0o700 })
  const path = join(home, 'update'), token = randomUUID(), adapter = Object.create(fs)
  const readOwner = file => JSON.parse(fs.readFileSync(join(file, 'owner.json'), 'utf8'))
  adapter.mkdir = (file, callback) => {
    const candidate = `${file}.candidate-${process.pid}-${token}`
    fs.mkdir(candidate, { mode: 0o700 }, error => {
      if (error) return callback(error)
      fs.writeFile(join(candidate, 'owner.json'), JSON.stringify({ pid: process.pid, startedAt: processStart, token }), { mode: 0o600 }, error => {
        if (error) return fs.rm(candidate, { recursive: true, force: true }, () => callback(error))
        fs.rename(candidate, file, error => {
          if (error && ['ENOTEMPTY', 'EACCES', 'EPERM'].includes(error.code) && fs.existsSync(file)) error.code = 'EEXIST'
          if (error) fs.rm(candidate, { recursive: true, force: true }, () => callback(error))
          else callback(null)
        })
      })
    })
  }
  adapter.stat = (file, callback) => fs.stat(file, (error, stat) => {
    if (!error && file === `${path}.lock`) {
      try {
        const owner = readOwner(file)
        if (owner.token !== token && alive(owner)) { stat.mtime = new Date(); stat.mtimeMs = Date.now() }
        else if (!alive(owner)) { stat.mtime = new Date(0); stat.mtimeMs = 0 }
      } catch { /* Ambiguous owner: preserve it rather than assuming that a timer proves death. */ }
    }
    callback(error, stat)
  })
  adapter.rmdir = (file, callback) => {
    try {
      const owner = readOwner(file)
      if (owner.token !== token && alive(owner)) return callback(Object.assign(Error('CONTROL_UPDATE_OWNER_CONFLICT'), { code: 'ELOCKED' }))
      fs.unlinkSync(join(file, 'owner.json'))
    } catch (error) { if (error.code !== 'ENOENT') return callback(error) }
    // A competing publisher uses a nonempty directory, so rmdir cannot delete its new live lock.
    fs.rmdir(file, callback)
  }
  let compromised
  const release = await lockfile.lock(path, { realpath: false, fs: adapter, stale: 10000, update: 2000,
    retries: { retries: 2, factor: 1, minTimeout: 50, maxTimeout: 50 }, onCompromised: error => { compromised = error } })
  const assertOwned = () => { if (compromised) throw Error('CONTROL_UPDATE_OWNER_CONFLICT') }
  try { const result = await operation(assertOwned); assertOwned(); return result }
  finally { await release() }
}
