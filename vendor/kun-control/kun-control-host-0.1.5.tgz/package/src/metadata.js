import { Updater, BaseFetcher } from 'tuf-js'
import { DownloadHTTPError } from 'tuf-js/dist/error.js'
import { mkdir, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { atomic, json, digest } from './files.js'
import { advancePolicy, allowed, compatible, manifest, MAX_PACKAGE, safePath } from './manifest.js'

class Fetcher extends BaseFetcher {
  constructor(origin, fetch) { super(); this.origin = origin; this.fetchImpl = fetch }
  async fetch(url) {
    const value = new URL(url)
    if (value.origin !== this.origin || value.search || value.hash ||
        !value.pathname.startsWith('/control/updates/') || !safePath(value.pathname.slice('/control/updates/'.length)))
      throw Error('CONTROL_UNSAFE_UPDATE_URL')
    const response = await this.fetchImpl(url, { redirect: 'error', credentials: 'omit', signal: AbortSignal.timeout(60_000) })
    if (!response.ok) throw new DownloadHTTPError(`HTTP ${response.status}`, response.status)
    return response.body
  }
}
export async function repository(home, trust, fetch = globalThis.fetch) {
  if (!trust?.root || typeof trust.origin !== 'string') throw Error('CONTROL_UPDATES_NOT_CONFIGURED')
  const url = new URL(trust.origin)
  if (url.protocol !== 'https:' && !(trust.development === true && url.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(url.hostname)))
    throw Error('CONTROL_UNSAFE_UPDATE_URL')
  if (url.pathname !== '/' || url.search || url.hash || url.username || url.password) throw Error('CONTROL_UNSAFE_UPDATE_URL')
  const directory = join(home, 'trust', 'metadata'), downloads = join(home, 'downloads')
  await mkdir(directory, { recursive: true, mode: 0o700 }); await mkdir(downloads, { recursive: true, mode: 0o700 })
  if (!await json(join(directory, 'root.json'))) await atomic(join(directory, 'root.json'), trust.root)
  const previousTime = await json(join(home, 'trust', 'clock.json'), { verifiedAt: 0 })
  if (Date.now() < previousTime.verifiedAt - 300000) throw Error('CONTROL_CLOCK_ROLLBACK')
  const updater = new Updater({ metadataDir: directory, metadataBaseUrl: url.origin + '/control/updates/metadata/',
    targetBaseUrl: url.origin + '/control/updates/targets/', targetDir: downloads, fetcher: new Fetcher(url.origin, fetch),
    config: { fetchRetries: 0, maxRootRotations: 128, rootMaxLength: 65536, timestampMaxLength: 65536, snapshotMaxLength: 1048576, targetsMaxLength: 4194304 } })
  await updater.refresh()
  const target = async (path, limit = MAX_PACKAGE) => {
    if (!safePath(path)) throw Error('CONTROL_MANIFEST_INVALID')
    const info = await updater.getTargetInfo(path)
    if (!info || info.length > limit) throw Error('CONTROL_PACKAGE_CORRUPT')
    return await updater.findCachedTarget(info) ?? await updater.downloadTarget(info)
  }
  const current = advancePolicy(await json(join(home, 'trust', 'policy.json')),
    JSON.parse(await readFile(await target('stable.json', 262144), 'utf8')))
  await atomic(join(home, 'trust', 'policy.json'), current)
  await atomic(join(home, 'trust', 'clock.json'), { verifiedAt: Math.max(previousTime.verifiedAt, Date.now()) })
  return { policy: current, target }
}
export async function candidate(repo, host, installationId) {
  for (const item of repo.policy.releases) {
    const bucket = Number.parseInt(digest(`${item.salt}:${installationId}`).slice(0, 8), 16) % 10000
    if (bucket >= item.rollout) continue
    const raw = await readFile(await repo.target(item.manifestTarget, 262144))
    const release = manifest(JSON.parse(raw.toString()))
    if (release.releaseId !== item.releaseId) throw Error('CONTROL_MANIFEST_INVALID')
    if (compatible(release, host) && allowed(release, repo.policy)) return { release, raw }
  }
  return null
}
