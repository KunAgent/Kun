export type Manifest = {schemaVersion: 1; packageId: string; releaseId: string; version: string; platform: string; arch: string; hostApi: number; hostBuilds: string[]; securityEpoch: number; viewerApi?: 1; entrypoints: {runtime: string; capture: string; viewer?: string}; files: Record<string, {size: number; sha256: string}>}
export type PackageStatus = {phase: string; version?: string; releaseId?: string; candidateVersion?: string; checkedAt?: number; error?: string}
export type Driver = {probe(directory: string, release: Manifest): Promise<void>; activate(directory: string, release: Manifest): Promise<void>; drain(): Promise<boolean>; resume(): Promise<void>; stop(): Promise<void>}
export class ControlPackageManager {
  constructor(options: {home: string; baseline?: {directory: string; manifestHash: string}; host: {platform: string; arch: string; hostApi: number; buildId: string; minimumVersion?: string}; driver: Driver; trust?: {origin: string; root: unknown; development?: boolean}; fetch?: typeof fetch; changed?(status: PackageStatus): void})
  status(): PackageStatus
  initialize(): Promise<PackageStatus>
  check(): Promise<PackageStatus>
  install(): Promise<PackageStatus>
  apply(): Promise<PackageStatus>
  recover(): Promise<PackageStatus>
  shutdown(): Promise<void>
}
export class RpcPeer {
  constructor(send: (value: unknown) => void, generation: string, handlers?: Record<string, (value: any) => any>, event?: (name: string, value: any) => void)
  closed: boolean
  handlers: Record<string, (value: any) => any>
  call<T = any>(method: string, value?: unknown, timeout?: number): Promise<T>
  notify(event: string, value: unknown): void
  receive(value: unknown): Promise<void>
  close(): void
}
export function manifest(value: unknown): Manifest
export const HOST_API: number
