export const HOST_API = 1
export const MAX_PACKAGE = 128 * 1024 * 1024
export const MAX_EXPANDED = 384 * 1024 * 1024
export const validId = value => typeof value === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}$/.test(value)
export const validHash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value)
export function safePath(value) {
  if (typeof value !== 'string' || value.length > 240 || !/^[a-zA-Z0-9_./-]+$/.test(value)) return false
  return value.split('/').every(part => part && part !== '.' && part !== '..' && !part.endsWith('.') &&
    !/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(part))
}
export function manifest(value) {
  if (!value || value.schemaVersion !== 1 || value.packageId !== 'kun-control-bundle' || !validId(value.releaseId) ||
      !/^\d+\.\d+\.\d+$/.test(value.version) || !['darwin', 'win32', 'linux'].includes(value.platform) ||
      !['arm64', 'x64'].includes(value.arch) || value.hostApi !== HOST_API || value.runtimeApi !== 1 ||
      !Number.isSafeInteger(value.securityEpoch) || value.securityEpoch < 1 || value.stateSchema !== 1 ||
      value.migrationMode !== 'none' || value.rollbackSafe !== true ||
      !Array.isArray(value.hostBuilds) || !value.hostBuilds.length || value.hostBuilds.length > 128 || !value.hostBuilds.every(validId) ||
      !safePath(value.artifactTarget) || !value.artifactTarget.startsWith('bundles/') ||
      value.entrypoints?.runtime !== 'runtime/index.mjs' || value.entrypoints?.capture !== 'capture/index.html' ||
      !value.files || typeof value.files !== 'object' || Array.isArray(value.files)) throw Error('CONTROL_MANIFEST_INVALID')
  if ((value.viewerApi !== undefined || value.entrypoints.viewer !== undefined) &&
      (value.viewerApi !== 1 || value.entrypoints.viewer !== 'viewer/index.html' || !value.files[value.entrypoints.viewer]))
    throw Error('CONTROL_MANIFEST_INVALID')
  const paths = Object.keys(value.files), folded = new Set()
  let total = 0
  if (!paths.length || paths.length > 4096) throw Error('CONTROL_MANIFEST_INVALID')
  for (const path of paths) {
    const file = value.files[path]
    if (!safePath(path) || path === 'manifest.json' || folded.has(path.toLowerCase()) || !validHash(file?.sha256) ||
        !Number.isSafeInteger(file.size) || file.size < 0 || file.size > MAX_PACKAGE || file.executable === true)
      throw Error('CONTROL_MANIFEST_INVALID')
    folded.add(path.toLowerCase()); total += file.size
  }
  if (total > MAX_EXPANDED || !value.files[value.entrypoints.runtime] || !value.files[value.entrypoints.capture]) throw Error('CONTROL_MANIFEST_INVALID')
  return value
}
export function compatible(release, host) {
  return release.platform === host.platform && release.arch === host.arch && release.hostApi === host.hostApi &&
    release.hostBuilds.includes(host.buildId) && release.runtimeApi === 1 && release.stateSchema === 1 &&
    versionAtLeast(release.version, host.minimumVersion)
}
/** A new signed host can require a bundled feature floor without changing older hosts' policy. */
export function versionAtLeast(version, minimum) {
  if (minimum === undefined) return true
  if (![version, minimum].every(value => typeof value === 'string' && value.length <= 40 && /^\d+\.\d+\.\d+$/.test(value))) return false
  const actual = version.split('.').map(Number), floor = minimum.split('.').map(Number)
  if (![...actual, ...floor].every(Number.isSafeInteger)) return false
  for (let index = 0; index < 3; index++) if (actual[index] !== floor[index]) return actual[index] > floor[index]
  return true
}
export function policy(value) {
  if (!value || value.schemaVersion !== 1 || !Number.isSafeInteger(value.sequence) || value.sequence < 1 ||
      !Number.isSafeInteger(value.minimumSecurityEpoch) || value.minimumSecurityEpoch < 1 ||
      !Array.isArray(value.revoked) || value.revoked.length > 2000 || !value.revoked.every(validId) ||
      !Array.isArray(value.releases) || value.releases.length > 256) throw Error('CONTROL_POLICY_INVALID')
  const ids = new Set()
  for (const item of value.releases) {
    if (!validId(item.releaseId) || ids.has(item.releaseId) || !safePath(item.manifestTarget) || !item.manifestTarget.startsWith('releases/') ||
        !Number.isInteger(item.rollout) || item.rollout < 0 || item.rollout > 10000 || !validId(item.salt)) throw Error('CONTROL_POLICY_INVALID')
    ids.add(item.releaseId)
  }
  return value
}
export function allowed(release, currentPolicy) {
  return !currentPolicy || release.securityEpoch >= currentPolicy.minimumSecurityEpoch && !currentPolicy.revoked.includes(release.releaseId)
}
export function advancePolicy(prior, next) {
  policy(next)
  if (prior && (next.sequence < prior.sequence || next.minimumSecurityEpoch < prior.minimumSecurityEpoch ||
      prior.revoked.some(id => !next.revoked.includes(id)) || next.sequence === prior.sequence && JSON.stringify(prior) !== JSON.stringify(next)))
    throw Error('CONTROL_POLICY_ROLLBACK')
  return next
}
