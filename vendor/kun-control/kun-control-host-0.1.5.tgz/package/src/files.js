import { open, mkdir, rename, readFile, lstat } from 'node:fs/promises'
import { dirname } from 'node:path'
import { randomUUID, createHash } from 'node:crypto'

export const digest = data => createHash('sha256').update(data).digest('hex')
export async function json(path, fallback = null) {
  try { return JSON.parse(await readFile(path, 'utf8')) }
  catch (error) { if (error.code === 'ENOENT') return fallback; throw error }
}
export async function syncDirectory(path) {
  // Windows does not support opening directories for fsync. File replacement is still atomic;
  // failure never deletes the previous destination. Power-loss recovery uses the journal.
  if (process.platform === 'win32') return
  const handle = await open(path, 'r')
  try { await handle.sync() } finally { await handle.close() }
}
export async function atomic(path, value) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  const temporary = `${path}.${randomUUID()}.tmp`
  const handle = await open(temporary, 'wx', 0o600)
  try { await handle.writeFile(typeof value === 'string' || Buffer.isBuffer(value) ? value : JSON.stringify(value) + '\n'); await handle.sync() }
  finally { await handle.close() }
  // Never unlink the old pointer to work around a sharing violation.
  await rename(temporary, path)
  await syncDirectory(dirname(path))
}
export async function regular(path) {
  const stat = await lstat(path)
  if (!stat.isFile() || stat.isSymbolicLink()) throw Error('CONTROL_PACKAGE_CORRUPT')
  return stat
}
