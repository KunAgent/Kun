import { randomUUID } from 'node:crypto'
const LIMIT = 5 * 1024 * 1024
/** Explicit method table, bounded pending work, a generation per process, no dynamic property dispatch. */
export class RpcPeer {
  constructor(send, generation, handlers = {}, event = () => {}) {
    this.send = send; this.generation = generation; this.handlers = handlers; this.event = event
    this.pending = new Map(); this.closed = false; this.inflight = 0
  }
  post(value) {
    if (this.closed) throw Error('CONTROL_PROCESS_CLOSED')
    if (Buffer.byteLength(JSON.stringify(value)) > LIMIT) throw Error('CONTROL_RPC_TOO_LARGE')
    this.send({ ...value, generation: this.generation })
  }
  notify(event, value) { this.post({ type: 'event', event, value }) }
  call(method, value, timeout = 15000) {
    if (this.closed || this.pending.size >= 256) return Promise.reject(Error('CONTROL_PROCESS_UNAVAILABLE'))
    const id = randomUUID()
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(Error('CONTROL_RPC_TIMEOUT')) }, timeout)
      this.pending.set(id, { resolve, reject, timer })
      try { this.post({ type: 'request', id, method, value }) }
      catch (error) { clearTimeout(timer); this.pending.delete(id); reject(error) }
    })
  }
  async receive(message) {
    if (this.closed || !message || message.generation !== this.generation || Buffer.byteLength(JSON.stringify(message)) > LIMIT) return
    if (message.type === 'reply') {
      const request = this.pending.get(message.id)
      if (!request) return
      this.pending.delete(message.id); clearTimeout(request.timer)
      if (message.error) request.reject(Object.assign(Error(message.error.code), message.error))
      else request.resolve(message.value)
    } else if (message.type === 'event') {
      try { this.event(message.event, message.value) } catch { /* Peer events cannot crash their host. */ }
    } else if (message.type === 'request' && typeof message.id === 'string') {
      const handler = Object.hasOwn(this.handlers, message.method) && this.handlers[message.method]
      try {
        if (!handler || this.inflight >= 256) throw Error('CONTROL_RPC_REJECTED')
        this.inflight++
        try { const value = await handler(message.value); if (!this.closed) this.post({ type: 'reply', id: message.id, value }) }
        finally { this.inflight-- }
      } catch (error) {
        const code = typeof error.code === 'string' ? error.code : error.message
        if (!this.closed) this.post({ type: 'reply', id: message.id, error: { code: /^[A-Za-z0-9_]{1,80}$/.test(code) ? code : 'CONTROL_OPERATION_FAILED',
          ...(Number.isInteger(error.status) ? { status: error.status } : {}) } })
      }
    }
  }
  close() {
    this.closed = true
    for (const request of this.pending.values()) { clearTimeout(request.timer); request.reject(Error('CONTROL_PROCESS_CLOSED')) }
    this.pending.clear()
  }
}
