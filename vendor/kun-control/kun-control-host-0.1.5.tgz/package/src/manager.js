import { mkdir, readFile, rename, rm, statfs } from 'node:fs/promises'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'
import { locked } from './coordination.js'
import { atomic, json, digest, syncDirectory } from './files.js'
import { manifest, compatible, allowed, validId, validHash } from './manifest.js'
import { repository, candidate } from './metadata.js'
import { unpack, verifyDirectory } from './archive.js'

/** Only the driver owns live processes. This manager never touches business stores or runtime tasks. */
export class ControlPackageManager {
  constructor(options) { this.options = options; this.state = { phase: 'starting' }; this.running = false; this.closing = false; this.activated = false }
  status() { return { ...this.state } }
  change(value) { this.state = { ...this.state, ...value }; this.options.changed?.(this.status()) }
  async exclusive(operation) {
    if (this.closing) throw Error('CONTROL_HOST_STOPPED')
    if (this.running) throw Error('CONTROL_UPDATE_IN_PROGRESS')
    this.running = true
    try {
      await mkdir(this.options.home, { recursive: true, mode: 0o700 })
      return await locked(this.options.home, async assertOwned => { this.assertOwned = assertOwned; return operation() })
    } finally { this.assertOwned = undefined; this.running = false }
  }
  path(reference) {
    if (!reference || !validId(reference.id) || !validHash(reference.digest)) throw Error('CONTROL_PACKAGE_CORRUPT')
    if (reference.builtin) {
      if (!this.options.baseline) throw Error('CONTROL_PACKAGE_NOT_INSTALLED')
      if (reference.digest !== this.options.baseline.manifestHash) throw Error('CONTROL_PACKAGE_CORRUPT')
      return this.options.baseline.directory
    }
    return join(this.options.home, 'releases', reference.id)
  }
  async load(reference) {
    const directory = this.path(reference), raw = await readFile(join(directory, 'manifest.json'))
    if (digest(raw) !== reference.digest) throw Error('CONTROL_PACKAGE_CORRUPT')
    const release = manifest(JSON.parse(raw.toString()))
    if (release.releaseId !== reference.id || !compatible(release, this.options.host)) throw Error('CONTROL_HOST_UPGRADE_REQUIRED')
    if (!allowed(release, await json(join(this.options.home, 'trust', 'policy.json')))) throw Error('CONTROL_RELEASE_REVOKED')
    await verifyDirectory(directory, release, raw)
    return { release, directory }
  }
  async baseline() {
    if (!this.options.baseline) return null
    const raw = await readFile(join(this.options.baseline.directory, 'manifest.json'))
    if (digest(raw) !== this.options.baseline.manifestHash) throw Error('CONTROL_PACKAGE_CORRUPT')
    return { id: manifest(JSON.parse(raw.toString())).releaseId, digest: digest(raw), builtin: true }
  }
  async initialize() {
    return this.exclusive(async () => {
      const baseline = await this.baseline().catch(() => null)
      let malformed = false
      const pointer = async name => json(join(this.options.home, name)).catch(() => { malformed = true; return null })
      const active = await pointer('active.json'), confirmed = await pointer('confirmed.json')
      const transaction = await pointer('transaction.json')
      this.prepared = transaction?.phase === 'prepared' ? transaction.candidate : null
      // Never boot an interrupted, unconfirmed activation ahead of the last confirmed version.
      const references = [confirmed?.current, !active?.pending && active?.current, active?.previous, confirmed?.previous, baseline]
        .filter((value, index, all) => value && all.findIndex(other => other?.id === value.id && other?.digest === value.digest && other?.builtin === value.builtin) === index)
      const generation = Math.max(0, ...[active, confirmed].map(value => Number.isSafeInteger(value?.generation) ? value.generation : 0)) + 1
      let lastError = Error(active?.pending ? 'CONTROL_ACTIVATION_FAILED' : 'CONTROL_PACKAGE_CORRUPT')
      const rejected = new Set()
      for (const reference of references) {
        try {
          const loaded = await this.load(reference)
          if (this.closing) throw Error('CONTROL_HOST_STOPPED')
          await this.options.driver.activate(loaded.directory, loaded.release)
          this.activated = true
          if (this.closing) throw Error('CONTROL_HOST_STOPPED')
          let previous = null
          for (const other of references) {
            if (other.id !== reference.id && !rejected.has(other.id) && await this.load(other).then(() => true, () => false)) { previous = other; break }
          }
          this.active = { current: reference, previous, generation, pending: false }
          await this.confirm()
          this.change({ phase: this.prepared ? 'waiting_for_idle' : 'ready', version: loaded.release.version, releaseId: reference.id,
            error: active?.current && reference.id !== active.current.id ? 'CONTROL_RECOVERED_PREVIOUS' : undefined })
          return this.status()
        } catch (error) { rejected.add(reference.id); lastError = error; await this.stop(); if (this.closing) throw error }
      }
      this.active = undefined
      if (!this.options.baseline && !malformed && !active?.pending && references.every(value => value.builtin)) {
        if (this.prepared) {
          const loaded = await this.load(this.prepared)
          this.change({ phase: 'waiting_for_idle', candidateVersion: loaded.release.version, version: undefined, releaseId: undefined, error: undefined })
        } else this.change({ phase: 'not_installed', version: undefined, releaseId: undefined, candidateVersion: undefined, error: undefined })
        return this.status()
      }
      this.change({ phase: 'disabled', version: undefined, releaseId: undefined, error: lastError?.message ?? 'CONTROL_PACKAGE_CORRUPT' })
      throw lastError
    }).catch(error => { this.change({ phase: 'disabled', version: undefined, releaseId: undefined, error: error?.message ?? 'CONTROL_PACKAGE_CORRUPT' }); throw error })
  }
  async confirm() {
    this.assertOwned?.()
    this.active.pending = false
    await atomic(join(this.options.home, 'confirmed.json'), this.active)
    await atomic(join(this.options.home, 'active.json'), this.active)
  }
  async trusted() {
    const repo = await repository(this.options.home, this.options.trust, this.options.fetch)
    if (this.active) {
      try { await this.load(this.active.current) }
      catch (error) {
        await this.stop()
        this.change({ phase: 'disabled', version: undefined, releaseId: undefined, error: /^CONTROL_[A-Z_]+$/.test(error.message) ? error.message : 'CONTROL_PACKAGE_CORRUPT' })
      }
    }
    return repo
  }
  async check() {
    return this.exclusive(async () => {
      const before = this.state.phase
      this.change({ phase: 'checking', error: undefined })
      try {
        const repo = await this.trusted()
        const disabled = this.state.phase === 'disabled'
        let installation = await json(join(this.options.home, 'installation.json'))
        if (!installation) { installation = { id: randomUUID() }; await atomic(join(this.options.home, 'installation.json'), installation) }
        const next = await candidate(repo, this.options.host, installation.id)
        const available = next && (!this.activated || next.release.releaseId !== this.active?.current.id)
        this.change({ phase: available ? 'available' : disabled || before === 'disabled' ? 'disabled' : this.activated ? 'ready' : 'not_installed',
          candidateVersion: available ? next.release.version : undefined, checkedAt: Date.now(),
          error: !next ? 'CONTROL_NO_COMPATIBLE_RELEASE' : undefined })
        return this.status()
      } catch (error) { this.change({ phase: before, error: error.message }); throw error }
    })
  }
  async install() {
    return this.exclusive(async () => {
      let temporary
      try {
        const repo = await this.trusted(), installation = await json(join(this.options.home, 'installation.json'), { id: randomUUID() })
        await atomic(join(this.options.home, 'installation.json'), installation)
        const next = await candidate(repo, this.options.host, installation.id)
        if (!next) throw Error('CONTROL_NO_COMPATIBLE_RELEASE')
        if (this.activated && next.release.releaseId === this.active?.current.id) return this.status()
        this.change({ phase: 'downloading', candidateVersion: next.release.version, error: undefined })
        const disk = await statfs(this.options.home)
        const expanded = Object.values(next.release.files).reduce((sum, file) => sum + file.size, 0)
        if (disk.bavail * disk.bsize < expanded + 128 * 1024 * 1024 + 64 * 1024 * 1024) throw Error('CONTROL_DISK_SPACE_REQUIRED')
        const archive = await repo.target(next.release.artifactTarget)
        if (this.closing) throw Error('CONTROL_HOST_STOPPED')
        this.change({ phase: 'verifying' })
        temporary = join(this.options.home, 'staging', randomUUID())
        await unpack(archive, temporary, next.release, next.raw)
        await this.options.driver.probe(temporary, next.release)
        if (this.closing) throw Error('CONTROL_HOST_STOPPED')
        const reference = { id: next.release.releaseId, digest: digest(next.raw) }
        await mkdir(join(this.options.home, 'releases'), { recursive: true })
        try { await rename(temporary, this.path(reference)) }
        catch (error) { if (!['EEXIST', 'ENOTEMPTY'].includes(error.code)) throw error; await this.load(reference) }
        await syncDirectory(join(this.options.home, 'releases'))
        this.prepared = reference
        await atomic(join(this.options.home, 'transaction.json'), { phase: 'prepared', candidate: reference })
        return await this.applyPrepared()
      } catch (error) {
        const permitted = this.activated && this.active && await this.load(this.active.current).then(() => true, () => false)
        const unavailable = !this.options.baseline && !this.active && !this.closing ? 'not_installed' : 'disabled'
        this.change({ phase: !permitted || this.state.phase === 'disabled' || this.closing ? unavailable : this.prepared ? 'waiting_for_idle' : 'ready',
          ...(!permitted ? { version: undefined, releaseId: undefined } : {}), error: error.message })
        throw error
      }
      finally { if (temporary) await rm(temporary, { force: true, recursive: true }) }
    })
  }
  async apply() { return this.exclusive(async () => { await this.trusted(); return this.applyPrepared() }) }
  async applyPrepared() {
    if (!this.prepared) return this.status()
    const next = await this.load(this.prepared)
    let fallback = null
    for (const reference of [this.active?.current, this.active?.previous].filter(Boolean)) {
      if (await this.load(reference).then(() => true, () => false)) { fallback = reference; break }
    }
    if (this.closing) throw Error('CONTROL_HOST_STOPPED')
    if (!await this.options.driver.drain()) { this.change({ phase: 'waiting_for_idle' }); return this.status() }
    this.activated = false
    const old = this.active, reference = this.prepared
    try {
      if (this.closing) throw Error('CONTROL_HOST_STOPPED')
      this.assertOwned?.()
      this.change({ phase: 'activating' })
      this.active = { current: reference, previous: fallback, generation: (old?.generation ?? 0) + 1, pending: true }
      await atomic(join(this.options.home, 'transaction.json'), { phase: 'activating', old, candidate: reference })
      await atomic(join(this.options.home, 'active.json'), this.active)
      await this.options.driver.activate(next.directory, next.release)
      this.activated = true
      if (this.closing) throw Error('CONTROL_HOST_STOPPED')
      await this.confirm()
      await rm(join(this.options.home, 'transaction.json'), { force: true })
      this.prepared = null
      this.change({ phase: 'ready', version: next.release.version, releaseId: reference.id, candidateVersion: undefined, error: undefined })
    } catch (error) {
      await this.stop()
      if (this.closing) throw error
      this.prepared = null
      this.change({ phase: 'rolling_back', error: 'CONTROL_ACTIVATION_FAILED' })
      if (!fallback) {
        // A failed first activation is not an installed version. Restore the old pointer,
        // or a durable empty pointer, so retrying the same signed release is not skipped.
        this.active = old && !old.pending ? old : undefined
        const empty = { current: null, previous: null, generation: (old?.generation ?? 0) + 1, pending: false }
        await atomic(join(this.options.home, 'active.json'), this.active ?? empty)
        if (!this.active) await atomic(join(this.options.home, 'confirmed.json'), empty)
        await rm(join(this.options.home, 'transaction.json'), { force: true })
        this.change({ phase: !this.options.baseline && !this.active ? 'not_installed' : 'disabled', version: undefined, releaseId: undefined })
        throw error
      }
      try {
        const previous = await this.load(fallback)
        await this.options.driver.activate(previous.directory, previous.release)
        this.activated = true
        this.active = { current: fallback, previous: old?.previous?.id === fallback.id ? null : old?.previous ?? null, generation: this.active.generation + 1, pending: false }
        await this.confirm(); await rm(join(this.options.home, 'transaction.json'), { force: true })
        this.change({ phase: 'rolled_back', version: previous.release.version, releaseId: fallback.id, error: 'CONTROL_ACTIVATION_FAILED' })
      } catch (rollbackError) { await this.stop(); this.change({ phase: 'disabled', version: undefined, releaseId: undefined, error: 'CONTROL_ROLLBACK_UNAVAILABLE' }); throw rollbackError }
    } finally { if (!this.closing) await this.options.driver.resume() }
    return this.status()
  }
  async recover() {
    return this.exclusive(async () => {
      await this.stop()
      const previous = this.active?.previous
      if (!previous || previous.id === this.active.current.id) {
        this.change({ phase: 'disabled', version: undefined, releaseId: undefined, error: 'CONTROL_ROLLBACK_UNAVAILABLE' }); return this.status()
      }
      try {
        this.change({ phase: 'rolling_back' })
        const loaded = await this.load(previous)
        if (this.closing) throw Error('CONTROL_HOST_STOPPED')
        await this.options.driver.activate(loaded.directory, loaded.release)
        this.activated = true
        if (this.closing) throw Error('CONTROL_HOST_STOPPED')
        this.active = { current: previous, previous: null, generation: this.active.generation + 1, pending: false }
        await this.confirm()
        this.change({ phase: 'rolled_back', version: loaded.release.version, releaseId: previous.id, error: 'CONTROL_PROCESS_FAILED' })
      } catch (error) { await this.stop(); this.change({ phase: 'disabled', version: undefined, releaseId: undefined, error: 'CONTROL_ROLLBACK_UNAVAILABLE' }); throw error }
      finally { if (!this.closing) await this.options.driver.resume() }
      return this.status()
    })
  }
  async stop() { this.activated = false; await this.options.driver.stop() }
  async shutdown() { this.closing = true; await this.stop() }
}
