// Ciphertexts are durable before ACK. Unsupported formats are retried after upgrades.
import { deriveKeys, open, seal } from './crypto.js'
import { MailboxRequestError } from './mailbox-client.js'
import { createMessage, validateMessage } from './message.js'
import { UnsupportedMessage } from './compatibility.js'

const PAGE = 32
const check = (context) => context.assertBinding?.()
export function keysFor(config) { return deriveKeys(Buffer.from(config.secret, 'base64url'), config.enrollmentId) }

export async function flushOutbox(context) {
  const { store, client } = context
  const result = { sent: 0, pending: 0, dropped: [] }
  const items = await store.outgoing()
  for (let index = 0; index < items.length; index++) {
    const item = items[index]
    check(context)
    try {
      await client.send(item.messageId, item.envelope)
      check(context)
      await store.removeOutgoing(item.messageId)
      result.sent++
    } catch (error) {
      const status = error instanceof MailboxRequestError ? error.status : 0
      if (status === 400 || (status === 409 && error.code === 'conflict')) {
        await store.removeOutgoing(item.messageId)
        result.dropped.push({ messageId: item.messageId, code: error.code })
        continue
      }
      if (status === 401 || status === 426 || error.code === 'vip_personal_assistant_required') throw error
      result.pending = items.length - index
      result.blocked = error.code
      break
    }
  }
  return result
}

export async function pullInbox(context) {
  const { store, client, config, now = () => new Date() } = context
  const keys = keysFor(config), fresh = [], rejected = [], blocked = []
  const quarantine = store.blocked()
  async function consume(envelope, saved = false) {
    check(context)
    if (await store.isSeen(envelope.id)) { if (saved) await quarantine.remove(envelope.id); return }
    let message
    try {
      message = validateMessage(open(keys, 'to_assistant', config.enrollmentId, envelope.id, envelope.envelope), { from: 'kun', id: envelope.id })
    } catch (error) {
      if (error instanceof UnsupportedMessage || error.message === 'unsupported envelope') {
        await quarantine.save(envelope)
        blocked.push(envelope.id)
      } else {
        await store.reject(envelope.id, error.message, now())
        rejected.push(envelope.id)
        if (saved) await quarantine.remove(envelope.id)
      }
      return
    }
    check(context)
    if (await store.saveIncoming(message, now())) fresh.push(message)
    if (saved) await quarantine.remove(envelope.id)
  }
  for (const envelope of await quarantine.records()) await consume(envelope, true)
  for (let page = 0; page < 16; page++) {
    check(context)
    const { messages } = await client.inbox()
    check(context)
    if (!Array.isArray(messages) || messages.length === 0) break
    const handled = []
    for (const envelope of messages) { await consume(envelope); handled.push(envelope.id) }
    check(context)
    if (handled.length) await client.ack(handled)
    if (messages.length < PAGE) break
  }
  return { fresh, rejected, blocked }
}
export async function sync(context) {
  const outbox = await flushOutbox(context)
  return { ...await pullInbox(context), outbox }
}
export async function sendMessage(context) {
  const { store, client, config, now = () => new Date(), assertBinding, ...fields } = context
  check(context)
  const message = createMessage({ ...fields, from: 'assistant', now: now() })
  const envelope = seal(keysFor(config), 'to_host', config.enrollmentId, message.id, message)
  await store.queueOutgoing({ messageId: message.id, envelope, createdAt: message.createdAt, kind: message.kind, inReplyTo: message.inReplyTo, status: message.status })
  const outbox = await flushOutbox(context)
  return { message, outbox, delivered: !outbox.dropped.some((item) => item.messageId === message.id) && !(await store.outgoing()).some((item) => item.messageId === message.id) }
}
