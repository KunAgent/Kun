import { randomUUID } from 'node:crypto'
import { join } from 'node:path'
import { atomic, json } from './update/files.js'
import { createAssistantClient, MailboxRequestError } from './mailbox-client.js'
import { AGENT_VERSION } from './version.js'

const MAX_SEQUENCE = 9_007_199_254_740_991
const VALID_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
/** Serializes presence updates so a finished wait cannot be overwritten by an older heartbeat. */
export async function presenceReporter(home, config, { fetch, sleep } = {}) {
  const path = join(home, 'daemon', 'identity.json')
  let state = await json(path)
  if (!state) { state = { version: 1, instanceId: randomUUID(), sequence: 0 }; await atomic(path, state) }
  if (state.version !== 1 || !VALID_ID.test(state.instanceId) || !Number.isSafeInteger(state.sequence) || state.sequence < 0 || state.sequence >= MAX_SEQUENCE) throw new Error('invalid_daemon_identity')
  let desired = { syncState: 'reconnecting', listening: false, lastError: null }, dirty = false, stopped = false, unsupportedUntil = 0
  let running = null
  let controller = new AbortController()
  const makeClient = timeoutMs => createAssistantClient({ server: config.server, assistantId: config.assistantId, token: config.token, fetch, sleep, timeoutMs, signal: controller.signal })
  let client = makeClient(3000)
  async function flush() {
    while (dirty) {
      dirty = false
      if (Date.now() < unsupportedUntil) return
      if (state.sequence >= MAX_SEQUENCE) throw new Error('daemon_sequence_exhausted')
      state = { ...state, sequence: state.sequence + 1 }; await atomic(path, state)
      const report = { instanceId: state.instanceId, platform: `${process.platform}-${process.arch}`, agentVersion: AGENT_VERSION,
        capabilities: ['daemon', 'explicit_ack', 'polling'], reportSequence: state.sequence, ...desired }
      try {
        const result = await client.presence(report)
        if (result.ok !== true || !Number.isSafeInteger(result.lastSequence) || result.lastSequence < 1 || result.lastSequence >= MAX_SEQUENCE) throw new Error('invalid_presence_response')
        if (Number.isSafeInteger(result.lastSequence) && result.lastSequence > state.sequence && result.lastSequence < MAX_SEQUENCE) {
          state = { ...state, sequence: result.lastSequence }; await atomic(path, state)
          dirty = true
        }
      } catch (error) {
        if (error instanceof MailboxRequestError && error.status === 404) unsupportedUntil = Date.now() + 60_000
        else if (!stopped) return
      }
    }
  }
  function update(next) {
    desired = { ...desired, ...next }; dirty = true
    if (!running) running = flush().catch(() => {}).finally(() => { running = null; if (dirty && !stopped && Date.now() >= unsupportedUntil) void update({}) })
    return running
  }
  async function close(final = { syncState: 'stopped', listening: false, lastError: null }) {
    stopped = true; controller.abort()
    if (running) await running
    controller = new AbortController(); client = makeClient(1000)
    const timer = setTimeout(() => controller.abort(), 3500)
    try { await update(final) }
    finally { clearTimeout(timer); controller.abort() }
  }
  return { instanceId: state.instanceId, update, close }
}
