// The assistant's local mailbox under KUN_HOME (default ~/.kun). Messages are persisted before
// the server copy is acknowledged, so a crash never loses a task. Layout:
//   agent.json            enrollment, bearer token and secret (mode 0600)
//   login.json            a join request still waiting for approval, with its private key (0600)
//   mailboxes/<binding>/ contains the following per-connection directories:
//   messages/<id>.json    every received message with its local status (source of truth)
//   inbox/<id>.md         readable copy of each open item, for assistants that prefer files
//   archive/<id>.md       readable copy once the item is closed
//   outbox/<id>.json      sealed outgoing envelopes not yet accepted by the server
//   rejected/<id>.json    envelopes that failed authentication (never shown to the assistant)
import { mkdir, open as openFile, readFile, readdir, rename, rm, stat } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { createHash, randomBytes } from 'node:crypto'
import { randomUUID } from 'node:crypto'
import { BlockedStore } from './blocked-store.js'
import { business } from './update/coordination.js'
import { atomic, json, syncDir } from './update/files.js'
import { DeliveryStore } from './delivery-store.js'
import { withStoreLock } from './store-lock.js'

const CLOSED = new Set(['done', 'failed', 'cancelled'])
const ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
const MAILBOX_DIRS = ['messages', 'inbox', 'archive', 'outbox', 'rejected']

export function resolveHome(env = process.env) {
  return env.KUN_HOME?.trim() || join(homedir(), '.kun')
}

async function writeAtomic(path, text, mode = 0o600) {
  const temporary = `${path}.tmp-${process.pid}-${randomBytes(4).toString('hex')}`
  const handle = await openFile(temporary, 'w', mode)
  try {
    await handle.writeFile(text, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
  await rename(temporary, path)
  await syncDir(join(path, '..'))
}

async function exists(path) {
  try { await stat(path); return true } catch (error) { if (error.code === 'ENOENT') return false; throw error }
}

async function readJson(path) {
  try { return JSON.parse(await readFile(path, 'utf8')) } catch (error) { if (error.code === 'ENOENT') return null; throw error }
}

function markdown(record) {
  const { message, status, receivedAt } = record
  const lines = [`# ${message.title || (message.kind === 'task' ? 'Task from Kun' : `${message.kind} from Kun`)}`, '',
    `- id: ${message.id}`, `- kind: ${message.kind}`, `- status: ${status}`, `- received: ${receivedAt}`]
  if (message.deadline) lines.push(`- deadline: ${message.deadline}`)
  if (message.inReplyTo) lines.push(`- in reply to: ${message.inReplyTo}`)
  if (message.kind === 'task' && !CLOSED.has(status)) {
    lines.push(`- reply: kun-agent reply ${message.id.slice(0, 8)} --status done "<what you did>"`)
  }
  return lines.concat('', message.body, '').join('\n')
}

export class LocalStore {
  constructor(home) {
    this.home = home
  }

  path(...parts) {
    return join(this.home, ...parts)
  }

  async prepare() {
    for (const dir of ['', ...MAILBOX_DIRS]) {
      await mkdir(this.path(dir), { recursive: true, mode: 0o700 })
    }
  }

  /** Each binding has its own inbox, deduplication history and encrypted outbox. */
  async forConfig(config) {
    const scope = createHash('sha256').update(JSON.stringify([
      config.server, config.enrollmentId, config.assistantId
    ])).digest('hex')
    const mailbox = new LocalStore(this.path('mailboxes', scope))
    await withStoreLock(this.home, async () => {
      const current = await this.readConfig()
      if (current?.version === 1 && current.server === config.server &&
          current.enrollmentId === config.enrollmentId && current.assistantId === config.assistantId) {
        await mkdir(mailbox.home, { recursive: true, mode: 0o700 })
        // Renames are restartable. Only the still-current legacy binding may claim old files.
        for (const dir of MAILBOX_DIRS) {
          if (await exists(this.path(dir)) && !await exists(mailbox.path(dir))) {
            await rename(this.path(dir), mailbox.path(dir))
          }
        }
        await writeAtomic(this.path('agent.json'), JSON.stringify({ ...current, version: 2 }) + '\n')
      }
    })
    await mailbox.prepare()
    return mailbox
  }

  async readConfig() {
    const config = await readJson(this.path('agent.json'))
    if (config && ![1, 2, 3].includes(config.version)) throw Object.assign(new Error('unsupported_local_binding'), { code: 'unsupported_local_binding', exitCode: 6 })
    return config
  }

  async writeConfig(config) {
    return business(this.home, () => this.writeConfigUnlocked(config))
  }

  async writeConfigUnlocked(config) {
    const current = await this.readConfig()
    if (current?.version === 1) await this.forConfig(current)
    await this.prepare()
    await writeAtomic(this.path('agent.json'), JSON.stringify({ ...config, version: 3, bindingGeneration: randomUUID() }, null, 2) + '\n')
  }

  blocked() { return new BlockedStore(this.path('blocked')) }

  delivery() { return new DeliveryStore(this) }
  async historyCursor(direction = 'incoming') { const state = await json(this.path('sync.json'), {}); return state[direction === 'incoming' ? 'afterSequence' : 'sentSequence'] ?? 0 }
  async saveHistoryCursor(afterSequence, direction = 'incoming') {
    if (!Number.isSafeInteger(afterSequence) || afterSequence < 0) throw new Error('invalid_history_cursor')
    const state = await json(this.path('sync.json'), {})
    await atomic(this.path('sync.json'), { ...state, [direction === 'incoming' ? 'afterSequence' : 'sentSequence']: afterSequence })
  }

  async removeConfig() {
    return business(this.home, () => this.removeConfigUnlocked())
  }

  async removeConfigUnlocked() {
    const config = await this.readConfig()
    if (config?.version === 1) await this.forConfig(config)
    await rm(this.path('agent.json'), { force: true })
    await this.removeLogin()
  }

  async readLogin() {
    return readJson(this.path('login.json'))
  }

  async writeLogin(login) {
    await this.prepare()
    await writeAtomic(this.path('login.json'), JSON.stringify(login, null, 2) + '\n')
  }

  async removeLogin() {
    await rm(this.path('login.json'), { force: true })
  }

  async isSeen(id) {
    return ID.test(id) && (await exists(this.path('messages', `${id}.json`)) || await exists(this.path('rejected', `${id}.json`)))
  }

  async reject(id, reason, now = new Date()) {
    if (!ID.test(id)) return
    await writeAtomic(this.path('rejected', `${id}.json`), JSON.stringify({ id, reason, at: now.toISOString() }) + '\n')
  }

  async saveIncoming(message, now = new Date()) {
    return withStoreLock(this.home, async () => {
      if (await this.isSeen(message.id)) return null
      // The cancel effect precedes its dedup marker under the same writer lock.
      if (message.kind === 'cancel') await this.setStatusUnlocked(message.inReplyTo, 'cancelled', now)
      const cancelled = message.kind === 'task' && (await this.records()).some(({ message: prior }) =>
        prior.kind === 'cancel' && prior.inReplyTo === message.id)
      const record = { message, status: cancelled ? 'cancelled' : 'new', receivedAt: now.toISOString(), updatedAt: now.toISOString() }
      await writeAtomic(this.path(cancelled ? 'archive' : 'inbox', `${message.id}.md`), markdown(record))
      await writeAtomic(this.path('messages', `${message.id}.json`), JSON.stringify(record, null, 2) + '\n')
      return record
    })
  }

  async records() {
    const names = (await readdir(this.path('messages')).catch(() => [])).filter((name) => name.endsWith('.json'))
    const records = []
    for (const name of names) {
      const record = await readJson(this.path('messages', name))
      if (record?.message?.id) records.push(record)
    }
    return records.sort((a, b) => a.receivedAt.localeCompare(b.receivedAt) || a.message.id.localeCompare(b.message.id))
  }

  /** Open tasks plus any other message the assistant has not been shown yet. */
  async openRecords() {
    return (await this.records()).filter(({ message, status }) =>
      message.kind === 'task' ? !CLOSED.has(status) : status === 'new')
  }

  /** Finds a message by full id or by a unique prefix of at least 4 characters. */
  async find(idOrPrefix) {
    const wanted = String(idOrPrefix ?? '').toLowerCase()
    if (wanted.length < 4) return null
    const matches = (await this.records()).filter(({ message }) => message.id.startsWith(wanted))
    if (matches.length > 1) throw new Error(`"${idOrPrefix}" matches ${matches.length} messages; use more characters`)
    return matches[0] ?? null
  }

  async setStatus(id, status, now = new Date()) {
    return withStoreLock(this.home, () => this.setStatusUnlocked(id, status, now))
  }

  // Internal: callers hold the mailbox writer lock.
  async setStatusUnlocked(id, status, now) {
    const record = await readJson(this.path('messages', `${id}.json`))
    if (!record) return null
    // A reader may have captured a stale snapshot while another command finished the task.
    if (status === 'read' && record.status !== 'new') return record
    if (CLOSED.has(record.status)) return record
    if (status === 'received' && ['working', 'blocked'].includes(record.status)) return record
    record.status = status
    record.updatedAt = now.toISOString()
    const closed = record.message.kind === 'task' ? CLOSED.has(status) : status !== 'new'
    await writeAtomic(this.path(closed ? 'archive' : 'inbox', `${id}.md`), markdown(record))
    if (closed) await rm(this.path('inbox', `${id}.md`), { force: true })
    await writeAtomic(this.path('messages', `${id}.json`), JSON.stringify(record, null, 2) + '\n')
    return record
  }

  async queueOutgoing(item) {
    await this.prepare()
    if (!ID.test(item.messageId)) throw new Error('invalid_outbox_id')
    const path = this.path('outbox', `${item.messageId}.json`)
    const prior = await readJson(path)
    if (prior && JSON.stringify(prior) !== JSON.stringify(item)) throw new Error('outbox_id_conflict')
    if (!prior) await writeAtomic(path, JSON.stringify(item) + '\n')
  }

  async outgoing() {
    const names = (await readdir(this.path('outbox')).catch(() => [])).filter((name) => name.endsWith('.json'))
    const items = []
    for (const name of names) {
      const item = await readJson(this.path('outbox', name))
      if (item?.messageId) items.push(item)
    }
    return items.sort((a, b) => a.createdAt.localeCompare(b.createdAt))
  }

  async saveSentHistory(item) { await atomic(this.path('sent-history', `${item.id}.json`), { messageId: item.id, envelope: item.envelope, createdAt: item.createdAt }) }

  async sentHistory() {
    const names = await readdir(this.path('sent-history')).catch(error => { if (error.code === 'ENOENT') return []; throw error })
    return Promise.all(names.filter(name => ID.test(name.replace(/\.json$/, ''))).map(name => readJson(this.path('sent-history', name))))
  }

  async failedOutgoing() {
    const names = await readdir(this.path('failed-outbox')).catch(error => { if (error.code === 'ENOENT') return []; throw error })
    return Promise.all(names.filter(name => ID.test(name.replace(/\.json$/, ''))).map(name => readJson(this.path('failed-outbox', name))))
  }

  async failOutgoing(item, code) {
    await atomic(this.path('failed-outbox', `${item.messageId}.json`), { ...item, failure: code })
    await this.removeOutgoing(item.messageId)
  }

  async removeOutgoingFailure(messageId) {
    if (!ID.test(messageId)) throw new Error('invalid_outbox_id')
    await rm(this.path('failed-outbox', `${messageId}.json`), { force: true })
  }

  async removeOutgoing(messageId) {
    await rm(this.path('outbox', `${messageId}.json`), { force: true })
  }
}
