// Joining Kun from an assistant VM: file a join request with a fresh key pair, show the
// verification code, and wait for the desktop user's decision. The pending request lives in
// login.json, so `kun-agent login` without a code resumes it after an interrupted command.
import { randomBytes, randomUUID } from 'node:crypto'
import { newKeyPair, pairingSecret, sha256Hex, verificationCode } from './crypto.js'
import { MailboxRequestError, enrollmentStatus, requestEnrollment } from './mailbox-client.js'
import { AGENT_VERSION } from './version.js'

export const LOGIN_WAIT_SECONDS = 240
const POLL_MS = 3000

export class LoginEnded extends Error {}

function platform() {
  return `${process.platform}-${process.arch}`.toLowerCase().replace(/[^a-z0-9_.-]/g, '')
}

/** Reuses the pending request for the same enrollment; anything else starts a new one. */
export async function startLogin({ store, code, server, now }) {
  const pending = await store.readLogin()
  if (pending?.enrollmentId === code.enrollmentId && pending.server === server) return pending
  const keyPair = newKeyPair()
  const login = {
    version: 1, server, enrollmentId: code.enrollmentId, hostPublicKey: code.hostPublicKey,
    requestId: randomUUID(), token: randomBytes(32).toString('hex'), publicKey: keyPair.publicKey, privateKey: keyPair.privateKey,
    verificationCode: verificationCode(code.enrollmentId, code.hostPublicKey, keyPair.publicKey),
    createdAt: now.toISOString(), filed: false
  }
  await store.writeLogin(login)
  return login
}

async function status(login, io) {
  return enrollmentStatus({ server: login.server, requestId: login.requestId, token: login.token, fetch: io.fetch, sleep: io.sleep })
}

/** Sends the request once. A lost reply is recovered by asking for the request's status. */
export async function fileRequest(store, login, io) {
  if (login.filed) return login
  let filed
  // An earlier POST may have committed even when its response never arrived. Check by
  // our own credentials before POSTing again: consumed codes and full queues reject POSTs.
  try {
    filed = await status(login, io)
  } catch (error) {
    if (!(error instanceof MailboxRequestError) || error.status !== 401) throw error
  }
  if (!filed) {
    try {
      filed = await requestEnrollment({ server: login.server, fetch: io.fetch, input: {
        enrollmentId: login.enrollmentId, requestId: login.requestId, publicKey: login.publicKey,
        tokenHash: sha256Hex(login.token), platform: platform(), agentVersion: AGENT_VERSION
      } })
    } catch (error) {
      if (!(error instanceof MailboxRequestError)) throw error
      if (error.status === 404) {
        await store.removeLogin()
        throw new LoginEnded('This enrollment code is no longer valid: it expired, was already used, or was cancelled. Ask the user to create a new one in Kun.')
      }
      if (error.status !== 409 || error.code !== 'conflict') throw error
      filed = await status(login, io)
    }
  }
  const next = { ...login, filed: true, name: filed.name, kind: filed.kind, expiresAt: filed.expiresAt }
  await store.writeLogin(next)
  return next
}

/** Polls until the user decides or `seconds` pass; a vanished request counts as cancelled. */
export async function waitForDecision(login, seconds, io) {
  const deadline = Date.now() + seconds * 1000
  for (;;) {
    let current
    try {
      current = await status(login, io)
    } catch (error) {
      if (error instanceof MailboxRequestError && error.status === 401) return { state: 'cancelled' }
      throw error
    }
    if (current.state !== 'pending' || Date.now() >= deadline) return current
    await io.sleep(Math.min(POLL_MS, Math.max(0, deadline - Date.now())))
  }
}

/** Derives the mailbox secret from the approved pairing and stores the agent's credentials. */
export async function completeLogin(store, login, decision, now) {
  const secret = pairingSecret({
    enrollmentId: login.enrollmentId, privateKey: login.privateKey, publicKey: login.publicKey,
    peerPublicKey: login.hostPublicKey, hostPublicKey: login.hostPublicKey, assistantPublicKey: login.publicKey
  })
  const config = {
    version: 3, server: login.server, assistantId: login.requestId, token: login.token, enrollmentId: login.enrollmentId,
    secret: secret.toString('base64url'), name: decision.name ?? login.name, kind: decision.kind ?? login.kind, enrolledAt: now.toISOString()
  }
  await store.writeConfig(config)
  await store.removeLogin()
  return config
}
