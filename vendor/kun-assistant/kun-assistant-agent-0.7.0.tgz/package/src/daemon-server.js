import { createServer } from 'node:net'
import { rm, chmod } from 'node:fs/promises'
import { Readable } from 'node:stream'
import { randomUUID } from 'node:crypto'
import { locked } from './update/coordination.js'
import { atomic } from './update/files.js'
import { daemonPreference, newDaemonSecret, prepareDaemonDirectory, validDaemonSecret } from './daemon-ipc.js'
import { LocalStore } from './local-store.js'
import { presenceReporter } from './daemon-presence.js'
import { createAssistantClient } from './mailbox-client.js'
import { subscribeMailbox } from './realtime.js'
import { AGENT_VERSION } from './version.js'

const COMMANDS = new Set(['inbox', 'ack', 'release', 'renew', 'tasks', 'show', 'reply', 'send', 'retry', 'recover', 'status'])


/** Owns one installation's network synchronization; messages remain in the existing mailbox. */
export async function serveDaemon(home, main, { env = process.env, intervalMs = 30_000 } = {}) {
  return locked(home, 'daemon-owner', async () => {
    const paths = await prepareDaemonDirectory(home)
    if ((await daemonPreference(home)).desired === 'stopped') return 0
    const config = await new LocalStore(home).readConfig()
    if (!config) throw new Error('connect_before_starting_daemon')
    const reporter = await presenceReporter(home, config)
    const secret = newDaemonSecret(), instance = randomUUID(), stop = new AbortController()
    const requests = new Set(), sockets = new Set()
    let listeners = 0
    let lastSyncAt = null, lastError = null, shuttingDown = false, terminalError = false, wake = null, signalled = false
    const wakeSync = () => { signalled = true; wake?.() }
    const client = createAssistantClient({ server: config.server, assistantId: config.assistantId, token: config.token, signal: stop.signal })
    const subscription = subscribeMailbox({ server: config.server, assistantId: config.assistantId, direction: 'to_assistant', client,
      onChange: wakeSync, onReady: wakeSync, signal: stop.signal })
    const wait = () => new Promise(resolve => {
      if (signalled || stop.signal.aborted) return resolve()
      const timer = setTimeout(done, intervalMs)
      function done() { clearTimeout(timer); stop.signal.removeEventListener('abort', done); wake = null; resolve() }
      wake = done; stop.signal.addEventListener('abort', done, { once: true })
      if (signalled || stop.signal.aborted) done()
    })
    const invoke = async (argv, stdin = '', signal = stop.signal) => {
      let stdout = '', stderr = ''
      const append = (target, chunk) => {
        const next = target + String(chunk)
        if (Buffer.byteLength(next) > 3 * 1024 * 1024) throw new Error('daemon_output_too_large')
        return next
      }
      const code = await main(argv, { env: { ...env, KUN_HOME: home, KUN_AGENT_DAEMON_INTERNAL: '1' },
        signal, stdin: Readable.from([stdin]), stdout: { write: chunk => { stdout = append(stdout, chunk) } },
        stderr: { write: chunk => { stderr = append(stderr, chunk) } } })
      return { code, stdout, stderr }
    }
    const server = createServer(socket => {
      if (sockets.size >= 32 || shuttingDown) return socket.destroy()
      sockets.add(socket)
      let data = '', handled = false
      const controller = new AbortController()
      socket.setTimeout(70_000, () => socket.destroy())
      socket.on('error', () => {})
      socket.on('close', () => { controller.abort(); sockets.delete(socket) })
      socket.on('data', chunk => {
        if (handled) return
        data += chunk.toString('utf8')
        if (Buffer.byteLength(data) > 256 * 1024) return socket.destroy()
        const end = data.indexOf('\n')
        if (end < 0) return
        handled = true
        socket.setTimeout(940_000)
        let request
        try { request = JSON.parse(data.slice(0, end)) } catch { return socket.destroy() }
        if (!validDaemonSecret(request.secret, secret)) return socket.destroy()
        const respond = value => { if (!socket.destroyed) socket.end(JSON.stringify(value) + '\n') }
        if (request.op === 'status') return respond({ version: 1, agentVersion: AGENT_VERSION, instance, pid: process.pid, lastSyncAt, lastError })
        if (request.op === 'stop') {
          socket.end(JSON.stringify({ ok: true }) + '\n', () => { sockets.delete(socket); shutdown() })
          return
        }
        if (request.op !== 'run' || !Array.isArray(request.argv) || !COMMANDS.has(request.argv[0]) ||
            request.argv.length > 64 || request.argv.some(v => typeof v !== 'string' || v.length > 65536) ||
            typeof request.stdin !== 'string' || Buffer.byteLength(request.stdin) > 65536) return socket.destroy()
        const waitIndex = request.argv.indexOf('--wait')
        const waiting = request.argv[0] === 'inbox' && waitIndex >= 0 && Number(request.argv[waitIndex + 1]) > 0
        if (waiting) { listeners++; void reporter.update({ listening: true }) }
        const work = invoke(request.argv, request.stdin, controller.signal).then(respond, () => respond({ code: 1, stdout: '', stderr: 'Daemon request failed.\n' }))
        requests.add(work); void work.finally(() => { requests.delete(work); if (waiting) { listeners--; void reporter.update({ listening: listeners > 0 }) } })
      })
    })
    function shutdown() {
      if (shuttingDown) return
      shuttingDown = true; stop.abort()
      for (const socket of sockets) socket.destroy()
      server.close()
    }
    process.once('SIGTERM', shutdown); process.once('SIGINT', shutdown)
    try {
      if (process.platform !== 'win32') await rm(paths.socket, { force: true })
      // Publish this generation's credentials before accepting a connection. Old metadata can
      // never authenticate against the newly bound socket during a concurrent restart.
      await atomic(paths.metadata, { version: 1, instance, pid: process.pid, secret })
      await new Promise((resolve, reject) => { server.once('error', reject); server.listen(paths.socket, resolve) })
      if (process.platform !== 'win32') await chmod(paths.socket, 0o600)
      void reporter.update({ syncState: 'reconnecting' })
      while (!stop.signal.aborted) {
        signalled = false
        const current = await new LocalStore(home).readConfig()
        if (!current || current.assistantId !== config.assistantId || current.token !== config.token || current.bindingGeneration !== config.bindingGeneration) break
        const result = await invoke(['daemon-sync'])
        if (result.code === 0) { lastSyncAt = new Date().toISOString(); lastError = null; void reporter.update({ syncState: 'online', lastError: null }) }
        else { lastError = `sync_exit_${Number(result.code) || 1}`; void reporter.update({ syncState: 'reconnecting', lastError }) }
        if ([3, 6, 9].includes(result.code)) { terminalError = true; break }
        await wait()
      }
      shutdown()
      await Promise.allSettled([...requests, subscription.finished])
      await reporter.close(terminalError ? { syncState: 'error', listening: false, lastError } : undefined)
      return 0
    } finally {
      shutdown(); process.removeListener('SIGTERM', shutdown); process.removeListener('SIGINT', shutdown)
      await rm(paths.metadata, { force: true })
      if (process.platform !== 'win32') await rm(paths.socket, { force: true })
    }
  }, 0)
}
