const quote = text => "'" + text.replaceAll("'", "'\\''") + "'"
/** Installer bytes are verified before a running daemon is stopped. */
export function verifiedInstallerCommand({ origin, url, sha, kind, initial }) {
  const home = kind === 'grok_bot' ? '/workspace/.kun' : '$HOME/.kun'
  const prefix = `set -eu\numask 077\nexport KUN_HOME="\${KUN_HOME:-${home}}"\nexport KUN_SERVER=${quote(origin)}\ntmp=$(mktemp)\nrestore_daemon=0\ncleanup() { if [ "$restore_daemon" = 1 ]; then "$KUN_HOME/bin/kun-agent" daemon start >/dev/null 2>&1 || true; fi; rm -f "$tmp"; }\ntrap cleanup EXIT INT TERM\ncurl -fsS --proto '=https,http' --max-time 120 -o "$tmp" ${quote(url)}\nif command -v sha256sum >/dev/null 2>&1; then actual=$(sha256sum "$tmp" | cut -d ' ' -f 1); else actual=$(shasum -a 256 "$tmp" | cut -d ' ' -f 1); fi\n[ "$actual" = '${sha}' ] || { echo 'Kun installer verification failed' >&2; exit 1; }`
  if (initial) return `${prefix}\nsh "$tmp"`
  return `${prefix}\nrestart_daemon=1\nprior=''\nif [ -x "$KUN_HOME/bin/kun-agent" ]; then prior=$("$KUN_HOME/bin/kun-agent" daemon status --json 2>/dev/null || true); fi\ncase "$prior" in *'"desired":"stopped"'*) restart_daemon=0 ;; *'"running":true'*) restore_daemon=1; "$KUN_HOME/bin/kun-agent" daemon stop ;; esac\nsh "$tmp" --legacy-stopped\nif [ "$restart_daemon" = 1 ]; then "$KUN_HOME/bin/kun-agent" daemon start; restore_daemon=0; fi\n"$KUN_HOME/bin/kun-agent" status --json`
}
