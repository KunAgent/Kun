import { verifiedInstallerCommand } from './installer-command.js'
import { readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { repository, UPDATE_TRUST } from './metadata.js'
import { loadRelease } from './release.js'
import { normalizeServer } from '../mailbox-client.js'
export async function migrationPrompt({ home, trust = UPDATE_TRUST, server, kind = 'other', locale = 'zh', fetch, initial = false }) {
  const repo = await repository(home, { trust, fetch })
  const reference = repo.policy.releases.find((item) => item.releaseId === repo.policy.recommendedReleaseId)
  const release = await loadRelease(repo, reference)
  const path = `releases/${release.releaseId}/install.sh`
  const installer = await readFile(await repo.target(path, 128 * 1024))
  const sha = createHash('sha256').update(installer).digest('hex')
  const url = `${repo.origin}/assistant/updates/targets/releases/${release.releaseId}/${sha}.install.sh`
  const code = verifiedInstallerCommand({ origin: normalizeServer(server), url, sha, kind, initial })
  const prompt = locale === 'en' ?
    `Update the existing Kun mailbox program to ${release.agentVersion}. First pause the existing scheduled checks, stop every old kun-agent watch and MCP process; the command safely stops and resumes the daemon for this KUN_HOME, and wait for running commands to finish. If you cannot confirm this, tell the user before proceeding. Keep the original custom KUN_HOME if one was used. Run the verified migration below. Do not run forget or login; keep credentials and tasks. After success resume the original checks, run status, and report the actual installed version.\n\n\`\`\`sh\n${code}\n\`\`\`` :
    `把现有 Kun 信箱程序升级到 ${release.agentVersion}。先暂停原定时检查，停止该 KUN_HOME 下所有旧 kun-agent watch 和 MCP，指令会安全停止并恢复后台进程，等待正在执行的命令结束；无法确认时先告诉用户。原来使用自定义 KUN_HOME 时继续用原目录。执行下方已验证的迁移指令，不运行 forget 或 login，保留凭据和任务。成功后恢复原检查，运行 status，并报告实际安装版本。\n\n\`\`\`sh\n${code}\n\`\`\``
  return { version: release.agentVersion, releaseId: release.releaseId, prompt, installerCommand: code }
}
