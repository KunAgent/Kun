import { open, rename, mkdir, readFile, lstat, rm } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { randomUUID } from 'node:crypto'

export async function json(path, fallback = null) {
  try { return JSON.parse(await readFile(path, 'utf8')) } catch (error) { if (error.code === 'ENOENT') return fallback; throw error }
}
export async function syncDir(path) {
  if (process.platform === 'win32') return // Windows does not expose fsync on directories.
  const fd = await open(path, 'r')
  try { await fd.sync() } finally { await fd.close() }
}
export async function atomic(path, value, mode = 0o600) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  const temporary = `${path}.tmp-${randomUUID()}`
  const fd = await open(temporary, 'wx', mode)
  try { await fd.writeFile(typeof value === 'string' || Buffer.isBuffer(value) ? value : JSON.stringify(value) + '\n'); await fd.sync() }
  finally { await fd.close() }
  await rename(temporary, path)
  await syncDir(dirname(path))
}
export async function exists(path) {
  try { await lstat(path); return true } catch (error) { if (error.code === 'ENOENT') return false; throw error }
}
export async function privateDirectory(path) {
  await mkdir(path, { recursive: true, mode: 0o700 })
  if (!(await lstat(path)).isDirectory()) throw new Error('unsafe_install_directory')
}
export async function cleanTemporary(home, name) {
  await rm(join(home, 'updates', name), { recursive: true, force: true })
}
