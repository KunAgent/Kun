// Test double, exported as @kun/assistant-agent/testing; not used by the agent itself.
// In-memory implementation of the `/api/assistants/v1/` contract for package tests. It mirrors
// the database rules the agent relies on: join requests the desktop approves or rejects,
// digest-checked tokens, idempotent sends by message id, acknowledgement deletes, and
// per-direction queues.
import { readFile } from 'node:fs/promises'
import { createHash, randomBytes, randomUUID } from 'node:crypto'

const sha = (value) => createHash('sha256').update(value).digest('hex')
const PREFIX = '/api/assistants/v1/'

export function fakeMailbox({ origin = 'https://kun.test', reliable = false } = {}) {
  const host = { accessToken: 'user-token', deviceId: randomUUID(), deviceCredential: randomBytes(32).toString('hex') }
  const state = { enrollments: new Map(), assistants: new Map(), messages: [], events: [], down: false, requests: [] }
  const json = (status, value) => new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json' } })
  const page = (assistantIds, direction) => state.messages
    .filter((m) => assistantIds.includes(m.assistantId) && m.direction === direction).slice(0, 32)
    .map(({ id, assistantId, envelope, createdAt }) => ({ id, assistantId, envelope, createdAt }))
  const post = (assistant, direction, { messageId, envelope }) => {
    const existing = (reliable ? state.events : state.messages).find((m) => m.id === messageId)
    if (existing) {
      if (existing.assistantId === assistant.id && existing.direction === direction && existing.envelope === envelope) return json(200, { messageId, createdAt: existing.createdAt, duplicate: true })
      return json(409, { error: 'conflict' })
    }
    if (state.messages.filter((m) => m.assistantId === assistant.id && m.direction === direction).length >= 100) return json(409, { error: 'assistant_limit' })
    const createdAt = new Date().toISOString()
    const sequence = state.events.filter(e => e.assistantId === assistant.id && e.direction === direction).length + 1
    const event = { id: messageId, assistantId: assistant.id, direction, envelope, createdAt, sequence, receivedAt: null, consumedAt: null }
    state.messages.push(event); state.events.push(event)
    return json(200, { messageId, createdAt, duplicate: false })
  }
  const ack = (assistantIds, direction, { messageIds }) => {
    for (const event of state.events) if (messageIds.includes(event.id) && assistantIds.includes(event.assistantId) && event.direction === direction) event.receivedAt ??= new Date().toISOString()
    const before = state.messages.length
    state.messages = state.messages.filter((m) => !(messageIds.includes(m.id) && assistantIds.includes(m.assistantId) && m.direction === direction))
    return json(200, { acked: before - state.messages.length })
  }
  const history = (assistantId, direction, { afterSequence, limit = 32 }) => {
    const all = state.events.filter(e => e.assistantId === assistantId && e.direction === direction)
    const messages = all.filter(e => e.sequence > afterSequence).slice(0, limit).map(({ direction: _, ...event }) => event)
    const nextSequence = messages.at(-1)?.sequence ?? afterSequence
    return json(200, { messages, floorSequence: 0, latestSequence: all.length, nextSequence, hasMore: nextSequence < all.length, resetRequired: false })
  }
  const consume = (ids, direction, body) => {
    ack(ids, direction, body)
    for (const event of state.events) if (ids.includes(event.assistantId) && event.direction === direction && body.messageIds.includes(event.id)) event.consumedAt ??= new Date().toISOString()
    return json(200, { ok: true })
  }
  const delivery = (ids, direction, body) => json(200, { receipts: state.events.filter(e => ids.includes(e.assistantId) && e.direction === direction && body.messageIds.includes(e.id)).map(e => ({ messageId: e.id, sequence: e.sequence, expired: false, storedAt: e.createdAt, receivedAt: e.receivedAt, consumedAt: e.consumedAt })) })
  const findRequest = (requestId) => {
    for (const enrollment of state.enrollments.values()) {
      const request = enrollment.requests.find((r) => r.requestId === requestId)
      if (request) return { enrollment, request }
    }
    return null
  }
  const summary = (a) => ({ id: a.id, enrollmentId: a.enrollmentId, name: a.name, kind: a.kind, platform: a.platform, agentVersion: a.agentVersion,
    runtime: a.runtime ?? null, createdAt: a.createdAt, lastSeenAt: a.lastSeenAt, pendingToAssistant: state.messages.filter((m) => m.assistantId === a.id && m.direction === 'to_assistant').length,
    pendingToHost: state.messages.filter((m) => m.assistantId === a.id && m.direction === 'to_host').length })

  async function fetch(url, init = {}) {
    if (state.down) throw new TypeError('fetch failed')
    const parsed = new URL(url)
    if (parsed.origin === origin && (parsed.pathname === '/assistant/install.sh' || /^\/assistant\/versions\/\d+\.\d+\.\d+\/install\.sh$/.test(parsed.pathname))) return new Response(await readFile(new URL('../../dist/install.sh', import.meta.url)), { status: 200 })
    if (parsed.origin !== origin || !parsed.pathname.startsWith(PREFIX)) return json(404, { error: 'not_found' })
    const path = parsed.pathname.slice(PREFIX.length).split('/')
    const method = init.method ?? 'GET'
    const headers = new Headers(init.headers)
    const body = init.body ? JSON.parse(init.body) : {}
    state.requests.push(`${method} ${path.join('/')}`)
    if (path.join('/') === 'capabilities') return reliable ? json(200, { reliableMailbox: 1, consumptionReceipts: true }) : json(404, { error: 'not_found' })
    if (path[0] === 'host') {
      if (headers.get('Authorization') !== `Bearer ${host.accessToken}` || headers.get('X-Kun-Device') !== host.deviceId
        || headers.get('X-Kun-Device-Credential') !== host.deviceCredential) return json(401, { error: 'unauthorized' })
      const live = [...state.assistants.values()].filter((a) => !a.revokedAt)
      const route = `${method} ${path.slice(1).join('/')}`
      if (route === 'POST enrollments') {
        const expiresAt = new Date(Date.now() + 30 * 60_000).toISOString()
        state.enrollments.set(body.enrollmentId, { ...body, expiresAt, consumed: false, requests: [] })
        return json(200, { enrollmentId: body.enrollmentId, expiresAt })
      }
      if (route === 'GET assistants') {
        const enrollments = [...state.enrollments.values()].filter((e) => !e.consumed).map(({ enrollmentId, name, kind, expiresAt, requests }) => ({
          enrollmentId, name, kind, expiresAt,
          requests: requests.filter((r) => r.state === 'pending').map(({ requestId, publicKey, platform, agentVersion, createdAt }) => ({ requestId, publicKey, platform, agentVersion, createdAt }))
        }))
        return json(200, { assistants: live.map(summary), enrollments })
      }
      if (method === 'DELETE' && path[1] === 'enrollments') {
        const enrollment = state.enrollments.get(path[2])
        if (!enrollment || enrollment.consumed) return json(404, { error: 'not_found' })
        state.enrollments.delete(path[2])
        return json(200, { ok: true })
      }
      if (method === 'POST' && path[1] === 'enrollments' && path[3] === 'requests' && ['approve', 'reject'].includes(path[5])) {
        const enrollment = state.enrollments.get(path[2])
        const request = enrollment?.requests.find((r) => r.requestId === path[4] && r.state === 'pending')
        if (!enrollment || enrollment.consumed || !request) return json(404, { error: 'not_found' })
        if (path[5] === 'reject') { request.state = 'rejected'; return json(200, { ok: true }) }
        for (const other of enrollment.requests) if (other.state === 'pending') other.state = other === request ? 'approved' : 'rejected'
        enrollment.consumed = true
        state.assistants.set(request.requestId, { id: request.requestId, enrollmentId: enrollment.enrollmentId, name: enrollment.name, kind: enrollment.kind,
          platform: request.platform, agentVersion: request.agentVersion, tokenHash: request.tokenHash, createdAt: new Date().toISOString(), lastSeenAt: null })
        return json(200, { assistantId: request.requestId })
      }
      if (method === 'DELETE' && path[1] === 'assistants') {
        const assistant = live.find((a) => a.id === path[2])
        if (!assistant) return json(404, { error: 'not_found' })
        assistant.revokedAt = new Date().toISOString()
        state.messages = state.messages.filter((m) => m.assistantId !== assistant.id)
        return json(200, { ok: true })
      }
      if (method === 'POST' && path[1] === 'assistants' && path[3] === 'messages') {
        const assistant = live.find((a) => a.id === path[2])
        return assistant ? post(assistant, 'to_assistant', body) : json(404, { error: 'not_found' })
      }
      if (reliable && method === 'POST' && path[1] === 'assistants' && path[3] === 'history') {
        const assistant = live.find(a => a.id === path[2]); return assistant ? history(assistant.id, body.direction ?? 'to_host', body) : json(404, { error: 'not_found' })
      }
      if (reliable && route === 'POST inbox/consume') return consume(live.map(a => a.id), 'to_host', body)
      if (reliable && route === 'POST delivery') return delivery(live.map(a => a.id), 'to_assistant', body)
      if (route === 'GET inbox') return json(200, { messages: page(live.map((a) => a.id), 'to_host') })
      if (route === 'POST inbox/ack') return ack(live.map((a) => a.id), 'to_host', body)
      return json(404, { error: 'not_found' })
    }
    if (method === 'POST' && path.join('/') === 'enroll') {
      const enrollment = state.enrollments.get(body.enrollmentId)
      if (!enrollment || enrollment.consumed) return json(404, { error: 'not_found' })
      if (enrollment.requests.filter((r) => r.state === 'pending').length >= 3) return json(409, { error: 'assistant_limit' })
      if (findRequest(body.requestId)) return json(409, { error: 'conflict' })
      enrollment.requests.push({ requestId: body.requestId, publicKey: body.publicKey, tokenHash: body.tokenHash, platform: body.platform,
        agentVersion: body.agentVersion, createdAt: new Date().toISOString(), state: 'pending' })
      return json(200, { requestId: body.requestId, enrollmentId: enrollment.enrollmentId, name: enrollment.name, kind: enrollment.kind, expiresAt: enrollment.expiresAt })
    }
    if (method === 'GET' && path.join('/') === 'enroll/status') {
      const auth = /^Assistant ([0-9a-f-]{36})\.([0-9a-f]{64})$/.exec(headers.get('Authorization') ?? '')
      const found = auth && findRequest(auth[1])
      if (!found || found.request.tokenHash !== sha(auth[2])) return json(401, { error: 'unauthorized' })
      const { enrollment, request } = found
      const expired = request.state === 'pending' && Date.parse(enrollment.expiresAt) <= Date.now()
      return json(200, { requestId: request.requestId, name: enrollment.name, kind: enrollment.kind, expiresAt: enrollment.expiresAt, state: expired ? 'expired' : request.state })
    }
    const match = /^Assistant ([0-9a-f-]{36})\.([0-9a-f]{64})$/.exec(headers.get('Authorization') ?? '')
    const assistant = match && state.assistants.get(match[1])
    if (!assistant || assistant.revokedAt || assistant.tokenHash !== sha(match[2])) return json(401, { error: 'unauthorized' })
    assistant.lastSeenAt = new Date().toISOString()
    const route = `${method} ${path.join('/')}`
    if (reliable && route === 'POST history') return history(assistant.id, body.direction ?? 'to_assistant', body)
    if (reliable && route === 'POST inbox/consume') return consume([assistant.id], 'to_assistant', body)
    if (reliable && route === 'POST delivery') return delivery([assistant.id], 'to_host', body)
    if (route === 'GET inbox') return json(200, { messages: page([assistant.id], 'to_assistant') })
    if (route === 'POST messages') return post(assistant, 'to_host', body)
    if (route === 'POST inbox/ack') return ack([assistant.id], 'to_assistant', body)
    if (route === 'POST runtime') { assistant.runtime = body; return json(200, { ok: true }) }
    if (reliable && route === 'POST presence') {
      if (!assistant.presence || body.reportSequence > assistant.presence.reportSequence) assistant.presence = body
      return json(200, { ok: true, lastSequence: assistant.presence.reportSequence })
    }
    if (route === 'GET status') return json(200, { assistant: summary(assistant) })
    return json(404, { error: 'not_found' })
  }
  return { origin, fetch, state, credentials: async () => host }
}
