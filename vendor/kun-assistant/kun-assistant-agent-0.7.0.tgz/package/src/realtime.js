import { normalizeServer } from './mailbox-client.js'

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
const TOKEN = /^[0-9a-f]{64}$/
const delay = (ms, signal) => new Promise(resolve => {
  if (signal.aborted) return resolve()
  const timer = setTimeout(done, ms); timer.unref?.()
  function done() { clearTimeout(timer); signal.removeEventListener('abort', done); resolve() }
  signal.addEventListener('abort', done, { once: true })
})
/** Realtime is a hint; callers always fetch encrypted history before advancing cursors. */
export function subscribeMailbox({ server, assistantId, direction, client, onChange, onReady = () => {}, onError = () => {}, WebSocket: Socket = globalThis.WebSocket, signal }) {
  if (!UUID.test(assistantId) || !['to_host', 'to_assistant'].includes(direction)) throw new Error('invalid_subscription')
  const origin = normalizeServer(server), controller = new AbortController()
  const abort = () => controller.abort()
  if (signal?.aborted) controller.abort(); else signal?.addEventListener('abort', abort, { once: true })
  let socket
  async function connection(ticket) {
    const parsed = new URL(origin); parsed.protocol = parsed.protocol === 'https:' ? 'wss:' : 'ws:'
    parsed.pathname = `/api/assistants/v1/live/connect/${assistantId}`
    return new Promise((resolve, reject) => {
      let ready = false, done = false
      let timer = setTimeout(() => finish(new Error('notification_connect_timeout')), 10000)
      const stop = () => finish()
      function finish(error) {
        if (done) return
        done = true; clearTimeout(timer); controller.signal.removeEventListener('abort', stop)
        try { socket?.close() } catch { /* already closed */ }
        socket = undefined
        if (error) reject(error); else resolve(ready)
      }
      if (controller.signal.aborted) return finish()
      controller.signal.addEventListener('abort', stop, { once: true })
      try { socket = new Socket(parsed.toString()) } catch (error) { finish(error); return }
      socket.addEventListener('open', () => socket?.send(JSON.stringify({ ticket })))
      socket.addEventListener('message', event => {
        if (typeof event.data !== 'string' || event.data.length > 512) return finish(new Error('invalid_notification'))
        let value
        try { value = JSON.parse(event.data) } catch { return finish(new Error('invalid_notification')) }
        if (!ready && value?.kind === 'ready' && value.leaseSeconds === 60 && Object.keys(value).length === 2) {
          ready = true; clearTimeout(timer); timer = setTimeout(() => finish(), 60000); try { onReady() } catch {} ; return
        }
        if (ready && value?.kind === 'changed' && value.direction === direction && Number.isSafeInteger(value.sequence) && value.sequence > 0 && Object.keys(value).length === 3) {
          try { onChange(value.sequence) } catch {} ; return
        }
        finish(new Error('invalid_notification'))
      })
      socket.addEventListener('error', () => finish(new Error('notification_connection_failed')))
      socket.addEventListener('close', () => finish())
    })
  }
  async function run() {
    let failures = 0
    while (!controller.signal.aborted) {
      try {
        if (!Socket || !await client.liveNotifications()) { await delay(60000, controller.signal); continue }
        const result = await client.notificationTicket(assistantId)
        if (!TOKEN.test(result?.ticket ?? '') || !Number.isFinite(Date.parse(result?.expiresAt ?? ''))) throw new Error('invalid_notification_ticket')
        const ready = await connection(result.ticket)
        failures = ready ? 0 : Math.min(failures + 1, 6)
      } catch (error) {
        if (controller.signal.aborted) break
        failures = Math.min(failures + 1, 6); try { onError(error) } catch {}
      }
      const ms = failures ? Math.min(30000, 500 * 2 ** failures) * (0.8 + Math.random() * 0.4) : 250
      await delay(ms, controller.signal)
    }
    signal?.removeEventListener('abort', abort)
  }
  const finished = run()
  return { stop: () => controller.abort(), finished }
}
