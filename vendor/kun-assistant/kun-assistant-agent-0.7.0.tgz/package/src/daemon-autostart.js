import { createHash } from 'node:crypto'
import { execFile as execFileCallback } from 'node:child_process'
import { lstat, mkdir, readFile, rm } from 'node:fs/promises'
import { join, isAbsolute } from 'node:path'
import { homedir } from 'node:os'
import { promisify } from 'node:util'
import { atomic, json } from './update/files.js'

const execFile = promisify(execFileCallback)
const xml = value => value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&apos;')
const systemd = value => '"' + value.replaceAll('%', '%%').replaceAll('\\', '\\\\').replaceAll('"', '\\"') + '"'
const configPath = home => join(home, 'daemon', 'autostart.json')
const defaultRun = async (file, args, env) => { await execFile(file, args, { env, timeout: 15_000, maxBuffer: 32 * 1024 }) }
export function autostartDefinition(home, { platform = process.platform, userHome = homedir(), uid = process.getuid?.() } = {}) {
  if (!isAbsolute(home) || !isAbsolute(userHome) || /[\r\n\0]/.test(home + userHome)) throw new Error('invalid_autostart_path')
  const hash = createHash('sha256').update(home).digest('hex').slice(0, 16)
  const node = join(home, 'current', 'runtime', 'bin', 'node'), program = join(home, 'current', 'kun-agent.mjs')
  if (platform === 'linux') {
    const name = `kun-assistant-${hash}.service`, path = join(userHome, '.config', 'systemd', 'user', name)
    const content = `# Managed by kun-agent.\n[Unit]\nDescription=Kun personal assistant sync\nAfter=network-online.target\n[Service]\nType=simple\nEnvironment=${systemd('KUN_HOME=' + home)}\nExecStart=${systemd(node)} ${systemd(program)} daemon serve\nRestart=on-failure\nRestartSec=10\n[Install]\nWantedBy=default.target\n`
    return { platform, name, path, content }
  }
  if (platform === 'darwin') {
    if (!Number.isInteger(uid)) throw new Error('autostart_user_unavailable')
    const name = `com.kun.assistant.${hash}`, path = join(userHome, 'Library', 'LaunchAgents', `${name}.plist`)
    const content = `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>\n<key>Label</key><string>${xml(name)}</string>\n<key>ProgramArguments</key><array><string>${xml(node)}</string><string>${xml(program)}</string><string>daemon</string><string>serve</string></array>\n<key>EnvironmentVariables</key><dict><key>KUN_HOME</key><string>${xml(home)}</string></dict>\n<key>RunAtLoad</key><true/>\n<key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>\n</dict></plist>\n`
    return { platform, name, path, content, uid }
  }
  throw new Error('autostart_unsupported_platform')
}
export async function autostartPreference(home) {
  const value = await json(configPath(home), { version: 1, enabled: false })
  if (value?.version !== 1 || typeof value.enabled !== 'boolean') throw new Error('unsupported_autostart_preference')
  return value
}
async function verifyFile(definition) {
  const stat = await lstat(definition.path)
  if (!stat.isFile() || stat.isSymbolicLink() || await readFile(definition.path, 'utf8') !== definition.content) throw new Error('autostart_configuration_changed')
}
export async function installAutostart(home, env = process.env, options = {}) {
  const definition = autostartDefinition(home, { userHome: env.HOME || homedir(), ...options })
  const run = options.run ?? defaultRun
  let existed = false
  try { await verifyFile(definition); existed = true } catch (error) { if (error.code !== 'ENOENT') throw error }
  await mkdir(join(definition.path, '..'), { recursive: true, mode: 0o700 })
  if (!existed) await atomic(definition.path, definition.content)
  let registered = false
  try {
    if (definition.platform === 'linux') {
      await run('systemctl', ['--user', 'daemon-reload'], env)
      await run('systemctl', ['--user', 'enable', definition.name], env)
    } else await run('/bin/launchctl', ['bootstrap', `gui/${definition.uid}`, definition.path], env)
    registered = true
    await atomic(configPath(home), { version: 1, enabled: true })
    return definition
  } catch {
    if (registered) {
      if (definition.platform === 'linux') await run('systemctl', ['--user', 'disable', '--now', definition.name], env).catch(() => {})
      else await run('/bin/launchctl', ['bootout', `gui/${definition.uid}/${definition.name}`], env).catch(() => {})
    }
    if (!existed) await rm(definition.path, { force: true })
    throw new Error('autostart_manager_unavailable')
  }
}
export async function removeAutostart(home, env = process.env, options = {}) {
  const preference = await autostartPreference(home)
  if (!preference.enabled) return
  const definition = autostartDefinition(home, { userHome: env.HOME || homedir(), ...options })
  const run = options.run ?? defaultRun
  await verifyFile(definition)
  try {
    if (definition.platform === 'linux') {
      await run('systemctl', ['--user', 'disable', '--now', definition.name], env)
      await atomic(configPath(home), { version: 1, enabled: false })
      await rm(definition.path); await run('systemctl', ['--user', 'daemon-reload'], env)
    } else {
      await run('/bin/launchctl', ['bootout', `gui/${definition.uid}/${definition.name}`], env)
      await atomic(configPath(home), { version: 1, enabled: false })
      await rm(definition.path)
    }
  } catch { throw new Error('autostart_manager_unavailable') }
}
export async function startManagedAutostart(home, env = process.env, options = {}) {
  if (!(await autostartPreference(home)).enabled) return false
  const definition = autostartDefinition(home, { userHome: env.HOME || homedir(), ...options }), run = options.run ?? defaultRun
  await verifyFile(definition)
  try {
    if (definition.platform === 'linux') await run('systemctl', ['--user', 'start', definition.name], env)
    else await run('/bin/launchctl', ['kickstart', `gui/${definition.uid}/${definition.name}`], env)
  } catch { throw new Error('autostart_manager_unavailable') }
  return true
}
