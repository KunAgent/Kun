#!/bin/sh
# Verified bootstrap. Existing 0.4 installations require --legacy-stopped after stopping checks.
set -eu
umask 077
KUN_AGENT_VERSION='@@VERSION@@'
KUN_AGENT_SHA256='@@SHA256@@'
KUN_NODE_VERSION='@@NODE_VERSION@@'
KUN_HOME="${KUN_HOME:-$HOME/.kun}"
KUN_SERVER="${KUN_SERVER:-@@DEFAULT_SERVER@@}"
fail() { printf 'kun-agent install: %s\n' "$*" >&2; exit 1; }
case "$KUN_HOME" in /*) ;; *) fail 'KUN_HOME must be absolute' ;; esac
case "$KUN_SERVER" in https://*|http://127.0.0.1:*|http://localhost:*) ;; *) fail 'KUN_SERVER must be an https origin' ;; esac
KUN_SERVER=${KUN_SERVER%/}
download() {
  if command -v curl >/dev/null 2>&1; then curl -fsSL --proto '=https,http' --proto-redir '=https' --max-time 120 --connect-timeout 20 -o "$2" "$1"
  elif command -v wget >/dev/null 2>&1; then wget -q --max-redirect=0 -T 120 -O "$2" "$1"
  else fail 'curl or wget required'; fi
}
sha256_of() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | cut -d ' ' -f 1
  elif command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | cut -d ' ' -f 1
  elif command -v openssl >/dev/null 2>&1; then openssl dgst -sha256 "$1" | sed 's/^.*= //'
  else fail 'SHA-256 tool required'; fi
}
work=$(mktemp -d "${TMPDIR:-/tmp}/kun-agent.XXXXXX")
trap 'rm -rf "$work"' EXIT INT TERM
download "@@PROGRAM_SOURCE@@/@@PROGRAM_PATH@@" "$work/kun-agent.mjs"
[ "$(sha256_of "$work/kun-agent.mjs")" = "$KUN_AGENT_SHA256" ] || fail 'kun-agent failed verification; nothing was installed'
node_usable() { "$1" -e 'const [a,b,c]=process.versions.node.split(".").map(Number);process.exit((a===22&&(b>22||(b===22&&c>=2)))||(a===24&&b>=15)?0:1)' >/dev/null 2>&1; }
node_bin=''
if command -v node >/dev/null 2>&1 && node_usable "$(command -v node)"; then node_bin=$(command -v node)
elif [ -x "$KUN_HOME/current/runtime/bin/node" ] && node_usable "$KUN_HOME/current/runtime/bin/node"; then node_bin="$KUN_HOME/current/runtime/bin/node"
elif [ -x "$KUN_HOME/runtime/bin/node" ] && node_usable "$KUN_HOME/runtime/bin/node"; then node_bin="$KUN_HOME/runtime/bin/node"
else
  case "$(uname -s)" in Linux) os=linux ;; Darwin) os=darwin ;; *) fail 'unsupported OS' ;; esac
  case "$(uname -m)" in x86_64|amd64) arch=x64 ;; arm64|aarch64) arch=arm64 ;; *) fail 'unsupported CPU' ;; esac
  expected=''
  case "$os-$arch" in
@@NODE_CHECKSUMS@@
  esac
  [ -n "$expected" ] || fail 'no approved Node runtime in this bootstrap; install a supported Node LTS and retry'
  name="node-v$KUN_NODE_VERSION-$os-$arch"
  download "https://nodejs.org/dist/v$KUN_NODE_VERSION/$name.tar.gz" "$work/node.tar.gz"
  [ "$(sha256_of "$work/node.tar.gz")" = "$expected" ] || fail 'Node runtime failed verification'
  mkdir "$work/node"
  # Only the executable is needed; no archive-controlled links or scripts are installed.
  tar -xzf "$work/node.tar.gz" -C "$work/node" "$name/bin/node"
  node_bin="$work/node/$name/bin/node"
  node_usable "$node_bin" || fail 'Node runtime cannot start'
fi
export KUN_HOME KUN_SERVER
KUN_BOOTSTRAP_PROGRAM="$work/kun-agent.mjs"
export KUN_BOOTSTRAP_PROGRAM
# Pass the selected executable explicitly; bootstrap copies it into its complete release slot.
"$node_bin" "$work/kun-agent.mjs" bootstrap "$@"
wrapper="$KUN_HOME/bin/kun-agent"
"$wrapper" version
if [ -d "$HOME/.local/bin" ] || mkdir -p "$HOME/.local/bin" 2>/dev/null; then
  if [ ! -e "$HOME/.local/bin/kun-agent" ] || [ -L "$HOME/.local/bin/kun-agent" ]; then ln -sf "$wrapper" "$HOME/.local/bin/kun-agent"; fi
fi
printf 'Installed kun-agent %s at %s\n' "$KUN_AGENT_VERSION" "$wrapper"
printf 'Existing connections and queued messages are preserved.\n'
printf 'After approval, background sync starts automatically. System autostart is off by default; use kun-agent daemon autostart enable to opt in.\n'
