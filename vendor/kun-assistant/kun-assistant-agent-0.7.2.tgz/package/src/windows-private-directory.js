import { execFile } from 'node:child_process'
import { join, resolve } from 'node:path'
import { promisify } from 'node:util'

const run = promisify(execFile)
const script = String.raw`
$ErrorActionPreference = 'Stop'
$homePath = $env:KUN_AGENT_PRIVATE_HOME
$directory = Join-Path $homePath $env:KUN_AGENT_PRIVATE_FOLDER
$sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
if ($null -eq $sid -or -not [System.IO.Directory]::Exists($homePath)) { throw 'unsafe daemon home' }
function TrustedOwner($owner) {
  if ($owner.Equals($sid)) { return $true }
  return $owner.Value -eq 'S-1-5-32-544' -and @([Security.Principal.WindowsIdentity]::GetCurrent().Groups | Where-Object { $_.Value -eq 'S-1-5-32-544' }).Count -gt 0
}
function CheckParent([string]$path, [bool]$parent) {
  $item = Get-Item -LiteralPath $path -Force
  if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'unsafe daemon parent' }
  $acl = [IO.Directory]::GetAccessControl($path)
  $trusted = @($sid.Value, 'S-1-5-18', 'S-1-5-32-544')
  foreach ($rule in $acl.GetAccessRules($true,$true,[System.Security.Principal.SecurityIdentifier])) {
    if ($rule.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Allow -or $trusted -contains $rule.IdentityReference.Value) { continue }
    $rights = [int64]$rule.FileSystemRights
    $mask = if ($parent) { [int64][System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles } else { [int64]([System.Security.AccessControl.FileSystemRights]::Write -bor [System.Security.AccessControl.FileSystemRights]::Delete -bor [System.Security.AccessControl.FileSystemRights]::ChangePermissions -bor [System.Security.AccessControl.FileSystemRights]::TakeOwnership) }
    if (($rights -band $mask) -ne 0) { throw 'shared daemon home' }
  }
}
CheckParent $homePath $false
$parent = [IO.Directory]::GetParent($homePath)
if ($null -eq $parent) { throw 'unsafe daemon home' }
CheckParent $parent.FullName $true
$dirAcl = New-Object System.Security.AccessControl.DirectorySecurity
$dirAcl.SetOwner($sid); $dirAcl.SetAccessRuleProtection($true,$false)
$inherit = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule($sid,'FullControl',$inherit,'None','Allow')
$dirAcl.AddAccessRule($rule)
if (-not [IO.Directory]::Exists($directory)) { [void][IO.Directory]::CreateDirectory($directory,$dirAcl) }
$item = Get-Item -LiteralPath $directory -Force
if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'unsafe daemon directory' }
$existing = [IO.Directory]::GetAccessControl($directory)
if (-not (TrustedOwner ($existing.GetOwner([System.Security.Principal.SecurityIdentifier])))) { throw 'unsafe daemon owner' }
[IO.Directory]::SetAccessControl($directory,$dirAcl)
foreach ($name in $env:KUN_AGENT_PRIVATE_FILES.Split(',')) {
  $path = Join-Path $directory $name
  if ([IO.File]::Exists($path)) {
    $item = Get-Item -LiteralPath $path -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'unsafe daemon file' }
    $old = [IO.File]::GetAccessControl($path)
    if (-not (TrustedOwner ($old.GetOwner([System.Security.Principal.SecurityIdentifier])))) { throw 'unsafe daemon file owner' }
    $acl = New-Object System.Security.AccessControl.FileSecurity
    $acl.SetOwner($sid); $acl.SetAccessRuleProtection($true,$false)
    $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($sid,'FullControl','Allow')))
    [IO.File]::SetAccessControl($path,$acl)
  }
}
$checked = [IO.Directory]::GetAccessControl($directory)
$allow = @($checked.GetAccessRules($true,$true,[System.Security.Principal.SecurityIdentifier]) | Where-Object { $_.AccessControlType -eq 'Allow' })
if (-not $checked.AreAccessRulesProtected -or $allow.Count -ne 1 -or $allow[0].IdentityReference.Value -ne $sid.Value) { throw 'unsafe daemon ACL' }
`

export async function secureWindowsDirectory(home, kind = 'daemon') {
  if (!['daemon', 'desktop'].includes(kind)) throw new Error('invalid_windows_private_directory')
  const systemRoot = process.env.SystemRoot
  if (!systemRoot) throw new Error('windows_system_directory_unavailable')
  const executable = join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
  try {
    await run(executable, ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], {
      windowsHide: true, timeout: 15000, maxBuffer: 16 * 1024, env: { ...process.env, KUN_AGENT_PRIVATE_HOME: resolve(home),
        KUN_AGENT_PRIVATE_FOLDER: kind === 'daemon' ? 'daemon' : 'assistant-mailbox',
        KUN_AGENT_PRIVATE_FILES: kind === 'daemon' ? 'instance.json,preference.json' : 'tools.secret' }
    })
  } catch (error) {
    if (process.env.KUN_WINDOWS_SECURITY_DEBUG === '1' && typeof error.stderr === 'string') process.stderr.write(error.stderr.slice(0, 4096))
    throw new Error('unsafe_windows_daemon_permissions')
  }
}
export const secureWindowsDaemonDirectory = home => secureWindowsDirectory(home, 'daemon')
