import { subscribeMailbox } from './realtime.js'
import { MANUAL_RELEASE, manualMigrationPrompt } from './update/manual-migration.js'
import { receiveHost } from './host-receive.js'
// Desktop side of the assistant mailbox. Kun's desktop creates enrollments, approves the join
// requests the user recognises, assigns tasks and collects replies. Secrets stay on the desktop:
// `secrets` is the desktop's own durable store. It holds the enrollment's private key under
// `pairing:<enrollmentId>` until approval, then the mailbox secret under `<enrollmentId>`.
import { deriveKeys, open, pairingSecret, seal, verificationCode } from './crypto.js'
import { formatEnrollmentCode, newEnrollment } from './enrollment-code.js'
import { createHostClient, normalizeServer } from './mailbox-client.js'
import { createMessage, validateMessage } from './message.js'
import { ASSISTANT_KINDS, installPrompt, validAssistantKind, wakeMessage } from './prompts.js'
import { join } from 'node:path'
import { homedir } from 'node:os'
import { createHash } from 'node:crypto'
import { UPDATE_TRUST } from './update/metadata.js'
import { migrationPrompt } from './update/migration-prompt.js'
import { UnsupportedMessage } from './compatibility.js'
import { DEFAULT_SERVER } from './version.js'

export { ASSISTANT_KINDS, installPrompt, validAssistantKind, wakeMessage }
export { MailboxRequestError } from './mailbox-client.js'
export { verificationCode } from './crypto.js'
export { AGENT_VERSION, PROTOCOL_VERSION, DEFAULT_SERVER } from './version.js'
export { WindowsPrivatePipe } from './windows-private-pipe.js'
export { secureWindowsDirectory } from './windows-private-directory.js'

function secretBuffer(value) {
  if (Buffer.isBuffer(value)) return value
  if (typeof value === 'string') return Buffer.from(value, 'base64url')
  return null
}

export class AssistantHost {
  /**
   * @param {object} options
   * @param {() => Promise<{accessToken: string, deviceId: string, deviceCredential: string}>} options.credentials
   * @param {{ get(enrollmentId: string): Promise<string|undefined>|string|undefined, set(enrollmentId: string, secret: string): Promise<void>|void }} options.secrets
   */
  constructor({ server = DEFAULT_SERVER, credentials, secrets, blocked, historyState, restoreOutgoing, updateCache, trust = UPDATE_TRUST, fetch, now = () => new Date() }) {
    if (typeof credentials !== 'function' || !secrets) throw new TypeError('credentials and secrets are required')
    this.server = normalizeServer(server)
    this.credentials = credentials
    this.trust = trust
    this.fetch = fetch
    this.updateCache = updateCache ?? join(homedir(), '.kun-desktop-updates', createHash('sha256').update(server).digest('hex'))
    this.client = createHostClient({ server, credentials, fetch })
    this.secrets = secrets
    this.blocked = blocked
    this.historyState = historyState
    this.restoreOutgoing = restoreOutgoing
    this.now = now
  }

  subscribe(assistantId, onChange, options = {}) {
    const controller = new AbortController()
    const client = createHostClient({ server: this.server, credentials: this.credentials, fetch: this.fetch, signal: controller.signal })
    const subscription = subscribeMailbox({ ...options, server: this.server, assistantId, direction: 'to_host', client, onChange, signal: controller.signal })
    return { stop: () => { controller.abort(); subscription.stop() }, finished: subscription.finished }
  }

  updatePrompt(options) {
    const trust = options.trust ?? this.trust
    return trust ? migrationPrompt({ ...options, trust, server: this.server, fetch: this.fetch })
      : manualMigrationPrompt({ ...options, server: this.server, fetch: this.fetch })
  }

  async enrollmentPrompt(options) {
    const installer = this.trust ? await migrationPrompt({ home: this.updateCache, trust: this.trust, server: this.server, fetch: this.fetch, kind: options.kind, initial: true }) : MANUAL_RELEASE ? await manualMigrationPrompt({ ...options, server: this.server, fetch: this.fetch, initial: true }) : null
    return installPrompt({ ...options, installerCommand: installer?.installerCommand })
  }

  async keys(enrollmentId) {
    const secret = secretBuffer(await this.secrets.get(enrollmentId))
    return secret?.length === 32 ? deriveKeys(secret, enrollmentId) : null
  }

  async pairingKey(enrollmentId) {
    try {
      const value = JSON.parse((await this.secrets.get(`pairing:${enrollmentId}`)) ?? 'null')
      return value?.privateKey && value?.publicKey ? value : null
    } catch {
      return null
    }
  }

  /** Creates an enrollment and the prompt to paste into the assistant. The prompt holds no secret. */
  async createEnrollment({ name, kind = 'other', locale = 'zh' }) {
    if (!validAssistantKind(kind)) throw new TypeError(`invalid assistant kind ${kind}`)
    const { enrollmentId, keyPair, code } = newEnrollment()
    await this.secrets.set(`pairing:${enrollmentId}`, JSON.stringify(keyPair))
    const created = await this.client.enroll({ enrollmentId, hostPublicKey: keyPair.publicKey, name, kind })
    return { enrollmentId, code, expiresAt: created.expiresAt, prompt: await this.enrollmentPrompt({ code, kind, server: this.server, locale }) }
  }

  /**
   * Rebuilds the code and prompt of an enrollment this desktop created (the code holds only the
   * public key, so it can be shown again until the enrollment completes). Null without the key.
   */
  async promptFor({ enrollmentId, kind = 'other', locale = 'zh' }) {
    const key = await this.pairingKey(enrollmentId)
    if (!key) return null
    const code = formatEnrollmentCode(enrollmentId, key.publicKey)
    return { code, prompt: await this.enrollmentPrompt({ code, kind, server: this.server, locale }) }
  }

  /**
   * `{ assistants, enrollments }` for this desktop. Each waiting join request carries the
   * verification code this desktop computes (null when another computer holds the enrollment key).
   */
  async list() {
    const listed = await this.client.list()
    for (const enrollment of listed.enrollments) {
      const key = await this.pairingKey(enrollment.enrollmentId)
      for (const request of enrollment.requests ?? []) {
        request.verificationCode = key ? verificationCode(enrollment.enrollmentId, key.publicKey, request.publicKey) : null
      }
    }
    return listed
  }

  /**
   * Admits one waiting request. The mailbox secret is computed and stored before the server learns
   * of the approval, so the first message from the new assistant can always be opened.
   */
  async approve(enrollmentId, requestId, expectedVerificationCode) {
    const enrollment = (await this.client.list()).enrollments.find((item) => item.enrollmentId === enrollmentId)
    const request = enrollment?.requests?.find((item) => item.requestId === requestId)
    if (!request) throw new Error('This join request is no longer waiting.')
    const key = await this.pairingKey(enrollmentId)
    if (!key) throw new Error('This computer does not hold the key for this enrollment.')
    if (!expectedVerificationCode || verificationCode(enrollmentId, key.publicKey, request.publicKey) !== expectedVerificationCode) {
      throw new Error('The verification code changed. Check the request again before approving.')
    }
    const secret = pairingSecret({
      enrollmentId, privateKey: key.privateKey, publicKey: key.publicKey, peerPublicKey: request.publicKey,
      hostPublicKey: key.publicKey, assistantPublicKey: request.publicKey
    })
    await this.secrets.set(enrollmentId, secret.toString('base64url'))
    return this.client.approve(enrollmentId, requestId)
  }

  reject(enrollmentId, requestId) {
    return this.client.reject(enrollmentId, requestId)
  }

  cancelEnrollment(enrollmentId) {
    return this.client.cancel(enrollmentId)
  }

  revoke(assistantId) {
    return this.client.revoke(assistantId)
  }

  /** Prepare a sealed message for durable storage; performs no network send. */
  async prepareMessage(assistant, fields) {
    const keys = await this.keys(assistant.enrollmentId)
    if (!keys) throw new Error(`no key stored for assistant ${assistant.id}`)
    const message = createMessage({ ...fields, from: 'kun', now: this.now() })
    return { assistantId: assistant.id, enrollmentId: assistant.enrollmentId, message,
      envelope: seal(keys, 'to_assistant', assistant.enrollmentId, message.id, message) }
  }

  /** Retry a durably stored envelope without generating a new id or nonce. */
  async deliverPrepared(prepared) {
    await this.client.send(prepared.assistantId, prepared.message.id, prepared.envelope)
    return prepared.message
  }

  async send(assistant, fields) {
    return this.deliverPrepared(await this.prepareMessage(assistant, fields))
  }

  assign(assistant, { title, body, deadline }) {
    return this.send(assistant, { kind: 'task', title, body, deadline })
  }

  cancel(assistant, taskId, body = '') {
    return this.send(assistant, { kind: 'cancel', inReplyTo: taskId, body })
  }

  /**
   * Collects replies and notes. `handler({ assistant, message })` must persist the message before
   * it resolves; the server copy is acknowledged afterwards. Envelopes that cannot be opened (an
   * unknown key or tampering) are reported once as `{ assistant, messageId, error }` and dropped.
   */
  receive(handler) { return receiveHost(this, handler) }

  async delivery(messageIds) {
    if (!messageIds.length || !await this.client.reliable()) return { receipts: [] }
    return this.client.delivery(messageIds)
  }

  async recoverHistory(assistantId) {
    if (!this.historyState || !await this.client.reliable()) throw new Error('history_not_supported')
    let inbound = 0
    for (const direction of ['to_host', 'to_assistant']) {
      let floor = 0
      try { await this.client.history(assistantId, 0, direction) } catch (error) {
        if (error.code !== 'assistant_history_expired') throw error
        floor = error.floorSequence
      }
      await this.historyState.set(direction === 'to_host' ? assistantId : assistantId + ':sent', floor)
      if (direction === 'to_host') inbound = floor
    }
    return { floorSequence: inbound }
  }
}

export { BlockedStore } from './blocked-store.js'
