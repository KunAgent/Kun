import { spawn } from 'node:child_process'
import { EventEmitter } from 'node:events'
import { join } from 'node:path'

// Windows named pipes use a permissive default DACL. This helper creates the server with an
// explicit protected DACL for the current SID, and proxies framed traffic over private stdio.
const script = String.raw`
$ErrorActionPreference = 'Stop'
$code = @'
using System;
using System.Collections.Concurrent;
using System.IO;
using System.IO.Pipes;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
public static class KunPrivatePipe {
  static readonly ConcurrentDictionary<string, TaskCompletionSource<string>> pending = new ConcurrentDictionary<string, TaskCompletionSource<string>>();
  static readonly ConcurrentDictionary<string, NamedPipeServerStream> clients = new ConcurrentDictionary<string, NamedPipeServerStream>();
  static readonly object output = new object();
  static volatile bool stopping;
  static NamedPipeServerStream accepting;
  static void Send(string line) { lock (output) { Console.Out.WriteLine(line); Console.Out.Flush(); } }
  static PipeSecurity Security() {
    var sid = WindowsIdentity.GetCurrent().User;
    if (sid == null) throw new InvalidOperationException("missing user SID");
    var acl = new PipeSecurity(); acl.SetOwner(sid); acl.SetAccessRuleProtection(true, false);
    acl.AddAccessRule(new PipeAccessRule(sid, PipeAccessRights.FullControl, AccessControlType.Allow));
    return acl;
  }
  static NamedPipeServerStream NewServer(string name) {
    return new NamedPipeServerStream(name, PipeDirection.InOut, 32, PipeTransmissionMode.Byte,
      PipeOptions.Asynchronous, 4096, 4096, Security());
  }
  static async Task Serve(NamedPipeServerStream pipe) {
    var id = Guid.NewGuid().ToString("N"); clients[id] = pipe;
    var reply = new TaskCompletionSource<string>(); pending[id] = reply;
    var readTimeout = new CancellationTokenSource(70000);
    try {
      var bytes = new MemoryStream(); var chunk = new byte[4096];
      bool http = Environment.GetEnvironmentVariable("KUN_AGENT_PRIVATE_PIPE_MODE") == "http";
      int boundary = -1;
      while (true) {
        int previous = (int)bytes.Length;
        int n = await pipe.ReadAsync(chunk, 0, chunk.Length, readTimeout.Token); if (n == 0) return;
        bytes.Write(chunk, 0, n);
        var buffer = bytes.GetBuffer(); int count = (int)bytes.Length;
        for (int i = Math.Max(0, previous - 3); i < count; i++) {
          if (!http && buffer[i] == 10) { if (i != count - 1) return; boundary = i; break; }
          if (http && i + 3 < count && buffer[i] == 13 && buffer[i+1] == 10 && buffer[i+2] == 13 && buffer[i+3] == 10) { boundary = i + 4; break; }
        }
        if (boundary >= 0) break;
        if (bytes.Length >= (http ? 8192 : 256 * 1024)) return;
      }
      if (http) {
        if (boundary > 8192) return;
        var lines = Encoding.ASCII.GetString(bytes.GetBuffer(), 0, boundary).Split(new string[] { "\r\n" }, StringSplitOptions.None);
        var lengths = lines.Where(x => x.StartsWith("Content-Length:", StringComparison.OrdinalIgnoreCase)).ToArray();
        if (lengths.Length != 1 || lines.Any(x => x.StartsWith("Transfer-Encoding:", StringComparison.OrdinalIgnoreCase))) return;
        int length; if (!Int32.TryParse(lengths[0].Substring(15).Trim(), out length) || length < 0 || length > 65536) return;
        if (bytes.Length > boundary + length) return;
        while (bytes.Length < boundary + length) {
          int n = await pipe.ReadAsync(chunk, 0, Math.Min(chunk.Length, boundary + length - (int)bytes.Length), readTimeout.Token);
          if (n == 0) return; bytes.Write(chunk, 0, n);
        }
      } else { if (boundary >= 256 * 1024) return; bytes.SetLength(boundary); }
      Send("REQ " + id + " " + Convert.ToBase64String(bytes.ToArray()));
      var extra = pipe.ReadAsync(new byte[1], 0, 1);
      var completed = await Task.WhenAny(reply.Task, extra, Task.Delay(940000));
      if (completed != reply.Task) return;
      var response = await reply.Task;
      if (response == null) return;
      var result = Convert.FromBase64String(response);
      await pipe.WriteAsync(result, 0, result.Length); await pipe.FlushAsync();
      Send("DONE " + id);
    } catch (Exception) { }
    finally {
      readTimeout.Dispose();
      TaskCompletionSource<string> ignored; NamedPipeServerStream removed;
      pending.TryRemove(id, out ignored); clients.TryRemove(id, out removed);
      pipe.Dispose(); Send("CLOSE " + id);
    }
  }
  static void Accept(string name) {
    try {
      while (!stopping) {
        var pipe = NewServer(name); accepting = pipe;
        Send("READY"); pipe.WaitForConnection(); accepting = null;
        if (stopping) { pipe.Dispose(); break; }
        Task.Run(() => Serve(pipe));
      }
    } catch (Exception) { if (!stopping) Send("ERROR"); }
  }
  public static void Run() {
    string name = Environment.GetEnvironmentVariable("KUN_AGENT_PRIVATE_PIPE");
    if (String.IsNullOrEmpty(name)) throw new InvalidOperationException("missing pipe name");
    var listener = new Thread(() => Accept(name)); listener.IsBackground = true; listener.Start();
    string line;
    while ((line = Console.In.ReadLine()) != null) {
      var parts = line.Split(new char[] {' '}, 3);
      if (parts[0] == "QUIT") break;
      if (parts.Length < 2) continue;
      TaskCompletionSource<string> target;
      if (pending.TryGetValue(parts[1], out target)) {
        if (parts[0] == "SEND" && parts.Length == 3) target.TrySetResult(parts[2]);
        else if (parts[0] == "CLOSE") target.TrySetResult(null);
      }
    }
    stopping = true; if (accepting != null) accepting.Dispose();
    foreach (var pipe in clients.Values) pipe.Dispose();
  }
}
'@
Add-Type -TypeDefinition $code
[KunPrivatePipe]::Run()
`

class PipeSocket extends EventEmitter {
  destroyed = false
  timer = null
  constructor(server, id) { super(); this.server = server; this.id = id }
  setTimeout(ms, fn) {
    if (fn) this.on('timeout', fn)
    clearTimeout(this.timer)
    if (ms) this.timer = setTimeout(() => this.emit('timeout'), ms)
    return this
  }
  end(data, callback) { if (this.destroyed) return; this.callback = callback; this.server.send(`SEND ${this.id} ${Buffer.from(data).toString('base64')}`) }
  destroy() { if (!this.destroyed) { this.server.send(`CLOSE ${this.id}`); this.closed() } }
  closed() { if (this.destroyed) return; this.destroyed = true; clearTimeout(this.timer); this.emit('close'); this.server.sockets.delete(this.id) }
}

export class WindowsPrivatePipe extends EventEmitter {
  sockets = new Map()
  child = null
  buffer = ''
  ready = false
  failed = false
  constructor(onConnection, mode = 'lines') { super(); this.onConnection = onConnection; this.mode = mode }
  send(line) { if (this.child && !this.child.stdin.destroyed) this.child.stdin.write(line + '\n') }
  fail(error) { if (this.failed || this.closing) return; this.failed = true; this.close(); this.emit('error', error) }
  listen(path, callback) {
    const prefix = String.raw`\\.\pipe\x`.slice(0, -1)
    if (!path.startsWith(prefix) || !/^(?:kun-agent-[a-f0-9]{32}|kun-assistant-mailbox-[a-f0-9]{16})$/.test(path.slice(prefix.length)) || !['lines', 'http'].includes(this.mode)) throw new Error('invalid_private_pipe_name')
    const systemRoot = process.env.SystemRoot
    if (!systemRoot) throw new Error('windows_system_directory_unavailable')
    const executable = join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
    const encoded = Buffer.from(script, 'utf16le').toString('base64')
    this.child = spawn(executable, ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded], {
      windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'], env: { ...process.env, KUN_AGENT_PRIVATE_PIPE: path.slice(prefix.length), KUN_AGENT_PRIVATE_PIPE_MODE: this.mode }
    })
    this.child.stderr.resume()
    this.child.stdin.on('error', error => this.fail(error))
    this.child.on('error', error => this.fail(error))
    this.child.on('exit', () => { for (const socket of this.sockets.values()) socket.closed(); this.fail(new Error('private_pipe_unavailable')) })
    this.child.stdout.on('data', chunk => {
      this.buffer += chunk.toString('utf8')
      if (this.buffer.length > 512 * 1024) { this.fail(new Error('private_pipe_frame_too_large')); return }
      let index
      while ((index = this.buffer.indexOf('\n')) >= 0) {
        const line = this.buffer.slice(0, index).trimEnd(); this.buffer = this.buffer.slice(index + 1)
        if (line === 'READY') { if (!this.ready) { this.ready = true; callback() }; continue }
        if (line === 'ERROR') { this.fail(new Error('private_pipe_unavailable')); continue }
        const [op, id, data] = line.split(' ', 3)
        if (!/^[a-f0-9]{32}$/.test(id ?? '')) continue
        if (op === 'REQ' && data) {
          if (this.sockets.size >= 32) { this.send(`CLOSE ${id}`); continue }
          const socket = new PipeSocket(this, id); this.sockets.set(id, socket); this.onConnection(socket)
          socket.emit('data', Buffer.concat([Buffer.from(data, 'base64'), Buffer.from('\n')]))
        } else if (op === 'DONE') { const socket = this.sockets.get(id); socket?.callback?.() }
        else if (op === 'CLOSE') this.sockets.get(id)?.closed()
      }
    })
    return this
  }
  close() { this.closing = true; this.send('QUIT'); for (const socket of this.sockets.values()) socket.closed(); this.child?.stdin.end() }
}
