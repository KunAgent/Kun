import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'
import { connect } from 'node:net'
import { chmod, lstat, mkdir, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { atomic, json } from './update/files.js'

const MAX_FRAME = 4 * 1024 * 1024
export function daemonPaths(home) {
  const directory = join(home, 'daemon')
  const hash = createHash('sha256').update(home).digest('hex').slice(0, 32)
  let socketDirectory = directory
  let socket = process.platform === 'win32' ? String.raw`\\.\pipe\kun-agent-${hash}` : join(directory, 'agent.sock')
  if (process.platform !== 'win32' && Buffer.byteLength(socket) > 100) {
    socketDirectory = join('/tmp', `kun-agent-${typeof process.getuid === 'function' ? process.getuid() : 'user'}`)
    socket = join(socketDirectory, `${hash}.sock`)
    if (Buffer.byteLength(socket) > 100) throw new Error('daemon_socket_path_too_long')
  }
  return { directory, socketDirectory, socket, metadata: join(directory, 'instance.json'), preference: join(directory, 'preference.json') }
}
export async function prepareDaemonDirectory(home) {
  const paths = daemonPaths(home)
  if (process.platform === 'win32') {
    await (await import('./windows-private-directory.js')).secureWindowsDaemonDirectory(home)
    return paths
  }
  await mkdir(paths.directory, { recursive: true, mode: 0o700 })
  for (const directory of new Set([paths.directory, paths.socketDirectory])) {
    await mkdir(directory, { recursive: true, mode: 0o700 })
    const stat = await lstat(directory)
    if (!stat.isDirectory() || stat.isSymbolicLink() || (typeof process.getuid === 'function' && stat.uid !== process.getuid())) throw new Error('unsafe_daemon_directory')
    if (process.platform !== 'win32') await chmod(directory, 0o700)
  }
  return paths
}
export async function daemonPreference(home) {
  if (process.platform === 'win32') await prepareDaemonDirectory(home)
  const p = await json(daemonPaths(home).preference, { version: 1, desired: 'running' })
  if (p?.version !== 1 || !['running', 'stopped'].includes(p.desired)) throw new Error('unsupported_daemon_preference')
  return p
}
export async function setDaemonPreference(home, desired) {
  const paths = await prepareDaemonDirectory(home)
  await atomic(paths.preference, { version: 1, desired })
}
export function newDaemonSecret() { return randomBytes(32).toString('base64url') }
export function validDaemonSecret(provided, expected) {
  if (typeof provided !== 'string' || typeof expected !== 'string') return false
  const a = Buffer.from(provided), b = Buffer.from(expected)
  return a.length === b.length && timingSafeEqual(a, b)
}
export async function daemonRequest(home, request, { signal, timeoutMs = 5000 } = {}) {
  if (process.platform === 'win32') await prepareDaemonDirectory(home)
  const paths = daemonPaths(home)
  let meta
  try { meta = JSON.parse(await readFile(paths.metadata, 'utf8')) }
  catch (error) { if (error.code === 'ENOENT') return null; throw error }
  if (meta?.version !== 1 || typeof meta.secret !== 'string' || meta.secret.length !== 43) throw new Error('invalid_daemon_metadata')
  return new Promise((resolve, reject) => {
    let settled = false, content = ''
    const socket = connect(paths.socket)
    const finish = (error, result) => {
      if (settled) return
      settled = true; clearTimeout(timer); signal?.removeEventListener('abort', abort); socket.destroy()
      if (error) reject(error); else resolve(result)
    }
    const abort = () => finish(Object.assign(new Error('daemon_request_cancelled'), { code: 'ABORT_ERR' }))
    const timer = setTimeout(() => finish(new Error('daemon_request_timeout')), timeoutMs)
    if (signal?.aborted) return abort()
    signal?.addEventListener('abort', abort, { once: true })
    socket.on('connect', () => socket.write(JSON.stringify({ ...request, secret: meta.secret }) + '\n'))
    socket.on('data', chunk => {
      content += chunk.toString('utf8')
      if (Buffer.byteLength(content) > MAX_FRAME) return finish(new Error('daemon_response_too_large'))
      const end = content.indexOf('\n')
      if (end < 0) return
      try { finish(null, JSON.parse(content.slice(0, end))) } catch { finish(new Error('invalid_daemon_response')) }
    })
    socket.on('error', error => {
      if (['ENOENT', 'ECONNREFUSED'].includes(error.code)) finish(null)
      else finish(error)
    })
    socket.on('end', () => finish(new Error('daemon_connection_closed')))
  })
}
