import { spawn } from 'node:child_process'
import { join } from 'node:path'
import { autostartPreference, installAutostart, removeAutostart, startManagedAutostart } from './daemon-autostart.js'
import { AGENT_VERSION } from './version.js'
import { currentRelease } from './update/install.js'
import { locked } from './update/coordination.js'
import { LocalStore } from './local-store.js'
import { daemonPreference, daemonRequest, setDaemonPreference } from './daemon-ipc.js'

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
const disconnected = error => ['daemon_connection_closed', 'daemon_request_timeout'].includes(error.message) ||
  ['ENOENT', 'ECONNREFUSED', 'ECONNRESET', 'EPIPE'].includes(error.code)
export async function daemonStatus(home) {
  const preference = await daemonPreference(home)
  const status = await daemonRequest(home, { op: 'status' })
  return { desired: preference.desired, running: Boolean(status), autoStart: (await autostartPreference(home)).enabled, ...(status ?? {}) }
}
export async function startDaemon(home, env = process.env, { onlyIfDesired = false } = {}) {
  return locked(home, 'daemon-control', async () => {
    const config = await new LocalStore(home).readConfig()
    if (!config) throw new Error('connect_before_starting_daemon')
    if (onlyIfDesired && (await daemonPreference(home)).desired === 'stopped') return { desired: 'stopped', running: false }
    const existing = await daemonRequest(home, { op: 'status' }).catch(error => { if (disconnected(error)) return null; throw error })
    await setDaemonPreference(home, 'running')
    if (existing) {
      if (existing.agentVersion !== AGENT_VERSION) throw new Error('daemon_restart_required')
      return { desired: 'running', running: true, ...existing }
    }
    let failed = false
    if (!await startManagedAutostart(home, env)) {
      const active = await currentRelease(home)
      const node = active ? join(active.directory, 'runtime', 'bin', 'node') : process.execPath
      const program = active ? join(active.directory, 'kun-agent.mjs') : process.argv[1]
      if (!program) throw new Error('daemon_launcher_unavailable')
      const child = spawn(node, [program, 'daemon', 'serve'], {
        detached: true, stdio: 'ignore', env: { ...env, KUN_HOME: home, KUN_AGENT_DAEMON_INTERNAL: '1' }
      })
      child.on('error', () => { failed = true }); child.unref()
    }
    for (let i = 0; i < 80; i++) {
      if (failed) break
      const status = await daemonRequest(home, { op: 'status' }, { timeoutMs: 500 }).catch(error => {
        if (disconnected(error)) return null
        throw error
      })
      if (status) return { desired: 'running', running: true, ...status }
      await sleep(100)
    }
    throw new Error('daemon_start_failed')
  }, 10_000)
}
/** Replaces only the authenticated owner of this installation after a verified release switch. */
export async function ensureDaemonVersion(home, env = process.env) {
  return locked(home, 'daemon-handoff', async () => {
    const preference = await daemonPreference(home)
    if (preference.desired === 'stopped') throw Object.assign(new Error('Background sync is stopped. Run kun-agent daemon start.'), { exitCode: 8 })
    const current = await daemonRequest(home, { op: 'status' }).catch(error => { if (disconnected(error)) return null; throw error })
    if (current?.agentVersion === AGENT_VERSION) return current
    if (current) await stopDaemon(home, { preservePreference: true })
    const started = await startDaemon(home, env, { onlyIfDesired: true })
    if (started.desired === 'stopped') throw Object.assign(new Error('Background sync is stopped. Run kun-agent daemon start.'), { exitCode: 8 })
    const refreshed = await daemonRequest(home, { op: 'status' })
    if (!refreshed || refreshed.agentVersion !== AGENT_VERSION) throw new Error('daemon_restart_required')
    return refreshed
  }, 30_000)
}
export async function stopDaemon(home, { preservePreference = false } = {}) {
  return locked(home, 'daemon-control', async () => {
    if (!preservePreference) await setDaemonPreference(home, 'stopped')
    const response = await daemonRequest(home, { op: 'stop' }).catch(error => {
      if (disconnected(error)) return null
      throw error
    })
    if (response && !response.ok) throw new Error('daemon_stop_failed')
    for (let i = 0; i < 100; i++) {
      const status = await daemonRequest(home, { op: 'status' }, { timeoutMs: 500 }).catch(error => {
        if (disconnected(error)) return null
        throw error
      })
      if (!status) {
        await locked(home, 'daemon-owner', async () => {}, 10_000)
        return { desired: 'stopped', running: false }
      }
      await sleep(100)
    }
    throw new Error('daemon_stop_timeout')
  }, 15_000)
}
export async function daemonCommand(home, action, { env = process.env, main, subaction, out = () => {}, err = () => {} } = {}) {
  if (action === 'serve' || action === 'run') {
    if (action === 'run') await locked(home, 'daemon-control', () => setDaemonPreference(home, 'running'), 10_000)
    if (!main) throw new Error('daemon_runner_unavailable')
    const { serveDaemon } = await import('./daemon-server.js')
    return serveDaemon(home, main, { env })
  }
  let result
  if (action === 'autostart') {
    if (subaction === 'status' || !subaction) result = { enabled: (await autostartPreference(home)).enabled }
    else if (subaction === 'enable' || subaction === 'disable') {
      result = await locked(home, 'autostart-control', async () => {
        const status = await daemonStatus(home), running = status.running
        const wanted = subaction === 'enable'
        if (status.autoStart === wanted) return { enabled: wanted, running }
        try {
          if (running) await stopDaemon(home)
          if (subaction === 'enable') {
            if (!await new LocalStore(home).readConfig()) throw new Error('connect_before_starting_daemon')
            await installAutostart(home, env)
            await startDaemon(home, env)
          } else {
            await removeAutostart(home, env)
            if (running) await startDaemon(home, env)
          }
          return { enabled: subaction === 'enable', running: (await daemonStatus(home)).running }
        } catch (error) {
          if (subaction === 'enable') await removeAutostart(home, env).catch(() => {})
          if (running) await startDaemon(home, env).catch(() => {})
          throw error
        }
      }, 30_000)
    } else { err('Usage: kun-agent daemon autostart enable|disable|status'); return 2 }
  } else if (action === 'start') result = await startDaemon(home, env)
  else if (action === 'stop') result = await stopDaemon(home)
  else if (action === 'restart') { await stopDaemon(home); result = await startDaemon(home, env) }
  else if (action === 'status' || !action) result = await daemonStatus(home)
  else { err('Usage: kun-agent daemon start|stop|restart|status|run'); return 2 }
  out(JSON.stringify(result))
  return 0
}
