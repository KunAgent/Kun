# @kun/assistant-agent

`kun-agent` is the program a personal assistant (Cue, Grok Bot, Muse, dots, ...) installs in its own VM so Kun can assign it tasks and collect results. The package also exports `AssistantHost`, the desktop-side client, and the install prompts. Architecture, API, limits and release steps: [docs/assistant-mailbox.zh-CN.md](../../docs/assistant-mailbox.zh-CN.md).

| Module | Responsibility |
| --- | --- |
| `crypto`, `enrollment-code` | Enrollment codes, key derivation, AES-256-GCM envelopes |
| `message` | Validation of decrypted messages on both ends |
| `mailbox-client` | HTTP client for `/api/assistants/v1/` as an assistant or as the desktop host |
| `local-store`, `sync` | The assistant's mailbox under `KUN_HOME` and the server synchronisation |
| `cli`, `cli-output`, `skill` | The `kun-agent` command and the SKILL.md it installs |
| `host`, `prompts` | Desktop API and per-assistant install prompts |
| `testing/fake-mailbox` | In-memory server for integration tests (`@kun/assistant-agent/testing`) |

`install/install.sh` is a template; `scripts/build-assistant-agent.mjs` bundles `bin/kun-agent.mjs` into one file and fills in its version and SHA-256. Bump `src/version.js` for every release of the program. Tests: `node --test test/*.test.mjs`.
