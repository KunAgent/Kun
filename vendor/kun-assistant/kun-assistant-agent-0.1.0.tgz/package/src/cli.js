// kun-agent: the program installed in a personal assistant's VM. Every command is short-lived:
// it syncs the mailbox, does one thing and exits, so it works on VMs that suspend between tasks.
import { readFile, mkdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { deriveKeys } from './crypto.js'
import { parseEnrollmentCode } from './enrollment-code.js'
import { MailboxRequestError, createAssistantClient, enrollAgent, normalizeServer } from './mailbox-client.js'
import { LocalStore, resolveHome } from './local-store.js'
import { MAX_BODY_BYTES, STATUSES } from './message.js'
import { SKILL_NAME, renderSkill } from './skill.js'
import { sendMessage, sync } from './sync.js'
import { AGENT_VERSION, DEFAULT_SERVER, PROTOCOL_VERSION } from './version.js'
import { EXIT, USAGE, describeOutbox, explainError, formatRecord } from './cli-output.js'

const VALUE_FLAGS = new Set(['server', 'wait', 'status', 'file', 'title', 'install', 'interval'])
const BOOLEAN_FLAGS = new Set(['json', 'yes', 'once', 'force', 'help'])
const COMMANDS = new Set(['help', 'version', 'skill', 'enroll', 'forget', 'inbox', 'show', 'reply', 'send', 'status', 'watch'])

class UsageError extends Error {}

export function parseArgs(argv) {
  const flags = {}
  const positional = []
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]
    if (arg === '--') { positional.push(...argv.slice(i + 1)); break }
    if (!arg.startsWith('--') || arg === '-') { positional.push(arg); continue }
    const [name, inline] = arg.slice(2).split(/=(.*)/s, 2)
    if (VALUE_FLAGS.has(name)) {
      const value = inline ?? argv[++i]
      if (value === undefined) throw new UsageError(`--${name} needs a value`)
      flags[name] = value
    } else if (BOOLEAN_FLAGS.has(name) && inline === undefined) {
      flags[name] = true
    } else {
      throw new UsageError(`unknown option --${name}`)
    }
  }
  return { command: positional.shift(), positional, flags }
}

function seconds(value, name, max) {
  const number = Number(value)
  if (!Number.isInteger(number) || number < 0 || number > max) throw new UsageError(`--${name} must be a whole number of seconds up to ${max}`)
  return number
}

async function readBody({ positional, flags }, io) {
  if (flags.file) {
    const text = await readFile(flags.file, 'utf8')
    if (Buffer.byteLength(text) > MAX_BODY_BYTES) throw new UsageError(`${flags.file} is larger than 32 KB; summarise it or put the full result somewhere Kun can reach and send the location`)
    return text
  }
  if (positional.length === 1 && positional[0] === '-') {
    let text = ''
    for await (const chunk of io.stdin) text += chunk
    return text
  }
  const text = positional.join(' ')
  if (Buffer.byteLength(text) > MAX_BODY_BYTES) throw new UsageError('the message is larger than 32 KB; use --file with a summary')
  return text
}

function platform() {
  return `${process.platform}-${process.arch}`.toLowerCase().replace(/[^a-z0-9_.-]/g, '')
}

export async function main(argv, io = {}) {
  const env = io.env ?? process.env
  const out = (text) => io.stdout.write(text.endsWith('\n') ? text : text + '\n')
  const err = (text) => io.stderr.write(text.endsWith('\n') ? text : text + '\n')
  const now = io.now ?? (() => new Date())
  const sleep = io.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)))
  const bin = env.KUN_AGENT_BIN || 'kun-agent'
  const store = new LocalStore(resolveHome(env))
  try {
    const args = parseArgs(argv)
    const { command, positional, flags } = args
    if (!command || command === 'help' || flags.help) { out(USAGE); return EXIT.ok }
    if (!COMMANDS.has(command)) throw new UsageError(`unknown command ${command}`)
    if (command === 'version') { out(`kun-agent ${AGENT_VERSION} (protocol ${PROTOCOL_VERSION})`); return EXIT.ok }
    if (command === 'skill') {
      const text = renderSkill(bin)
      if (!flags.install) { out(text); return EXIT.ok }
      const dir = join(flags.install, SKILL_NAME)
      await mkdir(dir, { recursive: true })
      await writeFile(join(dir, 'SKILL.md'), text)
      out(`Installed the Kun mailbox skill at ${join(dir, 'SKILL.md')}`)
      return EXIT.ok
    }
    if (command === 'enroll') {
      const code = parseEnrollmentCode(positional[0])
      if (!code) throw new UsageError('that is not a Kun enrollment code (it starts with KUN1-)')
      const existing = await store.readConfig()
      if (existing && !flags.force) {
        err(`Already connected to Kun as "${existing.name}". Run \`${bin} forget --yes\` first to connect again.`)
        return EXIT.failure
      }
      const server = normalizeServer(flags.server ?? env.KUN_SERVER ?? DEFAULT_SERVER)
      const enrolled = await enrollAgent({ server, enrollmentId: code.enrollmentId, enrollToken: deriveKeys(code.secret, code.enrollmentId).enrollToken, platform: platform(), agentVersion: AGENT_VERSION, fetch: io.fetch })
      await store.writeConfig({ version: 1, server, assistantId: enrolled.assistantId, token: enrolled.token, enrollmentId: code.enrollmentId, secret: code.secret.toString('base64url'), name: enrolled.name, kind: enrolled.kind, enrolledAt: now().toISOString() })
      out([`Connected to Kun as "${enrolled.name}" (${enrolled.kind}).`, `Next: install the guide with \`${bin} skill\`, then run \`${bin} send "Connected to Kun"\`.`, `Check for tasks with \`${bin} inbox\`.`].join('\n'))
      return EXIT.ok
    }
    const config = await store.readConfig()
    if (command === 'forget') {
      if (!flags.yes) throw new UsageError('forget removes this computer\'s Kun credentials; run it with --yes')
      await store.removeConfig()
      out(config ? `Removed the Kun credentials for "${config.name}". Received messages remain in ${store.home}.` : 'This computer was not connected to Kun.')
      return EXIT.ok
    }
    if (!config) {
      err(`Not connected to Kun yet. Ask the user for an enrollment code from Kun, then run \`${bin} enroll <code>\`.`)
      return EXIT.failure
    }
    await store.prepare()
    const client = createAssistantClient({ server: config.server, assistantId: config.assistantId, token: config.token, fetch: io.fetch, sleep })
    const context = { store, client, config, now }
    const acknowledge = async (records) => {
      for (const record of records.filter((item) => item.status === 'new')) {
        await store.setStatus(record.message.id, 'read', now())
        if (record.message.kind === 'task') {
          await sendMessage({ ...context, kind: 'reply', inReplyTo: record.message.id, status: 'received', body: '' })
        }
      }
    }
    if (command === 'inbox') {
      const wait = flags.wait === undefined ? 0 : seconds(flags.wait, 'wait', 900)
      const deadline = Date.now() + wait * 1000
      let result = await sync(context)
      let records = await store.openRecords()
      while (!records.length && Date.now() < deadline) {
        await sleep(Math.min(5000, deadline - Date.now()))
        result = await sync(context)
        records = await store.openRecords()
      }
      if (flags.json) {
        out(JSON.stringify({ items: records, rejected: result.rejected, outbox: result.outbox }))
      } else {
        const lines = records.length ? [`${records.length} open item(s) from Kun:`, '', ...records.map((record) => formatRecord(record, bin) + '\n')] : ['No open Kun tasks.']
        if (result.rejected.length) lines.push(`${result.rejected.length} message(s) failed authentication and were discarded.`)
        out([...lines, ...describeOutbox(result.outbox)].join('\n'))
      }
      await acknowledge(records)
      return EXIT.ok
    }
    if (command === 'show') {
      await sync(context)
      const record = await store.find(positional[0])
      if (!record) { err(`No message ${positional[0] ?? ''} in the local mailbox. Run \`${bin} inbox\`.`); return EXIT.failure }
      out(flags.json ? JSON.stringify(record) : formatRecord(record, bin))
      await acknowledge([record])
      return EXIT.ok
    }
    if (command === 'reply' || command === 'send') {
      let fields
      if (command === 'reply') {
        if (!STATUSES.includes(flags.status)) throw new UsageError(`reply needs --status ${STATUSES.join('|')}`)
        // The reply only needs the local copy; while offline it is queued and sent later.
        await sync(context).catch((error) => { if (!(error instanceof MailboxRequestError) || error.status === 401) throw error })
        const record = await store.find(positional.shift())
        if (!record) { err(`No such message in the local mailbox. Run \`${bin} inbox\` to see open items.`); return EXIT.failure }
        if (record.status === 'cancelled' && !flags.force) { err('Kun cancelled this task; no reply is needed.'); return EXIT.failure }
        fields = { kind: 'reply', inReplyTo: record.message.id, status: flags.status, body: await readBody(args, io) }
      } else {
        const body = await readBody(args, io)
        if (!body.trim() && !flags.title) throw new UsageError('send needs a message')
        fields = { kind: 'note', title: flags.title, body }
      }
      const sent = await sendMessage({ ...context, ...fields })
      if (command === 'reply' && fields.status !== 'received') await store.setStatus(fields.inReplyTo, fields.status, now())
      out([sent.delivered ? `Sent to Kun (${sent.message.id.slice(0, 8)}).` : `Queued for Kun (${sent.message.id.slice(0, 8)}); it will be sent on the next kun-agent command.`, ...describeOutbox(sent.outbox)].join('\n'))
      return EXIT.ok
    }
    if (command === 'status') {
      const outbox = await sync(context)
      const remote = (await client.status()).assistant
      const open = await store.openRecords()
      const queued = (await store.outgoing()).length
      if (flags.json) {
        out(JSON.stringify({ name: config.name, kind: config.kind, server: config.server, assistantId: config.assistantId, home: store.home, version: AGENT_VERSION, open: open.length, queued, remote }))
      } else {
        out([`Connected to Kun as "${config.name}" (${config.kind}) via ${config.server}.`, `Open items: ${open.length}. Messages waiting to be sent: ${queued}. Not yet collected by Kun: ${remote.pendingToHost}.`, `Mailbox folder: ${store.home}. kun-agent ${AGENT_VERSION}.`, ...describeOutbox(outbox.outbox)].join('\n'))
      }
      return EXIT.ok
    }
    if (command === 'watch') {
      const interval = seconds(flags.interval ?? 30, 'interval', 3600)
      if (interval < 5 && !flags.once) throw new UsageError('--interval must be at least 5 seconds')
      out(`Watching the Kun mailbox every ${interval}s. Press Ctrl-C to stop.`)
      for (;;) {
        try {
          const result = await sync(context)
          const shown = result.fresh.map((message) => ({ message, status: 'new', receivedAt: now().toISOString() }))
          for (const record of shown) out(formatRecord(record, bin) + '\n')
          for (const line of describeOutbox(result.outbox)) err(line)
        } catch (error) {
          const [code, text] = explainError(error)
          err(text)
          if (code === EXIT.unauthorized) return code
        }
        if (flags.once) return EXIT.ok
        await sleep(interval * 1000)
      }
    }
    throw new UsageError(`unknown command ${command}`)
  } catch (error) {
    if (error instanceof UsageError) { err(`kun-agent: ${error.message}\nRun \`${bin} help\` for usage.`); return EXIT.usage }
    const [code, text] = explainError(error)
    err(text)
    return code
  }
}
