// Desktop side of the assistant mailbox. Kun's desktop creates enrollment codes, assigns tasks,
// and collects replies. Secrets stay on the desktop: `secrets` is the desktop's own store, keyed by
// enrollment id, and must be durable before a code is shown to the user.
import { deriveKeys, open, seal, sha256Hex } from './crypto.js'
import { newEnrollmentCode } from './enrollment-code.js'
import { createHostClient } from './mailbox-client.js'
import { createMessage, validateMessage } from './message.js'
import { ASSISTANT_KINDS, installPrompt, wakeMessage } from './prompts.js'
import { DEFAULT_SERVER } from './version.js'

export { ASSISTANT_KINDS, installPrompt, wakeMessage }
export { MailboxRequestError } from './mailbox-client.js'
export { AGENT_VERSION, PROTOCOL_VERSION, DEFAULT_SERVER } from './version.js'

function secretBuffer(value) {
  if (Buffer.isBuffer(value)) return value
  if (typeof value === 'string') return Buffer.from(value, 'base64url')
  return null
}

export class AssistantHost {
  /**
   * @param {object} options
   * @param {() => Promise<{accessToken: string, deviceId: string, deviceCredential: string}>} options.credentials
   * @param {{ get(enrollmentId: string): Promise<string|undefined>|string|undefined, set(enrollmentId: string, secret: string): Promise<void>|void }} options.secrets
   */
  constructor({ server = DEFAULT_SERVER, credentials, secrets, fetch, now = () => new Date() }) {
    if (typeof credentials !== 'function' || !secrets) throw new TypeError('credentials and secrets are required')
    this.server = server
    this.client = createHostClient({ server, credentials, fetch })
    this.secrets = secrets
    this.now = now
  }

  async keys(enrollmentId) {
    const secret = secretBuffer(await this.secrets.get(enrollmentId))
    return secret?.length === 32 ? deriveKeys(secret, enrollmentId) : null
  }

  /** Creates a one-time code and the prompt to paste into the assistant. */
  async createEnrollment({ name, kind = 'other', locale = 'zh' }) {
    if (!ASSISTANT_KINDS.includes(kind)) throw new TypeError(`unknown assistant kind ${kind}`)
    const { enrollmentId, secret, code } = newEnrollmentCode()
    const { enrollToken } = deriveKeys(secret, enrollmentId)
    await this.secrets.set(enrollmentId, secret.toString('base64url'))
    const created = await this.client.enroll({ enrollmentId, tokenHash: sha256Hex(enrollToken), name, kind })
    return { enrollmentId, code, expiresAt: created.expiresAt, prompt: installPrompt({ code, kind, server: this.server, locale }) }
  }

  /** `{ assistants, enrollments }` for this desktop, with pending counts and last-seen times. */
  list() {
    return this.client.list()
  }

  revoke(assistantId) {
    return this.client.revoke(assistantId)
  }

  /** Seals and queues one message to an assistant from `list()`; returns the message sent. */
  async send(assistant, fields) {
    const keys = await this.keys(assistant.enrollmentId)
    if (!keys) throw new Error(`no key stored for assistant ${assistant.id}`)
    const message = createMessage({ ...fields, from: 'kun', now: this.now() })
    await this.client.send(assistant.id, message.id, seal(keys, 'to_assistant', assistant.enrollmentId, message.id, message))
    return message
  }

  assign(assistant, { title, body, deadline }) {
    return this.send(assistant, { kind: 'task', title, body, deadline })
  }

  cancel(assistant, taskId, body = '') {
    return this.send(assistant, { kind: 'cancel', inReplyTo: taskId, body })
  }

  /**
   * Collects replies and notes. `handler({ assistant, message })` must persist the message before
   * it resolves; the server copy is acknowledged afterwards. Envelopes that cannot be opened (an
   * unknown key or tampering) are reported once as `{ assistant, messageId, error }` and dropped.
   */
  async receive(handler) {
    let received = 0
    let rejected = 0
    let assistants = null
    for (let page = 0; page < 16; page++) {
      const { messages } = await this.client.inbox()
      if (!messages?.length) break
      assistants ??= new Map((await this.client.list()).assistants.map((assistant) => [assistant.id, assistant]))
      const handled = []
      for (const envelope of messages) {
        let assistant = assistants.get(envelope.assistantId)
        if (!assistant) {
          assistants = new Map((await this.client.list()).assistants.map((item) => [item.id, item]))
          assistant = assistants.get(envelope.assistantId)
        }
        let message
        try {
          const keys = assistant && await this.keys(assistant.enrollmentId)
          if (!keys) throw new Error('no key for this assistant')
          message = validateMessage(open(keys, 'to_host', assistant.enrollmentId, envelope.id, envelope.envelope), { from: 'assistant', id: envelope.id })
        } catch (error) {
          await handler({ assistant, messageId: envelope.id, error })
          rejected++
          handled.push(envelope.id)
          continue
        }
        await handler({ assistant, message })
        received++
        handled.push(envelope.id)
      }
      await this.client.ack(handled)
      if (messages.length < 32) break
    }
    return { received, rejected }
  }
}
