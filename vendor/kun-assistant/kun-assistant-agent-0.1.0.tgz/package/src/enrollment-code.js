// One-time enrollment code shown to the user inside the install prompt:
//   KUN1-<enrollment id, 32 hex>-<secret, 43 base64url characters>
// The server never sees the secret half; it only stores the digest of the derived enroll token.
import { randomUUID } from 'node:crypto'
import { randomSecret } from './crypto.js'

const PATTERN = /^KUN1-([0-9a-f]{32})-([A-Za-z0-9_-]{43})$/

function dashed(hex) {
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
}

export function newEnrollmentCode() {
  const enrollmentId = randomUUID()
  const secret = randomSecret()
  return { enrollmentId, secret, code: formatEnrollmentCode(enrollmentId, secret) }
}

export function formatEnrollmentCode(enrollmentId, secret) {
  return `KUN1-${enrollmentId.replaceAll('-', '')}-${secret.toString('base64url')}`
}

/** Accepts the code with surrounding whitespace or quotes, as assistants often paste it. */
export function parseEnrollmentCode(value) {
  const match = PATTERN.exec(String(value ?? '').trim().replace(/^["'`]+|["'`]+$/g, ''))
  if (!match) return null
  const secret = Buffer.from(match[2], 'base64url')
  if (secret.length !== 32) return null
  return { enrollmentId: dashed(match[1]), secret }
}
