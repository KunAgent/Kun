// The assistant's local mailbox under KUN_HOME (default ~/.kun). Messages are persisted before
// the server copy is acknowledged, so a crash never loses a task. Layout:
//   agent.json            enrollment, bearer token and secret (mode 0600)
//   messages/<id>.json    every received message with its local status (source of truth)
//   inbox/<id>.md         readable copy of each open item, for assistants that prefer files
//   archive/<id>.md       readable copy once the item is closed
//   outbox/<id>.json      sealed outgoing envelopes not yet accepted by the server
//   rejected/<id>.json    envelopes that failed authentication (never shown to the assistant)
import { mkdir, open as openFile, readFile, readdir, rename, rm, stat } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { randomBytes } from 'node:crypto'

const CLOSED = new Set(['done', 'failed', 'cancelled'])
const ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/

export function resolveHome(env = process.env) {
  return env.KUN_HOME?.trim() || join(homedir(), '.kun')
}

async function writeAtomic(path, text, mode = 0o600) {
  const temporary = `${path}.tmp-${process.pid}-${randomBytes(4).toString('hex')}`
  const handle = await openFile(temporary, 'w', mode)
  try {
    await handle.writeFile(text, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
  await rename(temporary, path)
}

async function exists(path) {
  try { await stat(path); return true } catch (error) { if (error.code === 'ENOENT') return false; throw error }
}

async function readJson(path) {
  try { return JSON.parse(await readFile(path, 'utf8')) } catch (error) { if (error.code === 'ENOENT') return null; throw error }
}

function markdown(record) {
  const { message, status, receivedAt } = record
  const lines = [`# ${message.title || (message.kind === 'task' ? 'Task from Kun' : `${message.kind} from Kun`)}`, '',
    `- id: ${message.id}`, `- kind: ${message.kind}`, `- status: ${status}`, `- received: ${receivedAt}`]
  if (message.deadline) lines.push(`- deadline: ${message.deadline}`)
  if (message.inReplyTo) lines.push(`- in reply to: ${message.inReplyTo}`)
  if (message.kind === 'task' && !CLOSED.has(status)) {
    lines.push(`- reply: kun-agent reply ${message.id.slice(0, 8)} --status done "<what you did>"`)
  }
  return lines.concat('', message.body, '').join('\n')
}

export class LocalStore {
  constructor(home) {
    this.home = home
  }

  path(...parts) {
    return join(this.home, ...parts)
  }

  async prepare() {
    for (const dir of ['', 'messages', 'inbox', 'archive', 'outbox', 'rejected']) {
      await mkdir(this.path(dir), { recursive: true, mode: 0o700 })
    }
  }

  async readConfig() {
    return readJson(this.path('agent.json'))
  }

  async writeConfig(config) {
    await this.prepare()
    await writeAtomic(this.path('agent.json'), JSON.stringify(config, null, 2) + '\n')
  }

  async removeConfig() {
    await rm(this.path('agent.json'), { force: true })
  }

  async isSeen(id) {
    return ID.test(id) && (await exists(this.path('messages', `${id}.json`)) || await exists(this.path('rejected', `${id}.json`)))
  }

  async reject(id, reason, now = new Date()) {
    if (!ID.test(id)) return
    await writeAtomic(this.path('rejected', `${id}.json`), JSON.stringify({ id, reason, at: now.toISOString() }) + '\n')
  }

  async saveIncoming(message, now = new Date()) {
    const record = { message, status: 'new', receivedAt: now.toISOString(), updatedAt: now.toISOString() }
    await writeAtomic(this.path('inbox', `${message.id}.md`), markdown(record))
    await writeAtomic(this.path('messages', `${message.id}.json`), JSON.stringify(record, null, 2) + '\n')
    return record
  }

  async records() {
    const names = (await readdir(this.path('messages')).catch(() => [])).filter((name) => name.endsWith('.json'))
    const records = []
    for (const name of names) {
      const record = await readJson(this.path('messages', name))
      if (record?.message?.id) records.push(record)
    }
    return records.sort((a, b) => a.receivedAt.localeCompare(b.receivedAt) || a.message.id.localeCompare(b.message.id))
  }

  /** Open tasks plus any other message the assistant has not been shown yet. */
  async openRecords() {
    return (await this.records()).filter(({ message, status }) =>
      message.kind === 'task' ? !CLOSED.has(status) : status === 'new')
  }

  /** Finds a message by full id or by a unique prefix of at least 4 characters. */
  async find(idOrPrefix) {
    const wanted = String(idOrPrefix ?? '').toLowerCase()
    if (wanted.length < 4) return null
    const matches = (await this.records()).filter(({ message }) => message.id.startsWith(wanted))
    if (matches.length > 1) throw new Error(`"${idOrPrefix}" matches ${matches.length} messages; use more characters`)
    return matches[0] ?? null
  }

  async setStatus(id, status, now = new Date()) {
    const record = await readJson(this.path('messages', `${id}.json`))
    if (!record) return null
    record.status = status
    record.updatedAt = now.toISOString()
    const closed = record.message.kind === 'task' ? CLOSED.has(status) : status !== 'new'
    await writeAtomic(this.path(closed ? 'archive' : 'inbox', `${id}.md`), markdown(record))
    if (closed) await rm(this.path('inbox', `${id}.md`), { force: true })
    await writeAtomic(this.path('messages', `${id}.json`), JSON.stringify(record, null, 2) + '\n')
    return record
  }

  async queueOutgoing(item) {
    await this.prepare()
    await writeAtomic(this.path('outbox', `${item.messageId}.json`), JSON.stringify(item) + '\n')
  }

  async outgoing() {
    const names = (await readdir(this.path('outbox')).catch(() => [])).filter((name) => name.endsWith('.json'))
    const items = []
    for (const name of names) {
      const item = await readJson(this.path('outbox', name))
      if (item?.messageId) items.push(item)
    }
    return items.sort((a, b) => a.createdAt.localeCompare(b.createdAt))
  }

  async removeOutgoing(messageId) {
    await rm(this.path('outbox', `${messageId}.json`), { force: true })
  }
}
