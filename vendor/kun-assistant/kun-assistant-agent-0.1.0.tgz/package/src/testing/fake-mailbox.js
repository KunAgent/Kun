// Test double, exported as @kun/assistant-agent/testing; not used by the agent itself.
// In-memory implementation of the `/api/assistants/v1/` contract for package tests. It mirrors
// the database rules the agent relies on: digest-checked tokens, one-time enrollment, idempotent
// sends by message id, acknowledgement deletes, and per-direction queues.
import { createHash, randomBytes, randomUUID } from 'node:crypto'

const sha = (value) => createHash('sha256').update(value).digest('hex')
const PREFIX = '/api/assistants/v1/'

export function fakeMailbox({ origin = 'https://kun.test' } = {}) {
  const host = { accessToken: 'user-token', deviceId: randomUUID(), deviceCredential: randomBytes(32).toString('hex') }
  const state = { enrollments: new Map(), assistants: new Map(), messages: [], down: false, requests: [] }
  const json = (status, value) => new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json' } })
  const page = (assistantIds, direction) => state.messages
    .filter((m) => assistantIds.includes(m.assistantId) && m.direction === direction).slice(0, 32)
    .map(({ id, assistantId, envelope, createdAt }) => ({ id, assistantId, envelope, createdAt }))
  const post = (assistant, direction, { messageId, envelope }) => {
    const existing = state.messages.find((m) => m.id === messageId)
    if (existing) {
      if (existing.assistantId === assistant.id && existing.direction === direction && existing.envelope === envelope) return json(200, { messageId, createdAt: existing.createdAt, duplicate: true })
      return json(409, { error: 'conflict' })
    }
    if (state.messages.filter((m) => m.assistantId === assistant.id && m.direction === direction).length >= 100) return json(409, { error: 'assistant_limit' })
    const createdAt = new Date().toISOString()
    state.messages.push({ id: messageId, assistantId: assistant.id, direction, envelope, createdAt })
    return json(200, { messageId, createdAt, duplicate: false })
  }
  const ack = (assistantIds, direction, { messageIds }) => {
    const before = state.messages.length
    state.messages = state.messages.filter((m) => !(messageIds.includes(m.id) && assistantIds.includes(m.assistantId) && m.direction === direction))
    return json(200, { acked: before - state.messages.length })
  }
  const summary = (a) => ({ id: a.id, enrollmentId: a.enrollmentId, name: a.name, kind: a.kind, platform: a.platform, agentVersion: a.agentVersion,
    createdAt: a.createdAt, lastSeenAt: a.lastSeenAt, pendingToAssistant: state.messages.filter((m) => m.assistantId === a.id && m.direction === 'to_assistant').length,
    pendingToHost: state.messages.filter((m) => m.assistantId === a.id && m.direction === 'to_host').length })

  async function fetch(url, init = {}) {
    if (state.down) throw new TypeError('fetch failed')
    const parsed = new URL(url)
    if (parsed.origin !== origin || !parsed.pathname.startsWith(PREFIX)) return json(404, { error: 'not_found' })
    const path = parsed.pathname.slice(PREFIX.length).split('/')
    const method = init.method ?? 'GET'
    const headers = new Headers(init.headers)
    const body = init.body ? JSON.parse(init.body) : {}
    state.requests.push(`${method} ${path.join('/')}`)
    if (path[0] === 'host') {
      if (headers.get('Authorization') !== `Bearer ${host.accessToken}` || headers.get('X-Kun-Device') !== host.deviceId
        || headers.get('X-Kun-Device-Credential') !== host.deviceCredential) return json(401, { error: 'unauthorized' })
      const live = [...state.assistants.values()].filter((a) => !a.revokedAt)
      const route = `${method} ${path.slice(1).join('/')}`
      if (route === 'POST enrollments') {
        const expiresAt = new Date(Date.now() + 30 * 60_000).toISOString()
        state.enrollments.set(body.enrollmentId, { ...body, expiresAt, consumed: false })
        return json(200, { enrollmentId: body.enrollmentId, expiresAt })
      }
      if (route === 'GET assistants') {
        const enrollments = [...state.enrollments.values()].filter((e) => !e.consumed).map(({ enrollmentId, name, kind, expiresAt }) => ({ enrollmentId, name, kind, expiresAt }))
        return json(200, { assistants: live.map(summary), enrollments })
      }
      if (method === 'DELETE' && path[1] === 'assistants') {
        const assistant = live.find((a) => a.id === path[2])
        if (!assistant) return json(404, { error: 'not_found' })
        assistant.revokedAt = new Date().toISOString()
        state.messages = state.messages.filter((m) => m.assistantId !== assistant.id)
        return json(200, { ok: true })
      }
      if (method === 'POST' && path[1] === 'assistants' && path[3] === 'messages') {
        const assistant = live.find((a) => a.id === path[2])
        return assistant ? post(assistant, 'to_assistant', body) : json(404, { error: 'not_found' })
      }
      if (route === 'GET inbox') return json(200, { messages: page(live.map((a) => a.id), 'to_host') })
      if (route === 'POST inbox/ack') return ack(live.map((a) => a.id), 'to_host', body)
      return json(404, { error: 'not_found' })
    }
    if (method === 'POST' && path.join('/') === 'enroll') {
      const enrollment = state.enrollments.get(body.enrollmentId)
      if (!enrollment || enrollment.consumed || enrollment.tokenHash !== sha(body.enrollToken)) return json(401, { error: 'unauthorized' })
      enrollment.consumed = true
      const token = randomBytes(32).toString('hex')
      const assistant = { id: randomUUID(), enrollmentId: enrollment.enrollmentId, name: enrollment.name, kind: enrollment.kind, platform: body.platform,
        agentVersion: body.agentVersion, tokenHash: sha(token), createdAt: new Date().toISOString(), lastSeenAt: null }
      state.assistants.set(assistant.id, assistant)
      return json(200, { assistantId: assistant.id, enrollmentId: enrollment.enrollmentId, name: assistant.name, kind: assistant.kind, token })
    }
    const match = /^Assistant ([0-9a-f-]{36})\.([0-9a-f]{64})$/.exec(headers.get('Authorization') ?? '')
    const assistant = match && state.assistants.get(match[1])
    if (!assistant || assistant.revokedAt || assistant.tokenHash !== sha(match[2])) return json(401, { error: 'unauthorized' })
    assistant.lastSeenAt = new Date().toISOString()
    const route = `${method} ${path.join('/')}`
    if (route === 'GET inbox') return json(200, { messages: page([assistant.id], 'to_assistant') })
    if (route === 'POST messages') return post(assistant, 'to_host', body)
    if (route === 'POST inbox/ack') return ack([assistant.id], 'to_assistant', body)
    if (route === 'GET status') return json(200, { assistant: summary(assistant) })
    return json(404, { error: 'not_found' })
  }
  return { origin, fetch, state, credentials: async () => host }
}
