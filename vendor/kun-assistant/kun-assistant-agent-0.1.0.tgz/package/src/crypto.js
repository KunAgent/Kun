// End-to-end sealing for the assistant mailbox. The desktop puts a random secret in the
// enrollment code and never sends it to Kun's servers; both ends derive the same keys from it:
//   enroll token   — proves possession of the code when the agent enrolls (server keeps a digest)
//   to-assistant   — AES-256-GCM key for desktop → assistant messages
//   to-host        — AES-256-GCM key for assistant → desktop messages
// Separate keys per direction stop the server reflecting a message back to its sender, and the
// associated data binds every envelope to its enrollment, direction and message id.
import { createCipheriv, createDecipheriv, createHash, hkdfSync, randomBytes } from 'node:crypto'

const LABEL = 'kun-assistant/v1'
const ENVELOPE_VERSION = 1
const NONCE_BYTES = 12
const TAG_BYTES = 16
export const DIRECTIONS = Object.freeze(['to_assistant', 'to_host'])

export function randomSecret() {
  return randomBytes(32)
}

function uuidBytes(id) {
  const hex = String(id).replaceAll('-', '')
  if (!/^[0-9a-f]{32}$/.test(hex)) throw new TypeError('invalid enrollment id')
  return Buffer.from(hex, 'hex')
}

function derive(secret, enrollmentId, purpose) {
  if (!Buffer.isBuffer(secret) || secret.length !== 32) throw new TypeError('invalid secret')
  return Buffer.from(hkdfSync('sha256', secret, uuidBytes(enrollmentId), `${LABEL}/${purpose}`, 32))
}

export function sha256Hex(value) {
  return createHash('sha256').update(value).digest('hex')
}

/** Everything one side needs for one enrollment. */
export function deriveKeys(secret, enrollmentId) {
  return {
    enrollToken: derive(secret, enrollmentId, 'enroll').toString('hex'),
    to_assistant: derive(secret, enrollmentId, 'to-assistant'),
    to_host: derive(secret, enrollmentId, 'to-host')
  }
}

function associatedData(direction, enrollmentId, messageId) {
  if (!DIRECTIONS.includes(direction)) throw new TypeError('invalid direction')
  return Buffer.from(`${LABEL}|${direction}|${enrollmentId}|${messageId}`, 'utf8')
}

/** Seals a JSON-serialisable value into a base64url envelope. */
export function seal(keys, direction, enrollmentId, messageId, value) {
  const nonce = randomBytes(NONCE_BYTES)
  const cipher = createCipheriv('aes-256-gcm', keys[direction], nonce)
  cipher.setAAD(associatedData(direction, enrollmentId, messageId))
  const body = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()])
  return Buffer.concat([Buffer.from([ENVELOPE_VERSION]), nonce, body, cipher.getAuthTag()]).toString('base64url')
}

/** Opens an envelope; throws when it was altered, misrouted or sealed with another key. */
export function open(keys, direction, enrollmentId, messageId, envelope) {
  const raw = Buffer.from(String(envelope), 'base64url')
  if (raw.length < 1 + NONCE_BYTES + TAG_BYTES + 1 || raw[0] !== ENVELOPE_VERSION) {
    throw new Error('unsupported envelope')
  }
  const nonce = raw.subarray(1, 1 + NONCE_BYTES)
  const tag = raw.subarray(raw.length - TAG_BYTES)
  const decipher = createDecipheriv('aes-256-gcm', keys[direction], nonce)
  decipher.setAAD(associatedData(direction, enrollmentId, messageId))
  decipher.setAuthTag(tag)
  const plain = Buffer.concat([decipher.update(raw.subarray(1 + NONCE_BYTES, raw.length - TAG_BYTES)), decipher.final()])
  return JSON.parse(plain.toString('utf8'))
}
