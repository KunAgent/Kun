/** Release of the agent program; the installer and `/assistant/version.json` carry the same value. */
export const AGENT_VERSION = '0.1.0'
/** Wire format of sealed envelopes and of the decrypted message objects. */
export const PROTOCOL_VERSION = 1
/** Production Kun API origin. `KUN_SERVER` or `--server` override it for testing. */
export const DEFAULT_SERVER = 'https://api-kun-server.com'
