/** Presets with tailored prompts; any other lowercase slug (`^[a-z0-9_]{1,32}$`) is accepted too. */
export type KnownAssistantKind = 'cue' | 'grok_bot' | 'muse' | 'dots' | 'hark' | 'today' | 'other'
export type AssistantKind = KnownAssistantKind | (string & {})
export type MessageKind = 'task' | 'note' | 'reply' | 'cancel'
export type MessageStatus = 'received' | 'working' | 'done' | 'blocked' | 'failed'

export interface MailboxMessage {
  v: 1
  id: string
  kind: MessageKind
  from: 'kun' | 'assistant'
  createdAt: string
  body: string
  title?: string
  inReplyTo?: string
  status?: MessageStatus
  deadline?: string
}

export interface AssistantSummary {
  id: string
  enrollmentId: string
  name: string
  kind: AssistantKind
  platform: string
  agentVersion: string
  createdAt: string
  lastSeenAt: string | null
  pendingToAssistant: number
  pendingToHost: number
}

export interface JoinRequest {
  requestId: string
  publicKey: string
  platform: string
  agentVersion: string
  createdAt: string
  /** Same code the agent shows; null when another computer holds this enrollment's key. */
  verificationCode: string | null
}

export interface PendingEnrollment { enrollmentId: string; name: string; kind: AssistantKind; expiresAt: string; requests: JoinRequest[] }

export interface HostCredentials { accessToken: string; deviceId: string; deviceCredential: string }

/** Durable desktop store. Keys are `pairing:<enrollmentId>` (pairing key pair) and `<enrollmentId>` (mailbox secret). */
export interface SecretStore {
  get(enrollmentId: string): Promise<string | undefined> | string | undefined
  set(enrollmentId: string, secret: string): Promise<void> | void
}

export type ReceivedItem =
  | { assistant: AssistantSummary; message: MailboxMessage; messageId?: undefined; error?: undefined }
  | { assistant: AssistantSummary | undefined; messageId: string; error: Error; message?: undefined }

export declare class MailboxRequestError extends Error {
  status: number
  code: string
}

export declare class AssistantHost {
  constructor(options: {
    server?: string
    credentials: () => Promise<HostCredentials>
    secrets: SecretStore
    fetch?: typeof fetch
    now?: () => Date
  })
  createEnrollment(input: { name: string; kind?: AssistantKind; locale?: 'zh' | 'en' }): Promise<{ enrollmentId: string; code: string; expiresAt: string; prompt: string }>
  list(): Promise<{ assistants: AssistantSummary[]; enrollments: PendingEnrollment[] }>
  promptFor(input: { enrollmentId: string; kind?: AssistantKind; locale?: 'zh' | 'en' }): Promise<{ code: string; prompt: string } | null>
  approve(enrollmentId: string, requestId: string): Promise<{ assistantId: string }>
  reject(enrollmentId: string, requestId: string): Promise<{ ok: true }>
  cancelEnrollment(enrollmentId: string): Promise<{ ok: true }>
  revoke(assistantId: string): Promise<{ ok: true }>
  send(assistant: Pick<AssistantSummary, 'id' | 'enrollmentId'>, fields: { kind: MessageKind; title?: string; body?: string; inReplyTo?: string; status?: MessageStatus; deadline?: string }): Promise<MailboxMessage>
  assign(assistant: Pick<AssistantSummary, 'id' | 'enrollmentId'>, task: { title?: string; body: string; deadline?: string }): Promise<MailboxMessage>
  cancel(assistant: Pick<AssistantSummary, 'id' | 'enrollmentId'>, taskId: string, body?: string): Promise<MailboxMessage>
  receive(handler: (item: ReceivedItem) => Promise<void> | void): Promise<{ received: number; rejected: number }>
}

export declare const ASSISTANT_KINDS: readonly KnownAssistantKind[]
export declare function validAssistantKind(kind: unknown): kind is AssistantKind
export declare const AGENT_VERSION: string
export declare const PROTOCOL_VERSION: 1
export declare const DEFAULT_SERVER: string
export declare function verificationCode(enrollmentId: string, hostPublicKey: string, assistantPublicKey: string): string
export declare function installPrompt(input: { code: string; kind?: AssistantKind; server?: string; locale?: 'zh' | 'en' }): string
export declare function wakeMessage(input?: { kind?: AssistantKind; locale?: 'zh' | 'en' }): string
