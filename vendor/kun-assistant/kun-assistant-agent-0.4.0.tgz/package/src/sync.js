// Moves sealed envelopes between the server and the local mailbox. Incoming messages are opened,
// validated and persisted before the server copy is acknowledged; outgoing messages are written
// to the outbox first and retried until the server accepts them (sends are idempotent by id).
import { deriveKeys, open, seal } from './crypto.js'
import { MailboxRequestError } from './mailbox-client.js'
import { createMessage, validateMessage } from './message.js'

const PAGE = 32

export function keysFor(config) {
  return deriveKeys(Buffer.from(config.secret, 'base64url'), config.enrollmentId)
}

/** Sends queued envelopes. Returns `{ sent, pending, dropped }`; stops at the first outage. */
export async function flushOutbox({ store, client }) {
  const result = { sent: 0, pending: 0, dropped: [] }
  const items = await store.outgoing()
  for (let index = 0; index < items.length; index++) {
    const item = items[index]
    try {
      await client.send(item.messageId, item.envelope)
      await store.removeOutgoing(item.messageId)
      result.sent++
    } catch (error) {
      const status = error instanceof MailboxRequestError ? error.status : 0
      // A malformed or conflicting envelope will never be accepted; anything else is retried.
      if (status === 400 || (status === 409 && error.code === 'conflict')) {
        await store.removeOutgoing(item.messageId)
        result.dropped.push({ messageId: item.messageId, code: error.code })
        continue
      }
      if (status === 401) throw error
      result.pending = items.length - index
      result.blocked = error.code
      break
    }
  }
  return result
}

/** Pulls every pending message. Returns the newly stored ones and any rejected envelope ids. */
export async function pullInbox({ store, client, config, now = () => new Date() }) {
  const keys = keysFor(config)
  const fresh = []
  const rejected = []
  for (let page = 0; page < 16; page++) {
    const { messages } = await client.inbox()
    if (!Array.isArray(messages) || messages.length === 0) break
    const handled = []
    for (const envelope of messages) {
      if (await store.isSeen(envelope.id)) { handled.push(envelope.id); continue }
      let message
      try {
        message = validateMessage(open(keys, 'to_assistant', config.enrollmentId, envelope.id, envelope.envelope), { from: 'kun', id: envelope.id })
      } catch (error) {
        await store.reject(envelope.id, error.message, now())
        rejected.push(envelope.id)
        handled.push(envelope.id)
        continue
      }
      // The store commits cancellation effects before the deduplication marker.
      const saved = await store.saveIncoming(message, now())
      if (saved) fresh.push(message)
      handled.push(envelope.id)
    }
    if (handled.length) await client.ack(handled)
    if (messages.length < PAGE) break
  }
  return { fresh, rejected }
}

export async function sync(context) {
  const outbox = await flushOutbox(context)
  const inbox = await pullInbox(context)
  return { ...inbox, outbox }
}

/** Seals a message from this assistant, queues it durably and tries to deliver it now. */
export async function sendMessage({ store, client, config, now = () => new Date(), ...fields }) {
  const message = createMessage({ ...fields, from: 'assistant', now: now() })
  const envelope = seal(keysFor(config), 'to_host', config.enrollmentId, message.id, message)
  await store.queueOutgoing({ messageId: message.id, envelope, createdAt: message.createdAt, kind: message.kind, inReplyTo: message.inReplyTo, status: message.status })
  const outbox = await flushOutbox({ store, client })
  return { message, outbox, delivered: !(await store.outgoing()).some((item) => item.messageId === message.id) }
}
