// A durable handoff lease is separate from transport ACK and task execution state.
import { randomUUID } from 'node:crypto'
import { atomic, json } from './update/files.js'
import { withStoreLock } from './store-lock.js'
import { prepareOutgoing } from './sync.js'
const ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
const fail = code => { throw Object.assign(new Error(code), { code }) }
export class DeliveryStore {
  constructor(store) { this.store = store; this.path = store.path('delivery.json') }
  async read() {
    const state = await json(this.path, { version: 1, leases: {}, consumed: {} })
    if (state.version !== 1 || !state.leases || !state.consumed) fail('delivery_store_corrupt')
    return state
  }
  async claim({ now = new Date(), limit = 10, leaseSeconds = 120, consumer = 'cli' } = {}) {
    if (!Number.isInteger(limit) || limit < 1 || limit > 32 || !Number.isInteger(leaseSeconds) || leaseSeconds < 30 || leaseSeconds > 300) fail('invalid_delivery_options')
    return withStoreLock(this.store.home, async () => {
      const state = await this.read(), excluded = new Set()
      for (const lease of Object.values(state.leases)) {
        if (lease.stage === 'committing' || lease.stage === 'leased' && lease.expiresAt > now.valueOf()) lease.messageIds.forEach(id => excluded.add(id))
      }
      const available = (await this.store.openRecords()).filter(record => record.status === 'new' && !state.consumed[record.message.id] && !excluded.has(record.message.id))
      let bytes = 0
      const items = []
      for (const record of available) {
        const size = Buffer.byteLength(JSON.stringify(record))
        if (items.length >= limit || items.length && bytes + size > 64 * 1024) break
        items.push(record); bytes += size
      }
      if (!items.length) return { leaseId: null, expiresAt: null, items: [], hasMore: available.length > 0 }
      const leaseId = randomUUID(), expiresAt = now.valueOf() + leaseSeconds * 1000
      state.leases[leaseId] = { messageIds: items.map(r => r.message.id), expiresAt, consumer, stage: 'leased' }
      await atomic(this.path, state)
      return { leaseId, expiresAt: new Date(expiresAt).toISOString(), items, hasMore: available.length > items.length }
    })
  }
  async commit(context, id) {
    if (!ID.test(id)) fail('invalid_delivery_lease')
    context.assertBinding?.()
    const now = context.now?.() ?? new Date()
    await withStoreLock(this.store.home, async () => {
      const state = await this.read(), lease = state.leases[id]
      if (!lease || lease.stage === 'released') fail('delivery_lease_expired')
      if (lease.stage !== 'leased') return
      if (lease.expiresAt <= now.valueOf()) fail('delivery_lease_expired')
      const records = await this.store.records(), messages = new Map(records.map(r => [r.message.id, r]))
      const pending = []
      for (const messageId of lease.messageIds) {
        const record = messages.get(messageId)
        if (record?.message.kind === 'task' && record.status === 'new') {
          pending.push(prepareOutgoing({ ...context, kind: 'reply', inReplyTo: messageId, status: 'received', body: '' }).item)
        }
      }
      if (lease.messageIds.length) pending.push({ messageId: id, operation: 'consume', messageIds: lease.messageIds, createdAt: now.toISOString() })
      lease.stage = 'committing'; lease.pending = pending; lease.committedAt = now.toISOString()
      // The exact receipt envelopes survive failure at any subsequent filesystem/network step.
      await atomic(this.path, state)
    })
    await this.recover(context)
    const state = await this.read(), lease = state.leases[id]
    const records = await this.store.records()
    return { ok: true, leaseId: id, items: records.filter(r => lease.messageIds.includes(r.message.id)).map(r => ({ id: r.message.id, status: r.status })) }
  }
  async recover(context) {
    const state = await this.read()
    for (const [id, lease] of Object.entries(state.leases)) {
      if (lease.stage !== 'committing') continue
      context.assertBinding?.()
      for (const item of lease.pending) await this.store.queueOutgoing(item)
      for (const messageId of lease.messageIds) await this.store.setStatus(messageId, 'read', new Date(lease.committedAt))
      await withStoreLock(this.store.home, async () => {
        const latest = await this.read(), current = latest.leases[id]
        if (current?.stage !== 'committing') return
        for (const messageId of current.messageIds) latest.consumed[messageId] = current.committedAt
        current.stage = 'committed'; delete current.pending
        await atomic(this.path, latest)
      })
    }
    // A legacy server cannot accept consumption receipts. Persisted leases let a later
    // compatible server receive those confirmations without replaying tasks to the model.
    if (await context.client?.reliable?.().catch(() => false)) {
      for (const [id, lease] of Object.entries((await this.read()).leases)) {
        if (lease.stage === 'committed' && !lease.remoteConfirmed && lease.messageIds.length) {
          context.assertBinding?.()
          await this.store.queueOutgoing({ messageId: id, operation: 'consume', messageIds: lease.messageIds, createdAt: lease.committedAt })
        }
      }
    }
  }
  async confirmRemote(id) {
    await withStoreLock(this.store.home, async () => {
      const state = await this.read(), lease = state.leases[id]
      if (lease?.stage === 'committed' && !lease.remoteConfirmed) { lease.remoteConfirmed = true; await atomic(this.path, state) }
    })
  }
  async acknowledgeTask(context, taskId) {
    // Replying is an explicit consumer action; it also supports skills installed by older agents.
    const state = await this.read(), now = context.now?.() ?? new Date()
    if (state.consumed[taskId]) return
    const id = randomUUID()
    await withStoreLock(this.store.home, async () => {
      const latest = await this.read()
      latest.leases[id] = { messageIds: [taskId], expiresAt: now.valueOf() + 120000, consumer: 'reply', stage: 'leased' }
      await atomic(this.path, latest)
    })
    await this.commit(context, id)
  }
  async restoreConsumed(id, at) {
    await this.store.setStatus(id, 'read', new Date(at))
    await withStoreLock(this.store.home, async () => {
      const state = await this.read(); state.consumed[id] ??= at; await atomic(this.path, state)
    })
  }
  async release(id) {
    if (!ID.test(id)) fail('invalid_delivery_lease')
    return withStoreLock(this.store.home, async () => {
      const state = await this.read(), lease = state.leases[id]
      if (lease?.stage === 'leased') { lease.stage = 'released'; await atomic(this.path, state) }
      return { ok: true }
    })
  }
  async renew(id, now = new Date()) {
    return withStoreLock(this.store.home, async () => {
      const state = await this.read(), lease = ID.test(id) && state.leases[id]
      if (!lease || lease.stage !== 'leased' || lease.expiresAt <= now.valueOf()) fail('delivery_lease_expired')
      lease.expiresAt = now.valueOf() + 120000
      await atomic(this.path, state)
      return { leaseId: id, expiresAt: new Date(lease.expiresAt).toISOString() }
    })
  }
}
