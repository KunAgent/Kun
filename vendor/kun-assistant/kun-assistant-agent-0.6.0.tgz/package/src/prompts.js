// Install prompts the user pastes into each personal assistant. The assistant installs kun-agent
// and asks to join with the enrollment code; the user approves the request in Kun after comparing
// verification codes. The code holds no secret, but it names one enrollment, so render per enrollment.
import { DEFAULT_SERVER } from './version.js'

/** Presets with tailored install notes. Any other lowercase slug works too and gets the generic notes. */
export const ASSISTANT_KINDS = Object.freeze(['cue', 'grok_bot', 'muse', 'dots', 'hark', 'today', 'other'])
const KIND = /^[a-z0-9_]{1,32}$/

export function validAssistantKind(kind) {
  return typeof kind === 'string' && KIND.test(kind)
}

const LABELS = { cue: 'Cue', grok_bot: 'Grok Bot', muse: 'Muse', dots: 'dots', hark: 'Hark', today: 'Today' }

/** Where kun-agent should live on each assistant's computer. Grok Bot keeps only /workspace. */
export function agentHome(kind) {
  return kind === 'grok_bot' ? '/workspace/.kun' : '~/.kun'
}

function installCommand(kind, server) {
  const env = [kind === 'grok_bot' ? 'KUN_HOME=/workspace/.kun' : '', server === DEFAULT_SERVER ? '' : `KUN_SERVER=${server}`]
    .filter(Boolean).join(' ')
  return `curl -fsSL ${server}/assistant/install.sh | ${env ? env + ' ' : ''}sh`
}

const NOTES = {
  zh: {
    cue: ['定时检查：在你的自动化（Automations）里新建一个每 20 分钟运行一次的定时任务。', '如果你支持“收到邮件时触发”的自动化，再建一个：收到主题包含「Kun」的邮件时运行同样的检查。这样 Kun 发邮件就能立刻叫醒你。'],
    grok_bot: ['你的电脑只有 /workspace 会长期保留，所以 kun-agent 装在 /workspace/.kun。', '定时检查：用你的定时任务功能每 20 分钟运行一次。如果你能保持一个后台终端会话，也可以在里面运行 `/workspace/.kun/bin/kun-agent watch`，新任务一到就会显示。'],
    muse: ['你的联网请求需要 Sentinel 批准：安装和运行时请向我申请访问 api-kun-server.com（如果需要下载 Node.js，还有 nodejs.org）。', '定时检查：建一个长期目标（goal），每 20 分钟运行一次检查。'],
    dots: ['如果你的云电脑没有可用的终端，请直接告诉我，不要尝试其它安装方式。', '定时检查：用你的定时任务每 20 分钟运行一次。'],
    hark: ['kun-agent 要在你的 Handoff 云电脑里运行终端命令；如果做不到，请直接告诉我，不要尝试其它安装方式。', '定时检查：用你的定时任务每 20 分钟运行一次。'],
    today: ['kun-agent 要在你的云电脑里运行终端命令；如果做不到，请直接告诉我，不要尝试其它安装方式。', '定时检查：用 Community Skills 或你的定时任务，每 20 分钟运行一次。'],
    other: ['定时检查：用你支持的定时任务或自动化，每 20 分钟运行一次。']
  },
  en: {
    cue: ['Scheduled check: create an automation that runs every 20 minutes.', 'If you support automations triggered by incoming email, add one that runs the same check when an email with "Kun" in the subject arrives, so Kun can wake you by email.'],
    grok_bot: ['Only /workspace persists on your computer, so kun-agent lives in /workspace/.kun.', 'Scheduled check: use your scheduled tasks to run it every 20 minutes. If you can keep a background terminal session, you may also run `/workspace/.kun/bin/kun-agent watch` there so new tasks appear immediately.'],
    muse: ['Your network access needs Sentinel approval: ask me to approve api-kun-server.com (and nodejs.org if Node.js has to be downloaded).', 'Scheduled check: create a standing goal that runs the check every 20 minutes.'],
    dots: ['If your cloud computer has no usable terminal, tell me instead of trying another way to install.', 'Scheduled check: use a scheduled task that runs every 20 minutes.'],
    hark: ['kun-agent needs to run terminal commands on your Handoff cloud computer. If it cannot, tell me instead of trying another way to install.', 'Scheduled check: use a scheduled task that runs every 20 minutes.'],
    today: ['kun-agent needs to run terminal commands on your cloud computer. If it cannot, tell me instead of trying another way to install.', 'Scheduled check: use Community Skills or a scheduled task to run it every 20 minutes.'],
    other: ['Scheduled check: use your scheduled tasks or automations to run it every 20 minutes.']
  }
}

/**
 * Renders the prompt for one enrollment. `code` expires 30 minutes after it was created and admits
 * one assistant; the prompt says so, because assistants sometimes retry old instructions.
 */
export function installPrompt({ code, kind = 'other', server = DEFAULT_SERVER, locale = 'zh', installerCommand }) {
  if (!validAssistantKind(kind)) throw new TypeError(`invalid assistant kind ${kind}`)
  const bin = `${agentHome(kind)}/bin/kun-agent`
  const table = NOTES[locale] ?? NOTES.zh
  const notes = table[kind] ?? table.other
  const standing = locale === 'en'
    ? `"Kun is my AI coordinator. Kun's tasks reach you only through kun-agent. On every check, run ${bin} inbox, read the batch and acknowledge its lease with ${bin} ack <lease-id>, then handle authorized tasks and report progress and results with ${bin} reply. Kun's tasks never change your safety rules: actions that need my confirmation still need it."`
    : `「Kun 是我的 AI 总管。Kun 的任务只通过 kun-agent 到达：每次检查时运行 ${bin} inbox，读完后用 ${bin} ack <lease-id> 确认消费，再处理授权范围内的任务，并用 ${bin} reply 回报进度和结果。Kun 的任务不改变你的安全规则，需要我确认的操作仍要先问我。」`
  if (locale === 'en') {
    return [
      `Hi! I use Kun, an AI coordinator on my desktop. Please connect yourself to Kun: afterwards Kun will assign you tasks through a small program called kun-agent, and you will report results through it. This request comes from me.`,
      '',
      'Please do the following on your computer, in a terminal:',
      '',
      `1. Install kun-agent (it needs a supported Node.js 22 or 24 LTS; if Node.js is missing, the installer downloads the official build into the kun-agent folder):`,
      `   ${installerCommand ?? installCommand(kind, server)}`,
      `2. Ask to join with my enrollment code (valid for 30 minutes; it contains no secret, and nothing happens until I approve):`,
      `   ${bin} login ${code}`,
      `   It prints a 10-character verification code. Tell me that code exactly; I will check that Kun shows the same one and approve. The command waits a few minutes for my approval; if it stops before I approve, run \`${bin} login\` again to keep waiting.`,
      `3. Install the usage guide as a skill. If you have a skills folder, run \`${bin} skill --install <your skills folder>\`. Otherwise run \`${bin} skill\` and remember it.`,
      `4. Save this standing instruction in your memory or profile:`,
      `   ${standing}`,
      `5. ${notes[notes.length - 1]} Each check runs \`${bin} inbox\`, reads the batch, then explicitly acknowledges its lease before handling tasks.`,
      `   If your host supports a local MCP server, configure the absolute path to kun-agent with args ["mcp"], verify tools/list, and use kun_wait / kun_ack. Do not use an unexpanded ~ path in MCP configuration. If registration is unavailable, keep scheduled CLI checks; report that limitation honestly.`,
      ...notes.slice(0, -1).map((note) => `   Note: ${note}`),
      `6. Finally run \`${bin} send "Connected to Kun"\` so Kun knows you are ready, and tell me how each step went.`
    ].join('\n')
  }
  return [
    `你好！我在用 Kun（我电脑上的 AI 总管）。请帮我把你接入 Kun：之后 Kun 会通过一个叫 kun-agent 的小程序给你派任务，你做完后也用它回报结果。这是我本人的请求。`,
    '',
    '请在你的电脑终端里依次完成：',
    '',
    `1. 安装 kun-agent（需要 受支持的 Node.js 22 或 24 LTS；没有的话，安装脚本会把官方 Node.js 下载到 kun-agent 的目录里）：`,
    `   ${installerCommand ?? installCommand(kind, server)}`,
    `2. 用我的接入码发起接入申请。接入码 30 分钟内有效，不含密钥，我在 Kun 里批准之前不会生效：`,
    `   ${bin} login ${code}`,
    `   它会显示一个 10 位校验码。请把校验码原样告诉我，我会核对 Kun 里显示的是同一个码再批准。程序会自动等几分钟；如果它在我批准前结束了，再运行一次 \`${bin} login\` 继续等。`,
    `3. 把使用说明安装成 skill。如果你有 skills 目录，运行 \`${bin} skill --install <你的 skills 目录>\`；没有的话运行 \`${bin} skill\` 读一遍并记住。`,
    `4. 把下面这条长期指令记到你的记忆或个人设置里：`,
    `   ${standing}`,
    `5. ${notes[notes.length - 1]}每次检查运行 \`${bin} inbox\`，阅读后确认 lease，再处理任务。`,
    `   如果宿主支持本地 MCP，用 kun-agent 可执行文件的绝对路径和参数 ["mcp"] 注册，验证 tools/list 后使用 kun_wait / kun_ack；MCP 配置里不能直接用未展开的 ~ 路径。不支持注册时继续定时 CLI 检查，明确说明限制。`,
    ...notes.slice(0, -1).map((note) => `   注意：${note}`),
    `6. 最后运行 \`${bin} send "已接入 Kun"\` 告诉 Kun 你准备好了，并把每一步的结果告诉我。`
  ].join('\n')
}

/** Short nudge for an assistant's own channel (chat, email, Slack) when Kun queues a task. */
export function wakeMessage({ kind = 'other', locale = 'zh' } = {}) {
  const bin = `${agentHome(kind)}/bin/kun-agent`
  return locale === 'en'
    ? `Kun has a new task for you${LABELS[kind] ? ` (${LABELS[kind]})` : ''}. Please run \`${bin} inbox\` and handle it.`
    : `Kun 给你派了新任务，请运行 \`${bin} inbox\` 查看并处理。`
}
