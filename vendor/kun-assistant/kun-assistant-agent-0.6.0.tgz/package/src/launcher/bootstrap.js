import { copyFile, mkdir, chmod, readFile, rm } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { createHash, randomUUID } from 'node:crypto'
import { atomic, exists } from '../update/files.js'
import { locked } from '../update/coordination.js'
import { activate, currentRelease } from '../update/install.js'
import { health, loadRelease, prepareRelease } from '../update/release.js'
import { UPDATE_TRUST, UpdateError, repository } from '../update/metadata.js'
import { normalizeServer } from '../mailbox-client.js'
import { AGENT_VERSION, SECURITY_EPOCH } from '../version.js'
import { updateSkills } from '../update/skills.js'
import { LocalStore } from '../local-store.js'
import { business } from '../update/coordination.js'
import { renderSkill } from '../skill.js'

const quote = (value) => "'" + value.replaceAll("'", "'\\''") + "'"
export function wrapper(home, server) {
  // repair-only is a separate invocation: a failed business command is never replayed.
  return `#!/bin/sh\nset -eu\nKUN_HOME=\${KUN_HOME:-${quote(home)}}\nKUN_SERVER=\${KUN_SERVER:-${quote(server)}}\nexport KUN_HOME KUN_SERVER\nKUN_AGENT_BIN="$KUN_HOME/bin/kun-agent"\nexport KUN_AGENT_BIN\nslot=$(readlink "$KUN_HOME/current")\ncase "$slot" in releases/*) ;; *) exit 7 ;; esac\nif ! "$KUN_HOME/$slot/runtime/bin/node" "$KUN_HOME/$slot/kun-agent.mjs" repair-only; then\n  old=$(readlink "$KUN_HOME/previous") || exit 7\n  case "$old" in releases/*) ;; *) exit 7 ;; esac\n  "$KUN_HOME/$old/runtime/bin/node" "$KUN_HOME/$old/kun-agent.mjs" repair-only || exit 7\nfi\nslot=$(readlink "$KUN_HOME/current")\nexec "$KUN_HOME/$slot/runtime/bin/node" "$KUN_HOME/$slot/kun-agent.mjs" launch "$@"\n`
}
export async function bootstrap(home, { program, node = process.execPath, server, legacyStopped = false, trust = UPDATE_TRUST, fetch } = {}) {
  server = normalizeServer(server)
  if (!program || !server) throw new UpdateError('invalid_bootstrap')
  return locked(home, 'install', async () => {
    await new LocalStore(home).readConfig() // Refuse unknown binding formats before touching release pointers.
    const active = await currentRelease(home)
    if (!active && await exists(join(home, 'agent.json')) && !legacyStopped) throw new UpdateError('stop_legacy_watch_before_migration', 8)
    const source = await readFile(program), sha256 = createHash('sha256').update(source).digest('hex')
    const id = `${AGENT_VERSION}-${sha256.slice(0, 16)}`
    await mkdir(join(home, 'releases'), { recursive: true, mode: 0o700 })
    const directory = join(home, 'updates', 'staging', `bootstrap-${randomUUID()}`)
    await mkdir(join(directory, 'runtime', 'bin'), { recursive: true, mode: 0o700 })
    try {
      await copyFile(resolve(program), join(directory, 'kun-agent.mjs'))
      await copyFile(resolve(node), join(directory, 'runtime', 'bin', 'node'))
      await chmod(join(directory, 'runtime', 'bin', 'node'), 0o700)
      let release = { schema: 1, releaseId: id, agentVersion: AGENT_VERSION, securityEpoch: SECURITY_EPOCH, launcherAbi: 1,
        wireRead: [1], wireWrite: 1, storeReadMin: 1, storeReadMax: 2, storeWrite: 2,
        autoUpdateAllowed: true, migrationMode: 'none', rollbackSafe: true,
        files: { 'kun-agent.mjs': { target: `releases/${id}/kun-agent.mjs`, sha256 } }, runtimes: {} }
      if (trust) {
        const repo = await repository(home, { trust, fetch })
        const reference = repo.policy.releases.find((item) => item.releaseId === id)
        release = await loadRelease(repo, reference)
        // Production bootstraps install the signed runtime, never the incidental system Node.
        await rm(directory, { recursive: true, force: true })
        await prepareRelease(repo, release, directory)
      }
      await atomic(join(directory, 'release.json'), release)
      if (!trust) await atomic(join(directory, 'SKILL.md'), renderSkill(join(home, 'bin', 'kun-agent')))
      await health(directory)
      if (trust) {
        const prior = await readFile(join(home, 'updates', 'trust.json'), 'utf8').catch(() => null)
        if (prior && prior !== JSON.stringify(trust) + '\n') throw new UpdateError('update_trust_cannot_change')
        if (!prior) await atomic(join(home, 'updates', 'trust.json'), trust)
      }
      await activate(home, release, directory)
      await mkdir(join(home, 'bin'), { recursive: true, mode: 0o700 })
      // Old lib/ files and original agent.json/mailboxes are deliberately retained.
      const oldWrapper = join(home, 'bin', 'kun-agent')
      if (!active && await exists(oldWrapper)) await copyFile(oldWrapper, join(home, 'updates', 'legacy-wrapper'))
      await atomic(oldWrapper, wrapper(home, server), 0o700)
      await business(home, async () => { const store = new LocalStore(home), config = await store.readConfig(); if (config) await store.writeConfigUnlocked(config) })
      const skills = await updateSkills(home, renderSkill(join(home, 'bin', 'kun-agent'))).catch(() => ({ skillUpdatePending: true }))
      if (skills.skillUpdatePending) await atomic(join(home, 'updates', 'skill-status.json'), skills)
      return release
    } finally { await rm(directory, { recursive: true, force: true }) }
  })
}
