import { readFile } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import { join } from 'node:path'
import { main } from '../cli.js'
import { resolveHome } from '../local-store.js'
import { atomic, json } from '../update/files.js'
import { locked, business } from '../update/coordination.js'
import { update, rollback, setPolicy, recovery, currentRelease, assertAllowed } from '../update/install.js'
import { UPDATE_TRUST } from '../update/metadata.js'
import { updateSkills } from '../update/skills.js'
import { bootstrap } from './bootstrap.js'
import { renderSkill } from '../skill.js'

async function installedTrust(home) { return await json(join(home, 'updates', 'trust.json'), UPDATE_TRUST) }
export async function maybeUpdate(home, { force = false, ...options } = {}) {
  const trust = options.trust ?? await installedTrust(home)
  if (!trust) return { configured: false }
  const path = join(home, 'updates', 'checks.json'), state = await json(path, {})
  if (!force && Date.now() < (state.nextCheckAt ?? 0)) return state
  try {
    const result = await update(home, { ...options, trust, automatic: true, timeoutMs: 5000 })
    await atomic(path, { ...result, failures: 0, nextCheckAt: Date.now() + 6 * 3600_000 + Math.floor(Math.random() * 1800_000) })
    const installed = await currentRelease(home)
    if (installed) await updateSkills(home, await readFile(join(installed.directory, 'SKILL.md'), 'utf8'))
    return result
  } catch (error) {
    const failures = Math.min((state.failures ?? 0) + 1, 3)
    const result = { failures, lastError: /^[a-z_]{1,64}$/.test(error.code ?? '') ? error.code : 'update_check_failed', nextCheckAt: Date.now() + [900_000, 3600_000, 21600_000][failures - 1] }
    await atomic(path, result)
    return result
  }
}
async function child(home, argv, env) {
  const active = await currentRelease(home)
  if (!active) throw new Error('installation_missing')
  return new Promise((resolve, reject) => {
    const process = spawn(join(active.directory, 'runtime', 'bin', 'node'), [join(active.directory, 'kun-agent.mjs'), ...argv], { env, stdio: 'inherit' })
    process.on('error', reject); process.on('exit', (code, signal) => resolve(signal ? 1 : code ?? 1))
  })
}
export async function entry(argv, io = { stdout: process.stdout, stderr: process.stderr, stdin: process.stdin, env: process.env }) {
  const env = io.env ?? process.env, home = resolveHome(env)
  try {
    if (argv[0] === 'bootstrap') {
      await bootstrap(home, { program: env.KUN_BOOTSTRAP_PROGRAM, server: env.KUN_SERVER, legacyStopped: argv.includes('--legacy-stopped') })
      return 0
    }
    if (argv[0] === 'repair-only') { await locked(home, 'install', () => business(home, () => recovery(home))); return 0 }
    if (argv[0] === 'update') {
      const options = { trust: await installedTrust(home), fetch: io.fetch }
      let result
      if (argv[1] === 'policy') result = await setPolicy(home, argv[2])
      else if (argv[1] === 'rollback') result = await rollback(home, options)
      else {
        if (argv[1] && !['check', '--version', '--json'].includes(argv[1])) throw new Error('invalid_update_command')
        const at = argv.indexOf('--version')
        if (at >= 0 && !/^[0-9]+\.[0-9]+\.[0-9]+$/.test(argv[at + 1] ?? '')) throw new Error('invalid_update_version')
        result = await update(home, { ...options, check: argv[1] === 'check', version: at >= 0 ? argv[at + 1] : undefined })
      }
      if (argv[1] !== 'check') {
        const installed = await currentRelease(home)
        if (installed) await updateSkills(home, await readFile(join(installed.directory, 'SKILL.md'), 'utf8'))
      }
      io.stdout.write(JSON.stringify(result) + '\n'); return 0
    }
    if (argv[0] === 'launch') {
      const args = argv.slice(1)
      if (['version', 'help', 'skill', 'self-test'].includes(args[0])) return main(args, io)
      if (args[0] === 'update') return entry(args, io)
      const launcherId = (await currentRelease(home))?.release.releaseId
      const handoff = async () => {
        const active = await currentRelease(home)
        if (active?.release.releaseId !== launcherId) {
          if (typeof process.execve !== 'function') throw Object.assign(new Error('restart_launcher_required'), { exitCode: 6 })
          const node = join(active.directory, 'runtime', 'bin', 'node')
          process.execve(node, [node, join(active.directory, 'kun-agent.mjs'), 'launch', ...args], env)
        }
      }
      const watch = args[0] === 'watch', interval = Number(args[args.indexOf('--interval') + 1]) || 30
      do {
        await handoff()
        await maybeUpdate(home)
        await handoff()
        await assertAllowed(home)
        const config = await json(join(home, 'agent.json'))
        const generation = config?.bindingGeneration
        // A single iteration exits its business lease before the updater runs again.
        const code = await child(home, watch ? ['watch', '--once'] : args, env)
        if (code === 6) { await maybeUpdate(home, { force: true }); return 6 }
        if (!watch || code === 3 || code === 9 || args.includes('--once')) return code
        await new Promise((resolve) => setTimeout(resolve, Math.max(5, interval) * 1000))
        if ((await json(join(home, 'agent.json')))?.bindingGeneration !== generation || !await json(join(home, 'agent.json'))) return 3
      } while (watch)
    }
    return main(argv, io)
  } catch (error) { io.stderr.write(`kun-agent: ${error.code ?? error.message}\n`); return error.exitCode ?? 7 }
}
