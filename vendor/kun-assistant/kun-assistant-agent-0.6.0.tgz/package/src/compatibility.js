import { PROTOCOL_VERSION } from './version.js'
export class UnsupportedMessage extends Error {
  constructor(reason = 'version') { super(`invalid message: ${reason}; compatible update required`); this.code = 'upgrade_required' }
}
export function checkMessageCompatibility(message, fields) {
  if (message && typeof message === 'object' && (message.v !== PROTOCOL_VERSION || Object.keys(message).some((key) => !fields.has(key)))) {
    throw new UnsupportedMessage(message.v !== PROTOCOL_VERSION ? 'version' : 'unknown field')
  }
}
