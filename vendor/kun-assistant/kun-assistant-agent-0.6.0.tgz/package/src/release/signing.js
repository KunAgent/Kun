// Publishing only. This module is never imported by the client or Worker.
import { generateKeyPairSync, createHash, createPrivateKey, createPublicKey, sign } from 'node:crypto'
import { readFile, mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { Metadata, Root, Key, Signature, Snapshot, Timestamp, Targets, MetaFile, TargetFile } from '@tufjs/models'
import { Role } from '@tufjs/models/dist/role.js'
import { normalizeServer } from '../mailbox-client.js'
import { atomic, json, exists } from '../update/files.js'
const hash = (data) => createHash('sha256').update(data).digest('hex')
const expires = (days) => new Date(Date.now() + days * 86400_000).toISOString()
function publicKey(privateKey) {
  const value = createPublicKey(privateKey).export({ format: 'jwk' }).x
  const raw = Buffer.from(value, 'base64url').toString('hex')
  return new Key({ keyID: hash(raw), keyType: 'ed25519', scheme: 'ed25519', keyVal: { public: raw } })
}
async function signer(path) {
  const privateKey = createPrivateKey(await readFile(path)), key = publicKey(privateKey)
  return { key, sign: (data) => new Signature({ keyID: key.keyID, sig: sign(null, data, privateKey).toString('hex') }) }
}
async function signed(value, paths) {
  const metadata = new Metadata(value)
  for (const path of paths) metadata.sign((await signer(path)).sign, true)
  return metadata
}
export async function initialize(keys, output, origin) {
  origin = normalizeServer(origin)
  if (await exists(join(output, 'metadata', 'root.json'))) throw new Error('root_already_exists')
  await mkdir(keys, { recursive: true, mode: 0o700 })
  const root = new Root({ version: 1, expires: expires(365), consistentSnapshot: true })
  for (const role of ['root', 'targets', 'snapshot', 'timestamp']) {
    const count = role === 'root' ? 3 : 1
    for (let index = 1; index <= count; index++) {
      const name = role === 'root' ? `root-${index}` : role
      const path = join(keys, `${name}.pem`)
      if (await exists(path)) throw new Error('signing_key_already_exists')
      const generated = generateKeyPairSync('ed25519')
      await atomic(path, generated.privateKey.export({ type: 'pkcs8', format: 'pem' }), 0o600)
      root.addKey(publicKey(generated.privateKey), role)
    }
  }
  root.roles.root = new Role({ keyIDs: root.roles.root.keyIDs, threshold: 2 })
  const metadata = await signed(root, [join(keys, 'root-1.pem'), join(keys, 'root-2.pem')])
  root.keys[root.roles.root.keyIDs[0]].verifySignature(metadata)
  await atomic(join(output, 'metadata', 'root.json'), metadata.toJSON())
  await atomic(join(output, 'metadata', '1.root.json'), metadata.toJSON())
  const trust = { origin, root: metadata.toJSON() }
  await atomic(join(output, 'trust.json'), trust)
  return trust
}
export async function target(output, path, data) {
  const sha256 = hash(data), segments = path.split('/'), name = segments.pop()
  const location = join(output, 'targets', ...segments, `${sha256}.${name}`)
  if (await exists(location) && hash(await readFile(location)) !== sha256) throw new Error('immutable_target_changed')
  await atomic(location, data)
  return new TargetFile({ path, length: data.length, hashes: { sha256 } })
}
function meta(data, version) { return new MetaFile({ version, length: data.length, hashes: { sha256: hash(data) } }) }
const bytes = (metadata) => Buffer.from(JSON.stringify(metadata.toJSON()) + '\n')
export async function publish(output, keys, files, { now = Date.now() } = {}) {
  const previous = await json(join(output, 'metadata', 'targets.json'))
  const version = (previous?.signed.version ?? 0) + 1
  const targets = new Targets({ version, expires: expires(90) })
  if (previous) for (const [path, file] of Object.entries(previous.signed.targets)) targets.addTarget(TargetFile.fromJSON(path, file))
  for (const [path, data] of Object.entries(files)) {
    if (path.startsWith('releases/') && previous?.signed.targets[path] && previous.signed.targets[path].hashes.sha256 !== hash(Buffer.from(data))) throw new Error('immutable_release_changed')
    targets.addTarget(await target(output, path, Buffer.from(data)))
  }
  const signedTargets = await signed(targets, [join(keys, 'targets.pem')]), targetsBytes = bytes(signedTargets)
  await atomic(join(output, 'metadata', `${version}.targets.json`), targetsBytes)
  await atomic(join(output, 'metadata', 'targets.json'), targetsBytes)
  return refresh(output, keys)
}
export async function refresh(output, keys) {
  const targets = await readFile(join(output, 'metadata', 'targets.json'))
  const targetMetadata = JSON.parse(targets).signed
  if (Date.parse(targetMetadata.expires) <= Date.now()) throw new Error('targets_require_offline_resigning')
  const targetVersion = targetMetadata.version
  const prior = await json(join(output, 'metadata', 'snapshot.json'))
  const version = (prior?.signed.version ?? 0) + 1
  const snapshot = await signed(new Snapshot({ version, expires: expires(7), meta: { 'targets.json': meta(targets, targetVersion) } }), [join(keys, 'snapshot.pem')])
  const snapshotBytes = bytes(snapshot)
  await atomic(join(output, 'metadata', `${version}.snapshot.json`), snapshotBytes)
  await atomic(join(output, 'metadata', 'snapshot.json'), snapshotBytes)
  const priorTimestamp = await json(join(output, 'metadata', 'timestamp.json'))
  const timestamp = await signed(new Timestamp({ version: (priorTimestamp?.signed.version ?? 0) + 1, expires: expires(1), snapshotMeta: meta(snapshotBytes, version) }), [join(keys, 'timestamp.pem')])
  await atomic(join(output, 'metadata', 'timestamp.json'), bytes(timestamp))
  return { version }
}
export async function rotateRoot(output, oldKeys, newKeys) {
  const prior = await json(join(output, 'metadata', 'root.json'))
  const oldRoot = Metadata.fromJSON('root', prior)
  const replacement = await json(join(newKeys, 'public-root.json'))
  if (!replacement) throw new Error('new_keys_require_public_root')
  const next = Root.fromJSON({ ...replacement.signed, version: oldRoot.signed.version + 1, expires: expires(365) })
  const metadata = await signed(next, [join(oldKeys, 'root-1.pem'), join(oldKeys, 'root-2.pem'), join(newKeys, 'root-1.pem'), join(newKeys, 'root-2.pem')])
  oldRoot.verifyDelegate('root', metadata); metadata.verifyDelegate('root', metadata)
  await atomic(join(output, 'metadata', `${next.version}.root.json`), metadata.toJSON())
  await atomic(join(output, 'metadata', 'root.json'), metadata.toJSON())
  return { version: next.version }
}
