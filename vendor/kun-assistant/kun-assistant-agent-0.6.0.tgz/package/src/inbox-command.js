import { business } from './update/coordination.js'
import { sync, flushOutbox } from './sync.js'
import { formatRecord, describeOutbox } from './cli-output.js'
export async function inboxCommand(context, { root, flags, out, sleep, bin, signal }) {
  const wait = Number(flags.wait ?? 0)
  if (!Number.isInteger(wait) || wait < 0 || wait > 900) throw new Error('invalid_wait_seconds')
  const deadline = Date.now() + wait * 1000
  const timedOut = async () => {
    const value = { leaseId: null, expiresAt: null, items: [], hasMore: true, historyPending: true, synced: false, timedOut: true }
    await out(flags.json ? JSON.stringify(value) : 'Synchronization did not complete before the deadline; no messages confirmed. Run inbox again.')
    return 0
  }
  let result, batch
  try {
    for (;;) {
      if (signal?.aborted) return 0
      if (context.operationController?.signal.aborted) return timedOut()
      batch = await business(root.home, async () => {
        context.assertBinding?.()
        result = await sync(context)
        context.assertBinding?.()
        if (signal?.aborted || context.operationController?.signal.aborted) return { leaseId: null, items: [] }
        return result.historyPending ? { leaseId: null, expiresAt: null, items: [], hasMore: true }
          : context.store.delivery().claim({ now: context.now?.(), limit: Number(flags.limit ?? 10) })
      }, Math.max(0, (context.operationDeadline ?? deadline) - Date.now()))
      if (batch.items.length || Date.now() >= deadline) break
      await sleep(Math.min(2000, Math.max(0, deadline - Date.now())))
    }
  } catch (error) {
    if (context.operationController?.signal.aborted && !signal?.aborted) return timedOut()
    throw error
  }
  if (signal?.aborted || context.operationController?.signal.aborted) {
    if (batch.leaseId) await context.store.delivery().release(batch.leaseId)
    return signal?.aborted ? 0 : timedOut()
  }
  const resultBody = { ...batch, historyPending: result.historyPending, rejected: result.rejected, blocked: result.blocked, outbox: result.outbox }
  if (flags.json) await out(JSON.stringify(resultBody))
  else {
    const lines = batch.items.length ? [`${batch.items.length} item(s) from Kun:`, '', ...batch.items.map(record => formatRecord(record, bin) + '\n'),
      `Delivery lease: ${batch.leaseId} (expires ${batch.expiresAt}).`,
      `After reading this batch, run: ${bin} ack ${batch.leaseId}`, 'Confirming delivery does not complete a task. Reply working/done/blocked/failed separately.']
      : [result.historyPending ? 'History catch-up is incomplete; no messages confirmed. Run inbox again to continue.' : 'No unclaimed Kun messages. Use `kun-agent tasks` to resume already accepted tasks.']
    if (result.rejected.length) lines.push(`${result.rejected.length} message(s) failed authentication and were discarded.`)
    if (result.blocked.length) lines.push(`${result.blocked.length} message(s) need a compatible update and are saved for recovery.`)
    await out([...lines, ...describeOutbox(result.outbox)].join('\n'))
  }
  return 0
}
export async function deliveryCommand(context, command, id, out) {
  let result
  if (command === 'ack') {
    await sync(context)
    result = await context.store.delivery().commit(context, id)
    result.outbox = await flushOutbox(context)
  } else if (command === 'release') result = await context.store.delivery().release(id)
  else result = await context.store.delivery().renew(id, context.now?.())
  await out(JSON.stringify(result))
  return 0
}
