// Decrypted message objects exchanged through the mailbox. They are validated on both ends so a
// peer cannot smuggle unexpected fields into the assistant's prompt or the desktop's state.
import { randomUUID } from 'node:crypto'
import { checkMessageCompatibility } from './compatibility.js'
import { PROTOCOL_VERSION } from './version.js'

export const KINDS = Object.freeze(['task', 'note', 'reply', 'cancel'])
export const STATUSES = Object.freeze(['received', 'working', 'done', 'blocked', 'failed'])
export const MAX_BODY_BYTES = 32 * 1024
const MAX_TITLE_CHARS = 200
const FIELDS = new Set(['v', 'id', 'kind', 'from', 'createdAt', 'title', 'body', 'inReplyTo', 'status', 'deadline'])
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/

function fail(reason) {
  throw new TypeError(`invalid message: ${reason}`)
}

function iso(value, field) {
  if (typeof value !== 'string' || Number.isNaN(Date.parse(value))) fail(field)
}

/**
 * Builds a message from the sender's side. `from` is `kun` for the desktop and `assistant` for an
 * assistant VM; replies must name the message they answer and carry a status.
 */
export function createMessage({ kind, from, title, body, inReplyTo, status, deadline, id = randomUUID(), now = new Date() }) {
  const message = { v: PROTOCOL_VERSION, id, kind, from, createdAt: now.toISOString(), body: body ?? '' }
  if (title !== undefined && title !== '') message.title = title
  if (inReplyTo !== undefined) message.inReplyTo = inReplyTo
  if (status !== undefined) message.status = status
  if (deadline !== undefined) message.deadline = deadline
  return validateMessage(message, { from, id })
}

/** Checks a decrypted message; `from` and `id` must match what the envelope was routed as. */
export function validateMessage(message, { from, id }) {
  if (!message || typeof message !== 'object' || Array.isArray(message)) fail('not an object')
  checkMessageCompatibility(message, FIELDS)
  for (const key of Object.keys(message)) if (!FIELDS.has(key)) fail(`unknown field ${key}`)
  if (message.v !== PROTOCOL_VERSION) fail('version')
  if (message.id !== id || !UUID.test(message.id)) fail('id')
  if (message.from !== from || !['kun', 'assistant'].includes(from)) fail('from')
  if (!KINDS.includes(message.kind)) fail('kind')
  if (from === 'assistant' && ['task', 'cancel'].includes(message.kind)) fail('assistants cannot assign tasks')
  iso(message.createdAt, 'createdAt')
  if (typeof message.body !== 'string' || Buffer.byteLength(message.body) > MAX_BODY_BYTES) fail('body')
  if (message.title !== undefined && (typeof message.title !== 'string' || message.title.length > MAX_TITLE_CHARS || /[\r\n]/.test(message.title))) fail('title')
  if (message.inReplyTo !== undefined && !UUID.test(message.inReplyTo)) fail('inReplyTo')
  if (message.kind === 'reply' && message.inReplyTo === undefined) fail('reply without inReplyTo')
  if (message.kind === 'cancel' && message.inReplyTo === undefined) fail('cancel without inReplyTo')
  if (message.status !== undefined && !STATUSES.includes(message.status)) fail('status')
  if (message.kind === 'reply' && message.status === undefined) fail('reply without status')
  if (message.deadline !== undefined) iso(message.deadline, 'deadline')
  if (message.kind === 'task' && !message.title && !message.body) fail('empty task')
  return message
}
