import { inboxCommand, deliveryCommand } from './inbox-command.js'
// kun-agent: the program installed in a personal assistant's VM. Every command is short-lived:
// it syncs the mailbox, does one thing and exits, so it works on VMs that suspend between tasks.
import { json as updateJson } from './update/files.js'
import { reportRuntime } from './runtime-report.js'
import { registerSkill } from './update/skills.js'
import { readFileSync } from 'node:fs'
import { business } from './update/coordination.js'
import { readFile, mkdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { parseEnrollmentCode } from './enrollment-code.js'
import { MailboxRequestError, createAssistantClient, normalizeServer } from './mailbox-client.js'
import { LOGIN_WAIT_SECONDS, LoginEnded, completeLogin, fileRequest, startLogin, waitForDecision } from './login.js'
import { LocalStore, resolveHome } from './local-store.js'
import { MAX_BODY_BYTES, STATUSES } from './message.js'
import { SKILL_NAME, renderSkill } from './skill.js'
import { sendMessage, sync, failedOutgoingRecord } from './sync.js'
import { AGENT_VERSION, DEFAULT_SERVER, PROTOCOL_VERSION } from './version.js'
import { EXIT, USAGE, describeOutbox, explainError, formatRecord } from './cli-output.js'

const VALUE_FLAGS = new Set(['server', 'wait', 'status', 'file', 'title', 'install', 'interval', 'limit'])
const BOOLEAN_FLAGS = new Set(['json', 'yes', 'once', 'force', 'help'])
const COMMANDS = new Set(['help', 'version', 'self-test', 'skill', 'login', 'forget', 'inbox', 'show', 'reply', 'send', 'status', 'watch', 'ack', 'release', 'renew', 'tasks', 'recover', 'mcp', 'retry'])

class UsageError extends Error {}

export function parseArgs(argv) {
  const flags = {}
  const positional = []
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]
    if (arg === '--') { positional.push(...argv.slice(i + 1)); break }
    if (!arg.startsWith('--') || arg === '-') { positional.push(arg); continue }
    const [name, inline] = arg.slice(2).split(/=(.*)/s, 2)
    if (VALUE_FLAGS.has(name)) {
      const value = inline ?? argv[++i]
      if (value === undefined) throw new UsageError(`--${name} needs a value`)
      flags[name] = value
    } else if (BOOLEAN_FLAGS.has(name) && inline === undefined) {
      flags[name] = true
    } else {
      throw new UsageError(`unknown option --${name}`)
    }
  }
  return { command: positional.shift(), positional, flags }
}

function seconds(value, name, max) {
  const number = Number(value)
  if (!Number.isInteger(number) || number < 0 || number > max) throw new UsageError(`--${name} must be a whole number of seconds up to ${max}`)
  return number
}

async function readBody({ positional, flags }, io) {
  if (flags.file) {
    const text = await readFile(flags.file, 'utf8')
    if (Buffer.byteLength(text) > MAX_BODY_BYTES) throw new UsageError(`${flags.file} is larger than 32 KB; summarise it or put the full result somewhere Kun can reach and send the location`)
    return text
  }
  if (positional.length === 1 && positional[0] === '-') {
    let text = ''
    for await (const chunk of io.stdin) text += chunk
    return text
  }
  const text = positional.join(' ')
  if (Buffer.byteLength(text) > MAX_BODY_BYTES) throw new UsageError('the message is larger than 32 KB; use --file with a summary')
  return text
}

export async function main(argv, io = {}) {
  io = { env: process.env, stdout: process.stdout, stderr: process.stderr, stdin: process.stdin, ...io }
  let command
  try { command = parseArgs(argv).command } catch { return run(argv, io) }
  if (['show', 'reply', 'send', 'status', 'ack', 'release', 'renew', 'tasks', 'recover', 'retry'].includes(command)) {
    try { return await business(resolveHome(io.env), () => run(argv, io)) }
    catch (error) { io.stderr.write(error.message + '\n'); return error.exitCode ?? 1 }
  }
  return run(argv, io)
}

async function run(argv, io = {}) {
  const env = io.env ?? process.env
  const out = (text) => io.stdout.write(text.endsWith('\n') ? text : text + '\n')
  const err = (text) => io.stderr.write(text.endsWith('\n') ? text : text + '\n')
  const now = io.now ?? (() => new Date())
  const sleep = io.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)))
  const bin = env.KUN_AGENT_BIN || 'kun-agent'
  let store = new LocalStore(resolveHome(env))
  let operationTimer
  try {
    const args = parseArgs(argv)
    const { command, positional, flags } = args
    if (command === 'mcp') {
      const { runMcp } = await import('./mcp.js')
      return await runMcp(io)
    }
    if (command === 'self-test') {
      const { newKeyPair, pairingSecret, deriveKeys, seal, open } = await import('./crypto.js')
      const { randomUUID } = await import('node:crypto')
      const a = newKeyPair(), b = newKeyPair(), id = randomUUID()
      const keys = deriveKeys(pairingSecret({ enrollmentId: id, privateKey: a.privateKey, publicKey: a.publicKey, peerPublicKey: b.publicKey, hostPublicKey: a.publicKey, assistantPublicKey: b.publicKey }), id)
      if (open(keys, 'to_host', id, id, seal(keys, 'to_host', id, id, { ok: true })).ok !== true) throw new Error('crypto_self_test_failed')
      out('ready'); return EXIT.ok
    }
    if (!command || command === 'help' || flags.help) { out(USAGE); return EXIT.ok }
    if (!COMMANDS.has(command)) throw new UsageError(`unknown command ${command}`)
    if (command === 'version') { out(`kun-agent ${AGENT_VERSION} (protocol ${PROTOCOL_VERSION})`); return EXIT.ok }
    if (command === 'skill') {
      const text = renderSkill(bin)
      if (!flags.install) { out(text); return EXIT.ok }
      const dir = join(flags.install, SKILL_NAME)
      await mkdir(dir, { recursive: true })
      await writeFile(join(dir, 'SKILL.md'), text)
      await registerSkill(resolveHome(env), join(dir, 'SKILL.md'), text)
      out(`Installed the Kun mailbox skill at ${join(dir, 'SKILL.md')}`)
      return EXIT.ok
    }
    if (command === 'login') {
      const existing = await store.readConfig()
      if (existing && !flags.force) {
        err(`Already connected to Kun as "${existing.name}". Run \`${bin} forget --yes\` first to connect again.`)
        return EXIT.failure
      }
      const wait = flags.wait === undefined ? LOGIN_WAIT_SECONDS : seconds(flags.wait, 'wait', 900)
      let login
      if (positional[0]) {
        const code = parseEnrollmentCode(positional[0])
        if (!code) throw new UsageError('that is not a Kun enrollment code (it starts with KUN2-)')
        const server = normalizeServer(flags.server ?? env.KUN_SERVER ?? DEFAULT_SERVER)
        login = await startLogin({ store, code, server, now: now() })
      } else {
        login = await store.readLogin()
        if (!login) throw new UsageError('login needs the enrollment code from Kun (it starts with KUN2-)')
      }
      try {
        login = await fileRequest(store, login, { fetch: io.fetch, sleep })
      } catch (error) {
        if (error instanceof LoginEnded) { err(error.message); return EXIT.failure }
        throw error
      }
      out([`Join request sent to Kun as "${login.name}".`, `Verification code: ${login.verificationCode}`,
        'Tell the user this code and ask them to approve the request in Kun (Remote > Personal assistants).',
        'Kun must show exactly the same code; if it shows a different one, the user should reject the request.'].join('\n'))
      const decision = await waitForDecision(login, wait, { fetch: io.fetch, sleep })
      if (decision.state === 'approved') {
        const config = await completeLogin(store, login, decision, now())
        await reportRuntime(store.home, createAssistantClient({ server: config.server, assistantId: config.assistantId, token: config.token, fetch: io.fetch, sleep, signal: io.signal }), { force: true }).catch(() => {})
        out([`Approved. Connected to Kun as "${config.name}" (${config.kind}).`,
          `Next: install the guide with \`${bin} skill\`, then run \`${bin} send "Connected to Kun"\`.`].join('\n'))
        return EXIT.ok
      }
      if (decision.state === 'pending') {
        out(`Still waiting for the user to approve (verification code ${login.verificationCode}). Run \`${bin} login\` again to keep waiting.`)
        return EXIT.pending
      }
      await store.removeLogin()
      if (decision.state === 'rejected') {
        err('The user rejected this join request. Ask them for a new enrollment code if that was a mistake.')
        return EXIT.unauthorized
      }
      err('This enrollment code expired or was cancelled before it was approved. Ask the user to create a new one in Kun.')
      return EXIT.failure
    }
    const config = await store.readConfig()
    if (command === 'forget') {
      if (!flags.yes) throw new UsageError('forget removes this computer\'s Kun credentials; run it with --yes')
      await store.removeConfig()
      out(config ? `Removed the Kun credentials for "${config.name}". Received messages remain in ${store.home}.` : 'This computer was not connected to Kun.')
      return EXIT.ok
    }
    if (!config) {
      const pending = await store.readLogin()
      err(pending
        ? `Not connected yet: the join request (verification code ${pending.verificationCode}) is waiting for the user's approval in Kun. Run \`${bin} login\` to keep waiting.`
        : `Not connected to Kun yet. Ask the user for an enrollment code from Kun, then run \`${bin} login <code>\`.`)
      return EXIT.failure
    }
    const root = store
    const assertBinding = () => {
      let current
      try { current = JSON.parse(readFileSync(root.path('agent.json'), 'utf8')) } catch {}
      if (!current || current.assistantId !== config.assistantId || current.token !== config.token || current.bindingGeneration !== config.bindingGeneration) {
        throw new MailboxRequestError(401, 'binding_changed')
      }
    }
    assertBinding()
    store = await store.forConfig(config)
    const operationController = command === 'inbox' ? new AbortController() : null
    const operationDeadline = operationController ? Date.now() + (seconds(flags.wait ?? 0, 'wait', 900) * 1000 || 10000) : undefined
    if (operationController) { operationTimer = setTimeout(() => operationController.abort(), Math.max(0, operationDeadline - Date.now())); operationTimer.unref?.() }
    const signal = operationController ? AbortSignal.any([operationController.signal, ...(io.signal ? [io.signal] : [])]) : io.signal
    const client = createAssistantClient({ server: config.server, assistantId: config.assistantId, token: config.token, fetch: io.fetch, sleep, signal })
    const context = { store, client, config, now, assertBinding, operationController, operationDeadline }
    await reportRuntime(root.home, client).catch((error) => { if (error.status === 401 || error.status === 426) throw error })
    if (['ack', 'release', 'renew'].includes(command)) return await deliveryCommand(context, command, positional[0], out)
    if (command === 'inbox') return await inboxCommand(context, { root, flags, out, sleep, bin, signal: io.signal })
    if (command === 'retry') {
      const matches = (await store.failedOutgoing()).filter(item => positional[0]?.length >= 8 && item.messageId.startsWith(positional[0]))
      if (matches.length !== 1) throw new UsageError('retry needs one unambiguous failed message id from status')
      const { failure: _failure, ...item } = matches[0]
      await store.queueOutgoing(item)
      const result = await sync(context)
      const delivered = !(await store.outgoing()).some(v => v.messageId === item.messageId) && !(await store.failedOutgoing()).some(v => v.messageId === item.messageId)
      out(JSON.stringify({ messageId: item.messageId, delivered, outbox: result.outbox }))
      return delivered ? EXIT.ok : EXIT.failure
    }
    if (command === 'tasks') {
      const synced = await sync(context)
      if (synced.historyPending) { out(flags.json ? JSON.stringify({ items: [], historyPending: true }) : 'History catch-up is incomplete. Run inbox again before resuming work.'); return EXIT.ok }
      const items = await store.openRecords()
      out(flags.json ? JSON.stringify({ items }) : items.map(record => formatRecord(record, bin)).join('\n') || 'No open Kun tasks.')
      return EXIT.ok
    }
    if (command === 'recover') {
      if (!flags.yes) throw new UsageError('recover --yes resumes from retained history; expired server history cannot be restored. Local tasks are kept.')
      if (!await client.reliable()) throw new UsageError('This server does not support replay history.')
      for (const direction of ['to_assistant', 'to_host']) {
        let floor = 0
        try { await client.history(0, direction) } catch (error) { if (error.code !== 'assistant_history_expired') throw error; floor = error.floorSequence }
        await store.saveHistoryCursor(floor, direction === 'to_assistant' ? 'incoming' : 'sent')
      }
      out('History cursor reset. Run kun-agent inbox to recover retained messages; already accepted tasks remain available in kun-agent tasks.')
      return EXIT.ok
    }
    if (command === 'show') {
      await sync(context)
      const record = await store.find(positional[0]) ?? await failedOutgoingRecord(context, positional[0])
      if (!record) { err(`No message ${positional[0] ?? ''} in the local mailbox. Run \`${bin} inbox\`.`); return EXIT.failure }
      out(flags.json ? JSON.stringify(record) : formatRecord(record, bin))
      return EXIT.ok
    }
    if (command === 'reply' || command === 'send') {
      let fields
      if (command === 'reply') {
        if (!STATUSES.includes(flags.status)) throw new UsageError(`reply needs --status ${STATUSES.join('|')}`)
        // The reply only needs the local copy; while offline it is queued and sent later.
        const synced = await sync(context).catch((error) => { if (flags.status === 'working' || !(error instanceof MailboxRequestError) || error.status === 401) throw error })
        if (flags.status === 'working' && synced?.historyPending) throw new Error('History catch-up is incomplete; run inbox before starting work.')
        const record = await store.find(positional.shift())
        if (!record) { err(`No such message in the local mailbox. Run \`${bin} inbox\` to see open items.`); return EXIT.failure }
        if (record.status === 'cancelled') { err('Kun cancelled this task; no reply is needed.'); return EXIT.failure }
        if (['done', 'failed'].includes(record.status)) { err('This task is already finished. Use send for a follow-up note; do not restart it.'); return EXIT.failure }
        fields = { kind: 'reply', inReplyTo: record.message.id, status: flags.status, body: await readBody(args, io) }
      } else {
        const body = await readBody(args, io)
        if (!body.trim() && !flags.title) throw new UsageError('send needs a message')
        fields = { kind: 'note', title: flags.title, body }
      }
      if (command === 'reply') await store.delivery().acknowledgeTask(context, fields.inReplyTo)
      const sent = await sendMessage({ ...context, ...fields })
      if (command === 'reply' && fields.status !== 'received') await store.setStatus(fields.inReplyTo, fields.status, now())
      const refused = sent.outbox.dropped.some(item => item.messageId === sent.message.id)
      out([refused ? `Refused by Kun (${sent.message.id}); retained locally. Inspect with show and explicitly retry only after addressing the error.` : sent.delivered ? `Sent to Kun (${sent.message.id.slice(0, 8)}).` : `Queued for Kun (${sent.message.id.slice(0, 8)}); it will be sent on the next kun-agent command.`, ...describeOutbox(sent.outbox)].join('\n'))
      return refused ? EXIT.failure : EXIT.ok
    }
    if (command === 'status') {
      const outbox = await sync(context)
      const remote = (await client.status()).assistant
      const open = await store.openRecords()
      const queued = (await store.outgoing()).length
      const failedOutgoing = (await store.failedOutgoing()).map(item => ({ id: item.messageId, code: item.failure }))
      if (flags.json) {
        out(JSON.stringify({ name: config.name, kind: config.kind, server: config.server, assistantId: config.assistantId, home: store.home, version: AGENT_VERSION, updates: await updateJson(root.path('updates', 'checks.json'), { configured: false }), open: open.length, queued, failedOutgoing, reliableMailbox: await client.reliable(), historyPending: outbox.historyPending, remote }))
      } else {
        out([`Connected to Kun as "${config.name}" (${config.kind}) via ${config.server}.`, `Open items: ${open.length}. Messages waiting to be sent: ${queued}. Not yet collected by Kun: ${remote.pendingToHost}.`, `Failed outgoing: ${failedOutgoing.length}. Inspect a failed message with kun-agent show <id>.`, `Mailbox folder: ${store.home}. kun-agent ${AGENT_VERSION}.`, ...describeOutbox(outbox.outbox)].join('\n'))
      }
      return EXIT.ok
    }
    if (command === 'watch') {
      const interval = seconds(flags.interval ?? 30, 'interval', 3600)
      if (interval < 5 && !flags.once) throw new UsageError('--interval must be at least 5 seconds')
      out(`Watching the Kun mailbox every ${interval}s. Press Ctrl-C to stop.`)
      let failures = 0
      for (;;) {
        try {
          await business(root.home, async () => {
          assertBinding()
          const result = await sync(context)
          assertBinding()
          const batch = result.historyPending ? { items: [], leaseId: null } : await store.delivery().claim({ now: now() })
          if (batch.items.length) {
            for (const record of batch.items) out(formatRecord(record, bin) + '\n')
            out(`Delivery lease: ${batch.leaseId}. After reading, run: ${bin} ack ${batch.leaseId}`)
          }
          for (const line of describeOutbox(result.outbox)) err(line)
          })
          failures = 0
        } catch (error) {
          failures = Math.min(failures + 1, 5)
          const [code, text] = explainError(error)
          err(text)
          if (code === EXIT.unauthorized || code === EXIT.upgradeRequired || code === EXIT.vipRequired) return code
        }
        if (flags.once) return EXIT.ok
        await sleep(Math.min(600000, interval * 1000 * 2 ** failures) * (failures ? 0.8 + Math.random() * 0.4 : 1))
      }
    }
    throw new UsageError(`unknown command ${command}`)
  } catch (error) {
    if (error instanceof UsageError) { err(`kun-agent: ${error.message}\nRun \`${bin} help\` for usage.`); return EXIT.usage }
    const [code, text] = explainError(error)
    err(text)
    return code
  } finally { clearTimeout(operationTimer) }
}
