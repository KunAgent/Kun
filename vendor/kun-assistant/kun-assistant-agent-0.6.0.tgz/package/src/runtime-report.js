import { join } from 'node:path'
import { atomic, json } from './update/files.js'
import { locked } from './update/coordination.js'
import { AGENT_VERSION, PROTOCOL_VERSION } from './version.js'
export async function reportRuntime(home, client, { force = false } = {}) {
  return locked(home, 'report', async () => {
    const config = await json(join(home, 'agent.json'))
    if (!config) return
    const path = join(home, 'updates', 'runtime-report.json'), previous = await json(path, {})
    const binding = `${config.server}|${config.assistantId}`
    const state = await json(join(home, 'updates', 'state.json'), { generation: 0 })
    const checks = await json(join(home, 'updates', 'checks.json'), {})
    if (!force && previous.lastError === checks.lastError && previous.binding === binding && previous.generation === state.generation && Date.now() - previous.at < 1800_000) return
    const reportSequence = (previous.sequence ?? 0) + 1
    await atomic(path, { ...previous, sequence: reportSequence })
    const code = typeof checks.lastError === 'string' && /^[a-z_]{1,64}$/.test(checks.lastError) ? checks.lastError : null
    const report = { agentVersion: AGENT_VERSION, releaseId: state.current ?? `source-${AGENT_VERSION}`, nodeVersion: process.versions.node,
      installGeneration: state.generation ?? 0, reportSequence, wireRead: [PROTOCOL_VERSION], lastError: code ?? (checks.available && checks.lastResult !== 'updated' ? 'update_available' : null) }
    try { await client.runtime(report) }
    catch (error) { if (error.status === 404) return; throw error }
    await atomic(path, { binding, generation: state.generation, sequence: reportSequence, lastError: checks.lastError, at: Date.now() })
  })
}
