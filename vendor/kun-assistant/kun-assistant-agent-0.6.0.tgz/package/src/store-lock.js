// A filesystem lock shared by separate CLI/watch processes. Heartbeats keep long writes
// alive; a terminated writer's lock expires so the next invocation can recover.
import { mkdir } from 'node:fs/promises'
import lockfile from 'proper-lockfile'

export async function withStoreLock(home, work) {
  await mkdir(home, { recursive: true, mode: 0o700 })
  const release = await lockfile.lock(home, {
    realpath: false, stale: 10_000, update: 2000,
    retries: { retries: 400, minTimeout: 50, maxTimeout: 100, factor: 1 }
  })
  try { return await work() } finally { await release() }
}
