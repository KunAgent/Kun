// End-to-end sealing for the assistant mailbox.
//
// Pairing: the desktop creates an X25519 key per enrollment and puts only its public half in the
// enrollment code. The agent creates its own key pair and sends its public half with the join
// request. Both ends compute the same shared secret by X25519; Kun's servers relay public keys
// only. Both ends also show a verification code derived from the enrollment id and the two public
// keys, so the user can tell when a request was replaced on the way before approving it.
//
// Messages: from the shared secret both ends derive
//   to-assistant   — AES-256-GCM key for desktop → assistant messages
//   to-host        — AES-256-GCM key for assistant → desktop messages
// Separate keys per direction stop the server reflecting a message back to its sender, and the
// associated data binds every envelope to its enrollment, direction and message id.
import {
  createCipheriv, createDecipheriv, createHash, createPrivateKey, createPublicKey, diffieHellman,
  generateKeyPairSync, hkdfSync, randomBytes
} from 'node:crypto'

const LABEL = 'kun-assistant/v1'
const ENVELOPE_VERSION = 1
const NONCE_BYTES = 12
const TAG_BYTES = 16
export const DIRECTIONS = Object.freeze(['to_assistant', 'to_host'])

const BASE32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'
const KEY = /^[A-Za-z0-9_-]{43}$/

/** A new X25519 key pair as unpadded base64url strings (32 bytes each). */
export function newKeyPair() {
  const jwk = generateKeyPairSync('x25519').privateKey.export({ format: 'jwk' })
  return { publicKey: jwk.x, privateKey: jwk.d }
}

export function validPublicKey(value) {
  return typeof value === 'string' && KEY.test(value) && Buffer.from(value, 'base64url').length === 32
}

function uuidBytes(id) {
  const hex = String(id).replaceAll('-', '')
  if (!/^[0-9a-f]{32}$/.test(hex)) throw new TypeError('invalid enrollment id')
  return Buffer.from(hex, 'hex')
}

function derive(secret, enrollmentId, purpose) {
  if (!Buffer.isBuffer(secret) || secret.length !== 32) throw new TypeError('invalid secret')
  return Buffer.from(hkdfSync('sha256', secret, uuidBytes(enrollmentId), `${LABEL}/${purpose}`, 32))
}

export function sha256Hex(value) {
  return createHash('sha256').update(value).digest('hex')
}

/**
 * The mailbox secret both ends of a pairing compute: the desktop with its enrollment key and the
 * assistant's public key, the assistant with its own key and the desktop's public key.
 */
export function pairingSecret({ enrollmentId, privateKey, publicKey, peerPublicKey, hostPublicKey, assistantPublicKey }) {
  if (![publicKey, peerPublicKey, hostPublicKey, assistantPublicKey].every(validPublicKey)) throw new TypeError('invalid public key')
  const shared = diffieHellman({
    privateKey: createPrivateKey({ key: { kty: 'OKP', crv: 'X25519', d: privateKey, x: publicKey }, format: 'jwk' }),
    publicKey: createPublicKey({ key: { kty: 'OKP', crv: 'X25519', x: peerPublicKey }, format: 'jwk' })
  })
  if (shared.every((byte) => byte === 0)) throw new Error('invalid peer key')
  return Buffer.from(hkdfSync('sha256', shared, uuidBytes(enrollmentId), `${LABEL}/pairing|${hostPublicKey}|${assistantPublicKey}`, 32))
}

/**
 * Ten characters (50 bits) both screens show for one request, such as `7KQ2M-X9CHD`. A relay that
 * swapped in its own key would need about 2^50 attempts to match it within the code's lifetime.
 */
export function verificationCode(enrollmentId, hostPublicKey, assistantPublicKey) {
  const digest = createHash('sha256').update(`${LABEL}/verify|${enrollmentId}|${hostPublicKey}|${assistantPublicKey}`).digest()
  let bits = 0n
  for (const byte of digest.subarray(0, 7)) bits = (bits << 8n) | BigInt(byte)
  bits >>= 6n
  let code = ''
  for (let i = 9; i >= 0; i--) code += BASE32[Number((bits >> BigInt(i * 5)) & 31n)]
  return `${code.slice(0, 5)}-${code.slice(5)}`
}

/** Message keys for one enrollment, from its pairing secret. */
export function deriveKeys(secret, enrollmentId) {
  return {
    to_assistant: derive(secret, enrollmentId, 'to-assistant'),
    to_host: derive(secret, enrollmentId, 'to-host')
  }
}

function associatedData(direction, enrollmentId, messageId) {
  if (!DIRECTIONS.includes(direction)) throw new TypeError('invalid direction')
  return Buffer.from(`${LABEL}|${direction}|${enrollmentId}|${messageId}`, 'utf8')
}

/** Seals a JSON-serialisable value into a base64url envelope. */
export function seal(keys, direction, enrollmentId, messageId, value) {
  const nonce = randomBytes(NONCE_BYTES)
  const cipher = createCipheriv('aes-256-gcm', keys[direction], nonce)
  cipher.setAAD(associatedData(direction, enrollmentId, messageId))
  const body = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()])
  return Buffer.concat([Buffer.from([ENVELOPE_VERSION]), nonce, body, cipher.getAuthTag()]).toString('base64url')
}

/** Opens an envelope; throws when it was altered, misrouted or sealed with another key. */
export function open(keys, direction, enrollmentId, messageId, envelope) {
  const raw = Buffer.from(String(envelope), 'base64url')
  if (raw.length < 1 + NONCE_BYTES + TAG_BYTES + 1 || raw[0] !== ENVELOPE_VERSION) {
    throw new Error(raw[0] > ENVELOPE_VERSION ? 'unsupported envelope' : 'invalid envelope')
  }
  const nonce = raw.subarray(1, 1 + NONCE_BYTES)
  const tag = raw.subarray(raw.length - TAG_BYTES)
  const decipher = createDecipheriv('aes-256-gcm', keys[direction], nonce)
  decipher.setAAD(associatedData(direction, enrollmentId, messageId))
  decipher.setAuthTag(tag)
  const plain = Buffer.concat([decipher.update(raw.subarray(1 + NONCE_BYTES, raw.length - TAG_BYTES)), decipher.final()])
  return JSON.parse(plain.toString('utf8'))
}
