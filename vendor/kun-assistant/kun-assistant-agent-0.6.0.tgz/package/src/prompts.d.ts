import type { AssistantKind, KnownAssistantKind } from './host.js'

export declare const ASSISTANT_KINDS: readonly KnownAssistantKind[]
export declare function validAssistantKind(kind: unknown): kind is AssistantKind
/** Where kun-agent lives on that assistant's computer (`/workspace/.kun` for Grok Bot). */
export declare function agentHome(kind: AssistantKind): string
export declare function installPrompt(input: { code: string; kind?: AssistantKind; server?: string; locale?: 'zh' | 'en' }): string
/** A one-line nudge to send through the assistant's own channel when a task is urgent. */
export declare function wakeMessage(input?: { kind?: AssistantKind; locale?: 'zh' | 'en' }): string
