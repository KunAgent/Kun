// Enrollment code shown to the user inside the install prompt:
//   KUN2-<enrollment id, 32 hex>-<desktop's X25519 public key, 43 base64url characters>
// It holds no secret. It tells the agent where to ask and whom to pair with; the desktop user
// still has to approve the request after comparing verification codes.
import { randomUUID } from 'node:crypto'
import { newKeyPair, validPublicKey } from './crypto.js'

const PATTERN = /^KUN2-([0-9a-f]{32})-([A-Za-z0-9_-]{43})$/

function dashed(hex) {
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
}

/** A new enrollment: its id, the desktop's key pair for it, and the code to put in the prompt. */
export function newEnrollment() {
  const enrollmentId = randomUUID()
  const keyPair = newKeyPair()
  return { enrollmentId, keyPair, code: formatEnrollmentCode(enrollmentId, keyPair.publicKey) }
}

export function formatEnrollmentCode(enrollmentId, hostPublicKey) {
  return `KUN2-${enrollmentId.replaceAll('-', '')}-${hostPublicKey}`
}

/** Accepts the code with surrounding whitespace or quotes, as assistants often paste it. */
export function parseEnrollmentCode(value) {
  const match = PATTERN.exec(String(value ?? '').trim().replace(/^["'`]+|["'`]+$/g, ''))
  if (!match || !validPublicKey(match[2])) return null
  return { enrollmentId: dashed(match[1]), hostPublicKey: match[2] }
}
