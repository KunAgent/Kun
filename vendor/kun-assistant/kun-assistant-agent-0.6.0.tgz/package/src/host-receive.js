import { open } from './crypto.js'
import { validateMessage } from './message.js'
import { UnsupportedMessage } from './compatibility.js'

/** Persist before receipt; retain unsupported envelopes and missing-key messages for recovery. */
export async function receiveHost(host, handler) {
  const reliable = await host.client.reliable()
  let received = 0, rejected = 0, complete = true
  const assistants = new Map((await host.client.list()).assistants.map(a => [a.id, a]))
  if (reliable && host.historyState && host.restoreOutgoing) {
    for (const assistant of assistants.values()) {
      const keys = await host.keys(assistant.enrollmentId)
      if (!keys) continue
      const key = assistant.id + ':sent'
      let cursor = await host.historyState.get(key)
      for (let n = 0; n < 16; n++) {
        const batch = await host.client.history(assistant.id, cursor, 'to_assistant')
        for (const item of batch.messages) {
          const message = validateMessage(open(keys, 'to_assistant', assistant.enrollmentId, item.id, item.envelope), { from: 'kun', id: item.id })
          await host.restoreOutgoing({ assistant, message, storedAt: item.createdAt, receivedAt: item.receivedAt, consumedAt: item.consumedAt })
        }
        cursor = batch.nextSequence
        await host.historyState.set(key, cursor)
        if (!batch.hasMore) break
        if (n === 15) complete = false
      }
    }
  }
  async function process(item) {
    const assistant = assistants.get(item.assistantId)
    let message
    try {
      const keys = assistant && await host.keys(assistant.enrollmentId)
      if (!keys) {
        if (host.blocked) { await host.blocked.save(item); return 'blocked' }
        return 'held'
      }
      message = validateMessage(open(keys, 'to_host', assistant.enrollmentId, item.id, item.envelope), { from: 'assistant', id: item.id })
    } catch (error) {
      if (error instanceof UnsupportedMessage || error.message === 'unsupported envelope') {
        if (host.blocked) { await host.blocked.save(item); return 'blocked' }
        return 'held'
      }
      await handler({ assistant, messageId: item.id, error })
      rejected++; return 'accepted'
    }
    await handler({ assistant, message })
    received++
    if (host.blocked) await host.blocked.remove(item.id)
    return 'accepted'
  }
  async function page(items) {
    const handled = [], consumed = []
    for (const item of items) {
      const result = await process(item)
      if (result === 'held') break
      handled.push(item.id)
      if (result === 'accepted') consumed.push(item.id)
    }
    if (handled.length) await host.client.ack(handled)
    if (reliable && consumed.length) await host.client.consume(consumed)
    return handled.length === items.length
  }
  const saved = host.blocked ? await host.blocked.records() : []
  for (let i = 0; i < saved.length; i += 32) await page(saved.slice(i, i + 32))
  if (reliable && host.historyState) {
    for (const assistant of assistants.values()) {
      let cursor = await host.historyState.get(assistant.id)
      for (let n = 0; n < 16; n++) {
        const batch = await host.client.history(assistant.id, cursor)
        if (!batch.messages.length) break
        if (!await page(batch.messages)) { complete = false; break }
        cursor = batch.nextSequence
        await host.historyState.set(assistant.id, cursor)
        if (!batch.hasMore) break
        if (n === 15) complete = false
      }
    }
  } else {
    for (let n = 0; n < 16; n++) {
      const { messages } = await host.client.inbox()
      if (!messages.length) break
      if (!await page(messages)) { complete = false; break }
      if (messages.length < 32) break
      if (n === 15) complete = false
    }
  }
  return { received, rejected, ...(host.historyState ? { complete } : {}) }
}
