// Text shown to the assistant. It is read by a language model as often as by a person, so every
// block is self-describing and ends with the exact command to run next.
import { MailboxRequestError } from './mailbox-client.js'

export const EXIT = Object.freeze({ ok: 0, failure: 1, usage: 2, unauthorized: 3, offline: 4, pending: 5, upgradeRequired: 6, updateFailed: 7, busy: 8, vipRequired: 9 })

export const USAGE = `kun-agent: Kun's mailbox for this assistant

Usage:
  kun-agent login <code> [--wait <seconds>]  Ask to join Kun with the code from the user;
                                              shows a verification code and waits for approval
  kun-agent login                             Keep waiting for a request already sent
  kun-agent inbox [--wait <seconds>] [--json] Claim new messages with a renewable delivery lease
  kun-agent ack <lease-id>                    Confirm a batch was handed to the consumer
  kun-agent release <lease-id>                Return an unhandled batch for redelivery
  kun-agent renew <lease-id>                  Extend a live delivery lease
  kun-agent tasks [--json]                    Resume already accepted open tasks
  kun-agent retry <failed-message-id>         Explicitly retry the same retained envelope
  kun-agent recover --yes                     Recover retained history after a cursor expiry
  kun-agent mcp                               Serve wait/ack/reply tools over MCP stdio
  kun-agent show <id> [--json]                Show one message in full
  kun-agent reply <id> --status <status> [--file <path> | <text> | -]
                                              Report progress or a result to Kun
                                              status: received, working, done, blocked, failed
  kun-agent send [--title <title>] [--file <path> | <text> | -]
                                              Send Kun a note
  kun-agent watch [--interval <seconds>]      Keep checking and print tasks as they arrive
  kun-agent status [--json]                   Check the connection and local mailbox
  kun-agent skill [--install <skills-dir>]    Print or install the usage guide (SKILL.md)
  kun-agent forget --yes                      Remove this computer's Kun credentials
  kun-agent update [check | rollback | policy auto-compatible|manual] [--version <version>]
  kun-agent version

Messages are kept in $KUN_HOME (default ~/.kun). Ids may be shortened to 8 characters.
`

function when(iso) {
  return iso ? iso.replace('T', ' ').replace(/\.\d+Z$/, 'Z') : ''
}

export function formatRecord({ message, status, receivedAt }, bin) {
  const short = message.id.slice(0, 8)
  const head = [`[${message.kind}] ${short}`, message.title, `received ${when(receivedAt)}`]
  if (message.deadline) head.push(`deadline ${when(message.deadline)}`)
  const lines = [`── ${head.filter(Boolean).join(' · ')}`, `status: ${status}${message.inReplyTo ? ` · about ${message.inReplyTo.slice(0, 8)}` : ''}`]
  if (message.body) lines.push('', message.body.trimEnd())
  if (message.kind === 'task') {
    lines.push('', `reply: ${bin} reply ${short} --status working|done|blocked|failed "<details>"`)
  } else if (message.kind === 'cancel') {
    lines.push('', 'Kun cancelled the task above. Stop working on it and do not reply to it.')
  }
  return lines.join('\n')
}

export function describeOutbox(outbox) {
  if (!outbox) return []
  const lines = []
  if (outbox.pending) lines.push(`${outbox.pending} message(s) to Kun are queued and will be retried on the next command (${outbox.blocked}).`)
  for (const dropped of outbox.dropped ?? []) lines.push(`Message ${dropped.messageId.slice(0, 8)} was refused by the server (${dropped.code}) and retained locally for inspection with show.`)
  return lines
}

/** Maps request failures to an exit code and an instruction the assistant can act on. */
export function explainError(error) {
  if (error?.code === 'unsupported_local_binding') return [EXIT.upgradeRequired, 'The local binding was written by a newer program. Upgrade this program; do not delete or recreate the binding.']
  if (error instanceof MailboxRequestError) {
    if (error.code === 'binding_changed') return [EXIT.unauthorized, 'unauthorized: this process belongs to an older binding generation. Restart the command; keep credentials and tasks, do not run forget or login.']
    if (error.code === 'vip_personal_assistant_required') return [EXIT.vipRequired, 'Personal assistants require an active Kun Pro or Max membership. Pause mailbox checks until the user restores membership. Credentials and queued messages are preserved; do not run forget or login.']
    if (error.status === 426) return [EXIT.upgradeRequired, 'Kun requires a compatible update. Run kun-agent update; queued messages are preserved.']
    if (error.status === 401) {
      return [EXIT.unauthorized, 'unauthorized: Kun no longer accepts this connection (the user removed this assistant or its computer). Stop checking the Kun mailbox and tell the user; they can add this assistant again in Kun.']
    }
    if (error.status === 0) return [EXIT.offline, `${error.message}. Check the network (or ask the user to allow access to the Kun server) and try again later.`]
    if (error.status === 404) return [EXIT.failure, 'The Kun server does not offer the assistant mailbox (404). Check --server / KUN_SERVER, or tell the user it is not enabled yet.']
    if (error.status === 429) return [EXIT.offline, 'The Kun server is rate limiting this assistant (429). Wait a minute and try again.']
    if (error.status === 409 && error.code === 'assistant_limit') return [EXIT.failure, 'The mailbox is full because Kun has not collected earlier messages. Try again later.']
    return [EXIT.failure, `The Kun server refused the request (${error.status} ${error.code}).`]
  }
  return [EXIT.failure, error?.message ?? String(error)]
}
