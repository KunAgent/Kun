import { MailboxRequestError } from './mailbox-client.js'
const ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
const integer = value => Number.isSafeInteger(value) && value >= 0
export function historyPage(value, after, assistantId) {
  const fail = () => { throw new MailboxRequestError(502, 'invalid_history') }
  if (!value || !integer(value.floorSequence) || !integer(value.latestSequence) || !integer(value.nextSequence)
    || value.floorSequence > value.latestSequence || value.nextSequence > value.latestSequence
    || !Array.isArray(value.messages) || value.messages.length > 32 || typeof value.hasMore !== 'boolean' || typeof value.resetRequired !== 'boolean') fail()
  if (value.resetRequired) {
    if (after >= value.floorSequence || value.messages.length || value.hasMore) fail()
    const error = new MailboxRequestError(410, 'assistant_history_expired', `History before ${value.floorSequence} has expired. Explicitly recover from the retained history; existing local tasks are preserved.`)
    error.floorSequence = value.floorSequence
    throw error
  }
  let sequence = after
  for (const item of value.messages) {
    if (!item || !ID.test(item.id) || item.assistantId !== assistantId || item.sequence !== sequence + 1
      || typeof item.envelope !== 'string' || !/^[A-Za-z0-9_-]{32,65536}$/.test(item.envelope)
      || !Number.isFinite(Date.parse(item.createdAt))
      || ![item.receivedAt, item.consumedAt].every(t => t === null || typeof t === 'string' && Number.isFinite(Date.parse(t)))) fail()
    sequence = item.sequence
  }
  if (sequence !== value.nextSequence || value.hasMore !== (sequence < value.latestSequence) || after < value.floorSequence) fail()
  return value
}
export function capabilities(request) {
  let cached, checkedAt = 0
  return () => {
    if (cached && Date.now() - checkedAt >= 60000) cached = undefined
    return cached ??= request('GET', 'capabilities').then(value => {
    if (value.reliableMailbox !== 1 || value.consumptionReceipts !== true) throw new MailboxRequestError(502, 'invalid_capabilities')
    checkedAt = Date.now(); return true
  }).catch(error => {
    if (error.status === 404) { checkedAt = Date.now(); return false }
    cached = undefined; throw error
  })
  }
}
export function verifySend(value, id) {
  if (value?.messageId !== id) throw new MailboxRequestError(502, 'invalid_send_receipt')
  return value
}
