import { readdir, stat, readFile, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { atomic, privateDirectory } from './update/files.js'
import { withStoreLock } from './store-lock.js'
const ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/
const LIMIT = 16 * 1024 * 1024
export class BlockedStore {
  constructor(home) { this.home = home }
  async records() {
    await privateDirectory(this.home)
    const names = (await readdir(this.home)).filter((name) => ID.test(name.replace(/\.json$/, '')))
    return Promise.all(names.map(async (name) => JSON.parse(await readFile(join(this.home, name), 'utf8'))))
  }
  async save(envelope) {
    if (!ID.test(envelope.id) || typeof envelope.envelope !== 'string' || envelope.envelope.length > 65536) throw new Error('invalid_blocked_envelope')
    await privateDirectory(this.home)
    return withStoreLock(this.home, async () => {
      const path = join(this.home, `${envelope.id}.json`)
      const prior = await readFile(path, 'utf8').catch((e) => { if (e.code !== 'ENOENT') throw e })
      if (prior) { if (JSON.parse(prior).envelope !== envelope.envelope) throw new Error('blocked_id_conflict'); return }
      let size = 0
      for (const name of await readdir(this.home)) size += (await stat(join(this.home, name))).size
      const record = { id: envelope.id, assistantId: envelope.assistantId, envelope: envelope.envelope, createdAt: envelope.createdAt }
      const text = JSON.stringify(record) + '\n'
      if (size + Buffer.byteLength(text) > LIMIT) throw new Error('blocked_mailbox_full')
      await atomic(path, text)
    })
  }
  remove(id) { if (!ID.test(id)) throw new Error('invalid_message_id'); return rm(join(this.home, `${id}.json`), { force: true }) }
}
