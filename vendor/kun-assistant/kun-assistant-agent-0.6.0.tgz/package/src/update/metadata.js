import { DownloadHTTPError } from 'tuf-js/dist/error.js'
import { Updater, BaseFetcher } from 'tuf-js'
import { readFile, mkdir, cp, readlink, symlink, rename, readdir, rm } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import { locked } from './coordination.js'
import { join } from 'node:path'
import { atomic, exists, json, syncDir } from './files.js'
import { normalizeServer } from '../mailbox-client.js'

export const UPDATE_TRUST = typeof __KUN_UPDATE_TRUST__ === 'undefined' ? null : __KUN_UPDATE_TRUST__
export class UpdateError extends Error {
  constructor(code, exitCode = 7) { super(code); this.code = code; this.exitCode = exitCode }
}
class ReleaseFetcher extends BaseFetcher {
  constructor(origin, fetch, timeoutMs) { super(); this.origin = origin; this.request = fetch; this.timeoutMs = timeoutMs; this.deadline = Date.now() + timeoutMs }
  async fetch(url) {
    const parsed = new URL(url)
    if (parsed.origin !== this.origin || !/^\/assistant\/updates\/(metadata|targets)\/[a-zA-Z0-9_./-]+$/.test(parsed.pathname) || parsed.pathname.includes('..') || parsed.search) throw new UpdateError('unsafe_update_url')
    const response = await this.request(url, { redirect: 'error', credentials: 'omit', signal: AbortSignal.timeout(Math.max(1, this.deadline - Date.now())) })
    if (!response.ok) {
      throw new DownloadHTTPError(`HTTP ${response.status}`, response.status)
    }
    return response.body
  }
}
export function validatePolicy(value) {
  if (!value || value.schema !== 1 || !Number.isSafeInteger(value.policySequence) || value.policySequence < 1 ||
      !Number.isSafeInteger(value.minimumSecurityEpoch) || value.minimumSecurityEpoch < 1 ||
      !Array.isArray(value.releases) || value.releases.length > 100 || !Array.isArray(value.revoked) ||
      !/^[a-zA-Z0-9_.-]{1,100}$/.test(value.recommendedReleaseId)) throw new UpdateError('invalid_update_policy')
  for (const release of value.releases) {
    if (!/^[a-zA-Z0-9_.-]{1,100}$/.test(release.releaseId) || !/^[0-9]+\.[0-9]+\.[0-9]+$/.test(release.agentVersion) ||
        !/^releases\/[a-zA-Z0-9_.-]+\/release.json$/.test(release.target) || !Number.isSafeInteger(release.securityEpoch)) throw new UpdateError('invalid_release_reference')
  }
  if (new Set(value.releases.map((item) => item.releaseId)).size !== value.releases.length) throw new UpdateError('duplicate_release_id')
  return value
}
export function allowed(policy, release) {
  return !!release && release.securityEpoch >= policy.minimumSecurityEpoch && !policy.revoked.includes(release.releaseId) &&
    policy.releases.some((item) => item.releaseId === release.releaseId && item.securityEpoch === release.securityEpoch)
}
export async function repository(home, options = {}) {
  return locked(home, 'metadata', () => refreshRepository(home, options))
}
async function refreshRepository(home, { trust = UPDATE_TRUST, fetch = globalThis.fetch, timeoutMs = 60_000 } = {}) {
  if (!trust?.root || !trust.origin) throw new UpdateError('updates_not_configured')
  const clockPath = join(home, 'updates', 'clock.json')
  const clock = await json(clockPath, { lastVerifiedAt: 0 })
  if (Date.now() < clock.lastVerifiedAt - 300_000) throw new UpdateError('update_clock_rollback')
  const origin = normalizeServer(trust.origin)
  const metadataRoot = join(home, 'updates', 'metadata-generations')
  const generation = randomUUID(), directory = join(metadataRoot, generation), targets = join(home, 'updates', 'downloads')
  const pointer = join(home, 'updates', 'metadata-current')
  const previousDirectory = await readlink(pointer).catch(() => null)
  if (previousDirectory && !/^metadata-generations\/[a-f0-9-]{36}$/.test(previousDirectory)) throw new UpdateError('unsafe_metadata_pointer')
  if (previousDirectory) await cp(join(home, 'updates', previousDirectory), directory, { recursive: true })
  await mkdir(directory, { recursive: true, mode: 0o700 }); await mkdir(targets, { recursive: true, mode: 0o700 })
  if (!await exists(join(directory, 'root.json'))) await atomic(join(directory, 'root.json'), trust.root)
  const fetcher = new ReleaseFetcher(origin, fetch, timeoutMs)
  const updater = new Updater({ metadataDir: directory, metadataBaseUrl: origin + '/assistant/updates/metadata/',
    targetBaseUrl: origin + '/assistant/updates/targets/', targetDir: targets,
    fetcher,
    config: { fetchRetries: 0, maxRootRotations: 128, rootMaxLength: 65536, timestampMaxLength: 65536, snapshotMaxLength: 1024 * 1024, targetsMaxLength: 4 * 1024 * 1024 } })
  await updater.refresh()
  async function target(path, max = 64 * 1024 * 1024) {
    if (!/^[a-zA-Z0-9_./-]+$/.test(path) || path.includes('..')) throw new UpdateError('invalid_target_path')
    const info = await updater.getTargetInfo(path)
    if (!info || info.length > max) throw new UpdateError('invalid_target_length')
    const cached = await updater.findCachedTarget(info)
    return cached ?? await updater.downloadTarget(info)
  }
  const policy = validatePolicy(JSON.parse(await readFile(await target('stable.json', 256 * 1024), 'utf8')))
  const previous = await json(join(home, 'updates', 'policy.json'))
  if (previous && policy.minimumSecurityEpoch < previous.minimumSecurityEpoch) throw new UpdateError('security_floor_rollback')
  if (previous && previous.revoked.some((id) => !policy.revoked.includes(id))) throw new UpdateError('revoked_release_restored')
  if (previous && policy.policySequence < previous.policySequence) throw new UpdateError('policy_rollback')
  if (previous && policy.policySequence === previous.policySequence && JSON.stringify(policy) !== JSON.stringify(previous)) throw new UpdateError('policy_sequence_reused')
  // Publish a complete metadata generation only after all validation has succeeded.
  await (await import('./release.js')).syncTree(directory)
  await syncDir(directory); await syncDir(metadataRoot)
  await atomic(join(home, 'updates', 'policy.json'), policy)
  await atomic(clockPath, { lastVerifiedAt: Math.max(clock.lastVerifiedAt, Date.now()) })
  const temporary = `${pointer}.${generation}`
  await symlink(`metadata-generations/${generation}`, temporary)
  await rename(temporary, pointer)
  await syncDir(join(home, 'updates'))
  const generations = await readdir(metadataRoot)
  for (const old of generations.slice(0, Math.max(0, generations.length - 8))) {
    if (old !== generation && `metadata-generations/${old}` !== previousDirectory) await rm(join(metadataRoot, old), { recursive: true, force: true })
  }
  fetcher.deadline = Date.now() + 60_000
  return { policy, target, origin }
}
