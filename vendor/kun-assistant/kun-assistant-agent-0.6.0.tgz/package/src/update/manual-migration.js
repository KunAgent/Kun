// Explicit migration when automatic TUF updates have not been provisioned. The hash comes
// from the installed desktop SDK build, never from the same network response being verified.
import { createHash } from 'node:crypto'
import { normalizeServer } from '../mailbox-client.js'
const quote = text => "'" + text.replaceAll("'", "'\\''") + "'"
export const MANUAL_RELEASE = typeof __KUN_AGENT_INSTALLER__ === 'undefined' ? null : __KUN_AGENT_INSTALLER__
export async function manualMigrationPrompt({ server, release = MANUAL_RELEASE, kind = 'other', locale = 'zh', fetch = globalThis.fetch, initial = false }) {
  if (!release || !/^[a-f0-9]{64}$/.test(release.installerSha256) || !/^[0-9]+\.[0-9]+\.[0-9]+$/.test(release.version)) throw Object.assign(new Error('updates_not_configured'), { code: 'updates_not_configured' })
  const origin = normalizeServer(server), url = origin + '/assistant/install.sh'
  const response = await fetch(url, { redirect: 'error', signal: AbortSignal.timeout(10000) })
  if (!response.ok || !response.body) throw new Error('installer_unavailable')
  const reader = response.body.getReader(), parts = []; let size = 0
  try { for (;;) { const { done, value } = await reader.read(); if (done) break; size += value.length; if (size > 128 * 1024) throw new Error('installer_too_large'); parts.push(value) } }
  finally { await reader.cancel().catch(() => {}) }
  const sha = createHash('sha256').update(Buffer.concat(parts)).digest('hex')
  if (sha !== release.installerSha256) throw new Error('installer_changed_update_desktop')
  const installerCommand = `set -eu\numask 077\nexport KUN_HOME="\${KUN_HOME:-${kind === 'grok_bot' ? '/workspace/.kun' : '$HOME/.kun'}}"\nexport KUN_SERVER=${quote(origin)}\ntmp=$(mktemp)\ntrap 'rm -f "$tmp"' EXIT INT TERM\ncurl -fsS --proto '=https,http' --max-time 120 -o "$tmp" ${quote(url)}\nif command -v sha256sum >/dev/null 2>&1; then actual=$(sha256sum "$tmp" | cut -d ' ' -f 1); else actual=$(shasum -a 256 "$tmp" | cut -d ' ' -f 1); fi\n[ "$actual" = '${sha}' ] || { echo 'Kun installer verification failed' >&2; exit 1; }\nsh "$tmp"${initial ? '' : ' --legacy-stopped\n"$KUN_HOME/bin/kun-agent" status --json'}`
  const intro = locale === 'en'
    ? `Upgrade the existing Kun mailbox to ${release.version}. Pause scheduled checks and stop every kun-agent watch and MCP process for this KUN_HOME; wait for running commands to finish. Keep the original KUN_HOME, credentials and tasks. This explicitly requested installer is pinned by the desktop release; automatic updates remain governed by the installed update policy. Do not run forget or login. After success restart MCP/watch and use inbox/ack or kun_wait/kun_ack to confirm consumption.`
    : `将现有 Kun 信箱升级到 ${release.version}。先暂停定时检查，停止该 KUN_HOME 下所有 kun-agent watch 和 MCP 进程，等待正在执行的命令结束。保留原 KUN_HOME、凭据与任务，不运行 forget 或 login。下方安装器摘要由当前桌面版本固定；自动更新仍遵循原更新策略。成功后重启 MCP/watch，用 inbox/ack 或 kun_wait/kun_ack 确认消息消费。`
  return { version: release.version, releaseId: release.releaseId, prompt: `${intro}\n\n\`\`\`sh\n${installerCommand}\n\`\`\``, installerCommand }
}
