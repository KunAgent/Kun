import { readdir, stat, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { currentRelease } from './install.js'
import { allowed } from './metadata.js'
import { json } from './files.js'
export async function prune(home, policy) {
  const active = await currentRelease(home), previous = await currentRelease(home, 'previous')
  const keep = new Set([active?.release.releaseId, previous?.release.releaseId])
  const slots = []
  for (const name of await readdir(join(home, 'releases'))) {
    if (!/^[a-zA-Z0-9_.-]{1,100}$/.test(name)) continue
    const path = join(home, 'releases', name)
    slots.push({ name, path, time: (await stat(path)).mtimeMs, release: await json(join(path, 'release.json')) })
  }
  slots.sort((a, b) => b.time - a.time)
  const extraSafe = slots.find((slot) => !keep.has(slot.name) && allowed(policy, slot.release))
  if (extraSafe) keep.add(extraSafe.name)
  for (const slot of slots) if (!keep.has(slot.name)) await rm(slot.path, { recursive: true, force: true })
  const cache = join(home, 'updates', 'downloads'), files = []
  for (const name of await readdir(cache)) {
    const path = join(cache, name), info = await stat(path)
    if (info.isFile()) files.push({ path, size: info.size, time: info.mtimeMs })
  }
  let size = files.reduce((total, file) => total + file.size, 0)
  for (const file of files.sort((a, b) => a.time - b.time)) {
    if (size <= 256 * 1024 * 1024) break
    await rm(file.path, { force: true }); size -= file.size
  }
}
