import { readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { join, resolve } from 'node:path'
import { atomic, json } from './files.js'
import { locked } from './coordination.js'
const digest = (text) => createHash('sha256').update(text).digest('hex')
export async function registerSkill(home, path, text) {
  return locked(home, 'skills', async () => {
    const location = join(home, 'updates', 'skills.json'), entries = await json(location, {})
    entries[resolve(path)] = digest(text); await atomic(location, entries)
  })
}
export async function updateSkills(home, text) {
  return locked(home, 'skills', async () => {
    const location = join(home, 'updates', 'skills.json'), entries = await json(location, {})
    let pending = 0
    for (const [path, hash] of Object.entries(entries)) {
      const current = await readFile(path, 'utf8').catch(() => null)
      if (current === null || digest(current) !== hash) { pending++; continue }
      try { await atomic(path, text); entries[path] = digest(text) } catch { pending++ }
    }
    await atomic(location, entries)
    return { skillUpdatePending: pending > 0 }
  })
}
