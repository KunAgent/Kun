import { readFile, mkdir, copyFile, chmod, realpath, readdir, lstat } from 'node:fs/promises'
import { join, resolve, sep } from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { createHash } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { createGunzip } from 'node:zlib'
import { Transform } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { x as extract } from 'tar'
import { atomic } from './files.js'
import { supportedRuntime } from './runtime-version.js'
import { allowed, UpdateError } from './metadata.js'
const run = promisify(execFile)
export const platformKey = () => `${process.platform}-${process.arch}${process.platform === 'linux' ? '-glibc' : ''}`
export function validateRelease(value, reference) {
  if (!value || value.schema !== 1 || value.releaseId !== reference.releaseId || value.agentVersion !== reference.agentVersion ||
      value.securityEpoch !== reference.securityEpoch || value.launcherAbi !== 1 || value.storeReadMin > 2 || value.storeReadMax < 2 ||
      value.storeWrite !== 2 || !value.wireRead?.includes(1) || value.wireWrite !== 1 ||
      !['none', 'additive'].includes(value.migrationMode) || value.rollbackSafe !== true || !value.files || !value.runtimes) throw new UpdateError('release_requires_manual_migration', 6)
  for (const file of Object.values(value.files)) {
    if (!file || !/^[a-zA-Z0-9_./-]+$/.test(file.target) || file.target.includes('..') || !/^[a-f0-9]{64}$/.test(file.sha256)) throw new UpdateError('invalid_release_file')
  }
  return value
}
export async function loadRelease(repo, reference) {
  if (!allowed(repo.policy, reference)) throw new UpdateError('release_not_allowed', 6)
  return validateRelease(JSON.parse(await readFile(await repo.target(reference.target, 64 * 1024), 'utf8')), reference)
}
export async function checkedTarget(repo, file) {
  const path = await repo.target(file.target)
  const data = await readFile(path)
  if (createHash('sha256').update(data).digest('hex') !== file.sha256) throw new UpdateError('release_hash_mismatch')
  return path
}
export async function prepareRelease(repo, release, directory, { platform = platformKey(), runtimeSource } = {}) {
  if (process.platform === 'linux' && !process.report.getReport().header.glibcVersionRuntime && !runtimeSource) throw new UpdateError('unsupported_platform', 6)
  await mkdir(directory, { recursive: true, mode: 0o700 })
  for (const name of ['kun-agent.mjs', 'SKILL.md']) {
    if (!release.files[name]) throw new UpdateError('incomplete_release')
    await copyFile(await checkedTarget(repo, release.files[name]), join(directory, name))
    await chmod(join(directory, name), 0o600)
  }
  if (runtimeSource) {
    // Dependency injection for local fixtures; the production CLI never supplies this option.
    await mkdir(join(directory, 'runtime', 'bin'), { recursive: true })
    await copyFile(runtimeSource, join(directory, 'runtime', 'bin', 'node'))
    await chmod(join(directory, 'runtime', 'bin', 'node'), 0o700)
  } else {
    const runtime = release.runtimes[platform]
    if (!runtime || !supportedRuntime(runtime.version)) throw new UpdateError('unsupported_runtime', 6)
    const archive = await checkedTarget(repo, runtime)
    const destination = join(directory, 'runtime')
    await mkdir(destination)
    let unsafe = false, expanded = 0
    const limit = new Transform({ transform(chunk, encoding, callback) {
      expanded += chunk.length
      callback(expanded > 512 * 1024 * 1024 ? new UpdateError('runtime_archive_too_large') : null, chunk)
    } })
    const unpack = extract({ cwd: destination, strip: 1, strict: true, preservePaths: false,
      filter: (name, entry) => {
        const segments = name.split('/')
        if (name.startsWith('/') || segments.includes('..')) { unsafe = true; return false }
        if (segments.slice(1).join('/') !== 'bin/node') return false
        if (entry.type !== 'File' || entry.size > 256 * 1024 * 1024) { unsafe = true; return false }
        return true
      } })
    await pipeline(createReadStream(archive), createGunzip(), limit, unpack, { signal: AbortSignal.timeout(30_000) })
    if (unsafe) throw new UpdateError('unsafe_runtime_archive')
    const version = (await run(join(destination, 'bin', 'node'), ['--version'], { timeout: 10_000 })).stdout.trim()
    if (version !== `v${runtime.version}`) throw new UpdateError('runtime_version_mismatch')
  }
  await atomic(join(directory, 'release.json'), release)
  await health(directory)
}
export async function health(directory) {
  const root = await realpath(directory)
  for (const file of ['runtime/bin/node', 'kun-agent.mjs', 'release.json']) {
    if (!(await realpath(join(root, file))).startsWith(root + sep)) throw new UpdateError('unsafe_release_layout')
  }
  const result = await run(join(root, 'runtime/bin/node'), [join(root, 'kun-agent.mjs'), 'self-test'],
    { timeout: 15_000, maxBuffer: 65536, env: { PATH: process.env.PATH ?? '', KUN_SELF_TEST: '1' } })
  const release = JSON.parse(await readFile(join(root, 'release.json'), 'utf8'))
  const version = await run(join(root, 'runtime/bin/node'), [join(root, 'kun-agent.mjs'), 'version'], { timeout: 10_000, maxBuffer: 65536, env: { PATH: process.env.PATH ?? '' } })
  if (!version.stdout.includes(release.agentVersion)) throw new UpdateError('release_version_mismatch')
  if (result.stdout.trim() !== 'ready') throw new UpdateError('release_self_test_failed')
}
export async function syncTree(directory) {
  const { open } = await import('node:fs/promises')
  for (const name of await readdir(directory)) {
    const path = join(directory, name), stat = await lstat(path)
    if (stat.isDirectory()) await syncTree(path)
    else if (!stat.isFile()) throw new UpdateError('unsafe_release_layout')
    const fd = await open(path, 'r'); try { await fd.sync() } finally { await fd.close() }
  }
}
