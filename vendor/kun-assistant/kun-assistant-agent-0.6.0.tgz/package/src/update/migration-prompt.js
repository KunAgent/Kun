import { readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { repository, UPDATE_TRUST } from './metadata.js'
import { loadRelease } from './release.js'
import { normalizeServer } from '../mailbox-client.js'
const quote = (text) => "'" + text.replaceAll("'", "'\\''") + "'"
export async function migrationPrompt({ home, trust = UPDATE_TRUST, server, kind = 'other', locale = 'zh', fetch, initial = false }) {
  const repo = await repository(home, { trust, fetch })
  const reference = repo.policy.releases.find((item) => item.releaseId === repo.policy.recommendedReleaseId)
  const release = await loadRelease(repo, reference)
  const path = `releases/${release.releaseId}/install.sh`
  const installer = await readFile(await repo.target(path, 128 * 1024))
  const sha = createHash('sha256').update(installer).digest('hex')
  const url = `${repo.origin}/assistant/updates/targets/releases/${release.releaseId}/${sha}.install.sh`
  const code = `set -eu\numask 077\nexport KUN_HOME="\${KUN_HOME:-${kind === 'grok_bot' ? '/workspace/.kun' : '$HOME/.kun'}}"\nexport KUN_SERVER=${quote(normalizeServer(server))}\ntmp=$(mktemp)\ntrap 'rm -f "$tmp"' EXIT INT TERM\ncurl -fsS --proto '=https,http' --max-time 120 -o "$tmp" ${quote(url)}\nif command -v sha256sum >/dev/null 2>&1; then actual=$(sha256sum "$tmp" | cut -d ' ' -f 1); else actual=$(shasum -a 256 "$tmp" | cut -d ' ' -f 1); fi\n[ "$actual" = '${sha}' ] || { echo 'Kun installer verification failed' >&2; exit 1; }\nsh "$tmp"${initial ? '' : ' --legacy-stopped\n"$KUN_HOME/bin/kun-agent" status --json'}`
  const prompt = locale === 'en' ?
    `Update the existing Kun mailbox program to ${release.agentVersion}. First pause the existing scheduled checks, stop every old kun-agent watch and MCP process for this KUN_HOME, and wait for running commands to finish. If you cannot confirm this, tell the user before proceeding. Keep the original custom KUN_HOME if one was used. Run the verified migration below. Do not run forget or login; keep credentials and tasks. After success resume the original checks, run status, and report the actual installed version.\n\n\`\`\`sh\n${code}\n\`\`\`` :
    `把现有 Kun 信箱程序升级到 ${release.agentVersion}。先暂停原定时检查，停止该 KUN_HOME 下所有旧 kun-agent watch 和 MCP，等待正在执行的命令结束；无法确认时先告诉用户。原来使用自定义 KUN_HOME 时继续用原目录。执行下方已验证的迁移指令，不运行 forget 或 login，保留凭据和任务。成功后恢复原检查，运行 status，并报告实际安装版本。\n\n\`\`\`sh\n${code}\n\`\`\``
  return { version: release.agentVersion, releaseId: release.releaseId, prompt, installerCommand: code }
}
