// Match the supported LTS branches of the pinned TUF client; reject obsolete patch levels.
export function supportedRuntime(version) {
  const match = /^(22|24)\.([0-9]+)\.([0-9]+)$/.exec(version)
  if (!match) return false
  const [, major, minor, patch] = match.map(Number)
  return major === 24 ? minor >= 15 : minor > 22 || (minor === 22 && patch >= 2)
}
