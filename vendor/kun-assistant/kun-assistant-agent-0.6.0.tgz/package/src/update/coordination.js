// A live process is never considered stale, including while its VM is suspended.
import fs from 'node:fs'
import { randomUUID } from 'node:crypto'
import { mkdir, rm } from 'node:fs/promises'
import { join } from 'node:path'
import lockfile from 'proper-lockfile'

export class UpdateBusy extends Error { constructor() { super('update_busy'); this.exitCode = 8 } }
function alive(pid) {
  try { process.kill(pid, 0); return true } catch (error) { return error.code !== 'ESRCH' }
}
export async function locked(home, name, work, waitMs = 30_000) {
  await mkdir(join(home, 'updates'), { recursive: true, mode: 0o700 })
  const path = join(home, 'updates', name)
  const owner = `${path}.lock/owner`
  const adapter = Object.create(fs)
  // Publish owner and lock directory together; a crash cannot leave an ownerless lock.
  adapter.mkdir = (file, callback) => {
    const candidate = `${file}.candidate-${process.pid}-${randomUUID()}`
    fs.mkdir(candidate, (error) => {
      if (error) return callback(error)
      fs.writeFile(`${candidate}/owner`, String(process.pid), { mode: 0o600 }, (error) => {
        if (error) return fs.rm(candidate, { recursive: true, force: true }, () => callback(error))
        fs.rename(candidate, file, (error) => {
          if (error?.code === 'ENOTEMPTY') error.code = 'EEXIST'
          if (error) fs.rm(candidate, { recursive: true, force: true }, () => callback(error))
          else callback(null)
        })
      })
    })
  }
  adapter.rmdir = (file, callback) => {
    try {
      const pid = Number(fs.readFileSync(`${file}/owner`, 'utf8'))
      if (pid !== process.pid && alive(pid)) return callback(Object.assign(new Error('live_lock_owner'), { code: 'ELOCKED' }))
      fs.unlinkSync(`${file}/owner`)
    } catch (error) { if (error.code !== 'ENOENT') return callback(error) }
    fs.rmdir(file, callback)
  }
  adapter.stat = (file, callback) => fs.stat(file, (error, stat) => {
    if (!error && file === `${path}.lock`) {
      try {
        const pid = Number(fs.readFileSync(owner, 'utf8'))
        if (pid !== process.pid && alive(pid)) { stat.mtime = new Date(); stat.mtimeMs = Date.now() }
        else if (!alive(pid)) { stat.mtime = new Date(0); stat.mtimeMs = 0 }
      } catch { /* A just-created lock has not published its owner yet. */ }
    }
    callback(error, stat)
  })
  let compromised
  const release = await lockfile.lock(path, { realpath: false, fs: adapter, stale: 10_000, update: 2000,
    retries: { retries: Math.ceil(waitMs / 100), factor: 1, minTimeout: 100, maxTimeout: 100 },
    onCompromised: (error) => { compromised = error }
  }).catch((error) => { if (error.code === 'ELOCKED') throw new UpdateBusy(); throw error })
  try {
    const value = await work(() => { if (compromised) throw compromised })
    if (compromised) throw compromised
    return value
  } finally { await rm(owner, { force: true }); await release().catch(() => {}) }
}
export const business = (home, work, waitMs) => locked(home, 'business', work, waitMs)
