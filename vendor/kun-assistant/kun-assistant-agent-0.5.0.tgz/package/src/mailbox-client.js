import { AGENT_VERSION } from './version.js'
// HTTP client for `/api/assistants/v1/`. Assistant VMs authenticate with their own bearer
// (`Authorization: Assistant <id>.<token>`); the desktop authenticates as its registered remote
// host device with the signed-in user's access token. Only opaque envelopes cross this boundary.
const PREFIX = '/api/assistants/v1/'
const RETRYABLE = new Set([429, 500, 502, 503, 504])

export class MailboxRequestError extends Error {
  constructor(status, code, detail) {
    super(detail ?? `mailbox request failed: ${status} ${code}`)
    this.name = 'MailboxRequestError'
    this.status = status
    this.code = code
  }
}

export function normalizeServer(server) {
  const url = new URL(server)
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)
  if (url.protocol !== 'https:' && !(local && url.protocol === 'http:')) {
    throw new TypeError('the Kun server must use https (http is allowed only for localhost)')
  }
  if (url.pathname !== '/' || url.search || url.hash || url.username || url.password) {
    throw new TypeError('the Kun server must be an origin such as https://api-kun-server.com')
  }
  return url.origin
}

function transport({ server, fetch = globalThis.fetch, timeoutMs = 20_000, sleep = (ms) => new Promise((r) => setTimeout(r, ms)) }) {
  const origin = normalizeServer(server)
  return async function request(method, path, { headers = {}, body, retry = true } = {}) {
    const attempts = retry ? 3 : 1
    let lastError
    for (let attempt = 0; attempt < attempts; attempt++) {
      if (attempt > 0) await sleep(attempt === 1 ? 500 : 1500)
      let response
      try {
        response = await fetch(origin + PREFIX + path, {
          method,
          headers: { Accept: 'application/json', 'X-Kun-Agent-Version': AGENT_VERSION, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...headers },
          body: body === undefined ? undefined : JSON.stringify(body),
          redirect: 'error',
          signal: AbortSignal.timeout(timeoutMs)
        })
      } catch (error) {
        lastError = new MailboxRequestError(0, 'network_error', `cannot reach ${origin}: ${error.message}`)
        continue
      }
      const text = await response.text()
      let value = null
      try { value = text ? JSON.parse(text) : null } catch { value = null }
      if (response.ok && value && typeof value === 'object') return value
      const code = typeof value?.error === 'string' ? value.error : (typeof value?.message === 'string' ? value.message : 'unexpected_response')
      lastError = new MailboxRequestError(response.status, code)
      if (!RETRYABLE.has(response.status)) break
    }
    throw lastError
  }
}

/**
 * Files a join request. Not retried here: a lost reply may already have filed it, which the agent
 * finds out by asking for the request's status with its own token.
 */
export async function requestEnrollment({ server, input, fetch, timeoutMs }) {
  return transport({ server, fetch, timeoutMs })('POST', 'enroll', { body: input, retry: false })
}

/** `{ state: 'pending' | 'approved' | 'rejected' | 'expired', name, kind, expiresAt }` for a request. */
export async function enrollmentStatus({ server, requestId, token, fetch, timeoutMs, sleep }) {
  return transport({ server, fetch, timeoutMs, sleep })('GET', 'enroll/status', { headers: { Authorization: `Assistant ${requestId}.${token}` } })
}

export function createAssistantClient({ server, assistantId, token, fetch, timeoutMs, sleep }) {
  const request = transport({ server, fetch, timeoutMs, sleep })
  const headers = { Authorization: `Assistant ${assistantId}.${token}` }
  return {
    runtime: (body) => request('POST', 'runtime', { headers, body }),
    inbox: () => request('GET', 'inbox', { headers }),
    send: (messageId, envelope) => request('POST', 'messages', { headers, body: { messageId, envelope } }),
    ack: (messageIds) => request('POST', 'inbox/ack', { headers, body: { messageIds } }),
    status: () => request('GET', 'status', { headers })
  }
}

/**
 * `credentials()` returns `{ accessToken, deviceId, deviceCredential }` for the desktop's remote
 * host device; it is called per request so the desktop can refresh its session in between.
 */
export function createHostClient({ server, credentials, fetch, timeoutMs, sleep }) {
  const request = transport({ server, fetch, timeoutMs, sleep })
  const call = async (method, path, body) => {
    const { accessToken, deviceId, deviceCredential } = await credentials()
    return request(method, path, {
      body,
      headers: { Authorization: `Bearer ${accessToken}`, 'X-Kun-Device': deviceId, 'X-Kun-Device-Credential': deviceCredential }
    })
  }
  return {
    enroll: (input) => call('POST', 'host/enrollments', input),
    cancel: (enrollmentId) => call('DELETE', `host/enrollments/${enrollmentId}`),
    approve: (enrollmentId, requestId) => call('POST', `host/enrollments/${enrollmentId}/requests/${requestId}/approve`),
    reject: (enrollmentId, requestId) => call('POST', `host/enrollments/${enrollmentId}/requests/${requestId}/reject`),
    runtime: (body) => call('POST', 'host/runtime', body),
    list: () => call('GET', 'host/assistants'),
    revoke: (assistantId) => call('DELETE', `host/assistants/${assistantId}`),
    send: (assistantId, messageId, envelope) => call('POST', `host/assistants/${assistantId}/messages`, { messageId, envelope }),
    inbox: () => call('GET', 'host/inbox'),
    ack: (messageIds) => call('POST', 'host/inbox/ack', { messageIds })
  }
}
