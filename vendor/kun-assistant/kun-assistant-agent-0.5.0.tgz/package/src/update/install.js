import { join } from 'node:path'
import { readlink, symlink, rename, rm, readFile } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import { atomic, json, exists, syncDir } from './files.js'
import { business, locked } from './coordination.js'
import { repository, allowed, UpdateError } from './metadata.js'
import { loadRelease, prepareRelease, health, syncTree } from './release.js'

export async function currentRelease(home, pointer = 'current') {
  let target
  try { target = await readlink(join(home, pointer)) } catch (error) { if (error.code === 'ENOENT') return null; throw error }
  if (!/^releases\/[a-zA-Z0-9_.-]{1,100}$/.test(target)) throw new UpdateError('unsafe_release_pointer')
  return { directory: join(home, target), release: await json(join(home, target, 'release.json')) }
}
async function point(home, name, id) {
  if (!/^[a-zA-Z0-9_.-]{1,100}$/.test(id)) throw new UpdateError('invalid_release_id')
  const temporary = join(home, `${name}.tmp-${randomUUID()}`)
  await symlink(`releases/${id}`, temporary)
  await rename(temporary, join(home, name)); await syncDir(home)
}
export async function recovery(home) {
  let state = await json(join(home, 'updates', 'state.json'), {})
  const policy = await json(join(home, 'updates', 'policy.json'))
  if (!state.pending) {
    const current = await currentRelease(home)
    if (!current) return state
    try { await health(current.directory); return state }
    catch {
      if (!state.previous) throw new UpdateError('no_safe_rollback', 6)
      state = { ...state, pending: { from: state.previous, to: current.release.releaseId } }
      await atomic(join(home, 'updates', 'state.json'), state)
    }
  }
  const active = await currentRelease(home)
  if (active?.release?.releaseId === state.pending.to) {
    try {
      if (policy && !allowed(policy, active.release)) throw new UpdateError('release_not_allowed', 6)
      await health(active.directory)
      const recovered = { ...state, current: active.release.releaseId, previous: state.pending.from, pending: null, lastResult: 'updated', generation: state.generation + 1 }
      await atomic(join(home, 'updates', 'state.json'), recovered); return recovered
    } catch {
      const previous = state.pending.from && await json(join(home, 'releases', state.pending.from, 'release.json'))
      if (!previous || (policy && !allowed(policy, previous))) throw new UpdateError('no_safe_rollback', 6)
      await health(join(home, 'releases', previous.releaseId))
      await point(home, 'current', previous.releaseId)
    }
  }
  const recovered = { ...state, current: state.pending.from, pending: null, lastResult: 'rolled_back', generation: state.generation + 1 }
  await atomic(join(home, 'updates', 'state.json'), recovered); return recovered
}
export async function activate(home, release, directory, { failpoint = async () => {} } = {}) {
  return business(home, async () => {
    const old = await currentRelease(home), statePath = join(home, 'updates', 'state.json')
    const state = await json(statePath, { generation: 0 })
    if (old?.release.releaseId === release.releaseId) return { ...state, lastResult: 'current' }
    const destination = join(home, 'releases', release.releaseId)
    if (directory !== destination) {
      if (await exists(destination)) await health(destination)
      else { await syncTree(directory); await rename(directory, destination); await syncDir(join(home, 'releases')) }
    }
    const next = { ...state, pending: { from: old?.release.releaseId ?? null, to: release.releaseId }, lastResult: 'installing' }
    await atomic(statePath, next); await failpoint('journal')
    if (old) await point(home, 'previous', old.release.releaseId)
    await point(home, 'current', release.releaseId); await failpoint('pointer')
    await health(destination); await failpoint('ready')
    const committed = { ...next, current: release.releaseId, previous: old?.release.releaseId ?? null, pending: null,
      generation: state.generation + 1, lastResult: 'updated', lastUpdatedAt: new Date().toISOString() }
    await atomic(statePath, committed)
    return committed
  })
}
export async function update(home, options = {}) {
  return locked(home, 'install', async () => {
    await business(home, () => recovery(home))
    const repo = await repository(home, options)
    const active = await currentRelease(home)
    const reference = repo.policy.releases.find((item) => options.rollback ? item.releaseId === options.rollback :
      options.version ? item.agentVersion === options.version : item.releaseId === repo.policy.recommendedReleaseId)
    if (!reference) throw new UpdateError('release_not_found')
    const release = await loadRelease(repo, reference)
    const state = await json(join(home, 'updates', 'state.json'), {})
    const compatible = release.autoUpdateAllowed === true
    const result = { current: active?.release.agentVersion ?? null, candidate: release.agentVersion,
      releaseId: release.releaseId, available: active?.release.releaseId !== release.releaseId, compatible, policy: state.policy ?? 'auto-compatible' }
    if (options.check) return result
    if (options.automatic && (!compatible || state.policy === 'manual')) return result
    if (!result.available) return result
    const directory = join(home, 'updates', 'staging', `${release.releaseId}-${randomUUID()}`)
    const { mkdir } = await import('node:fs/promises')
    await mkdir(join(home, 'releases'), { recursive: true, mode: 0o700 })
    try {
      await prepareRelease(repo, release, directory, options)
      const installed = await activate(home, release, directory, options)
      return { ...result, ...installed }
    } catch (error) {
      await business(home, () => recovery(home))
      throw error
    } finally { await rm(directory, { recursive: true, force: true }) }
  })
}
export async function rollback(home, options = {}) {
  const previous = await currentRelease(home, 'previous')
  if (!previous) throw new UpdateError('no_previous_release')
  return update(home, { ...options, rollback: previous.release.releaseId })
}
export async function setPolicy(home, policy) {
  if (!['manual', 'auto-compatible'].includes(policy)) throw new UpdateError('invalid_update_preference')
  return locked(home, 'install', async () => {
    const path = join(home, 'updates', 'state.json'), state = await json(path, { generation: 0 })
    await atomic(path, { ...state, policy }); return { policy }
  })
}
export async function assertAllowed(home) {
  const policy = await json(join(home, 'updates', 'policy.json')), active = await currentRelease(home)
  if (policy && active && !allowed(policy, active.release)) throw new UpdateError('assistant_upgrade_required', 6)
}
