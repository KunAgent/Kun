export declare function main(argv: string[], io: {
  stdout: { write(text: string): unknown }
  stderr: { write(text: string): unknown }
  stdin?: AsyncIterable<string | Buffer>
  env?: Record<string, string | undefined>
  fetch?: typeof fetch
  now?: () => Date
  sleep?: (ms: number) => Promise<void>
}): Promise<number>
