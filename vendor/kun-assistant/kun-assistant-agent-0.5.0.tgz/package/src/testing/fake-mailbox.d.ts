export interface FakeMailbox {
  origin: string
  fetch: typeof fetch
  state: { messages: Array<{ id: string; assistantId: string; direction: string; envelope: string; createdAt: string }>; down: boolean; requests: string[] }
  credentials(): Promise<{ accessToken: string; deviceId: string; deviceCredential: string }>
}
/** In-memory `/api/assistants/v1/` server for tests of desktop and agent integrations. */
export declare function fakeMailbox(options?: { origin?: string }): FakeMailbox
