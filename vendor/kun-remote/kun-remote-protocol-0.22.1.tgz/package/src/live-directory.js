/** Opt-in directory invalidations over the existing personal relay connection. */
export const DIRECTORY_LIVE_CAPABILITY = 'directory.live.v1'
