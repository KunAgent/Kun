export type VipTier = 'free' | 'plus' | 'pro' | 'max'
export interface AccountEntitlements {
  version: 1; userId: string; tier: VipTier; effectiveTier: VipTier
  status: 'free' | 'active' | 'expired'; expiresAt: string | null; checkedAt: string; revision: number
  features: { mobileRemote: boolean; personalAssistant: boolean }
}
export declare const VIP_TIERS: readonly VipTier[]
export declare function vipRequirement(code: string): { feature: 'mobileRemote' | 'personalAssistant'; tier: 'plus' | 'pro' } | null
export declare function parseEntitlements(value: unknown): AccountEntitlements
