/** Round-robin peers and independent replies, retaining each peer's event ordering. */
export class FrameQueue {
  constructor() { this.peers = new Map(); this.length = 0 }
  enqueue(frame, parts) {
    const peer = frame.dst ?? ''
    let streams = this.peers.get(peer)
    if (!streams) { streams = new Map(); this.peers.set(peer, streams) }
    // Reply fragments can interleave; ordered event/subscription streams must not overtake.
    const key = frame.kind === 'result' ? 'result:' + frame.id : frame.kind
    const queue = streams.get(key)
    if (queue) queue.push(...parts)
    else streams.set(key, parts)
    this.length += parts.length
  }
  shift() {
    const entry = this.peers.entries().next().value
    if (!entry) return undefined
    const [peer, streams] = entry, [key, queue] = streams.entries().next().value
    const part = queue.shift()
    this.length--
    streams.delete(key)
    if (queue.length) streams.set(key, queue)
    this.peers.delete(peer)
    if (streams.size) this.peers.set(peer, streams)
    return part
  }
  cancel(id) {
    let bytes = 0
    for (const [peer, streams] of this.peers) {
      for (const [key, queue] of streams) {
        const keep = queue.filter(part => {
          if (part.id !== id) return true
          this.length--; bytes += part.size
          return false
        })
        if (keep.length) streams.set(key, keep)
        else streams.delete(key)
      }
      if (!streams.size) this.peers.delete(peer)
    }
    return bytes
  }
  clear() { this.peers.clear(); this.length = 0 }
}
