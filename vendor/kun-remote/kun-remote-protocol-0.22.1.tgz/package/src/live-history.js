/**
 * Live history: a desktop that keeps a subscription's latest history page sends that page once and
 * then only what changed. Both sides share this one definition, so applying a delta to the previous
 * page reproduces the desktop's next page exactly. Elements are matched by their `id`; a page whose
 * list cannot be keyed that way is always sent whole.
 */
export const LIVE_HISTORY_VERSION = 1
/** A delta above this size is replaced by the whole page, which may then be fragmented. */
export const LIVE_DELTA_MAX_BYTES = 192 * 1024
const LIST_KEYS = Object.freeze({ code: 'turns', agent: 'messages', group: 'messages' })

const plain = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
const same = (a, b) => a === b || JSON.stringify(a) === JSON.stringify(b)
const withoutItems = ({ items: _items, ...meta }) => meta

function listKey(kind) {
  const key = LIST_KEYS[kind]
  if (!key) throw new Error('INVALID_LIVE_KIND')
  return key
}
/** Ordered unique ids, or null when an element cannot be matched across pages. */
function ids(list) {
  if (!Array.isArray(list)) return null
  const seen = new Set()
  for (const element of list) {
    if (!plain(element) || typeof element.id !== 'string' || !element.id || seen.has(element.id)) return null
    seen.add(element.id)
  }
  return [...seen]
}
/** Order (when membership or position changed) and changed elements; null when equal. */
function listChange(previous, next, project = (value) => value) {
  const before = ids(previous), after = ids(next)
  if (!before || !after) return undefined
  const old = new Map(previous.map((element) => [element.id, project(element)]))
  const upsert = []
  for (const element of next) {
    const value = project(element)
    if (!old.has(element.id) || !same(old.get(element.id), value)) upsert.push(value)
  }
  const reordered = before.length !== after.length || after.some((id, index) => id !== before[index])
  if (!reordered && !upsert.length) return null
  return { ...(reordered ? { order: after } : {}), ...(upsert.length ? { upsert } : {}) }
}

/** `{ unchanged }`, `{ delta }`, or `{ snapshot }` when only the whole page can describe the change. */
export function diffHistory(kind, previous, next) {
  const key = listKey(kind)
  if (!plain(previous) || !plain(next)) return { snapshot: true }
  const set = {}, unset = []
  for (const name of new Set([...Object.keys(previous), ...Object.keys(next)])) {
    if (name === key) continue
    if (!Object.hasOwn(next, name)) unset.push(name)
    else if (!Object.hasOwn(previous, name) || !same(previous[name], next[name])) set[name] = next[name]
  }
  const delta = {}
  if (Object.hasOwn(next, key)) {
    const before = Object.hasOwn(previous, key) ? previous[key] : [], after = next[key]
    if (kind === 'code') {
      if (!Array.isArray(after) || after.some((turn) => !plain(turn) || !Array.isArray(turn.items))) return { snapshot: true }
      const turns = listChange(before, after, withoutItems)
      if (turns === undefined) return { snapshot: true }
      Object.assign(delta, turns ?? {})
      const old = new Map(before.map((turn) => [turn.id, turn]))
      const items = {}
      for (const turn of after) {
        const change = listChange(Array.isArray(old.get(turn.id)?.items) ? old.get(turn.id).items : [], turn.items)
        if (change === undefined) return { snapshot: true }
        if (change) items[turn.id] = change
      }
      if (Object.keys(items).length) delta.items = items
    } else {
      const change = listChange(before, after)
      if (change === undefined) return { snapshot: true }
      Object.assign(delta, change ?? {})
    }
    // An empty list that newly appears still needs its key.
    if (!Object.hasOwn(previous, key) && !delta.order) delta.order = []
  } else if (Object.hasOwn(previous, key)) unset.push(key)
  if (Object.keys(set).length) delta.set = set
  if (unset.length) delta.unset = unset
  return Object.keys(delta).length ? { delta: { v: LIVE_HISTORY_VERSION, ...delta } } : { unchanged: true }
}

function validList(change) {
  return (change.order === undefined || (Array.isArray(change.order) && change.order.every((id) => typeof id === 'string'))) &&
    (change.upsert === undefined || (Array.isArray(change.upsert) && change.upsert.every((value) => plain(value) && typeof value.id === 'string')))
}
function applyList(previous, change) {
  if (!change) return previous
  if (!plain(change) || !validList(change)) throw new Error('INVALID_LIVE_DELTA')
  const old = new Map(previous.map((element) => [element.id, element]))
  const upserts = new Map((change.upsert ?? []).map((element) => [element.id, element]))
  return (change.order ?? previous.map((element) => element.id)).map((id) => {
    const value = upserts.get(id) ?? old.get(id)
    if (!value) throw new Error('INVALID_LIVE_DELTA')
    return value
  })
}
function applyTurns(previous, delta) {
  const old = new Map(previous.map((turn) => [turn.id, turn]))
  const metas = new Map((delta.upsert ?? []).map((turn) => [turn.id, turn]))
  if (delta.items !== undefined && !plain(delta.items)) throw new Error('INVALID_LIVE_DELTA')
  return (delta.order ?? previous.map((turn) => turn.id)).map((id) => {
    const base = old.get(id), meta = metas.get(id) ?? (base && withoutItems(base))
    if (!meta) throw new Error('INVALID_LIVE_DELTA')
    return { ...meta, items: applyList(Array.isArray(base?.items) ? base.items : [], delta.items?.[id]) }
  })
}

/** The desktop's next page from the previous one; throws when the delta does not fit the page. */
export function applyHistoryDelta(kind, previous, delta) {
  const key = listKey(kind)
  if (!plain(previous) || !plain(delta) || delta.v !== LIVE_HISTORY_VERSION) throw new Error('INVALID_LIVE_DELTA')
  const unset = delta.unset ?? []
  if (!Array.isArray(unset) || unset.some((name) => typeof name !== 'string') ||
    (delta.set !== undefined && (!plain(delta.set) || Object.hasOwn(delta.set, key))) || !validList(delta))
    throw new Error('INVALID_LIVE_DELTA')
  const next = {}
  for (const [name, value] of Object.entries(previous)) if (name !== key && !unset.includes(name)) next[name] = value
  Object.assign(next, delta.set ?? {})
  const changed = delta.order !== undefined || delta.upsert !== undefined || (kind === 'code' && delta.items !== undefined)
  const before = Array.isArray(previous[key]) ? previous[key] : []
  if (!unset.includes(key)) {
    if (changed) next[key] = kind === 'code' ? applyTurns(before, delta) : applyList(before, delta)
    else if (Object.hasOwn(previous, key)) next[key] = previous[key]
  }
  return next
}

/** The event cursor a live page was read at: Code tasks use the runtime seq, rooms their store seq. */
export function liveCursor(kind, page) {
  const value = kind === 'code' ? page?.latestSeq : page?.cursor
  return Number.isSafeInteger(value) && value >= 0 ? value : 0
}
