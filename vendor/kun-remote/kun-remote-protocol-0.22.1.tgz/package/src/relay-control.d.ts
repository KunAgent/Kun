export const RELAY_FEATURES_HEADER: 'X-Kun-Relay-Features'
export const RELAY_FEATURES: readonly ['presence', 'authorization', 'lossy']
export type RelayFeature = (typeof RELAY_FEATURES)[number]
export const READ_CONDITIONAL_CAPABILITY: 'read.conditional'
export const HISTORY_LIVE_CAPABILITY: 'history.live'
export const MAX_LEASE_MS: number
export interface PeerPresence { deviceId: string; online: boolean }
export type RelayNotice =
  | { relay: 'presence'; snapshot: boolean; peers: PeerPresence[] }
  | { relay: 'authorization' }
  | { relay: 'shed' }
export function relayFeatures(value: unknown): Set<RelayFeature>
export function relayNotice(frame: unknown): RelayNotice | null
