/**
 * Optional personal-relay behaviours a client asks for in its WebSocket upgrade. A relay that does
 * not know the header ignores it, and a client never receives a notice it did not ask for.
 */
export const RELAY_FEATURES_HEADER = 'X-Kun-Relay-Features'
export const RELAY_FEATURES = Object.freeze(['presence', 'authorization', 'lossy'])
/** Desktop catalog capabilities a phone checks before sending the matching optional fields. */
export const READ_CONDITIONAL_CAPABILITY = 'read.conditional'
export const HISTORY_LIVE_CAPABILITY = 'history.live'
/** A personal lease may last this long; older relays keep issuing sixty seconds. */
export const MAX_LEASE_MS = 300000

/** Parse the relay's echo of accepted features from hello; anything unknown is dropped. */
export function relayFeatures(value) {
  return new Set(Array.isArray(value) ? value.filter((name) => RELAY_FEATURES.includes(name)) : [])
}

/**
 * Relay-authored notices are event frames without a source device. Presence reports one device or,
 * from hello, the full peer set; authorization says this device's peer set changed; shed says the
 * relay dropped lossy frames for this receiver while it was behind on acknowledgements.
 */
export function relayNotice(frame) {
  if (frame?.kind !== 'event' || frame.src !== undefined) return null
  const payload = frame.payload
  if (!payload || typeof payload.relay !== 'string') return null
  if (payload.relay === 'presence') {
    const snapshot = Array.isArray(payload.peers)
    const peers = snapshot ? payload.peers : [payload]
    if (snapshot && peers.length > 32) return null
    const valid = peers.filter((peer) => typeof peer?.deviceId === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(peer.deviceId) &&
      typeof peer.online === 'boolean').map(({ deviceId, online }) => ({ deviceId, online }))
    // A full snapshot can remove authority. Filtering, truncating or deduplicating it would
    // incorrectly turn malformed data into an authoritative partial set, so reject it whole.
    if (snapshot && (valid.length !== peers.length ||
      new Set(valid.map(peer => peer.deviceId)).size !== valid.length)) return null
    // An explicitly empty full snapshot revokes every previous peer; absent data does not.
    return valid.length || (snapshot && peers.length === 0)
      ? { relay: 'presence', snapshot, peers: valid } : null
  }
  if (payload.relay === 'authorization' || payload.relay === 'shed') return { relay: payload.relay }
  return null
}
