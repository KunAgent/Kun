import type { Call, ClientDependencies, Frame, RequestBudget, InvokeOptions } from './index.js'
export type ShareMode = 'read' | 'write'
export type SharePeer = { deviceId: string; accountId: string; memberId?: string; memberVersion?: number; mode?: ShareMode }
export interface ShareLease {
  shareId: string; ownerAccountId: string; hostDeviceId: string; resourceHandle: string; shareVersion: number
  userId: string; deviceId: string; role: 'host' | 'guest'; mode: ShareMode; expiresAt: number
  memberId?: string; memberVersion?: number; peers: readonly Readonly<SharePeer>[]
}
export type ShareExpected = {
  shareId: string; accountId: string; deviceId: string; hostDeviceId: string; resourceHandle: string
  ownerAccountId?: string; shareVersion?: number
} & ({ role: 'host'; memberId?: never; memberVersion?: never } | { role: 'guest'; memberId: string; memberVersion: number })
export interface SharedAuthority {
  shareId: string; resourceHandle: string; shareVersion: number; accountId: string; role: 'host' | 'guest'; mode: ShareMode
  memberId?: string; memberVersion?: number
}
export interface SharedFrame extends Frame { shared?: Readonly<SharedAuthority> }
export interface ShareClientDependencies extends Omit<ClientDependencies, 'renew' | 'frame'> {
  origin: string
  expected: ShareExpected
  renew(signal?: AbortSignal): Promise<{ ok: true; share: ShareLease }>
  lease?(value: Readonly<ShareLease> | null): void
  frame?(frame: SharedFrame): void
}
export class ShareClient {
  readonly lease: Readonly<ShareLease> | null
  online: boolean
  constructor(deps: ShareClientDependencies)
  /** Explicitly resume after login/authorization repair or a replaced connection. */
  start(): void
  /** Foreground wake: probe online sockets or accelerate retries; never restart terminal denial/replacement. */
  resume(): void
  /** Network recovery only; does not resume a terminal authorization failure. */
  reconnect(): void
  stop(): void
  send(frame: Frame): void
  invoke<T = unknown>(dst: string, call: Call, timeout?: number, options?: InvokeOptions): Promise<T>
}
export const SHARED_READ_METHODS: ReadonlySet<string>
export const SHARED_WRITE_METHODS: ReadonlySet<string>
export function validateShareLease(value: unknown, expected: ShareExpected, now?: number): Readonly<ShareLease>
export class SharedReassembler {
  constructor(lease: () => ShareLease | null, now?: () => number, budget?: RequestBudget)
  clear(): void
  accept(frame: SharedFrame): SharedFrame | null
}
