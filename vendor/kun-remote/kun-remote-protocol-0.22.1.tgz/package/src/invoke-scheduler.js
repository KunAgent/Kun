/** Per-peer admission, shared by all transports using one account's RequestBudget. */
const schedulers = new WeakMap()
export function schedulerFor(budget) {
  let scheduler = schedulers.get(budget)
  if (!scheduler) { scheduler = new InvokeScheduler(); schedulers.set(budget, scheduler) }
  return scheduler
}

export class InvokeScheduler {
  constructor() { this.peers = new Map() }
  schedule(peer, priority, start) {
    let lane = this.peers.get(peer)
    if (!lane) {
      lane = { active: 0, background: 0, foreground: [], idle: [], streak: 0, draining: false }
      this.peers.set(peer, lane)
    }
    const job = { priority, start, active: false, done: false }
    const release = () => {
      if (job.done) return
      job.done = true
      if (job.active) {
        lane.active--
        if (priority === 'background') lane.background--
      } else {
        const queue = priority === 'background' ? lane.idle : lane.foreground
        const index = queue.indexOf(job)
        if (index >= 0) queue.splice(index, 1)
      }
      this.drain(peer, lane)
    }
    job.release = release
    ;(priority === 'background' ? lane.idle : lane.foreground).push(job)
    this.drain(peer, lane)
    return release
  }
  drain(peer, lane) {
    if (lane.draining) return
    lane.draining = true
    try {
      while (lane.active < 12) {
        const background = lane.idle.length > 0 && lane.background < 4
        // Interactive work goes first, but a sustained stream cannot starve preloads forever.
        const queue = background && (!lane.foreground.length || lane.streak >= 4) ? lane.idle : lane.foreground
        const job = queue.shift()
        if (!job) break
        job.active = true
        lane.active++
        if (job.priority === 'background') { lane.background++; lane.streak = 0 }
        else lane.streak = background ? lane.streak + 1 : 0
        job.start(job.release)
      }
    } finally {
      lane.draining = false
      if (!lane.active && !lane.foreground.length && !lane.idle.length) this.peers.delete(peer)
    }
  }
}
