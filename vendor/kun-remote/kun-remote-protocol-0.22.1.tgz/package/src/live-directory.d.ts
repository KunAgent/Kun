/** Desktop capability required before sending a directory subscription. */
export const DIRECTORY_LIVE_CAPABILITY: 'directory.live.v1'
export type DirectoryResource = 'agent' | 'code' | 'project' | 'group'
export interface DirectorySubscription { kind: 'directory'; id: 'all'; active: boolean }
export type DirectoryEvent = {
  resource: 'directory'
  resourceId: 'all'
} & ({ kind: 'subscribed' } | { kind: 'directory_changed'; resources: DirectoryResource[] })
