import { RemoteError } from './index.js'
import { bounded, assertActive } from './deadline.js'
export const VIP_TIERS = Object.freeze(['free', 'plus', 'pro', 'max'])
export function vipRequirement(code) {
  return code === 'vip_mobile_remote_required' ? { feature: 'mobileRemote', tier: 'plus' }
    : code === 'vip_personal_assistant_required' ? { feature: 'personalAssistant', tier: 'pro' } : null
}
export function parseEntitlements(value) {
  const effective = value?.effectiveTier
  const state = value?.status
  const dates = [value?.checkedAt, ...(value?.expiresAt === null ? [] : [value?.expiresAt])]
  if (!value || value.version !== 1 || !VIP_TIERS.includes(value.tier) || !VIP_TIERS.includes(effective) ||
      typeof value.userId !== 'string' || !/^[a-f0-9-]{36}$/.test(value.userId) ||
      !Number.isSafeInteger(value.revision) || value.revision < 0 ||
      dates.some(date => typeof date !== 'string' || !Number.isFinite(Date.parse(date))) ||
      !(state === 'active' && effective === value.tier && effective !== 'free' || state === 'free' && value.tier === 'free' && effective === 'free' || state === 'expired' && value.tier !== 'free' && effective === 'free') ||
      value.features?.mobileRemote !== (effective !== 'free') || value.features?.personalAssistant !== ['pro', 'max'].includes(effective)) {
    throw new RemoteError('INVALID_ENTITLEMENTS')
  }
  return { version: 1, userId: value.userId, tier: value.tier, effectiveTier: effective, status: state,
    revision: value.revision, checkedAt: value.checkedAt, expiresAt: value.expiresAt,
    features: { mobileRemote: value.features.mobileRemote, personalAssistant: value.features.personalAssistant } }
}
export async function fetchEntitlements(api, signal) {
  return bounded(async active => {
    const token = await api.token(); assertActive(active)
    if (!token) throw new RemoteError('LOGIN_REQUIRED')
    const response = await api.fetch(api.origin + '/api/account/v1/entitlements', {
      headers: { Authorization: 'Bearer ' + token }, redirect: 'error', signal: active
    })
    assertActive(active)
    if (!response.ok) throw Object.assign(new RemoteError(response.status === 401 ? 'LOGIN_REQUIRED' : 'ENTITLEMENTS_UNAVAILABLE'), { status: response.status })
    const result = parseEntitlements(await response.json()); assertActive(active); return result
  }, 15000, signal)
}
