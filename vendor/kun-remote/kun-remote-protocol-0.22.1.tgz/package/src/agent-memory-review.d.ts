import type { AgentMemoryType } from './agent-memory.js'
import type { PageParams } from './values.js'
type MemoryReviewAgent = { agentId: string }
type Candidate = MemoryReviewAgent & { candidateId: string; expectedRevision: number }
type Memory = MemoryReviewAgent & { memoryId: string; expectedFingerprint: string }
type Slice = { contentOffset?: number; maxChars?: number }
export interface MemoryContentSlice { text: string; offset: number; nextOffset?: number; totalChars: number }
export interface AgentMemoryCandidateSummary {
  candidateId: string
  revision: number
  status: 'pending' | 'conflicted'
  action: 'create' | 'update' | 'supersede'
  type: AgentMemoryType
  proposed: { snippet: string; contentLength: number; contentTruncated: boolean; summary: true }
  /** Server eligibility hint; the decision still revalidates current state. */
  canAccept?: boolean
  targetAvailable: boolean
  target?: { memoryId: string; fingerprint: string; contentLength: number; disabled: boolean }
  reason?: 'user_locked' | 'source_changed' | 'conflicting_memory' | 'comparison_review_required'
  source: { roomId: string; messageIds: string[] }
}
export interface AgentMemoryRevisionSummary {
  revision: number
  changedAt: string
  operation: 'create' | 'update' | 'disable' | 'restore' | 'forget' | 'rollback' | 'supersede'
  type: AgentMemoryType
  contentLength: number
  available: true
}
export interface AgentHistoryParams {
  'agent.memory.candidates.list': MemoryReviewAgent & PageParams
  'agent.memory.candidates.get': Candidate & Slice & ({ side: 'proposed' } | { side: 'current'; expectedTargetFingerprint: string })
  'agent.memory.candidates.decide': Candidate & ({ decision: 'accept'; expectedTargetFingerprint?: string } | { decision: 'reject' })
  'agent.memory.history.list': Memory & PageParams
  'agent.memory.history.get': Memory & Slice & { revision: number }
}
type MemoryReviewPage = { hasMore: boolean; complete: boolean; nextCursor?: string }
export interface AgentHistoryResults {
  'agent.memory.candidates.list': MemoryReviewAgent & MemoryReviewPage & { candidates: AgentMemoryCandidateSummary[] }
  'agent.memory.candidates.get': MemoryReviewAgent & { candidateId: string; revision: number; side: 'proposed' | 'current'; targetFingerprint?: string; content: MemoryContentSlice }
  'agent.memory.candidates.decide': { candidateId: string; status: 'completed' | 'skipped'; revision: number; memoryId?: string }
  'agent.memory.history.list': MemoryReviewAgent & MemoryReviewPage & { memoryId: string; fingerprint: string; currentRevision: number; coverage: 'retained_local_revisions'; revisions: AgentMemoryRevisionSummary[] }
  'agent.memory.history.get': MemoryReviewAgent & { memoryId: string; fingerprint: string; revision: number; coverage: 'retained_local_revisions'; content: MemoryContentSlice }
}
export type AgentHistoryMethod = keyof AgentHistoryParams
export const AGENT_HISTORY_METHODS: readonly AgentHistoryMethod[]
export const AGENT_HISTORY_READ_METHODS: readonly AgentHistoryMethod[]
export function validateAgentHistoryParams<M extends AgentHistoryMethod>(method: M, params: AgentHistoryParams[M]): void
