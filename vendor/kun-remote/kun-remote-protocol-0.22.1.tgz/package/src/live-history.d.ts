export type LiveHistoryKind = 'code' | 'agent' | 'group'
export const LIVE_HISTORY_VERSION: 1
export const LIVE_DELTA_MAX_BYTES: number
export interface LiveListChange { order?: string[]; upsert?: Record<string, unknown>[] }
export interface LiveHistoryDelta extends LiveListChange {
  v: 1
  set?: Record<string, unknown>
  unset?: string[]
  /** Code tasks only: changed items per turn. */
  items?: Record<string, LiveListChange>
}
export type LiveHistoryDiff = { unchanged: true } | { snapshot: true } | { delta: LiveHistoryDelta }
/** One live event's payload field. A snapshot starts or restarts a chain; a delta extends `base`. */
export type LiveHistoryFrame =
  | { rev: number; snapshot: Record<string, unknown> }
  | { rev: number; base: number; delta: LiveHistoryDelta }
  | { rev: 0; error: string }
export function diffHistory(kind: LiveHistoryKind, previous: unknown, next: unknown): LiveHistoryDiff
export function applyHistoryDelta<T extends Record<string, unknown>>(kind: LiveHistoryKind, previous: T, delta: LiveHistoryDelta): T
export function liveCursor(kind: LiveHistoryKind, page: unknown): number
