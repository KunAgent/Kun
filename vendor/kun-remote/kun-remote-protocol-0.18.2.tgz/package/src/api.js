import { RemoteError } from './index.js'
import { assertActive, bounded } from './deadline.js'
export class RemoteApi {
  constructor({ origin, token, identity, fetch: fetcher = globalThis.fetch }) {
    const url = new URL(origin)
    if (
      url.protocol !== 'https:' &&
      !(
        url.protocol === 'http:' &&
        ['localhost', '127.0.0.1'].includes(url.hostname)
      )
    )
      throw new Error('UNTRUSTED_ORIGIN')
    this.origin = url.origin
    this.token = token
    this.identity = identity
    this.fetch = fetcher
  }
  async request(path, method = 'GET', body, raw = false, signal) {
    if (!/^\/[a-z0-9/-]+$/.test(path)) throw new Error('INVALID_PATH')
    return bounded(async (active) => {
      const identity = await this.identity()
      assertActive(active)
      const token = await this.token()
      assertActive(active)
      if (!token) throw new RemoteError('LOGIN_REQUIRED')
      const headers = {
        Authorization: 'Bearer ' + token,
        'X-Kun-Device': identity.id,
        'X-Kun-Device-Credential': identity.credential
      }
      if (body !== undefined)
        headers['Content-Type'] = raw
          ? 'application/octet-stream'
          : 'application/json'
      const r = await this.fetch(this.origin + '/api/remote/v1' + path, {
        method,
        headers,
        body:
          body === undefined ? undefined : raw ? body : JSON.stringify(body),
        redirect: 'error',
        signal: active
      })
      assertActive(active)
      if (!r.ok) {
        let code = 'HTTP_' + r.status
        try {
          const v = await r.json()
          if (typeof v.error === 'string') code = v.error
        } catch {}
        // Preserve HTTP authority even when the server supplies a more specific error code.
        throw Object.assign(new RemoteError(code), { status: r.status })
      }
      const result = raw ? r : await r.json()
      assertActive(active)
      return result
    }, raw ? 120000 : 15000, signal)
  }
  ticket(signal) {
    return this.request('/relay-tickets', 'POST', undefined, false, signal)
  }
  renew(signal) {
    return this.request('/relay-lease', 'POST', undefined, false, signal)
  }
}
