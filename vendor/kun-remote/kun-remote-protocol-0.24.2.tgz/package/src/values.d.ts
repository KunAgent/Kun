export type ResourceKind = 'catalog' | 'code' | 'agent' | 'message' | 'attention' | 'artifact' | 'project' | 'file' | 'group' | 'collaboration' | 'schedule' | 'plugin' | 'share' | 'desktop'
export type ResourceRef = { kind: 'code' | 'agent'; id: string }
export type PageParams = { cursor?: string; limit?: number }
export type RemotePage<T, K extends string> = { [P in K]: T[] } & {
  hasMore: boolean
  nextCursor?: string
}
type AtLeastOne<T> = { [K in keyof T]-?: Required<Pick<T, K>> & Partial<Omit<T, K>> }[keyof T]

/** Shared resource targets retained on the root type surface. */
export type Agent = { agentId: string }
export type Thread = { threadId: string }
export type Page = { hasMore: boolean; complete: boolean; nextCursor?: string }
