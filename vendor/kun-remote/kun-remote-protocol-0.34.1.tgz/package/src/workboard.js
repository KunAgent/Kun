import { RemoteError } from './index.js'

export const WORKBOARD_MAX_HOSTS = 16
export const WORKBOARD_MAX_SESSIONS = 200
export const WORKBOARD_PHASES = Object.freeze(['running', 'approval', 'input', 'failed', 'completed', 'stopped'])
const id = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(value)
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value)
const time = value => Number.isSafeInteger(value) && value > 0
const invalid = () => { throw new RemoteError('INVALID_WORKBOARD') }
export const workboardKey = value => value.hostId + ':' + value.kind + ':' + value.id

/** Titles, prompts, paths and tool arguments are deliberately absent from the cloud contract. */
export function validateWorkboardSnapshot(value) {
  if (!object(value) || value.schemaVersion !== 1 || typeof value.complete !== 'boolean' || !time(value.observedAt) ||
    !Array.isArray(value.sessions) || value.sessions.length > WORKBOARD_MAX_SESSIONS ||
    Object.keys(value).some(key => !['schemaVersion', 'complete', 'observedAt', 'sessions'].includes(key))) invalid()
  const seen = new Set()
  for (const row of value.sessions) {
    if (!object(row) || !id(row.id) || !id(row.runId) || !['code', 'agent'].includes(row.kind) ||
      !WORKBOARD_PHASES.includes(row.phase) || !time(row.updatedAt) ||
      Object.keys(row).sort().join() !== 'id,kind,phase,runId,updatedAt') invalid()
    const key = row.kind + ':' + row.id
    if (seen.has(key)) invalid()
    seen.add(key)
  }
  return value
}
export function validateWorkboard(value) {
  if (!object(value) || value.schemaVersion !== 1 || !time(value.checkedAt) ||
    !Array.isArray(value.hosts) || value.hosts.length > WORKBOARD_MAX_HOSTS || typeof value.pushAvailable !== 'boolean') invalid()
  const hosts = new Set()
  for (const host of value.hosts) {
    if (!object(host) || !id(host.hostId) || hosts.has(host.hostId) || !time(host.receivedAt) || !time(host.freshUntil)) invalid()
    validateWorkboardSnapshot(host.snapshot)
    hosts.add(host.hostId)
  }
  return value
}
export class RemoteWorkboardApi {
  constructor(api) { this.api = api }
  async snapshot(signal) { return validateWorkboard(await this.api.request('/workboard', 'GET', undefined, false, signal)) }
  publisher(signal) { return this.api.request('/workboard/publisher', 'POST', {}, false, signal) }
  publish(epoch, sequence, snapshot, signal) {
    validateWorkboardSnapshot(snapshot)
    if (!id(epoch) || !Number.isSafeInteger(sequence) || sequence < 1) invalid()
    return this.api.request('/workboard/snapshot', 'PUT', { epoch, sequence, snapshot }, false, signal)
  }
  register(value, signal) { return this.api.request('/workboard/activity', 'PUT', { ...value, schemaVersion: 1 }, false, signal) }
  stop(roundId, signal) { return this.api.request('/workboard/activity/stop', 'POST', { roundId }, false, signal) }
}
