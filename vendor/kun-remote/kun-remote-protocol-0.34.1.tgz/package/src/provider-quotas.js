import { check, object, integer, oneOf, string, optional } from './validation.js'
export const PROVIDER_QUOTA_METHODS = Object.freeze(['usage.quotas.list'])
const timestamp = value => { string(value, 40); check(Number.isFinite(Date.parse(value))) }
const number = value => check(typeof value === 'number' && Number.isFinite(value))
function costWindow(value) {
  object(value, ['requests', 'totalTokens', 'amount', 'coverage'])
  integer(value.requests); integer(value.totalTokens)
  if (value.amount !== null) { number(value.amount); check(value.amount >= 0) }
  oneOf(value.coverage, ['complete', 'partial', 'unavailable'])
}
export function validateProviderQuotaParams(_method, value) { object(value, []); return value }
export function validateProviderQuotas(value) {
  object(value, ['entries', 'truncated', 'refreshedAt'])
  check(Array.isArray(value.entries) && value.entries.length <= 50 && typeof value.truncated === 'boolean')
  timestamp(value.refreshedAt)
  value.entries.forEach(entry => {
    object(entry, ['providerId', 'providerName', 'status', 'metrics', 'metricsTruncated'], ['updatedAt', 'localCost'])
    string(entry.providerId, 128); string(entry.providerName, 120)
    oneOf(entry.status, ['available', 'unsupported', 'missing_credentials', 'error'])
    check(typeof entry.metricsTruncated === 'boolean' && Array.isArray(entry.metrics) && entry.metrics.length <= 16)
    optional(entry, 'updatedAt', timestamp)
    entry.metrics.forEach(metric => {
      object(metric, ['id', 'label', 'unit'], ['used', 'limit', 'remaining', 'usedPercent', 'resetsAt', 'windowSeconds'])
      string(metric.id, 256); string(metric.label, 512); string(metric.unit, 64)
      for (const key of ['used', 'limit', 'remaining', 'usedPercent']) optional(metric, key, number)
      if (metric.usedPercent !== undefined) check(metric.usedPercent >= 0 && metric.usedPercent <= 100)
      optional(metric, 'windowSeconds', value => integer(value, 1, 400 * 86400))
      optional(metric, 'resetsAt', timestamp)
    })
    if (entry.localCost !== undefined) {
      object(entry.localCost, ['kind', 'currency', 'today', 'last30Days', 'updatedAt'])
      check(entry.localCost.kind === 'reference_api_estimate' && entry.localCost.currency === 'USD')
      costWindow(entry.localCost.today); costWindow(entry.localCost.last30Days); timestamp(entry.localCost.updatedAt)
    }
  })
  return value
}
