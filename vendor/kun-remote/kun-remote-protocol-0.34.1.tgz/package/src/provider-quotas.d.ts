import type { UsagePriceCoverage } from './usage-summary.js'
export interface ProviderQuotaMetric {
  id: string; label: string; unit: string
  used?: number; limit?: number; remaining?: number; usedPercent?: number
  resetsAt?: string; windowSeconds?: number
}
export interface ProviderCostWindow {
  requests: number; totalTokens: number; amount: number | null; coverage: UsagePriceCoverage
}
export interface ProviderQuota {
  providerId: string; providerName: string
  status: 'available' | 'unsupported' | 'missing_credentials' | 'error'
  metrics: ProviderQuotaMetric[]
  metricsTruncated: boolean
  updatedAt?: string
  localCost?: { kind: 'reference_api_estimate'; currency: 'USD'; today: ProviderCostWindow; last30Days: ProviderCostWindow; updatedAt: string }
}
/** Explicit projection: no login identity, token, endpoint, raw error or dashboard URL. */
export interface ProviderQuotas { entries: ProviderQuota[]; truncated: boolean; refreshedAt: string }
export interface ProviderQuotaParams { 'usage.quotas.list': Record<string, never> }
export interface ProviderQuotaResults { 'usage.quotas.list': ProviderQuotas }
export const PROVIDER_QUOTA_METHODS: readonly ['usage.quotas.list']
export function validateProviderQuotaParams(method: string, value: unknown): Record<string, never>
export function validateProviderQuotas(value: unknown): ProviderQuotas
