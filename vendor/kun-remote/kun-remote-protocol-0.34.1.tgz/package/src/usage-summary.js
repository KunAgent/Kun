import { check, object, integer, oneOf, string } from './validation.js'

export const USAGE_SUMMARY_METHODS = Object.freeze(['usage.summary.get'])
const counts = ['inputTokens', 'outputTokens', 'reasoningTokens', 'cachedTokens', 'cacheMissTokens', 'cacheWriteTokens',
  'totalTokens', 'unpricedRequests', 'savedTokens', 'turns', 'threadCount']
const money = ['costUsd', 'costCny', 'referenceUsd', 'referenceCny']
const counterKeys = [...counts, ...money, 'referenceCoverage', 'cacheHitRate']
function date(value) {
  check(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) &&
    Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value)
}
function counters(value, extra = []) {
  object(value, [...counterKeys, ...extra])
  counts.forEach(key => integer(value[key]))
  money.forEach(key => check(typeof value[key] === 'number' && Number.isFinite(value[key]) && value[key] >= 0))
  oneOf(value.referenceCoverage, ['complete', 'partial', 'unavailable'])
  check(value.cacheHitRate === null || typeof value.cacheHitRate === 'number' && Number.isFinite(value.cacheHitRate) && value.cacheHitRate >= 0 && value.cacheHitRate <= 1)
}
export function validateUsageSummaryParams(_method, value) {
  object(value, ['days', 'modelScope'])
  oneOf(value.days, [1, 7, 30, 90])
  oneOf(value.modelScope, ['all', 'primary', 'side'])
  return value
}
export function validateUsageSummary(value) {
  object(value, ['days', 'modelScope', 'from', 'to', 'timezone', 'totals', 'daily', 'models', 'modelsTruncated', 'degraded', 'syncedAt'])
  validateUsageSummaryParams('', { days: value.days, modelScope: value.modelScope })
  date(value.from); date(value.to); check(value.from <= value.to)
  string(value.timezone, 80)
  counters(value.totals)
  check(Array.isArray(value.daily) && value.daily.length <= 90)
  value.daily.forEach(item => { counters(item, ['date']); date(item.date); check(item.date >= value.from && item.date <= value.to) })
  check(new Set(value.daily.map(item => item.date)).size === value.daily.length)
  check(Array.isArray(value.models) && value.models.length <= 100)
  value.models.forEach(item => { counters(item, ['model']); string(item.model, 256) })
  check(typeof value.modelsTruncated === 'boolean' && typeof value.degraded === 'boolean')
  integer(value.syncedAt, 1)
  return value
}
