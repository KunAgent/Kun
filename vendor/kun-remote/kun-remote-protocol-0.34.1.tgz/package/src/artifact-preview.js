import { check, id, integer, object, oneOf, optional, page, resource, revision, string } from './validation.js'

export const ARTIFACT_PREVIEW_METHODS = Object.freeze(['artifact.catalog.list', 'artifact.preview.get', 'artifact.widget.state.update'])
export const ARTIFACT_PREVIEW_READ_METHODS = new Set(['artifact.catalog.list', 'artifact.preview.get'])
const KINDS = ['file', 'design', 'component', 'diagram', 'widget', 'report', 'chart', 'visualization', 'canvas', 'slides', 'mcp-app']
const MAX_ASSET_BYTES = 25 * 1024 * 1024

export function validateArtifactPreviewParams(method, params) {
  switch (method) {
    case 'artifact.catalog.list':
      object(params, ['resource'], ['cursor', 'limit'])
      resource(params.resource)
      page(params)
      break
    case 'artifact.preview.get':
      object(params, ['resource', 'id', 'revision'])
      resource(params.resource)
      id(params.id)
      revision(params.revision, 'artifact')
      break
    case 'artifact.widget.state.update':
      object(params, ['resource', 'id', 'revision', 'state'])
      resource(params.resource)
      id(params.id)
      revision(params.revision, 'artifact')
      widgetState(params.state)
      break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return params
}

export function validateArtifactPreviewExport(params) {
  object(params, ['previewResource', 'previewId', 'previewRevision', 'previewAssetId'])
  resource(params.previewResource)
  id(params.previewId)
  revision(params.previewRevision, 'artifact')
  id(params.previewAssetId)
  return params
}

function summary(value) {
  object(value, ['id', 'resource', 'kind', 'title', 'name', 'mimeType', 'size', 'revision', 'available'],
    ['updatedAt', 'messageId', 'turnId', 'pageCount', 'detail'])
  id(value.id)
  resource(value.resource)
  oneOf(value.kind, KINDS)
  string(value.title, 240)
  string(value.name, 512)
  mime(value.mimeType)
  integer(value.size, 0)
  revision(value.revision, 'artifact')
  check(typeof value.available === 'boolean')
  optional(value, 'updatedAt', v => { string(v, 64); check(Number.isFinite(Date.parse(v))) })
  optional(value, 'messageId', id)
  optional(value, 'turnId', id)
  optional(value, 'pageCount', v => integer(v, 0, 512))
  optional(value, 'detail', v => string(v, 500))
}

function mime(value) {
  string(value, 160)
  check(/^[\w.+-]+\/[\w.+-]+(?:;[\x20-\x7e]*)?$/.test(value))
}

function virtualPath(value) {
  string(value, 1024)
  check(!/[\\\x00-\x1f\x7f?#]/.test(value))
  check(!value.startsWith('/') && !/^[a-z][a-z0-9+.-]*:/i.test(value))
  check(value.split('/').every(part => part && part !== '.' && part !== '..'))
}

function asset(value) {
  object(value, ['id', 'path', 'name', 'mimeType', 'size', 'sha256'], ['dependencies'])
  id(value.id)
  virtualPath(value.path)
  string(value.name, 512)
  mime(value.mimeType)
  integer(value.size, 1, MAX_ASSET_BYTES)
  check(typeof value.sha256 === 'string' && /^[a-f0-9]{64}$/.test(value.sha256))
}

function widgetState(state) {
  object(state, [], ['modelContent', 'privateContent'])
  const encoded = JSON.stringify(state)
  check(typeof encoded === 'string' && new TextEncoder().encode(encoded).byteLength <= 16 * 1024)
}

function viewport(value) {
  object(value, ['width', 'height'])
  integer(value.width, 1, 10000)
  integer(value.height, 1, 20000)
}

function origin(value) {
  string(value, 256)
  let url
  try { url = new URL(value) } catch { check(false) }
  check(url.protocol === 'https:' && !url.username && !url.password && url.origin === value)
  check(!['localhost', 'localhost.localdomain'].includes(url.hostname.toLowerCase()))
  check(!url.hostname.endsWith('.localhost') && !url.hostname.endsWith('.local'))
  check(!/^\[|^\d+(?:\.\d+){3}$/.test(url.hostname))
}

function policy(value) {
  object(value, [], ['assetOrigins', 'scriptOrigins', 'connectOrigins'])
  for (const key of ['assetOrigins', 'scriptOrigins', 'connectOrigins']) {
    optional(value, key, values => {
      check(Array.isArray(values) && values.length <= (key === 'scriptOrigins' ? 12 : 24))
      values.forEach(origin)
      check(new Set(values).size === values.length)
    })
  }
}

export function validateArtifactPreview(value) {
  object(value, ['version', 'artifact', 'renderer', 'assets', 'pages'],
    ['entryAssetId', 'dataAssetId', 'originalAssetId', 'viewport', 'resourcePolicy', 'widgetState', 'missingResources'])
  check(value.version === 1)
  summary(value.artifact)
  oneOf(value.renderer, ['file', 'html', 'data', 'pages'])
  check(Array.isArray(value.assets) && value.assets.length <= 256)
  value.assets.forEach(asset)
  const ids = new Set(value.assets.map(item => item.id))
  check(ids.size === value.assets.length)
  check(new Set(value.assets.map(item => item.path)).size === value.assets.length)
  for (const item of value.assets) optional(item, 'dependencies', values => {
    check(Array.isArray(values) && values.length <= 256 && new Set(values).size === values.length)
    values.forEach(value => { id(value); check(ids.has(value)) })
  })
  check(Array.isArray(value.pages) && value.pages.length <= 512)
  const pageIds = new Set()
  for (const item of value.pages) {
    object(item, ['id', 'title', 'assetId', 'width', 'height'], ['section'])
    id(item.id)
    check(!pageIds.has(item.id))
    pageIds.add(item.id)
    string(item.title, 240)
    id(item.assetId)
    check(ids.has(item.assetId))
    integer(item.width, 1, 10000)
    integer(item.height, 1, 20000)
    optional(item, 'section', v => string(v, 120))
  }
  for (const key of ['entryAssetId', 'dataAssetId', 'originalAssetId']) {
    optional(value, key, v => { id(v); check(ids.has(v)) })
  }
  if (value.renderer === 'file' || value.renderer === 'html') check(Boolean(value.entryAssetId))
  if (value.renderer === 'data') check(Boolean(value.dataAssetId))
  if (value.renderer === 'pages') check(value.pages.length > 0)
  optional(value, 'viewport', viewport)
  optional(value, 'resourcePolicy', policy)
  optional(value, 'widgetState', widgetState)
  optional(value, 'missingResources', values => {
    check(Array.isArray(values) && values.length <= 100)
    values.forEach(v => string(v, 1024))
  })
  return value
}

export function validateArtifactCatalog(value) {
  object(value, ['artifacts', 'hasMore'], ['nextCursor'])
  check(Array.isArray(value.artifacts) && value.artifacts.length <= 50)
  value.artifacts.forEach(summary)
  check(new Set(value.artifacts.map(item => item.id)).size === value.artifacts.length)
  check(typeof value.hasMore === 'boolean')
  optional(value, 'nextCursor', v => string(v, 2048))
  check(!value.hasMore || Boolean(value.nextCursor))
  return value
}
