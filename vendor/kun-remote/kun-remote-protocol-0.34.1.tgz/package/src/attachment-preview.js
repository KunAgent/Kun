import { check, id, integer, object, string } from './validation.js'

export const ATTACHMENT_PREVIEW_CAPABILITY = 'attachment.preview'
export const ATTACHMENT_PREVIEW_LIMITS = Object.freeze({ edge: 480, bytes: 128 * 1024 })
export const ATTACHMENT_PREVIEW_METHODS = Object.freeze(['attachment.preview'])

export function validateAttachmentPreviewParams(_method, params) {
  object(params, ['attachmentId', 'threadId'])
  check(typeof params.attachmentId === 'string' && /^att_[a-f0-9]{24}$/.test(params.attachmentId))
  id(params.threadId)
  return params
}

/** A preview contains only bounded image bytes; source paths and remote URLs never cross this boundary. */
export function validateAttachmentPreview(value) {
  object(value, ['attachmentId', 'name', 'mimeType', 'thumbnail'])
  check(typeof value.attachmentId === 'string' && /^att_[a-f0-9]{24}$/.test(value.attachmentId))
  string(value.name, 180)
  string(value.mimeType, 120)
  if (value.thumbnail === null) return value
  check(value.mimeType.startsWith('image/'))
  const image = value.thumbnail
  object(image, ['mimeType', 'width', 'height', 'size', 'sha256', 'dataBase64'])
  check(image.mimeType === 'image/jpeg' || image.mimeType === 'image/png')
  integer(image.width, 1, ATTACHMENT_PREVIEW_LIMITS.edge)
  integer(image.height, 1, ATTACHMENT_PREVIEW_LIMITS.edge)
  integer(image.size, 1, ATTACHMENT_PREVIEW_LIMITS.bytes)
  check(typeof image.sha256 === 'string' && /^[a-f0-9]{64}$/.test(image.sha256))
  check(typeof image.dataBase64 === 'string' && image.dataBase64.length === Math.ceil(image.size / 3) * 4 &&
    /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(image.dataBase64))
  return value
}
