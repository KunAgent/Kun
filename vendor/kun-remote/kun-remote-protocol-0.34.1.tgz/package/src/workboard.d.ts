import type { RemoteApi } from './index.js'
export const WORKBOARD_MAX_HOSTS: 16
export const WORKBOARD_MAX_SESSIONS: 200
export const WORKBOARD_PHASES: readonly WorkboardPhase[]
export type WorkboardPhase = 'running' | 'approval' | 'input' | 'failed' | 'completed' | 'stopped'
export interface WorkboardSession { id: string; kind: 'code' | 'agent'; runId: string; phase: WorkboardPhase; updatedAt: number }
export interface WorkboardHostSnapshot { schemaVersion: 1; complete: boolean; observedAt: number; sessions: WorkboardSession[] }
export interface WorkboardHost { hostId: string; receivedAt: number; freshUntil: number; snapshot: WorkboardHostSnapshot }
export interface WorkboardSnapshot { schemaVersion: 1; checkedAt: number; hosts: WorkboardHost[]; pushAvailable: boolean }
export interface WorkboardPin { hostId: string; kind: 'code' | 'agent'; id: string }
export interface WorkboardRegistration {
  roundId: string; activityId: string; token: string | null; environment: 'sandbox' | 'production'
  startedAt: number
  language: 'zh' | 'en'; allHosts: boolean; hostIds: string[]; pinned: WorkboardPin[]
}
export function workboardKey(value: WorkboardPin): string
export function validateWorkboardSnapshot(value: unknown): WorkboardHostSnapshot
export function validateWorkboard(value: unknown): WorkboardSnapshot
export class RemoteWorkboardApi {
  constructor(api: RemoteApi)
  snapshot(signal?: AbortSignal): Promise<WorkboardSnapshot>
  publisher(signal?: AbortSignal): Promise<{ epoch: string }>
  publish(epoch: string, sequence: number, snapshot: WorkboardHostSnapshot, signal?: AbortSignal): Promise<{ ok: boolean }>
  register(value: WorkboardRegistration, signal?: AbortSignal): Promise<{ ok: boolean; pushAvailable: boolean }>
  stop(roundId: string, signal?: AbortSignal): Promise<{ ok: boolean }>
}
