import type { PageParams, RemotePage, ResourceRef } from './values.js'

export type ArtifactKind =
  | 'file' | 'design' | 'component' | 'diagram' | 'widget'
  | 'report' | 'chart' | 'visualization' | 'canvas' | 'slides' | 'mcp-app'

/** An immutable view of one delivered artifact, not an arbitrary workspace file. */
export interface ArtifactSummary {
  id: string
  resource: ResourceRef
  kind: ArtifactKind
  title: string
  name: string
  mimeType: string
  size: number
  revision: string
  available: boolean
  updatedAt?: string
  messageId?: string
  turnId?: string
  pageCount?: number
  detail?: string
}

export interface ArtifactPreviewAsset {
  id: string
  /** Virtual bundle path. Never an absolute host path or a download URL. */
  path: string
  name: string
  mimeType: string
  size: number
  sha256: string
  dependencies?: string[]
}

export interface ArtifactPreviewPage {
  id: string
  title: string
  assetId: string
  width: number
  height: number
  section?: string
}

export interface ArtifactResourcePolicy {
  assetOrigins?: string[]
  scriptOrigins?: string[]
  connectOrigins?: string[]
}

export interface ArtifactWidgetState {
  modelContent?: unknown
  privateContent?: unknown
}

/** Large bodies and all assets use the checksum-verified attachment transfer path. */
export interface ArtifactPreview {
  version: 1
  artifact: ArtifactSummary
  renderer: 'file' | 'html' | 'data' | 'pages'
  assets: ArtifactPreviewAsset[]
  pages: ArtifactPreviewPage[]
  entryAssetId?: string
  dataAssetId?: string
  originalAssetId?: string
  viewport?: { width: number; height: number }
  resourcePolicy?: ArtifactResourcePolicy
  widgetState?: ArtifactWidgetState
  missingResources?: string[]
}

export interface ArtifactPreviewExportParams {
  previewResource: ResourceRef
  previewId: string
  previewRevision: string
  previewAssetId: string
}

export interface ArtifactPreviewParams {
  'artifact.catalog.list': PageParams & { resource: ResourceRef }
  'artifact.preview.get': { resource: ResourceRef; id: string; revision: string }
  'artifact.widget.state.update': { resource: ResourceRef; id: string; revision: string; state: ArtifactWidgetState }
}

export interface ArtifactPreviewResults {
  'artifact.catalog.list': RemotePage<ArtifactSummary, 'artifacts'>
  'artifact.preview.get': ArtifactPreview
  'artifact.widget.state.update': { state: ArtifactWidgetState; updatedAt: string }
}

export const ARTIFACT_PREVIEW_METHODS: readonly ['artifact.catalog.list', 'artifact.preview.get', 'artifact.widget.state.update']
export const ARTIFACT_PREVIEW_READ_METHODS: ReadonlySet<string>
export function validateArtifactPreviewParams(method: string, params: unknown): unknown
export function validateArtifactPreviewExport(params: unknown): ArtifactPreviewExportParams
export function validateArtifactPreview(value: unknown): ArtifactPreview
export function validateArtifactCatalog(value: unknown): ArtifactPreviewResults['artifact.catalog.list']
