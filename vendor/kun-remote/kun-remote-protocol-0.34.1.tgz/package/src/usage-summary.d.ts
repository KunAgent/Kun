export type UsagePeriod = 1 | 7 | 30 | 90
export type UsageModelScope = 'all' | 'primary' | 'side'
export type UsagePriceCoverage = 'complete' | 'partial' | 'unavailable'
/** Local accounting, never a provider bill or the remaining context window. */
export interface UsageCounters {
  inputTokens: number
  outputTokens: number
  reasoningTokens: number
  cachedTokens: number
  cacheMissTokens: number
  cacheWriteTokens: number
  totalTokens: number
  costUsd: number
  costCny: number
  referenceUsd: number
  referenceCny: number
  referenceCoverage: UsagePriceCoverage
  unpricedRequests: number
  savedTokens: number
  turns: number
  threadCount: number
  cacheHitRate: number | null
}
export interface UsageSummary {
  days: UsagePeriod
  modelScope: UsageModelScope
  from: string
  to: string
  timezone: string
  totals: UsageCounters
  daily: Array<UsageCounters & { date: string }>
  models: Array<UsageCounters & { model: string }>
  modelsTruncated: boolean
  degraded: boolean
  syncedAt: number
}
export interface UsageSummaryParams { 'usage.summary.get': { days: UsagePeriod; modelScope: UsageModelScope } }
export interface UsageSummaryResults { 'usage.summary.get': UsageSummary }
export const USAGE_SUMMARY_METHODS: readonly ['usage.summary.get']
export function validateUsageSummaryParams(method: string, value: unknown): UsageSummaryParams['usage.summary.get']
export function validateUsageSummary(value: unknown): UsageSummary
