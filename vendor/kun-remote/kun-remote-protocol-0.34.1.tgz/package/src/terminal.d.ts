export type TerminalOrigin = { kind: 'code' | 'agent'; id: string }
export type TerminalState = 'running' | 'exited'
export interface TerminalSession {
  schemaVersion: 1
  startId: string
  sessionId: string
  /** Attach generation fences input from old views. */
  epoch: number
  origin: TerminalOrigin
  /** Resolved by the computer, never supplied by the controller. */
  cwd: string
  cols: number
  rows: number
  state: TerminalState
  exitCode?: number
  signal?: string
}
export interface TerminalSnapshot {
  state: TerminalState
  session: TerminalSession
  snapshot: string
  sequence: number
  inputSequence: number
  epoch: number
}
export interface TerminalParams {
  'terminal.list': Record<string, never>
  'terminal.open': { startId: string; origin: TerminalOrigin; cols?: number; rows?: number }
  'terminal.attach': { sessionId: string }
  'terminal.write': { sessionId: string; epoch: number; sequence: number; data: string }
  'terminal.resize': { sessionId: string; cols: number; rows: number }
  'terminal.close': { sessionId: string; reason: string }
}
export interface TerminalResults {
  'terminal.list': { sessions: TerminalSession[] }
  'terminal.open': TerminalSnapshot
  'terminal.attach': TerminalSnapshot | { state: 'missing' }
  'terminal.write': { accepted: true; sequence: number }
  'terminal.resize': { accepted: true; cols: number; rows: number }
  'terminal.close': { state: 'closed'; sessionId: string; reason: string; confirmed: true } | { state: 'missing' }
}
export type TerminalMethod = keyof TerminalParams
export interface TerminalOutputEvent {
  event: 'terminal.output'
  sessionId: string
  epoch: number
  sequence: number
  data: string
  lossy: true
}
export interface TerminalExitedEvent {
  event: 'terminal.exited'
  sessionId: string
  epoch: number
  sequence: number
  exitCode: number
  signal?: string
}
export type TerminalEvent = TerminalOutputEvent | TerminalExitedEvent
export const TERMINAL_CAPABILITY: 'terminal.v1'
export const TERMINAL_METHODS: readonly TerminalMethod[]
export const TERMINAL_READ_METHODS: readonly TerminalMethod[]
export const TERMINAL_CONTROL_METHODS: readonly TerminalMethod[]
export const TERMINAL_EVENTS: readonly ['terminal.output', 'terminal.exited']
export const TERMINAL_LIMITS: Readonly<{
  sessionsPerPeer: number; sessions: number; tombstones: number
  defaultCols: number; defaultRows: number; maxCols: number; maxRows: number
  writeBytes: number; outputChunkBytes: number; outputBacklog: number
  outputBytes: number; snapshotBytes: number; sequence: number; cwdBytes: number
  reasonBytes: number; retentionMs: number; startTimeoutMs: number; closeTimeoutMs: number
}>
export function validateTerminalParams<M extends TerminalMethod>(method: M, value: unknown): TerminalParams[M]
export function validateTerminalSession(value: unknown): TerminalSession
export function isAbsoluteTerminalCwd(value: unknown): value is string
export function validateTerminalResult<M extends TerminalMethod>(method: M, value: unknown): TerminalResults[M]
export function validateTerminalEvent(value: unknown): TerminalEvent
