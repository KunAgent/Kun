export interface AttachmentPreviewParams {
  'attachment.preview': { attachmentId: string; threadId: string }
}
export interface AttachmentPreview {
  attachmentId: string
  name: string
  mimeType: string
  /** Null for ordinary files or images the desktop cannot decode. */
  thumbnail: {
    mimeType: 'image/jpeg' | 'image/png'
    width: number
    height: number
    size: number
    sha256: string
    dataBase64: string
  } | null
}
export interface AttachmentPreviewResults { 'attachment.preview': AttachmentPreview }
export const ATTACHMENT_PREVIEW_CAPABILITY: 'attachment.preview'
export const ATTACHMENT_PREVIEW_LIMITS: Readonly<{ edge: 480; bytes: number }>
export const ATTACHMENT_PREVIEW_METHODS: readonly ['attachment.preview']
export function validateAttachmentPreviewParams(method: 'attachment.preview', params: unknown): AttachmentPreviewParams['attachment.preview']
export function validateAttachmentPreview(value: unknown): AttachmentPreview
