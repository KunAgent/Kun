import type { ProjectExportParams } from './project-files.js'
import type { AvatarExportParams } from './agent-avatars.js'
import type { ArtifactPreviewExportParams } from './artifact-preview.js'
type ExportField = 'attachmentId' | 'threadId' | 'agentId' | 'artifactId' | 'version' | 'projectId' | 'fileRef' | 'revision' | 'avatarRevision' |
  'previewResource' | 'previewId' | 'previewRevision' | 'previewAssetId'
type ExportVariant<T> = T & { [K in Exclude<ExportField, keyof T>]?: never }
export type AttachmentExportParams = ExportVariant<ArtifactPreviewExportParams> |
  ExportVariant<ProjectExportParams> |
  ExportVariant<{ attachmentId: string; threadId: string }> |
  ExportVariant<{ artifactId: string; threadId: string }> |
  ExportVariant<{ artifactId: string; agentId: string; version?: number }> |
  ExportVariant<AvatarExportParams>
