# Remote protocol modules

Version 0.28.1 adds optional `desktop.origin.device.v1` and `desktop.authorization.scoped.v1`
capabilities, a bounded `desktop.access.get` read, and a standalone device origin for paired
computer controllers. Conversation origins, wire version 1, phone permissions and input-channel
formats remain compatible. Device origins require a desktop-only grant and explicit peer support;
they never imply workbench or terminal access.

Wire version and receipt identity are unchanged. Version 0.25.1 adds the optional `activityAt` summary field and the ephemeral `terminal.v1` methods; older peers omit these capabilities. The package root exposes typed `RemoteParams`, `RemoteResults`, `RemoteMethod` and `OperationCall<M>`. `validateOperationParams` validates an explicit business method; `validateCall` keeps the legacy wire behavior and dispatches recognized operations through feature-owned validators. Discovery and cached descriptors never grant authority.

`operations.js` composes fixed method registration only. `scopes.js` owns required permissions, while each business module owns its own exact request keys and validation. No module represents an implementation phase. Private source paths may change; consumers import the package root.

| Responsibility | Modules |
| --- | --- |
| Task metadata and routing | `tasks`, `task-settings`, `models`, `model-info`, `history-actions` |
| Public content | `messages`, `source-content`, `attention`, `artifacts` |
| Personal Agent configuration | `agent-profiles`, `agent-directory`, `agent-avatars`, `agent-capabilities`, `agent-lifecycle`, `agent-import` |
| Personal Agent retained data | `agent-memory`, `agent-memory-review`, `agent-library`, `agent-reminders`, `agent-commitments` |
| Execution and bounded files | `execution`, `goals`, `project-files`, `work`, `attachments` |
| Explicit advanced scopes | `groups`, `group-mutations`, `collaboration`, `plugins`, `schedules`, `shared-owner` |
| Transport and discovery | `index`, `operations`, `scopes`, `capabilities`, `receipts`, `transport-client`, `relay-control`, `shared-*` |
| Live history | `live-history` |
| Live directories and request admission | `live-directory`, `invoke-scheduler` |
| Phone-owned PTY sessions | `terminal` |

Functional `*-contract.md` documents describe product boundaries. Feature fixtures cover each fixed method, `operation-registry.json` freezes method/read order, and Rust fixture tests verify only the opaque relay envelope. Run `npm run test:protocol` from the repository root and compile all `test/*.ts` fixtures with TypeScript strict mode. Every code file remains below 700 physical lines.

## Versioned distribution

Version 0.28.0 includes Work spaces and sessions (`work.*`) and `project.files.resolve`; see [project-files-contract.md](project-files-contract.md).

Version 0.25.1 includes optional `activityAt` task-summary metadata and `terminal.v1`.
Terminal calls require the existing `desktop.view` + `desktop.control` authorization, never create
receipts or cached read results, and never accept a client-supplied directory. Only `terminal.close`
uses the reserved desktop shutdown lane, so opening, attaching or writing cannot starve cleanup.
See [terminal-contract.md](terminal-contract.md) for ownership, stream and retention boundaries.

`RemoteApi.bootstrap({ name, role, platform }, signal?)` combines registration, device presence,
grants and a one-use relay ticket in one HTTP request. It returns `{ deviceId, enabled, devices,
grants, relay: { ticket, url } }`. Only a missing `/bootstrap` route (HTTP 404 with `not_found` or
`HTTP_404`) falls back to the existing endpoints; authorization, rate-limit and network failures
remain failures. Use `relay` once for the initial connection and get a fresh `ticket()` for every
reconnect. Do not persist the ticket with device/catalog caches. The server reuses the existing
user-token RPCs and rechecks session/device authority when minting the final ticket.

An explicit lease response `409 reconnect_required` now fences the old socket and immediately
requests a fresh ticket. Other transient renewal failures still retry the existing connection;
in-flight writes remain uncertain and are never replayed. The diagnostic `TICKET_READY` contains
only `elapsedMs` since `CONNECTING`; `CONNECTED.elapsedMs` includes both ticket and handshake time.

Version 0.20.1 adds `resume()` for foreground recovery. A healthy connection sends an immediate
ping with a five-second deadline; an outstanding pong deadline is never extended. A parked retry
runs immediately, while a ticket/hello handshake already in progress keeps its deadline. An
intentional background stop can resume, but authorization rejection and socket replacement remain
stopped even across `stop()`; only explicit `start()` clears that terminal fence. No business call
is replayed during a wake.

Version 0.20.0 adds `directory.live.v1` for opt-in, metadata-only directory invalidations;
see [directory-live-contract.md](directory-live-contract.md). The host supplies the change
feed and the App maintains shared read state across pages. `invoke(dst, call, timeout?,
{ priority: 'background' })` lets prefetch yield to foreground work. Each host admits at most
twelve ordinary calls, with at most four background calls; Stop retains its control reservation.
Queued calls never sent to the socket fail definitively on timeout/disconnect. A possibly sent
call still reports `RESULT_UNKNOWN` and is never automatically replayed. Request IDs, receipt
identity and permission checks are unchanged. The sender interleaves independent replies and
peers without reordering event streams, and keeps ACK/ping/Stop ahead of bulk frames.

Version 0.19.0 adds optional behaviour that older peers never see. Personal connections send
`X-Kun-Relay-Features` (presence, authorization, lossy); a relay that understands it echoes the
accepted names in hello and then sends relay notices (`event` frames without `src`) to
`deps.relay`. The lease length now comes from the relay, capped at five minutes, and renewal runs a
third of the way through it, so a sixty-second lease still renews every twenty seconds. One
acknowledgement covers every frame received before it is sent (sixteen frames, 1 MiB or 50 ms).
`Call.ifVersion` asks a desktop that lists `read.conditional` to answer `{ readUnchanged, readVersion }`
for an unchanged read. `live-history` defines the page deltas of `history.live` subscriptions. See
[relay-control-contract.md](relay-control-contract.md) and [live-history-contract.md](live-history-contract.md).
`utf8Size` and fragment splitting return the same results as before, without per-character allocation.

Version 0.18.2 stops automatic connection attempts after HTTP 401/403, explicit login/device
revocation failures, or socket replacement (4409). `state(false, reason)` reports the stop even
if no connection succeeded. After repairing authorization, call `start()` explicitly; network
`reconnect()` does not resume a stopped client. Lease expiry (4401) and authorization changes
(4403) request a fresh ticket; only a definitive HTTP rejection stops that recovery. Network
errors, timeouts, 429 and 5xx retain jittered exponential backoff. A successful hello resets the
backoff only after the connection has stayed online for 60 seconds. Business calls are never
automatically replayed. `RemoteError.status` preserves the HTTP status alongside its error code.
Disconnect also clears heartbeat state, so recovery and authorization repair retain pong
deadlines. Diagnostic callbacks run after the failed connection is fenced and released;
synchronous stop/restart callbacks cannot leave old sockets or timers alive.

Create the archive with `npm pack` from this directory, using a temporary output directory. Consumers pin its versioned filename and integrity in their package manifests and lockfiles. Do not overwrite an archive with different contents under the same version.

Each consumer's `vendor` directory keeps only the archive required by its current manifests and lockfiles. When updating, install and verify the new package in every affected consumer before removing superseded archives. Check scripts and tests for old paths as well; do not delete a still-referenced archive merely because its version is older. Keep any necessary historical artifacts outside the source checkout, rather than accumulating release copies in `vendor`.

## Desktop usage reads

`usage.summary.get` reads the selected computer's local usage ledger for 1, 7, 30 or 90 calendar days, using the computer's timezone. Model rankings can cover all, primary or side conversations. `usage.quotas.list` reads its existing provider quota cache. Both methods are read-only personal-device operations, excluded from shared guest and desktop-control grants. Discovery uses capability descriptors; older hosts do not advertise these methods.

Results are bounded projections without credentials, raw provider errors, account login identities, endpoint URLs, conversation text or thread identifiers. Recorded cost and subscription API reference value remain separate; unknown cache rates and balances must not become fabricated zeros. The exported validators cover live responses and account/host-scoped offline caches. Host code must recheck authority before publishing asynchronous answers.
