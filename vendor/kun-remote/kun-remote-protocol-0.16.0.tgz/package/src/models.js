import { check, object, oneOf, optional, text as string, harness } from './validation.js'
import { normalizeCapabilities } from './capabilities.js'
const CREDENTIAL_MODES = ['native-login', 'provider', 'kun-gateway']
/** Host reasoning levels in host order; `auto` lets the model decide and is not a point on the off→max scale. */
export const REASONING_EFFORTS = Object.freeze(['auto', 'off', 'low', 'medium', 'high', 'max'])
/**
 * Advertised in `catalog.get` capabilities only when the host accepts `reasoningEffort` on a model route and
 * describes per-model `profiles` on its agent routes. Without it a controller sends no effort and ignores profiles.
 */
export const REASONING_EFFORT_CAPABILITY = 'code.reasoningEffort'
/** Undefined means no catalog. Only the explicit capability string enables reasoning effort, never a broad feature. */
export function hasReasoningEffort(catalog) {
  if (catalog === undefined || catalog === null) return undefined
  return normalizeCapabilities(catalog).capabilities.includes(REASONING_EFFORT_CAPABILITY)
}
/** A chosen model route: never permissions, workspace, prompts, credentials or a gateway binding. */
export function validateModelRoute(value) {
  object(value, ['model'], ['harnessId', 'credentialMode', 'providerId', 'reasoningEffort'])
  string(value.model, 512)
  check(value.model.trim().length > 0)
  optional(value, 'harnessId', harness)
  optional(value, 'providerId', (field) => string(field, 128))
  optional(value, 'credentialMode', (field) => oneOf(field, CREDENTIAL_MODES))
  optional(value, 'reasoningEffort', (field) => oneOf(field, REASONING_EFFORTS))
  return value
}
function profile(value) {
  object(value, ['efforts'], ['defaultEffort', 'note'])
  check(Array.isArray(value.efforts) && value.efforts.length > 0 && value.efforts.length <= REASONING_EFFORTS.length)
  value.efforts.forEach((effort) => oneOf(effort, REASONING_EFFORTS))
  check(new Set(value.efforts).size === value.efforts.length)
  optional(value, 'defaultEffort', (effort) => check(value.efforts.includes(effort)))
  optional(value, 'note', (note) => { string(note, 160); check(note.trim().length > 0) })
}
/** Checks the per-model reasoning description a host attaches to one agent route; every key is a listed model. */
export function validateModelProfiles(route) {
  check(route !== null && typeof route === 'object' && Array.isArray(route.models))
  if (route.profiles === undefined) return route
  object(route.profiles, [], route.models)
  Object.values(route.profiles).forEach(profile)
  return route
}
