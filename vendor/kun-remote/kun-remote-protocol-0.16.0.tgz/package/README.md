# Remote protocol modules

Wire version, methods, limits, receipt identity and transport behavior are unchanged. The package root exposes typed `RemoteParams`, `RemoteResults`, `RemoteMethod` and `OperationCall<M>`. `validateOperationParams` validates an explicit business method; `validateCall` keeps the legacy wire behavior and dispatches recognized operations through feature-owned validators. Discovery and cached descriptors never grant authority.

`operations.js` composes fixed method registration only. `scopes.js` owns required permissions, while each business module owns its own exact request keys and validation. No module represents an implementation phase. Private source paths may change; consumers import the package root.

| Responsibility | Modules |
| --- | --- |
| Task metadata and routing | `tasks`, `task-settings`, `models`, `history-actions` |
| Public content | `messages`, `source-content`, `attention`, `artifacts` |
| Personal Agent configuration | `agent-profiles`, `agent-directory`, `agent-avatars`, `agent-capabilities`, `agent-lifecycle`, `agent-import` |
| Personal Agent retained data | `agent-memory`, `agent-memory-review`, `agent-library`, `agent-reminders`, `agent-commitments` |
| Execution and bounded files | `execution`, `goals`, `project-files`, `attachments` |
| Explicit advanced scopes | `groups`, `group-mutations`, `collaboration`, `plugins`, `schedules`, `shared-owner` |
| Transport and discovery | `index`, `operations`, `scopes`, `capabilities`, `receipts`, `transport-client`, `shared-*` |

Functional `*-contract.md` documents describe product boundaries. Feature fixtures cover each fixed method, `operation-registry.json` freezes method/read order, and Rust fixture tests verify only the opaque relay envelope. Run `npm run test:protocol` from the repository root and compile all `test/*.ts` fixtures with TypeScript strict mode. Every code file remains below 700 physical lines.
