import { check, integer, object, oneOf, optional, revision, string, text } from './validation.js'

export const DAILY_NOTES_METHODS = Object.freeze([
  'daily.notes.list',
  'daily.notes.get',
  'daily.notes.create',
  'daily.notes.update',
  'daily.notes.delete',
  'daily.notes.rollover'
])
export const DAILY_NOTES_READ_METHODS = new Set(['daily.notes.list', 'daily.notes.get'])
export const DAILY_NOTES_QUADRANTS = Object.freeze([1, 2, 3, 4])

function noteDay(value) {
  check(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value))
  const date = new Date(value + 'T12:00:00Z')
  check(Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value)
}

function noteMonth(value) {
  check(typeof value === 'string' && /^\d{4}-(0[1-9]|1[0-2])$/.test(value))
}

function noteLink(value) {
  object(value, ['label', 'url'])
  string(value.label, 80)
  string(value.url, 512, 7)
  check(value.url.startsWith('kun://') && !/\s/.test(value.url))
}

function noteLines(value) {
  check(Array.isArray(value) && value.length <= 50)
  let total = 0
  for (const line of value) {
    text(line, 1000, 0)
    check(!line.includes('\n') && !line.includes('\r'))
    total += line.length
  }
  check(total <= 8000)
}

export function validateDailyNotesParams(method, p) {
  switch (method) {
    case 'daily.notes.list':
      object(p, [], ['limitDays', 'month'])
      optional(p, 'limitDays', (v) => integer(v, 1, 60))
      optional(p, 'month', noteMonth)
      break
    case 'daily.notes.get':
      object(p, ['day'])
      noteDay(p.day)
      break
    case 'daily.notes.create':
      object(p, ['day', 'title'], ['expectedRevision', 'notes', 'quadrant', 'link'])
      noteDay(p.day)
      string(p.title, 500)
      optional(p, 'expectedRevision', (v) => revision(v, 'daily'))
      optional(p, 'notes', noteLines)
      optional(p, 'quadrant', (v) => { if (v !== null) oneOf(v, DAILY_NOTES_QUADRANTS) })
      optional(p, 'link', (v) => { if (v !== null) noteLink(v) })
      break
    case 'daily.notes.update':
      object(p, ['day', 'line', 'expectedRevision'], ['title', 'notes', 'done', 'quadrant', 'link', 'moveToDay'])
      noteDay(p.day)
      integer(p.line, 0, 100000)
      revision(p.expectedRevision, 'daily')
      check(['title', 'notes', 'done', 'quadrant', 'link', 'moveToDay'].some((key) => Object.hasOwn(p, key)))
      optional(p, 'title', (v) => string(v, 500))
      optional(p, 'notes', noteLines)
      optional(p, 'done', (v) => check(typeof v === 'boolean'))
      optional(p, 'quadrant', (v) => { if (v !== null) oneOf(v, DAILY_NOTES_QUADRANTS) })
      optional(p, 'link', (v) => { if (v !== null) noteLink(v) })
      optional(p, 'moveToDay', (v) => { noteDay(v); check(v !== p.day) })
      break
    case 'daily.notes.delete':
      object(p, ['day', 'line', 'expectedRevision'])
      noteDay(p.day)
      integer(p.line, 0, 100000)
      revision(p.expectedRevision, 'daily')
      break
    case 'daily.notes.rollover':
      object(p, ['fromDay', 'toDay'], ['expectedFromRevision'])
      noteDay(p.fromDay)
      noteDay(p.toDay)
      check(p.fromDay !== p.toDay)
      optional(p, 'expectedFromRevision', (v) => revision(v, 'daily'))
      break
    default:
      throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
