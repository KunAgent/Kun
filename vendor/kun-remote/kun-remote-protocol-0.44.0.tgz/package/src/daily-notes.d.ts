import type { AtLeastOne } from './values.js'

export type DailyNoteQuadrant = 1 | 2 | 3 | 4
export type DailyNoteLinkTone = 'pending' | 'running' | 'attention' | 'completed' | 'failed' | 'idle'

export interface DailyNoteLinkInput {
  label: string
  url: string
}

export interface RemoteDailyNoteTaskLink {
  kind: 'dispatch' | 'room' | 'thread'
  label: string
  url: string
  threadId?: string
  roomId?: string
  messageId?: string
  linkId?: string
  statusTone?: DailyNoteLinkTone
  statusText?: string
  progress?: {
    completed: number
    total: number
  }
}

export interface RemoteDailyNoteTask {
  id: string
  day: string
  line: number
  indent: number
  parentLine: number | null
  done: boolean
  title: string
  quadrant: DailyNoteQuadrant | null
  notes: string[]
  subLineCount: number
  link: RemoteDailyNoteTaskLink | null
}

export interface RemoteDailyNoteQuadrantCounts {
  q1: number
  q2: number
  q3: number
  q4: number
  unsorted: number
}

export interface RemoteDailyNoteDaySummary {
  day: string
  revision: string
  total: number
  completed: number
  quadrants: RemoteDailyNoteQuadrantCounts
  hasProse: boolean
}

export interface RemoteDailyNotePage {
  day: string
  revision: string
  tasks: RemoteDailyNoteTask[]
  prosePreview?: string
  completed: number
  total: number
}

export interface RemoteDailyNotesOverview {
  today: string
  days: RemoteDailyNoteDaySummary[]
  recentPages: RemoteDailyNotePage[]
}

export interface DailyNoteTaskEditableFields {
  title: string
  notes: string[]
  done: boolean
  quadrant: DailyNoteQuadrant | null
  link: DailyNoteLinkInput | null
  moveToDay: string
}

export interface RemoteDailyNoteUpdateResult {
  page: RemoteDailyNotePage
  movedToPage?: RemoteDailyNotePage
}

export interface RemoteDailyNoteRolloverResult {
  movedCount: number
  fromPage: RemoteDailyNotePage
  toPage: RemoteDailyNotePage
}

export interface DailyNotesParams {
  'daily.notes.list': {
    limitDays?: number
    month?: string
  }
  'daily.notes.get': {
    day: string
  }
  'daily.notes.create': {
    day: string
    title: string
    expectedRevision?: string
    notes?: string[]
    quadrant?: DailyNoteQuadrant | null
    link?: DailyNoteLinkInput | null
  }
  'daily.notes.update': {
    day: string
    line: number
    expectedRevision: string
  } & AtLeastOne<DailyNoteTaskEditableFields>
  'daily.notes.delete': {
    day: string
    line: number
    expectedRevision: string
  }
  'daily.notes.rollover': {
    fromDay: string
    toDay: string
    expectedFromRevision?: string
  }
}

export interface DailyNotesResults {
  'daily.notes.list': RemoteDailyNotesOverview
  'daily.notes.get': RemoteDailyNotePage
  'daily.notes.create': RemoteDailyNotePage
  'daily.notes.update': RemoteDailyNoteUpdateResult
  'daily.notes.delete': RemoteDailyNotePage
  'daily.notes.rollover': RemoteDailyNoteRolloverResult
}

export const DAILY_NOTES_METHODS: readonly (keyof DailyNotesParams)[]
export const DAILY_NOTES_READ_METHODS: ReadonlySet<keyof DailyNotesParams>
export const DAILY_NOTES_QUADRANTS: readonly DailyNoteQuadrant[]
export function validateDailyNotesParams<M extends keyof DailyNotesParams>(
  method: M,
  params: unknown
): DailyNotesParams[M]
