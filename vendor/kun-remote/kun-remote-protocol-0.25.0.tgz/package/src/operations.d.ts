import type { DesktopParams, DesktopResults } from './desktop-session.js'
import type { TerminalParams, TerminalResults } from './terminal.js'
import type { Call } from './index.js'
import type { TaskParams, TaskResults } from './tasks.js'
import type { TaskSettingsParams, TaskSettingsResults } from './task-settings.js'
import type { MessageParams, MessageResults } from './messages.js'
import type { AttentionParams, AttentionResults } from './attention.js'
import type { ArtifactParams, ArtifactResults } from './artifacts.js'
import type { AgentDirectoryParams, AgentDirectoryResults } from './agent-directory.js'
import type { ExecutionParams, ExecutionResults } from './execution.js'
import type { GoalParams, GoalResults } from './goals.js'
import type { AgentProfileParams, AgentProfileResults } from './agent-profiles.js'
import type { AgentMemoryParams, AgentMemoryResults } from './agent-memory.js'
import type { AgentCommitmentParams, AgentCommitmentResults } from './agent-commitments.js'
import type { ProjectFilesParams, ProjectFilesResults } from './project-files.js'
import type { GroupParams, GroupResults } from './groups.js'
import type { CollaborationParams, CollaborationResults } from './collaboration.js'
import type { PluginParams, PluginResults } from './plugins.js'
import type { ScheduleParams, ScheduleResults } from './schedules.js'
import type { AgentAvatarParams, AgentAvatarResults } from './agent-avatars.js'
import type { AgentCapabilityParams, AgentCapabilityResults } from './agent-capabilities.js'
import type { HistoryActionParams, HistoryActionResults } from './history-actions.js'
import type { AgentHistoryParams, AgentHistoryResults } from './agent-memory-review.js'
import type { AgentLibraryParams, AgentLibraryResults } from './agent-library.js'
import type { ReminderParams, ReminderResults } from './agent-reminders.js'
import type { AgentLifecycleParams, AgentLifecycleResults } from './agent-lifecycle.js'
import type { AgentImportParams, AgentImportResults } from './agent-import.js'
import type { SharedOwnerParams, SharedOwnerResults } from './shared-owner.js'
import type { SourceContentOperationParams, SourceContentOperationResults } from './source-content.js'

export interface RemoteParams extends
  DesktopParams,
  TerminalParams,
  TaskParams,
  TaskSettingsParams,
  MessageParams,
  AttentionParams,
  ArtifactParams,
  AgentDirectoryParams,
  ExecutionParams,
  GoalParams,
  AgentProfileParams,
  AgentMemoryParams,
  AgentCommitmentParams,
  ProjectFilesParams,
  GroupParams,
  CollaborationParams,
  PluginParams,
  ScheduleParams,
  AgentAvatarParams,
  AgentCapabilityParams,
  HistoryActionParams,
  AgentHistoryParams,
  AgentLibraryParams,
  ReminderParams,
  AgentLifecycleParams,
  AgentImportParams,
  SharedOwnerParams,
  SourceContentOperationParams {}
export interface RemoteResults extends
  DesktopResults,
  TerminalResults,
  TaskResults,
  TaskSettingsResults,
  MessageResults,
  AttentionResults,
  ArtifactResults,
  AgentDirectoryResults,
  ExecutionResults,
  GoalResults,
  AgentProfileResults,
  AgentMemoryResults,
  AgentCommitmentResults,
  ProjectFilesResults,
  GroupResults,
  CollaborationResults,
  PluginResults,
  ScheduleResults,
  AgentAvatarResults,
  AgentCapabilityResults,
  HistoryActionResults,
  AgentHistoryResults,
  AgentLibraryResults,
  ReminderResults,
  AgentLifecycleResults,
  AgentImportResults,
  SharedOwnerResults,
  SourceContentOperationResults {}
export type RemoteMethod = keyof RemoteParams
export type OperationCall<M extends RemoteMethod> = Omit<Call, 'method' | 'params'> & { method: M; params: RemoteParams[M] }
export const OPERATION_METHODS: readonly RemoteMethod[]
export const OPERATION_READ_METHODS: ReadonlySet<RemoteMethod>
export function validateOperationParams<M extends RemoteMethod>(method: M, params: unknown): RemoteParams[M]
