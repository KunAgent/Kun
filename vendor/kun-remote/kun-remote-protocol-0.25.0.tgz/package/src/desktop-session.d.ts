export type DesktopOrigin = { kind: 'code' | 'agent'; id: string }
export type DesktopQuality = 'smooth' | 'balanced' | 'sharp'
export type DesktopMode = 'view' | 'control'
export interface DesktopDisplay {
  token: string
  revision: string
  label?: string
  pixelWidth: number
  pixelHeight: number
  rotation: number
}
export interface DesktopSession {
  schemaVersion: 1
  startId: string
  sessionId: string
  epoch: number
  authorizationId: string
  origin: DesktopOrigin
  display: DesktopDisplay
  mode: DesktopMode
  controlAllowed: boolean
  heartbeatMs: number
  setupTimeoutMs: number
  expiresInMs: number
}
export interface DesktopSdp { type: 'offer' | 'answer'; sdp: string }
export interface DesktopIceCandidate {
  candidate: string
  sdpMid?: string | null
  sdpMLineIndex?: number | null
  usernameFragment?: string | null
}
export type DesktopActiveState = 'negotiating' | 'viewing' | 'controlling' | 'reconnecting'
export type DesktopSessionResult =
  | { state: DesktopActiveState; session: DesktopSession; offer?: DesktopSdp }
  | { state: 'ended'; startId: string; sessionId?: string; reason: string; confirmed: true }
  | { state: 'missing' }
export interface DesktopParams {
  'desktop.displays.list': Record<string, never>
  'desktop.session.start': { startId: string; origin: DesktopOrigin; displayToken: string; displayRevision: string; quality: DesktopQuality }
  'desktop.session.answer': { sessionId: string; epoch: number; answer: DesktopSdp }
  'desktop.signal.ice': { sessionId: string; epoch: number; candidates: DesktopIceCandidate[]; complete: boolean }
  'desktop.session.get': { startId: string; sessionId?: never } | { sessionId: string; startId?: never }
  'desktop.session.reconnect': { sessionId: string; epoch: number; attemptId: string }
  'desktop.session.cancel': { startId: string; reason: string }
  'desktop.session.stop': { sessionId: string; observedEpoch: number; reason: string }
  'desktop.control.acquire': { sessionId: string; epoch: number }
  'desktop.control.release': { sessionId: string; epoch: number }
  'desktop.session.quality': { sessionId: string; epoch: number; quality: DesktopQuality }
}
export interface DesktopResults {
  'desktop.displays.list': { displays: DesktopDisplay[] }
  'desktop.session.start': DesktopSessionResult
  'desktop.session.answer': { accepted: true }
  'desktop.signal.ice': { accepted: true }
  'desktop.session.get': DesktopSessionResult
  'desktop.session.reconnect': DesktopSessionResult
  'desktop.session.cancel': DesktopSessionResult
  'desktop.session.stop': DesktopSessionResult
  'desktop.control.acquire': { mode: 'control'; controlEpoch: number }
  'desktop.control.release': { mode: 'view'; controlEpoch: number }
  'desktop.session.quality': { quality: DesktopQuality }
}
export type DesktopMethod = keyof DesktopParams
export const DESKTOP_CAPABILITY: 'desktop.session.v1'
export const DESKTOP_METHODS: readonly DesktopMethod[]
export const DESKTOP_EPHEMERAL_METHODS: ReadonlySet<DesktopMethod>
export const EPHEMERAL_METHODS: ReadonlySet<DesktopMethod | import('./terminal.js').TerminalMethod>
export const DESKTOP_STOP_METHODS: ReadonlySet<DesktopMethod>
export const DESKTOP_READ_METHODS: readonly DesktopMethod[]
export const DESKTOP_LIMITS: Readonly<{
  sdpBytes: number; candidateBytes: number; candidateBatch: number; candidateBatchBytes: number
  candidatesPerEpoch: number; candidatesEpochBytes: number; displays: number; signalPending: number
  dataBytes: number; textBytes: number; inputQueueBytes: number; heartbeatMs: number; leaseMs: number
  mediaHealthIntervalMs: number; mediaHealthTimeoutMs: number; mediaStallTimeoutMs: number
  setupTimeoutMs: number; helloTimeoutMs: number; stopTimeoutMs: number; stopPending: number; stopBytes: number
}>
export function validateDesktopParams<M extends DesktopMethod>(method: M, value: unknown): DesktopParams[M]
export function validateDesktopSession(value: unknown): DesktopSession
export function validateDesktopDisplay(value: unknown): DesktopDisplay
export function validateDesktopResult<M extends DesktopMethod>(method: M, value: unknown): DesktopResults[M]

export function requestControlLane(method: string): boolean | 'desktop'
