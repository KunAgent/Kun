import { canonical, validId, RemoteError } from './index.js'

const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value)
const integer = value => Number.isSafeInteger(value) && value > 0
const mode = value => value === 'read' || value === 'write'
function check(value) { if (!value) throw new RemoteError('INVALID_SHARED_LEASE') }
function keys(value, required, optional = []) {
  check(plain(value) && required.every(key => Object.hasOwn(value, key)) && Object.keys(value).every(key => required.includes(key) || optional.includes(key)))
}
export function validateShareLease(value, expected, now = Date.now()) {
  keys(value, ['shareId', 'ownerAccountId', 'hostDeviceId', 'resourceHandle', 'shareVersion', 'userId', 'deviceId', 'role', 'mode', 'expiresAt', 'peers'], ['memberId', 'memberVersion'])
  for (const key of ['shareId', 'ownerAccountId', 'hostDeviceId', 'resourceHandle', 'userId', 'deviceId']) check(validId(value[key]))
  check(['host', 'guest'].includes(value.role) && mode(value.mode) && integer(value.shareVersion))
  check(Number.isSafeInteger(value.expiresAt) && value.expiresAt > now && value.expiresAt <= now + 65000)
  check(value.shareId === expected.shareId && value.userId === expected.accountId && value.deviceId === expected.deviceId && value.role === expected.role &&
    value.hostDeviceId === expected.hostDeviceId && value.resourceHandle === expected.resourceHandle)
  if (expected.ownerAccountId !== undefined) check(value.ownerAccountId === expected.ownerAccountId)
  if (expected.memberId !== undefined) check(value.memberId === expected.memberId)
  check(value.shareVersion >= (expected.shareVersion ?? 1))
  check(Array.isArray(value.peers) && value.peers.length <= 32)
  const devices = new Set()
  for (const peer of value.peers) {
    if (value.role === 'host') {
      keys(peer, ['deviceId', 'accountId', 'memberId', 'memberVersion', 'mode'])
      check(validId(peer.memberId) && integer(peer.memberVersion) && mode(peer.mode) && peer.accountId !== value.ownerAccountId)
    } else keys(peer, ['deviceId', 'accountId'])
    check(validId(peer.deviceId) && validId(peer.accountId) && !devices.has(peer.deviceId) && peer.deviceId !== value.deviceId)
    devices.add(peer.deviceId)
  }
  if (value.role === 'host') {
    check(value.deviceId === value.hostDeviceId && value.userId === value.ownerAccountId && value.mode === 'write' &&
      value.memberId === undefined && value.memberVersion === undefined)
  } else {
    check(validId(value.memberId) && integer(value.memberVersion) && value.memberVersion >= (expected.memberVersion ?? 1) &&
      value.userId !== value.ownerAccountId && value.deviceId !== value.hostDeviceId && value.peers.length === 1 &&
      value.peers[0].deviceId === value.hostDeviceId && value.peers[0].accountId === value.ownerAccountId)
  }
  return Object.freeze({ ...value, expiresAt: Math.min(value.expiresAt, now + 60000), peers: Object.freeze(value.peers.map(peer => Object.freeze({ ...peer }))) })
}
export function sharedAuthorityKey(lease) {
  const { expiresAt, ...scope } = lease
  return canonical({ ...scope, peers: [...scope.peers].sort((a, b) => a.deviceId.localeCompare(b.deviceId)) })
}
export function validateSharedFrame(frame, lease) {
  const shared = frame.shared
  check(lease && lease.expiresAt > Date.now())
  check(validId(frame.src) && frame.dst === lease.deviceId && frame.src !== lease.deviceId)
  const peer = lease.peers.find(peer => peer.deviceId === frame.src)
  check(peer)
  const host = lease.role === 'guest'
  keys(shared, ['shareId', 'resourceHandle', 'shareVersion', 'accountId', 'role', 'mode'], host ? [] : ['memberId', 'memberVersion'])
  check(shared.shareId === lease.shareId && shared.resourceHandle === lease.resourceHandle && shared.shareVersion === lease.shareVersion &&
    shared.accountId === peer.accountId && shared.role === (host ? 'host' : 'guest') && shared.mode === (host ? 'write' : peer.mode))
  if (!host) check(shared.memberId === peer.memberId && shared.memberVersion === peer.memberVersion)
  if (frame.kind !== 'fragment') check((host ? ['result', 'event', 'error', 'resync_required'] : ['invoke', 'subscribe']).includes(frame.kind))
  return Object.freeze({ ...shared })
}
