import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface AgentSearchSummary {
  id: string; name: string; title: string; revision: number; archived: boolean
  match?: { messageId: string; snippet: string; createdAt: string; historyVersion: string }
}
export interface AgentDirectoryParams {
  'agent.search': PageParams & { query: string; includeArchived?: boolean }
  'agent.directory.list': PageParams & { directoryView?: 'visible' | 'archived' | 'all' }
}
export interface AgentDirectoryResults {
  'agent.search': RemotePage<AgentSearchSummary, 'agents'> & { searchScope: 'profile_and_private_messages'; coverage: 'current_private_conversations'; scanned: number; complete: boolean }
  'agent.directory.list': { agents: Array<{ id: string; name: string; title: string; archived: boolean; revision: number; canLeadGroup?: boolean }>; hasMore: boolean; nextCursor?: string }
}
export const AGENT_DIRECTORY_METHODS: readonly (keyof AgentDirectoryParams)[]
export const AGENT_DIRECTORY_READ_METHODS: ReadonlySet<keyof AgentDirectoryParams>
export function validateAgentDirectoryParams<M extends keyof AgentDirectoryParams>(method: M, params: unknown): AgentDirectoryParams[M]
