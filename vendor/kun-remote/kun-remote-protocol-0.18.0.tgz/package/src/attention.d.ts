import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface AttentionItem {
  id: string
  kind: 'approval' | 'input'
  resource: ResourceRef
  summary: string
  threadId: string
  turnId: string
  approval?: Record<string, unknown>
  input?: Record<string, unknown>
}
export interface AttentionParams {
  'attention.list': PageParams
}
export interface AttentionResults {
  'attention.list': RemotePage<AttentionItem, 'items'>
}
export const ATTENTION_METHODS: readonly (keyof AttentionParams)[]
export const ATTENTION_READ_METHODS: ReadonlySet<keyof AttentionParams>
export function validateAttentionParams<M extends keyof AttentionParams>(method: M, params: unknown): AttentionParams[M]
