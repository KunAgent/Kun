import type { PageParams } from './values.js'
import type { MemoryContentSlice } from './agent-memory-review.js'
type LibraryAgent = { agentId: string }
export type AgentRunStatus = 'queued' | 'running' | 'completed' | 'failed' | 'cancelled' | 'recovery_required'
export interface AgentRunSource {
  resource: { kind: 'agent'; id: string }
  roomId: string
  runId: string
  runRevision: number
  messageId?: string
  code?: { resource: { kind: 'code'; id: string }; turnId?: string; historyVersion: string }
}
export interface AgentRunSummary {
  id: string
  revision: number
  status: AgentRunStatus
  outcome?: 'published' | 'skipped' | 'stale' | 'duplicate' | 'respond' | 'failed' | 'cancelled' | 'fail_open'
  attempt: number
  createdAt: string
  updatedAt: string
  startedAt?: string
  endedAt?: string
  elapsedMs?: number
  errorCode?: 'RUN_FAILED'
  summary: { text: string; truncated: boolean }
  source: AgentRunSource
}
export interface AgentRunMessageSummary {
  id: string
  role: 'user' | 'assistant'
  bodyRevision: number
  createdAt: string
  snippet: string
  contentLength: number
  contentTruncated: boolean
}
export interface AgentLibraryArtifact {
  id: string
  version: number
  revision?: number
  name: string
  size: number
  sha256: string
  mimeType: string
  status?: 'active' | 'archived'
  createdAt: string
  updatedAt?: string
  available: boolean
  source?: AgentRunSource
}
type Run = LibraryAgent & { runId: string; expectedRevision: number }
export interface AgentLibraryParams {
  'agent.runs.list': LibraryAgent & PageParams & { status?: AgentRunStatus }
  'agent.runs.get': Run & (
    { messageId?: never; expectedMessageRevision?: never; contentOffset?: never; maxChars?: never } |
    { messageId: string; expectedMessageRevision: number; contentOffset?: number; maxChars?: number }
  )
  'agent.artifacts.list': LibraryAgent & PageParams & { archived?: boolean; search?: string }
  'agent.artifacts.get': LibraryAgent & { artifactId: string; version?: number }
  'agent.artifacts.versions': LibraryAgent & PageParams & { artifactId: string }
}
type LibraryPage = { hasMore: boolean; complete: boolean; nextCursor?: string }
export interface AgentLibraryResults {
  'agent.runs.list': LibraryAgent & LibraryPage & { runs: AgentRunSummary[] }
  'agent.runs.get': { run: AgentRunSummary; messages: AgentRunMessageSummary[]; message?: { id: string; bodyRevision: number; content: MemoryContentSlice } }
  'agent.artifacts.list': LibraryAgent & LibraryPage & { artifacts: AgentLibraryArtifact[] }
  'agent.artifacts.get': LibraryAgent & { artifact: AgentLibraryArtifact }
  'agent.artifacts.versions': LibraryAgent & LibraryPage & { artifactId: string; currentVersion: number; revision: number; versions: AgentLibraryArtifact[] }
}
export type AgentLibraryMethod = keyof AgentLibraryParams
export const AGENT_LIBRARY_METHODS: readonly AgentLibraryMethod[]
export const AGENT_LIBRARY_READ_METHODS: readonly AgentLibraryMethod[]
export function validateAgentLibraryParams<M extends AgentLibraryMethod>(method: M, params: AgentLibraryParams[M]): void
