import type { AgentAvatarParams, AgentAvatarResults } from './agent-avatars.js'
import type { AgentCapabilityParams, AgentCapabilityResults } from './agent-capabilities.js'

export interface AgentAppearanceParams extends AgentAvatarParams, AgentCapabilityParams {}
export interface AgentAppearanceResults extends AgentAvatarResults, AgentCapabilityResults {}
export type AgentAppearanceMethod = keyof AgentAppearanceParams
export const AGENT_APPEARANCE_METHODS: readonly AgentAppearanceMethod[]
export const AGENT_APPEARANCE_READ_METHODS: readonly AgentAppearanceMethod[]
export function validateAgentAppearanceParams<M extends AgentAppearanceMethod>(method: M, params: AgentAppearanceParams[M]): void
export { AVATAR_BUILTINS, validateAvatarExport } from './agent-avatars.js'
export type { BuiltinAvatarId, RemoteAgentAvatar, AvatarState, AgentAvatarResult, AvatarExportParams } from './agent-avatars.js'
export type { AgentCatalogEntry, AgentCatalogResult } from './agent-capabilities.js'
