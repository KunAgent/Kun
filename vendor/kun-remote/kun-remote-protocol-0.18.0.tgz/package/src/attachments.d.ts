import type { ProjectExportParams } from './project-files.js'
import type { AvatarExportParams } from './agent-avatars.js'
type ExportField = 'attachmentId' | 'threadId' | 'agentId' | 'artifactId' | 'version' | 'projectId' | 'fileRef' | 'revision' | 'avatarRevision'
type ExportVariant<T> = T & { [K in Exclude<ExportField, keyof T>]?: never }
export type AttachmentExportParams = ExportVariant<ProjectExportParams> |
  ExportVariant<{ attachmentId: string; threadId: string }> |
  ExportVariant<{ artifactId: string; threadId: string }> |
  ExportVariant<{ artifactId: string; agentId: string; version?: number }> |
  ExportVariant<AvatarExportParams>
