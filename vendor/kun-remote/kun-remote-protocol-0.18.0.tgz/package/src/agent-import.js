import { check, object, string } from './validation.js'
export const AGENT_IMPORT_METHODS = Object.freeze(['agent.import.preview', 'agent.import.commit'])
export const AGENT_IMPORT_READ_METHODS = Object.freeze([])
function name(value) { string(value, 80, 1); check(Boolean(value.trim())) }
export function validateAgentImportParams(method, p) {
  check(AGENT_IMPORT_METHODS.includes(method))
  if (method === 'agent.import.preview') {
    object(p, ['document'], ['name']); object(p.document, ['format', 'version', 'profile'])
    check(p.document.format === 'kun-agent-profile' && p.document.version === 1)
    object(p.document.profile, ['name'], ['title', 'instructions']); name(p.document.profile.name)
    if (Object.hasOwn(p.document.profile, 'title')) string(p.document.profile.title, 160, 0)
    if (Object.hasOwn(p.document.profile, 'instructions')) string(p.document.profile.instructions, 8000, 0)
    if (Object.hasOwn(p, 'name')) name(p.name)
  } else {
    object(p, ['token', 'name']); name(p.name)
    check(typeof p.token === 'string' && /^[a-f0-9]{64}$/.test(p.token))
  }
}
