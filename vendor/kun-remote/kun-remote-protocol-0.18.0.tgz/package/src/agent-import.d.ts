import type { AgentProfile } from './agent-profiles.js'
export interface AgentImportProfile { name: string; title?: string; instructions?: string }
export interface AgentImportDocument { format: 'kun-agent-profile'; version: 1; profile: AgentImportProfile }
export interface AgentImportParams {
  'agent.import.preview': { document: AgentImportDocument; name?: string }
  'agent.import.commit': { token: string; name: string }
}
export interface AgentImportPreview {
  token: string
  expiresAt: number
  profile: Required<AgentImportProfile>
  conflicts: Array<{ agentId: string; name: string; revision: number }>
  canCommit: boolean
  imported: ['profile']
  excluded: string[]
}
export interface AgentImportResult { agent: AgentProfile; conversationId: string; imported: ['profile'] }
export interface AgentImportResults {
  'agent.import.preview': AgentImportPreview
  'agent.import.commit': AgentImportResult
}
export type AgentImportMethod = keyof AgentImportParams
export const AGENT_IMPORT_METHODS: readonly AgentImportMethod[]
export const AGENT_IMPORT_READ_METHODS: readonly AgentImportMethod[]
export function validateAgentImportParams<M extends AgentImportMethod>(method: M, params: AgentImportParams[M]): void
