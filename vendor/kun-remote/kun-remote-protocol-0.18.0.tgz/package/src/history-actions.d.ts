export type RemoteHistoryState = 'ready' | 'reconciliation_required'
export interface RemoteHistoryMetadata { revision?: string; historyVersion: string; historyState?: RemoteHistoryState }
import type { CodeSummary } from './tasks.js'
export interface HistoryActionTarget {
  threadId: string; turnId: string; expectedRevision: string; historyVersion: string
}
export interface RewindDraft {
  text: string; attachmentIds: string[]; complete: boolean; totalChars: number; totalAttachments: number
}
export interface HistoryActionParams {
  'code.fork': HistoryActionTarget & { title?: string; beforeTurn?: boolean }
  'code.rewind.preview': HistoryActionTarget
  'code.rewind.commit': { threadId: string; token: string }
}
export interface HistoryActionResults {
  'code.fork': { thread: CodeSummary; sourceThreadId: string; sourceTurnId: string; historyVersion: string }
  'code.rewind.preview': {
    token: string; expiresAt: number; canCommit: boolean; reason?: 'ATTACHMENT_UNAVAILABLE' | 'DRAFT_LIMIT'; draft: RewindDraft
    summary: { removedTurns: number; remainingTurns: number; filesReverted: false; externalEffectsReverted: false }
  }
  'code.rewind.commit': { thread: CodeSummary; historyVersion: string; draft: RewindDraft & { complete: true }; rewound: true }
}
export const HISTORY_METHODS: readonly (keyof HistoryActionParams)[]
export function validateHistoryParams<M extends keyof HistoryActionParams>(method: M, params: unknown): HistoryActionParams[M]
