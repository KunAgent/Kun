import { object, id, page } from './validation.js'

export const SCHEDULE_METHODS = Object.freeze(["schedule.list", "schedule.runs.list", "desktop.schedule.list", "desktop.schedule.runs.list"])
export const SCHEDULE_READ_METHODS = new Set(["schedule.list", "schedule.runs.list", "desktop.schedule.list", "desktop.schedule.runs.list"])
export function validateScheduleParams(method, p) {
  switch (method) {
    case 'schedule.list': object(p, [], ['cursor', 'limit']); page(p, 20); break
    case 'schedule.runs.list': object(p, ['scheduleId'], ['cursor', 'limit']); id(p.scheduleId); page(p, 20); break
    case 'desktop.schedule.list': object(p, [], ['cursor', 'limit']); page(p, 50); break
    case 'desktop.schedule.runs.list': object(p, ['scheduleId'], ['cursor', 'limit']); id(p.scheduleId); page(p, 50); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
