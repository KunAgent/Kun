import { object, textPage as page } from './validation.js'

export const ATTENTION_METHODS = Object.freeze(["attention.list"])
export const ATTENTION_READ_METHODS = new Set(["attention.list"])
export function validateAttentionParams(method, params) {
  switch (method) {
    case 'attention.list':
      object(params, [], ['cursor', 'limit'])
      page(params)
      break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return params
}
