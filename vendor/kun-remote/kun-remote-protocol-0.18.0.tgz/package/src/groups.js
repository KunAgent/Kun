import { GROUP_WRITE_METHODS, validateGroupWriteParams } from './group-mutations.js'
export { GROUP_WRITE_METHODS } from './group-mutations.js'
import { check, object, id, oneOf, optional, page, string } from './validation.js'

export const GROUP_METHODS = Object.freeze(["group.get", "group.list", "group.history", "group.message.send", ...GROUP_WRITE_METHODS])
export const GROUP_READ_METHODS = new Set(["group.get", "group.list", "group.history"])
export function validateGroupParams(method, p) {
  if (GROUP_WRITE_METHODS.includes(method)) { validateGroupWriteParams(method, p); return p }
  switch (method) {
    case 'group.get': object(p, ['roomId']); id(p.roomId); break
    case 'group.list':
      object(p, [], ['cursor', 'limit', 'query', 'archived']); page(p, 20)
      optional(p, 'query', (v) => string(v, 200, 0)); optional(p, 'archived', (v) => check(typeof v === 'boolean')); break
    case 'group.history':
      object(p, ['roomId'], ['cursor', 'limit']); id(p.roomId); page(p, 20)
      optional(p, 'cursor', (v) => check(/^[0-9]{1,16}$/.test(v) && Number.isSafeInteger(Number(v)) && Number(v) > 0)); break
    case 'group.message.send':
      object(p, ['roomId', 'text'], ['mentionMemberIds', 'executionIntent']); id(p.roomId); string(p.text, 64000)
      optional(p, 'mentionMemberIds', (values) => {
        check(Array.isArray(values) && values.length <= 20 && new Set(values).size === values.length); values.forEach(id)
      })
      optional(p, 'executionIntent', (v) => oneOf(v, ['auto', 'discussion', 'execute'])); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
