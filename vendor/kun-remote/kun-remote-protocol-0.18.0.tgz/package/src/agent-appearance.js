import { AGENT_AVATAR_METHODS, validateAgentAvatarParams } from './agent-avatars.js'
import { AGENT_CAPABILITY_METHODS, validateAgentCapabilityParams } from './agent-capabilities.js'

export const AGENT_APPEARANCE_METHODS = Object.freeze([...AGENT_AVATAR_METHODS, ...AGENT_CAPABILITY_METHODS])
export const AGENT_APPEARANCE_READ_METHODS = Object.freeze(AGENT_APPEARANCE_METHODS.filter(method => method !== 'agent.avatar.update'))
export function validateAgentAppearanceParams(method, params) {
  if (AGENT_AVATAR_METHODS.includes(method)) return validateAgentAvatarParams(method, params)
  return validateAgentCapabilityParams(method, params)
}
export { AVATAR_BUILTINS, validateAvatarExport } from './agent-avatars.js'
