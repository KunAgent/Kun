import { check, object, id, integer, optional, oneOf, page } from './validation.js'
export const REMINDER_METHODS = Object.freeze(['agent.reminders.list', 'agent.reminders.act'])
export const REMINDER_READ_METHODS = Object.freeze(['agent.reminders.list'])
export function validateReminderParams(method, p) {
  check(REMINDER_METHODS.includes(method))
  if (method === 'agent.reminders.list') {
    object(p, ['agentId'], ['status', 'cursor', 'limit']); page(p, 20)
    optional(p, 'status', (value) => oneOf(value, ['active', 'all', 'scheduled', 'paused', 'fired', 'cancelled', 'expired']))
  } else {
    object(p, ['agentId', 'reminderId', 'expectedRevision', 'action'])
    id(p.reminderId); integer(p.expectedRevision); oneOf(p.action, ['pause', 'resume', 'cancel'])
  }
  id(p.agentId)
}
