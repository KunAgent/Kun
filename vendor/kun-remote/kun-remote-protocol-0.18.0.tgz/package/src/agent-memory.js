import { check, object, id, oneOf, optional, page, string } from './validation.js'

export const AGENT_MEMORY_METHODS = Object.freeze(["agent.memory.list", "agent.memory.update"])
export const AGENT_MEMORY_READ_METHODS = new Set(["agent.memory.list"])
export function validateAgentMemoryParams(method, p) {
  switch (method) {
    case 'agent.memory.list':
      object(p, ['agentId'], ['cursor', 'limit', 'includeDeleted']); id(p.agentId); page(p)
      optional(p, 'includeDeleted', (v) => check(typeof v === 'boolean')); break
    case 'agent.memory.update':
      if (p?.action === 'create') {
        object(p, ['agentId', 'action', 'roomId', 'sourceMessageIds', 'content'], ['type'])
        id(p.agentId); id(p.roomId); string(p.content, 4000)
        check(Array.isArray(p.sourceMessageIds) && p.sourceMessageIds.length >= 1 && p.sourceMessageIds.length <= 8)
        p.sourceMessageIds.forEach(id); check(new Set(p.sourceMessageIds).size === p.sourceMessageIds.length)
        optional(p, 'type', (v) => oneOf(v, ['fact', 'preference', 'decision', 'episode', 'relationship', 'insight']))
      } else {
        object(p, ['agentId', 'action', 'memoryId', 'expectedFingerprint'], p?.action === 'edit' ? ['content', 'disabled'] : [])
        id(p.agentId); id(p.memoryId); oneOf(p.action, ['edit', 'forget'])
        check(typeof p.expectedFingerprint === 'string' && /^[a-f0-9]{64}$/.test(p.expectedFingerprint))
        if (p.action === 'edit') {
          check(p.content !== undefined || p.disabled !== undefined)
          optional(p, 'content', (v) => string(v, 4000)); optional(p, 'disabled', (v) => check(typeof v === 'boolean'))
        }
      }
      break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
