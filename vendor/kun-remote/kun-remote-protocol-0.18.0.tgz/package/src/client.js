import { TransportClient } from './transport-client.js'

/** Same-account transport. Shared envelopes are accepted only by ShareClient. */
export class RemoteClient extends TransportClient {
  constructor(deps) { super(deps) }
}
