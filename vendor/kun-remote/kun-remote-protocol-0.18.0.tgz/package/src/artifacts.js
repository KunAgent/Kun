import { object, textPage as page, resource } from './validation.js'

export const ARTIFACT_METHODS = Object.freeze(["artifact.list"])
export const ARTIFACT_READ_METHODS = new Set(["artifact.list"])
export function validateArtifactParams(method, params) {
  switch (method) {
    case 'artifact.list':
      object(params, ['resource'], ['cursor', 'limit'])
      resource(params.resource)
      page(params)
      break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return params
}
