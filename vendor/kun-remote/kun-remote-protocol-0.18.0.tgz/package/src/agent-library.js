import { check, object, id, integer, optional, oneOf, page, string } from './validation.js'
export const AGENT_LIBRARY_METHODS = Object.freeze(['agent.runs.list', 'agent.runs.get',
  'agent.artifacts.list', 'agent.artifacts.get', 'agent.artifacts.versions'])
export const AGENT_LIBRARY_READ_METHODS = AGENT_LIBRARY_METHODS
export function validateAgentLibraryParams(method, p) {
  check(AGENT_LIBRARY_METHODS.includes(method))
  if (method === 'agent.runs.list') {
    object(p, ['agentId'], ['cursor', 'limit', 'status']); page(p, 20)
    optional(p, 'status', (value) => oneOf(value, ['queued', 'running', 'completed', 'failed', 'cancelled', 'recovery_required']))
  } else if (method === 'agent.runs.get') {
    const message = p !== null && typeof p === 'object' && Object.hasOwn(p, 'messageId')
    object(p, ['agentId', 'runId', 'expectedRevision', ...(message ? ['messageId', 'expectedMessageRevision'] : [])],
      message ? ['contentOffset', 'maxChars'] : [])
    id(p.runId); integer(p.expectedRevision)
    if (message) {
      id(p.messageId); integer(p.expectedMessageRevision)
      optional(p, 'contentOffset', (value) => integer(value)); optional(p, 'maxChars', (value) => integer(value, 1, 16000))
    }
  } else if (method === 'agent.artifacts.list') {
    object(p, ['agentId'], ['cursor', 'limit', 'archived', 'search']); page(p, 20)
    optional(p, 'archived', (value) => check(typeof value === 'boolean')); optional(p, 'search', (value) => string(value, 200, 0))
  } else if (method === 'agent.artifacts.get') {
    object(p, ['agentId', 'artifactId'], ['version']); id(p.artifactId); optional(p, 'version', (value) => integer(value, 1))
  } else {
    object(p, ['agentId', 'artifactId'], ['cursor', 'limit']); id(p.artifactId); page(p, 20)
  }
  id(p.agentId)
}
