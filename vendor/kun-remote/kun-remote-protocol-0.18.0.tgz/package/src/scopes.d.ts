export type RemoteScopeName = 'personal' | 'groups.read' | 'groups.write' | 'collaboration.read' |
  'collaboration.control' | 'schedules.read' | 'extensions.read' | 'extensions.control' | 'shares.manage'
export const REMOTE_SCOPES: readonly RemoteScopeName[]
export const OPERATION_REQUIRED_SCOPES: Readonly<Partial<Record<import('./operations.js').RemoteMethod, readonly RemoteScopeName[]>>>
export function normalizeRemoteScopes(value?: unknown): RemoteScopeName[]
export function hasRemoteOperationScope(method: string, scopes?: readonly RemoteScopeName[], receiptRead?: boolean): boolean
