import { LIMITS, RemoteError } from './index.js'
/** Share this instance between personal and shared transports for one signed-in account. */
export class RequestBudget {
  constructor() { this.hosts = new Map() }
  lane(host) { return this.hosts.get(host) ?? { ordinaryCount: 0, ordinaryBytes: 0, controlCount: 0, controlBytes: 0, assemblyCount: 0, assemblyBytes: 0 } }
  prune(host, lane) { if (!lane.ordinaryCount && !lane.controlCount && !lane.assemblyCount && this.hosts.get(host) === lane) this.hosts.delete(host) }
  reserve(host, bytes, control = false) {
    if (!Number.isSafeInteger(bytes) || bytes < 0) throw new RemoteError('BACKPRESSURE')
    const lane = this.lane(host)
    const count = control ? 'controlCount' : 'ordinaryCount', size = control ? 'controlBytes' : 'ordinaryBytes'
    if (lane[count] >= (control ? LIMITS.controlPending : LIMITS.pending - LIMITS.controlPending) ||
      lane[size] + bytes + (control ? 0 : lane.assemblyBytes) > (control ? LIMITS.controlBytes : LIMITS.bytes - LIMITS.controlBytes)) throw new RemoteError('BACKPRESSURE')
    lane[count]++; lane[size] += bytes; this.hosts.set(host, lane)
    let active = true
    return () => {
      if (!active) return
      active = false; lane[count]--; lane[size] -= bytes
      this.prune(host, lane)
    }
  }
  beginAssembly(host) {
    const lane = this.lane(host)
    // Responses can be fragments of already-counted pending requests. Bound the
    // assembly set separately instead of double-counting those logical calls.
    if (lane.assemblyCount >= LIMITS.pending) throw new RemoteError('BACKPRESSURE')
    lane.assemblyCount++; this.hosts.set(host, lane)
    let active = true, bytes = 0
    return {
      add: size => {
        if (!active || !Number.isSafeInteger(size) || size < 0 || lane.ordinaryBytes + lane.assemblyBytes + size > LIMITS.bytes - LIMITS.controlBytes)
          throw new RemoteError('BACKPRESSURE')
        bytes += size; lane.assemblyBytes += size
      },
      release: () => {
        if (!active) return
        active = false; lane.assemblyCount--; lane.assemblyBytes -= bytes; this.prune(host, lane)
      }
    }
  }
}
