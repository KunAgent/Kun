import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export type AgentModelRef = { providerId: string; model: string }
export type AgentProfileFields = { name?: string; title?: string; instructions?: string; modelRef?: AgentModelRef | null; fastModelRef?: AgentModelRef | null }
export interface AgentProfile {
  id: string
  name: string
  title: string
  instructions: string
  revision: number
  archived: boolean
  createdAt: string
  updatedAt: string
  modelRef?: AgentModelRef
  fastModelRef?: AgentModelRef
}
export interface AgentProfileParams {
  'agent.get': { agentId: string }
  'agent.create': AgentProfileFields & { name: string }
  'agent.update': { agentId: string; expectedRevision: number } & AtLeastOne<AgentProfileFields>
  'agent.archive': { agentId: string; expectedRevision: number }
  'agent.restore': { agentId: string; expectedRevision: number }
}
export interface AgentProfileResults {
  'agent.get': { agent: AgentProfile; modelChoices: (AgentModelRef & { label: string })[] }
  'agent.create': { agent: AgentProfile }
  'agent.update': { agent: AgentProfile }
  'agent.archive': { agent: AgentProfile }
  'agent.restore': { agent: AgentProfile }
}
export const AGENT_PROFILE_METHODS: readonly (keyof AgentProfileParams)[]
export const AGENT_PROFILE_READ_METHODS: ReadonlySet<keyof AgentProfileParams>
export function validateAgentProfileParams<M extends keyof AgentProfileParams>(method: M, params: unknown): AgentProfileParams[M]
