import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export type AgentMemoryType = 'fact' | 'preference' | 'decision' | 'episode' | 'relationship' | 'insight'
export interface AgentMemory {
  id: string
  content: string
  type: AgentMemoryType
  disabled: boolean
  deleted: boolean
  revision: number
  fingerprint: string
  createdAt: string
  updatedAt: string
}
export type AgentMemoryUpdate = { agentId: string } & (
  { action: 'create'; roomId: string; sourceMessageIds: string[]; content: string; type?: AgentMemoryType } |
  ({ action: 'edit'; memoryId: string; expectedFingerprint: string } & AtLeastOne<{ content?: string; disabled?: boolean }>) |
  { action: 'forget'; memoryId: string; expectedFingerprint: string }
)
export interface AgentMemoryParams {
  'agent.memory.list': PageParams & { agentId: string; includeDeleted?: boolean }
  'agent.memory.update': AgentMemoryUpdate
}
export interface AgentMemoryResults {
  'agent.memory.list': RemotePage<AgentMemory, 'memories'> & { available: boolean }
  'agent.memory.update': { memory: AgentMemory } | { memoryId: string; forgotten: true }
}
export const AGENT_MEMORY_METHODS: readonly (keyof AgentMemoryParams)[]
export const AGENT_MEMORY_READ_METHODS: ReadonlySet<keyof AgentMemoryParams>
export function validateAgentMemoryParams<M extends keyof AgentMemoryParams>(method: M, params: unknown): AgentMemoryParams[M]
