import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface ScheduleSummary { id: string; roomId: string; agentId: string; title: string; revision: number; status: string; surface: string;
  schedule?: Record<string, unknown>; scheduledFor?: string; runCount: number; createdAt: string; updatedAt: string }
export interface ScheduleRun { id: string; scheduleId: string; roomId: string; revision: number; title: string; status: string; occurrence?: number;
  threadId?: string; turnId?: string; createdAt: string; finishedAt?: string; result?: { summary: string; finalExcerpt: string; finishedAt: string } }
export interface DesktopScheduleSummary { id: string; title: string; enabled: boolean; status: string; nextRunAt?: string; lastRunAt?: string;
  schedule: { kind: string; everyMinutes?: number; timeOfDay?: string; atTime?: string; timeZone?: string };
  historyCoverage: 'recorded_and_latest_snapshot' }
export interface DesktopScheduleRun { id: string; scheduleId: string; status: string; threadId?: string; turnId?: string;
  startedAt?: string; finishedAt?: string; coverage: 'recorded' | 'legacy_latest_snapshot' }
export interface ScheduleParams {
  'schedule.list': PageParams
  'schedule.runs.list': PageParams & { scheduleId: string }
  'desktop.schedule.list': PageParams
  'desktop.schedule.runs.list': PageParams & { scheduleId: string }
}
export interface ScheduleResults {
  'schedule.list': { source: 'runtime_workbench'; schedules: ScheduleSummary[]; hasMore: boolean; nextCursor?: string; complete: boolean; scanned: number }
  'schedule.runs.list': { source: 'runtime_workbench'; runs: ScheduleRun[]; hasMore: boolean; nextCursor?: string; complete: boolean; scanned: number }
  'desktop.schedule.list': { source: 'desktop_scheduler'; schedules: DesktopScheduleSummary[]; hasMore: boolean; nextCursor?: string }
  'desktop.schedule.runs.list': { source: 'desktop_scheduler'; runs: DesktopScheduleRun[]; hasMore: boolean; nextCursor?: string }
}
export const SCHEDULE_METHODS: readonly (keyof ScheduleParams)[]
export const SCHEDULE_READ_METHODS: ReadonlySet<keyof ScheduleParams>
export function validateScheduleParams<M extends keyof ScheduleParams>(method: M, params: unknown): ScheduleParams[M]
