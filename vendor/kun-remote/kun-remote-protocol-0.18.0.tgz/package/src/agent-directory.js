import { page as strictPage } from './validation.js'
import { check, object, oneOf, optional, text as string, textPage as page } from './validation.js'

export const AGENT_DIRECTORY_METHODS = Object.freeze(["agent.search", "agent.directory.list"])
export const AGENT_DIRECTORY_READ_METHODS = new Set(["agent.search", "agent.directory.list"])
export function validateAgentDirectoryParams(method, params) {
  switch (method) {
    case 'agent.search':
      object(params, ['query'], ['includeArchived', 'cursor', 'limit'])
      string(params.query, 200)
      check(params.query.trim().length > 0)
      optional(params, 'includeArchived', value => check(typeof value === 'boolean'))
      page(params)
      break
    case 'agent.directory.list':
      object(params, [], ['directoryView', 'cursor', 'limit']); strictPage(params, 50)
      optional(params, 'directoryView', (v) => oneOf(v, ['visible', 'archived', 'all'])); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return params
}
