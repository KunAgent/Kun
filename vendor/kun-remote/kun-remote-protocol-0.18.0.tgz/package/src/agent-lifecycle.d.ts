export interface AgentLifecycleParams {
  'agent.lifecycle.get': { agentId: string }
  'agent.restart': { agentId: string; expectedRevision: number; expectedLifecycleRevision: string }
}
export interface AgentLifecycleState {
  agentId: string
  agentRevision: number
  lifecycleRevision: string
  state: 'active' | 'restarting'
  contextGeneration: number
  queuePaused: boolean
  queuedCount: number
  actions: Array<'restart'>
}
export interface AgentRestartResult {
  agentId: string
  state: 'active'
  lifecycleRevision: string
  contextGeneration: number
  queuePaused: boolean
  restarted: true
  preserved: { history: true; memory: true; files: true; delegatedTasks: true }
}
export interface AgentLifecycleResults {
  'agent.lifecycle.get': AgentLifecycleState
  'agent.restart': AgentRestartResult
}
export type AgentLifecycleMethod = keyof AgentLifecycleParams
export const AGENT_LIFECYCLE_METHODS: readonly AgentLifecycleMethod[]
export const AGENT_LIFECYCLE_READ_METHODS: readonly AgentLifecycleMethod[]
export function validateAgentLifecycleParams<M extends AgentLifecycleMethod>(method: M, params: AgentLifecycleParams[M]): void
