import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface GroupSummary {
  id: string; name: string; description: string; revision: number; archived: boolean; collaborationMode: string
  pinned?: boolean; defaultMemberId?: string; maxConcurrentTasks?: number
  members: Array<{ id: string; name: string; role: string; enabled: boolean; participantAgentId?: string; removed: boolean; revision?: number; canLead?: boolean }>
  createdAt: string; updatedAt: string
}
export interface GroupMessage {
  id: string; roomId: string; body: string; bodyRevision: number; status?: string
  authorKind: string; authorLabel: string; authorMemberId?: string; attachmentIds: string[]; createdAt: string; messageSeq: number
  replyToMessageId?: string; rootRequestId?: string; presentationKind?: string
}
export interface GroupHistory { room: GroupSummary; messages: GroupMessage[]; hasMore: boolean; nextCursor?: string; eventScope?: string; cursor?: number }
export type GroupSettings = { name?: string; description?: string; defaultMemberId?: string;
  collaborationMode?: 'peer' | 'directed' | 'autonomous'; maxConcurrentTasks?: number; pinned?: boolean }
export type GroupMutationTarget = { roomId: string; expectedRevision: number }
export interface GroupParams {
  'group.get': { roomId: string }
  'group.list': PageParams & { query?: string; archived?: boolean }
  'group.history': PageParams & { roomId: string }
  'group.message.send': { roomId: string; text: string; mentionMemberIds?: string[]; executionIntent?: 'auto' | 'discussion' | 'execute' }
  'group.create': Omit<GroupSettings, 'defaultMemberId' | 'pinned'> & { name: string; participantAgentIds: string[]; defaultAgentId?: string }
  'group.update': GroupMutationTarget & GroupSettings
  'group.archive': GroupMutationTarget
  'group.restore': GroupMutationTarget
  'group.member.add': GroupMutationTarget & { agentId: string }
  'group.member.update': GroupMutationTarget & { memberId: string; enabled: boolean; defaultMemberId?: string }
  'group.member.remove': GroupMutationTarget & { memberId: string; defaultMemberId?: string }
}
export interface GroupResults {
  'group.get': { group: GroupSummary }
  'group.list': { groups: GroupSummary[]; hasMore: boolean; nextCursor?: string }
  'group.history': GroupHistory
  'group.message.send': { message: GroupMessage | Record<string, unknown>; requestId: string; roomId: string }
  'group.create': { group: GroupSummary }
  'group.update': { group: GroupSummary }
  'group.archive': { group: GroupSummary }
  'group.restore': { group: GroupSummary }
  'group.member.add': { group: GroupSummary }
  'group.member.update': { group: GroupSummary }
  'group.member.remove': { group: GroupSummary }
}
export const GROUP_METHODS: readonly (keyof GroupParams)[]
export const GROUP_READ_METHODS: ReadonlySet<keyof GroupParams>
export function validateGroupParams<M extends keyof GroupParams>(method: M, params: unknown): GroupParams[M]
export const GROUP_WRITE_METHODS: readonly ('group.create' | 'group.update' | 'group.archive' | 'group.restore' | 'group.member.add' | 'group.member.update' | 'group.member.remove')[]
