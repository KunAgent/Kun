import { check, object, id, integer, optional, oneOf, page } from './validation.js'
export const AGENT_HISTORY_METHODS = Object.freeze([
  'agent.memory.candidates.list', 'agent.memory.candidates.get', 'agent.memory.candidates.decide',
  'agent.memory.history.list', 'agent.memory.history.get'
])
export const AGENT_HISTORY_READ_METHODS = Object.freeze(AGENT_HISTORY_METHODS.filter((method) => !method.endsWith('.decide')))
function fingerprint(value) { check(typeof value === 'string' && /^[a-f0-9]{64}$/.test(value)) }
function slice(p) {
  optional(p, 'contentOffset', (value) => integer(value))
  optional(p, 'maxChars', (value) => integer(value, 1, 16000))
}
export function validateAgentHistoryParams(method, p) {
  check(AGENT_HISTORY_METHODS.includes(method))
  if (method === 'agent.memory.candidates.list') { object(p, ['agentId'], ['cursor', 'limit']); page(p, 20) }
  else if (method === 'agent.memory.candidates.get') {
    oneOf(p?.side, ['proposed', 'current'])
    object(p, ['agentId', 'candidateId', 'expectedRevision', 'side', ...(p.side === 'current' ? ['expectedTargetFingerprint'] : [])], ['contentOffset', 'maxChars'])
    if (p.side === 'current') fingerprint(p.expectedTargetFingerprint)
    slice(p)
  } else if (method === 'agent.memory.candidates.decide') {
    oneOf(p?.decision, ['accept', 'reject'])
    object(p, ['agentId', 'candidateId', 'expectedRevision', 'decision', ...(p.decision === 'accept' ? ['expectedTargetFingerprint'] : [])])
    if (p.decision === 'accept') fingerprint(p.expectedTargetFingerprint)
  } else if (method === 'agent.memory.history.list') {
    object(p, ['agentId', 'memoryId', 'expectedFingerprint'], ['cursor', 'limit']); page(p, 20)
  } else {
    object(p, ['agentId', 'memoryId', 'expectedFingerprint', 'revision'], ['contentOffset', 'maxChars'])
    integer(p.revision, 1); slice(p)
  }
  id(p.agentId)
  if (method.includes('.candidates.') && !method.endsWith('.list')) { id(p.candidateId); integer(p.expectedRevision) }
  if (method.includes('.history.')) { id(p.memoryId); fingerprint(p.expectedFingerprint) }
}
