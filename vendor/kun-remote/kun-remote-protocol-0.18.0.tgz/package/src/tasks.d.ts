import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export type RemoteCodeStatus = 'idle' | 'running' | 'archived' | 'deleted'
export interface CodeSummary {
  id: string
  title: string
  status: RemoteCodeStatus
  pinned: boolean
  archived: boolean
  revision: string
  model: string
  harnessId?: string
  providerId?: string
  projectId?: string
  createdAt: string
  updatedAt: string
}
export interface CodeSearchCoverage {
  metadataMatched: number; nativeMatched: number; sourceMatched: number
  searchedWithoutMatch: number; sourceUnavailable: number
}
type MetadataParams = { threadId: string; expectedRevision: string }
export interface TaskParams {
  'code.search': PageParams & {
    query?: string
    status?: 'all' | 'running' | 'idle' | 'archived'
    projectId?: string
    harnessId?: string
    updatedFrom?: number
    updatedBefore?: number
  }
  'code.rename': MetadataParams & { title: string }
  'code.pin': MetadataParams & { pinned: boolean }
  'code.archive': MetadataParams
  'code.restore': MetadataParams
  'code.delete': MetadataParams
}
export interface TaskResults {
  'code.search': RemotePage<CodeSummary, 'threads'> & { searchScope?: 'metadata' | 'title_and_content'; scanned?: number; complete?: boolean; coverage?: CodeSearchCoverage }
  'code.rename': { thread: CodeSummary }
  'code.pin': { thread: CodeSummary }
  'code.archive': { thread: CodeSummary }
  'code.restore': { thread: CodeSummary }
  'code.delete': { threadId: string; deleted: true }
}
export const TASK_METHODS: readonly (keyof TaskParams)[]
export const TASK_READ_METHODS: ReadonlySet<keyof TaskParams>
export function validateTaskParams<M extends keyof TaskParams>(method: M, params: unknown): TaskParams[M]
