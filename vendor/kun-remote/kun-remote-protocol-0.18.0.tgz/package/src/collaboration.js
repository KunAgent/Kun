import { check, object, id, optional, page } from './validation.js'

export const COLLABORATION_METHODS = Object.freeze(["collaboration.runs.list", "collaboration.tasks.list"])
export const COLLABORATION_READ_METHODS = new Set(["collaboration.runs.list", "collaboration.tasks.list"])
export function validateCollaborationParams(method, p) {
  switch (method) {
    case 'collaboration.runs.list':
      object(p, ['roomId'], ['cursor', 'limit']); id(p.roomId); page(p, 20)
      optional(p, 'cursor', (v) => check(/^[0-9]{1,16}$/.test(v) && Number.isSafeInteger(Number(v)) && Number(v) > 0)); break
    case 'collaboration.tasks.list':
      object(p, ['roomId'], ['cursor', 'limit']); id(p.roomId); page(p, 20)
      optional(p, 'cursor', (v) => check(/^[0-9]{1,16}$/.test(v) && Number.isSafeInteger(Number(v)) && Number(v) > 0)); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
