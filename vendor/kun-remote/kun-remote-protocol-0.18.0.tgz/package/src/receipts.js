export const REJECTION_CODES = Object.freeze([
  'REVISION_CONFLICT', 'MODEL_NOT_AVAILABLE', 'AGENT_NOT_AVAILABLE',
  'NOT_FOUND', 'TASK_BUSY', 'INVALID_REQUEST', 'NOT_A_CODE_TASK', 'ATTACHMENT_NOT_CONFIRMED'
])

/** Only a typed, persisted no-effect decision ends uncertainty. A generic error never does. */
export function isDefinitiveReceiptRejection(receipt) {
  if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt) ||
      receipt.status !== 'reconciliation_required') return false
  const error = receipt.error
  return !!error && typeof error === 'object' && !Array.isArray(error) &&
    Object.keys(error).length === 2 && Object.hasOwn(error, 'code') &&
    Object.hasOwn(error, 'definitive') && error.definitive === true &&
    REJECTION_CODES.includes(error.code)
}
