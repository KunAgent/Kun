import { check, object, oneOf, optional, text } from './validation.js'
import { normalizeCapabilities } from './capabilities.js'
/** Input kinds a model reads; `image` is what the desktop picker shows as a vision badge. */
export const INPUT_MODALITIES = Object.freeze(['text', 'image'])
/** The desktop Fast toggle's states for one model; an absent state hides the toggle. */
export const FAST_MODE_STATES = Object.freeze(['supported', 'unknown', 'unsupported'])
/** The request service tiers a phone may ask for on a turn; `priority` is Fast mode. */
export const SERVICE_TIERS = Object.freeze(['priority'])
/**
 * Advertised in `catalog.get` capabilities only when the host describes per-model `modelInfo` on its agent routes and
 * accepts `serviceTier` on `code.turn.start`. Without it a controller shows no model info and sends no service tier.
 */
export const MODEL_INFO_CAPABILITY = 'code.modelInfo'
/** Undefined means no catalog. Only the explicit capability string enables model info, never a broad feature. */
export function hasModelInfo(catalog) {
  if (catalog === undefined || catalog === null) return undefined
  return normalizeCapabilities(catalog).capabilities.includes(MODEL_INFO_CAPABILITY)
}
/** A requested service tier: one of the fixed tiers only. */
export function validateServiceTier(value) {
  oneOf(value, SERVICE_TIERS)
  return value
}
function info(value) {
  object(value, [], ['displayName', 'inputModalities', 'fastMode'])
  // An entry that says nothing is withheld rather than sent.
  check(Object.keys(value).length > 0)
  optional(value, 'displayName', (name) => { text(name, 160); check(name.trim().length > 0 && name === name.trim()) })
  optional(value, 'inputModalities', (kinds) => {
    check(Array.isArray(kinds) && kinds.length > 0 && kinds.length <= INPUT_MODALITIES.length)
    kinds.forEach((kind) => oneOf(kind, INPUT_MODALITIES))
    check(new Set(kinds).size === kinds.length)
  })
  optional(value, 'fastMode', (state) => oneOf(state, FAST_MODE_STATES))
}
/** Checks the per-model facts a host attaches to one agent route; every key is a listed model. */
export function validateModelInfo(route) {
  check(route !== null && typeof route === 'object' && Array.isArray(route.models))
  if (route.modelInfo === undefined) return route
  object(route.modelInfo, [], route.models)
  Object.values(route.modelInfo).forEach(info)
  return route
}
