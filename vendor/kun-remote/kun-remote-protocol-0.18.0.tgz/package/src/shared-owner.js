import { check, object, id, integer, oneOf, optional, page } from './validation.js'
export function validateSharedOwnerParams(method, p) {
  if (method === 'shares.list') {
    object(p, [], ['threadId', 'cursor', 'limit']); optional(p, 'threadId', id); page(p, 20); return p
  }
  check(method === 'shares.manage')
  switch (p?.action) {
    case 'create':
      object(p, ['action', 'threadId'], ['expiresAt']); id(p.threadId); break
    case 'invite':
      object(p, ['action', 'shareId', 'expectedVersion', 'invitationHash', 'mode'], ['expiresAt'])
      check(typeof p.invitationHash === 'string' && /^[a-f0-9]{64}$/.test(p.invitationHash)); oneOf(p.mode, ['read', 'write']); break
    case 'member.update':
      object(p, ['action', 'shareId', 'memberId', 'expectedVersion', 'mode']); id(p.memberId); oneOf(p.mode, ['read', 'write']); break
    case 'revoke': object(p, ['action', 'shareId', 'memberId', 'expectedVersion']); id(p.memberId); break
    case 'close': object(p, ['action', 'shareId', 'expectedVersion']); break
    default: check(false)
  }
  optional(p, 'shareId', id); optional(p, 'expectedVersion', value => integer(value, 1))
  optional(p, 'expiresAt', value => integer(value, 1))
  return p
}

export const SHARED_OWNER_METHODS = Object.freeze(['shares.list', 'shares.manage'])
export const SHARED_OWNER_READ_METHODS = new Set(['shares.list'])
