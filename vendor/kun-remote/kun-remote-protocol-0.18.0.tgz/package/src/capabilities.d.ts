import type { ResourceKind } from './values.js'
import type { RemoteCodeAgent } from './models.js'
export interface CapabilityDescriptor {
  operation: string
  schemaVersion: 1
  resourceKind: ResourceKind
  allowedActions: string[]
  supported: boolean
  enabled: boolean
  authorized: boolean
  online: boolean
  limits?: Record<string, number>
}
export interface RemoteCapabilities {
  capabilities: string[]
  capabilityDescriptors?: CapabilityDescriptor[]
}
export interface RemoteCatalog extends RemoteCapabilities {
  projects: { id: string; name: string }[]
  models: string[]
  defaultModel?: string
  agents?: RemoteCodeAgent[]
  attachmentMaxBytes?: number
  host?: { deviceId?: string; appVersion?: string; runtimeVersion?: string; protocolVersion?: number; releaseChannel?: 'stable' | 'frontier'; platform?: string; confirmedAt: number }
}
export function normalizeCapabilities(value: unknown): RemoteCapabilities
export function hasOperation(catalog: RemoteCapabilities | null | undefined, operation: string, resourceKind?: ResourceKind): boolean | undefined
