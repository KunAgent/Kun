import type { PageParams } from './values.js'
export type ReminderStatus = 'scheduled' | 'paused' | 'fired' | 'cancelled' | 'expired'
export type ReminderRecurrence = { kind: 'interval'; everySeconds: number } | { kind: 'daily'; localTime: string } |
  { kind: 'weekly'; localTime: string; weekdays: number[] }
export type ReminderTrigger = { kind: 'room_idle'; idleSeconds: number } | { kind: 'message'; authorKind: 'user' | 'agent'; contains?: string }
export interface RemoteReminder {
  id: string
  revision: number
  agentId: string
  /** At most 1,000 UTF-16 code units. A clipped legacy note is explicitly marked. */
  note: string
  noteTotalChars: number
  noteTruncated: boolean
  fireAt: string
  status: ReminderStatus
  /** Native schedule timezone; never guessed from the phone's current timezone. */
  timezone: string
  recurrence?: ReminderRecurrence
  quietHours?: { start: string; end: string }
  trigger?: ReminderTrigger
  expiresAt?: string
  occurrence: number
  maxOccurrences?: number
  deferredReason?: 'quiet_hours' | 'condition_pending' | 'fire_budget' | 'feature_disabled'
  endedReason?: 'agent_cancelled' | 'user_cancelled' | 'room_archived' | 'agent_unavailable' | 'too_late' | 'schedule_complete' | 'condition_expired'
  createdAt: string
  updatedAt: string
  firedAt?: string
  source: { resource: { kind: 'agent'; id: string }; roomId: string; anchorMessageId?: string }
  canPause: boolean
  canResume: boolean
  canCancel: boolean
}
export interface ReminderParams {
  'agent.reminders.list': PageParams & { agentId: string; status?: ReminderStatus | 'active' | 'all' }
  'agent.reminders.act': { agentId: string; reminderId: string; expectedRevision: number; action: 'pause' | 'resume' | 'cancel' }
}
export interface ReminderResults {
  'agent.reminders.list': { agentId: string; enabled: boolean; reminders: RemoteReminder[]; hasMore: boolean; complete: boolean; nextCursor?: string }
  /** No note or trigger text in durable remote operation receipts. Refresh the authorized list for content. */
  'agent.reminders.act': { reminder: { id: string; revision: number; status: ReminderStatus; fireAt: string; timezone: string; updatedAt: string } }
}
export type ReminderMethod = keyof ReminderParams
export const REMINDER_METHODS: readonly ReminderMethod[]
export const REMINDER_READ_METHODS: readonly ReminderMethod[]
export function validateReminderParams<M extends ReminderMethod>(method: M, params: ReminderParams[M]): void
