import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface AgentCatalogEntry { ref: string; name: string; status: 'available' | 'connected' | 'reconnecting' | 'unavailable'; available: boolean }
export interface AgentCatalogResult {
  agentId: string
  agentRevision: number
  appliesTo: 'next_api_turn'
  editable: false
  available: boolean
  enabled: boolean
  reason?: 'EXTERNAL_AGENT_UNSUPPORTED' | 'AGENT_UNAVAILABLE' | 'NO_CONVERSATION' | 'CATALOG_UNAVAILABLE'
  revision?: string
  items: AgentCatalogEntry[]
  hasMore: boolean
  complete: boolean
  nextCursor?: string
}
export interface AgentCapabilityParams {
  'agent.skills.list': PageParams & { agentId: string }
  'agent.connections.list': PageParams & { agentId: string }
}
export interface AgentCapabilityResults {
  'agent.skills.list': AgentCatalogResult
  'agent.connections.list': AgentCatalogResult
}
export const AGENT_CAPABILITY_METHODS: readonly (keyof AgentCapabilityParams)[]
export const AGENT_CAPABILITY_READ_METHODS: ReadonlySet<keyof AgentCapabilityParams>
export function validateAgentCapabilityParams<M extends keyof AgentCapabilityParams>(method: M, params: unknown): void
