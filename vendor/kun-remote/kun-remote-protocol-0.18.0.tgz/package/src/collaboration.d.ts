import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface CollaborationRun { id: string; roomId: string; memberId: string; taskId?: string; phase: string; status: string;
  startedAt?: string; endedAt?: string; elapsedMs?: number; threadId?: string; turnId?: string }
export interface CollaborationTask { id: string; roomId: string; revision: number; title: string; status: string; ownerMemberId: string; updatedAt: string }
export interface CollaborationParams {
  'collaboration.runs.list': PageParams & { roomId: string }
  'collaboration.tasks.list': PageParams & { roomId: string }
}
export interface CollaborationResults {
  'collaboration.runs.list': { runs: CollaborationRun[]; hasMore: boolean; nextCursor?: string }
  'collaboration.tasks.list': { tasks: CollaborationTask[]; hasMore: boolean; nextCursor?: string }
}
export const COLLABORATION_METHODS: readonly (keyof CollaborationParams)[]
export const COLLABORATION_READ_METHODS: ReadonlySet<keyof CollaborationParams>
export function validateCollaborationParams<M extends keyof CollaborationParams>(method: M, params: unknown): CollaborationParams[M]
