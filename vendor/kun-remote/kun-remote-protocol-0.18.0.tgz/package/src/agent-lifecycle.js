import { check, id, integer, object } from './validation.js'
export const AGENT_LIFECYCLE_METHODS = Object.freeze(['agent.lifecycle.get', 'agent.restart'])
export const AGENT_LIFECYCLE_READ_METHODS = Object.freeze(['agent.lifecycle.get'])
export function validateAgentLifecycleParams(method, p) {
  check(AGENT_LIFECYCLE_METHODS.includes(method))
  object(p, ['agentId', ...(method === 'agent.restart' ? ['expectedRevision', 'expectedLifecycleRevision'] : [])])
  id(p.agentId)
  if (method === 'agent.restart') {
    integer(p.expectedRevision)
    check(typeof p.expectedLifecycleRevision === 'string' && /^agent-life-v1:(0|[1-9]\d*)$/.test(p.expectedLifecycleRevision) &&
      Number.isSafeInteger(Number(p.expectedLifecycleRevision.slice(14))))
  }
}
