import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface MobilePluginView { id: string; title: string; location: string; mode: 'desktop_only'; available: false; reason: 'MOBILE_VIEW_NOT_DECLARED' }
export interface MobilePlugin { id: string; name: string; description: string; version?: string; enabled: boolean; compatible: boolean;
  revision?: string; globalEnabled?: boolean; hasWorkspaceOverrides?: boolean; views: MobilePluginView[]; actions: never[] }
export interface PluginParams {
  'plugin.catalog': PageParams
  'plugin.view': { pluginId: string; contributionId: string }
  'plugin.setEnabled': { pluginId: string; expectedRevision: string; enabled: boolean }
}
export interface PluginResults {
  'plugin.catalog': { revision: number; plugins: MobilePlugin[]; hasMore: boolean; nextCursor?: string }
  'plugin.view': { pluginId: string; pluginVersion: string; view: MobilePluginView; actions: never[] }
  'plugin.setEnabled': { plugin: MobilePlugin }
}
export const PLUGIN_METHODS: readonly (keyof PluginParams)[]
export const PLUGIN_READ_METHODS: ReadonlySet<keyof PluginParams>
export function validatePluginParams<M extends keyof PluginParams>(method: M, params: unknown): PluginParams[M]
