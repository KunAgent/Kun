import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
import type { RemoteModelRoute, RemoteCodeAgent } from './models.js'
export interface CodeSettings {
  threadId: string
  revision: string
  effective: RemoteModelRoute
  next: RemoteModelRoute
  models: string[]
  agents: RemoteCodeAgent[]
  editable: boolean
  reason?: string
}
export interface TaskSettingsParams {
  'code.settings.get': { threadId: string }
  'code.settings.update': { threadId: string; expectedRevision: string; next: RemoteModelRoute }
}
export interface TaskSettingsResults {
  'code.settings.get': CodeSettings
  'code.settings.update': CodeSettings
}
export const TASK_SETTINGS_METHODS: readonly (keyof TaskSettingsParams)[]
export const TASK_SETTINGS_READ_METHODS: ReadonlySet<keyof TaskSettingsParams>
export function validateTaskSettingsParams<M extends keyof TaskSettingsParams>(method: M, params: unknown): TaskSettingsParams[M]
