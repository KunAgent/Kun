import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
type ExecutionThread = { threadId: string }
type QueueMutation = ExecutionThread & { expectedRevision: string }
type MessageInput = { text: string; attachmentIds?: string[] }
export interface QueueEntry {
  turnId: string
  position: number
  text: string
  attachmentIds: string[]
  createdAt: string
  editable: boolean
  clientRequestId?: string
  clientSurface?: string
  messageId?: string
  historyVersion?: string
  textTruncated?: boolean
  pending?: boolean
  reason?: string
}
export interface QueueSnapshot extends RemotePage<QueueEntry, 'items'> {
  threadId: string
  revision: string
  paused: boolean
  pauseReason?: string
  canSteer?: boolean
  activeTurnId?: string
  steerReason?: string
}
export interface ExecutionParams {
  'execution.queue.list': ExecutionThread & PageParams
  'execution.queue.enqueue': ExecutionThread & MessageInput
  'execution.steer': ExecutionThread & MessageInput & { turnId: string }
  'execution.queue.update': QueueMutation & MessageInput & { turnId: string }
  'execution.queue.remove': QueueMutation & { turnId: string }
  'execution.resume': QueueMutation
}
export interface ExecutionResults {
  'execution.queue.list': QueueSnapshot
  'execution.queue.enqueue': { threadId: string; turnId: string; userMessageItemId: string; status: 'queued' | 'running'; queuedPosition?: number }
  'execution.steer': { ok: true; threadId: string; turnId: string }
  'execution.queue.update': QueueSnapshot
  'execution.queue.remove': QueueSnapshot
  'execution.resume': { threadId: string; started: boolean; turnId?: string; queue: QueueSnapshot }
}
export const EXECUTION_METHODS: readonly (keyof ExecutionParams)[]
export const EXECUTION_READ_METHODS: ReadonlySet<keyof ExecutionParams>
export function validateExecutionParams<M extends keyof ExecutionParams>(method: M, params: unknown): ExecutionParams[M]
