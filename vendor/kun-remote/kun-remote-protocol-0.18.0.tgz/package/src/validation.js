export function check(condition) { if (!condition) throw new Error('INVALID_PARAMS') }
export function object(value, required, optional = []) {
  check(value !== null && typeof value === 'object' && !Array.isArray(value))
  check(Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null)
  check(required.every((key) => Object.hasOwn(value, key)))
  check(Object.keys(value).every((key) => required.includes(key) || optional.includes(key)))
}
export function string(value, max, min = 1) {
  check(typeof value === 'string' && value.length >= min && value.length <= max && !value.includes('\0'))
  if (min) check(value.trim().length > 0)
}
export function id(value) { check(typeof value === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(value)) }
export function integer(value, min = 0, max = Number.MAX_SAFE_INTEGER) { check(Number.isSafeInteger(value) && value >= min && value <= max) }
export function optional(value, key, validate) { if (value[key] !== undefined) validate(value[key]) }
export function oneOf(value, allowed) { check(allowed.includes(value)) }
export function revision(value, kind) { check(typeof value === 'string' && new RegExp('^' + kind + '-v1:[a-f0-9]{64}$').test(value)) }
export function page(value, max = 50) {
  optional(value, 'cursor', (v) => string(v, 2048))
  optional(value, 'limit', (v) => integer(v, 1, max))
}
export function attachments(value) {
  optional(value, 'attachmentIds', (items) => {
    check(Array.isArray(items) && items.length <= 8)
    items.forEach(id)
    check(new Set(items).size === items.length)
  })
}

export function text(value, max, min = 1) {
  check(typeof value === 'string' && value.length >= min && value.length <= max && !value.includes('\0'))
}
export function textPage(value) {
  optional(value, 'cursor', field => text(field, 2048))
  optional(value, 'limit', field => integer(field, 1, 50))
}
export function harness(value) {
  check(typeof value === 'string' && /^[a-z][a-z0-9-]{1,47}$/.test(value))
}
export function resource(value) {
  object(value, ['kind', 'id'])
  oneOf(value.kind, ['code', 'agent'])
  id(value.id)
}
