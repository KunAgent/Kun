import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
type GoalThread = { threadId: string }
export interface RemoteGoal {
  threadId: string
  objective: string
  status: 'active' | 'paused' | 'blocked' | 'usageLimited' | 'budgetLimited' | 'complete'
  tokenBudget?: number | null
  tokensUsed: number
  timeUsedSeconds: number
  createdAt: string
  updatedAt: string
}
export interface GoalSnapshot { threadId: string; revision: string; goal: RemoteGoal | null }
export interface GoalParams {
  'goal.get': GoalThread
  'goal.clear': GoalThread & { expectedRevision: string }
  'goal.update': GoalThread & { expectedRevision: string } & AtLeastOne<{ objective?: string; status?: 'active' | 'paused' | 'complete'; tokenBudget?: number | null }>
}
export interface GoalResults {
  'goal.get': GoalSnapshot
  'goal.clear': GoalSnapshot
  'goal.update': GoalSnapshot
}
export const GOAL_METHODS: readonly (keyof GoalParams)[]
export const GOAL_READ_METHODS: ReadonlySet<keyof GoalParams>
export function validateGoalParams<M extends keyof GoalParams>(method: M, params: unknown): GoalParams[M]
