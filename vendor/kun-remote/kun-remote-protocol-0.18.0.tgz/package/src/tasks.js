import { check, object, id, integer, oneOf, optional, text as string, textPage as page, harness } from './validation.js'
function metadata(params) {
  id(params.threadId)
  string(params.expectedRevision, 64)
  check(/^thread-v1:(0|[1-9][0-9]*)$/.test(params.expectedRevision))
  integer(Number(params.expectedRevision.slice(10)), 0, Number.MAX_SAFE_INTEGER)
}

export const TASK_METHODS = Object.freeze(["code.search", "code.rename", "code.pin", "code.archive", "code.restore", "code.delete"])
export const TASK_READ_METHODS = new Set(["code.search"])
export function validateTaskParams(method, params) {
  switch (method) {
    case 'code.search':
      object(params, [], ['query', 'status', 'projectId', 'harnessId', 'cursor', 'limit', 'updatedFrom', 'updatedBefore'])
      optional(params, 'query', (value) => string(value, 200, 0))
      optional(params, 'status', (value) => oneOf(value, ['all', 'running', 'idle', 'archived']))
      optional(params, 'projectId', id)
      optional(params, 'harnessId', harness)
      optional(params, 'updatedFrom', value => integer(value, 0, 253402300799999))
      optional(params, 'updatedBefore', value => integer(value, 0, 253402300799999))
      check(params.updatedFrom === undefined || params.updatedBefore === undefined || params.updatedFrom < params.updatedBefore)
      page(params)
      break
    case 'code.rename':
      object(params, ['threadId', 'expectedRevision', 'title'])
      metadata(params)
      string(params.title, 160)
      check(params.title.trim().length > 0)
      break
    case 'code.pin':
      object(params, ['threadId', 'expectedRevision', 'pinned'])
      metadata(params)
      check(typeof params.pinned === 'boolean')
      break
    case 'code.archive':
    case 'code.restore':
    case 'code.delete':
      object(params, ['threadId', 'expectedRevision'])
      metadata(params)
      break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return params
}
