import { optional, object, string, check } from './validation.js'
export const WORK_FIELDS = ['objective', 'acceptance', 'deadline', 'nextCheckAt', 'waitingOn']
export const WORK_STATUS = ['open', 'in_progress', 'waiting', 'blocked', 'completed', 'cancelled']
function time(value) {
  if (value === null) return
  string(value, 64)
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.exec(value)
  check(m && Number.isFinite(Date.parse(value)))
  check(Number(m[2]) >= 1 && Number(m[2]) <= 12 && Number(m[3]) >= 1 &&
    Number(m[3]) <= new Date(Date.UTC(Number(m[1]), Number(m[2]), 0)).getUTCDate() &&
    Number(m[4]) <= 23 && Number(m[5]) <= 59 && Number(m[6]) <= 59)
}
export function work(value) {
  optional(value, 'objective', (v) => string(v, 8000))
  optional(value, 'acceptance', (v) => string(v, 4000))
  optional(value, 'deadline', time); optional(value, 'nextCheckAt', time)
  optional(value, 'waitingOn', (v) => { if (v !== null) string(v, 2000, 0) })
}
export function evidence(value) {
  check(Array.isArray(value) && value.length <= 30)
  for (const item of value) {
    object(item, ['summary'], ['reference']); string(item.summary, 4000)
    optional(item, 'reference', (v) => string(v, 4096))
  }
}
