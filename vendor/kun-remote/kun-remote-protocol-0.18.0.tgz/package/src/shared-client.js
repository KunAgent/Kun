import { TransportClient } from './transport-client.js'
import { SharedPolicy } from './shared-policy.js'
import { RequestBudget } from './request-budget.js'
export { SHARED_READ_METHODS, SHARED_WRITE_METHODS } from './shared-policy.js'
export { SharedReassembler } from './shared-frames.js'
export { validateShareLease } from './shared-validation.js'

/** Separate shared-task transport; no frame is ever dispatched through a personal client. */
export class ShareClient extends TransportClient {
  constructor(deps) {
    const configured = { ...deps, budget: deps.budget ?? new RequestBudget() }
    const policy = new SharedPolicy(configured)
    super(configured, policy)
  }
  get lease() { return this.protocol.current }
}
