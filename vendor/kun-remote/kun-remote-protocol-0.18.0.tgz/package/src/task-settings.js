import { object, id, check } from './validation.js'
import { validateModelRoute } from './models.js'
export const TASK_SETTINGS_METHODS = Object.freeze(["code.settings.get", "code.settings.update"])
export const TASK_SETTINGS_READ_METHODS = new Set(["code.settings.get"])
export function validateTaskSettingsParams(method, params) {
  switch (method) {
    case 'code.settings.get':
      object(params, ['threadId'])
      id(params.threadId)
      break
    case 'code.settings.update':
      object(params, ['threadId', 'expectedRevision', 'next'])
      id(params.threadId)
      check(typeof params.expectedRevision === 'string' && /^task-config-v1:[a-f0-9]{64}$/.test(params.expectedRevision))
      validateModelRoute(params.next)
      break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return params
}
