import { check, object, id, string, optional, oneOf, integer } from './validation.js'
export const GROUP_WRITE_METHODS = Object.freeze(['group.create', 'group.update', 'group.archive', 'group.restore',
  'group.member.add', 'group.member.update', 'group.member.remove'])
const fields = ['name', 'description', 'defaultMemberId', 'collaborationMode', 'maxConcurrentTasks', 'pinned']
function settings(p) {
  optional(p, 'name', (v) => { string(v, 120); check(v.trim().length <= 120) })
  optional(p, 'description', (v) => string(v, 8000, 0))
  optional(p, 'collaborationMode', (v) => oneOf(v, ['peer', 'directed', 'autonomous']))
  optional(p, 'maxConcurrentTasks', (v) => integer(v, 1, 2))
}
export function validateGroupWriteParams(method, p) {
  if (method === 'group.create') {
    object(p, ['name', 'participantAgentIds'], ['description', 'defaultAgentId', 'collaborationMode', 'maxConcurrentTasks'])
    settings(p); string(p.name, 120)
    check(Array.isArray(p.participantAgentIds) && p.participantAgentIds.length >= 1 && p.participantAgentIds.length <= 20 &&
      new Set(p.participantAgentIds).size === p.participantAgentIds.length)
    p.participantAgentIds.forEach(id)
    optional(p, 'defaultAgentId', (v) => { id(v); check(p.participantAgentIds.includes(v)) })
    return p
  }
  const required = ['roomId', 'expectedRevision']
  if (method === 'group.update') {
    object(p, required, fields); check(fields.some((key) => p[key] !== undefined)); settings(p)
    optional(p, 'defaultMemberId', id); optional(p, 'pinned', (v) => check(typeof v === 'boolean'))
  } else if (method === 'group.archive' || method === 'group.restore') object(p, required)
  else if (method === 'group.member.add') { object(p, [...required, 'agentId']); id(p.agentId) }
  else if (method === 'group.member.update' || method === 'group.member.remove') {
    object(p, [...required, 'memberId', ...(method === 'group.member.update' ? ['enabled'] : [])], ['defaultMemberId'])
    id(p.memberId); optional(p, 'defaultMemberId', id)
    if (method === 'group.member.update') check(typeof p.enabled === 'boolean')
  } else throw new Error('UNSUPPORTED_OPERATION')
  id(p.roomId); integer(p.expectedRevision)
  return p
}
