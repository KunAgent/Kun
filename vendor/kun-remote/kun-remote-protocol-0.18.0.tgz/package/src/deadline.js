import { RemoteError } from './index.js'

/** Bound credentials, fetch and response decoding even if a dependency ignores abort. */
export function bounded(operation, timeout, parent, code = 'REQUEST_TIMEOUT') {
  const control = new AbortController()
  return new Promise((resolve, reject) => {
    let settled = false, timer
    const finish = (fn, value) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      parent?.removeEventListener('abort', cancel)
      fn(value)
    }
    const cancel = () => {
      control.abort()
      finish(reject, new RemoteError('REQUEST_CANCELLED'))
    }
    if (parent?.aborted) { cancel(); return }
    parent?.addEventListener('abort', cancel, { once: true })
    timer = setTimeout(() => {
      control.abort()
      finish(reject, new RemoteError(code))
    }, timeout)
    Promise.resolve().then(() => {
      if (control.signal.aborted) throw new RemoteError('REQUEST_CANCELLED')
      return operation(control.signal)
    }).then((value) => finish(resolve, value), (error) => finish(reject, error))
  })
}
export function assertActive(signal) {
  if (signal.aborted) throw new RemoteError('REQUEST_CANCELLED')
}
