import { LIMITS, RemoteError, utf8Size } from './index.js'

/** Pace replay and fragments below the relay's 256 frames/s, including ACKs. */
export class Sender {
  constructor(socket, failed) {
    this.socket = socket
    this.failed = failed
    this.data = []
    this.control = []
    this.bytes = 0
    this.controlBytes = 0
    this.last = -Infinity
    this.lastData = -Infinity
    this.closed = false
  }
  enqueue(frame, frames) {
    const priority = ['ack', 'ping', 'resync_required'].includes(frame.kind) ||
      (frame.kind === 'invoke' && frame.payload?.method === 'execution.stop')
    if (['ack', 'ping'].includes(frame.kind) && this.control.some((part) => part.kind === frame.kind)) return
    const size = frames.reduce((n, raw) => n + utf8Size(raw), 0)
    const buffered = this.socket.bufferedAmount ?? 0
    if (this.closed || this.bytes + size + buffered > LIMITS.bytes ||
      (priority
        ? this.controlBytes + size > LIMITS.controlBytes || this.control.length + frames.length > 64
        : this.bytes - this.controlBytes + size + buffered > LIMITS.bytes - LIMITS.controlBytes || this.data.length + frames.length > 256))
      throw new RemoteError('BACKPRESSURE')
    for (const raw of frames) {
      const part = { raw, size: utf8Size(raw), id: frame.id, kind: frame.kind }
      if (priority) { this.control.push(part); this.controlBytes += part.size }
      else this.data.push(part)
      this.bytes += part.size
    }
    this.pump()
  }
  cancel(id) {
    for (const queue of [this.data, this.control]) {
      for (let i = queue.length - 1; i >= 0; i--) {
        if (queue[i].id !== id) continue
        const [part] = queue.splice(i, 1)
        this.bytes -= part.size
        if (queue === this.control) this.controlBytes -= part.size
      }
    }
  }
  pump() {
    if (this.closed) return
    clearTimeout(this.timer)
    const priority = this.control.length > 0
    if (!priority && !this.data.length) return
    const now = Date.now(), wait = Math.max(0, this.last + 5 - now,
      priority ? 0 : this.lastData + 13 - now)
    if (wait > 0) { this.timer = setTimeout(() => this.pump(), wait); return }
    const part = (priority ? this.control : this.data).shift()
    this.bytes -= part.size
    if (priority) this.controlBytes -= part.size
    this.last = now
    if (!priority) this.lastData = now
    try { this.socket.send(part.raw) }
    catch { this.failed(); return }
    this.pump()
  }
  close() {
    this.closed = true
    clearTimeout(this.timer)
    this.data.length = this.control.length = 0
    this.bytes = this.controlBytes = 0
  }
}
