import { OPERATION_METHODS, OPERATION_READ_METHODS, validateOperationParams } from './operations.js'
import { validateProjectExport } from './project-files.js'
import { validateAvatarExport } from './agent-avatars.js'
export { OPERATION_METHODS, OPERATION_READ_METHODS, validateOperationParams } from './operations.js'
export * from './tasks.js'
export * from './task-settings.js'
export * from './models.js'
export * from './model-info.js'
export * from './messages.js'
export * from './attention.js'
export * from './artifacts.js'
export * from './agent-directory.js'
export * from './execution.js'
export * from './goals.js'
export * from './agent-profiles.js'
export * from './agent-memory.js'
export * from './agent-commitments.js'
export * from './project-files.js'
export * from './groups.js'
export * from './collaboration.js'
export * from './plugins.js'
export * from './schedules.js'
export * from './agent-avatars.js'
export * from './agent-capabilities.js'
export * from './history-actions.js'
export * from './agent-memory-review.js'
export * from './agent-library.js'
export * from './agent-reminders.js'
export * from './agent-lifecycle.js'
export * from './agent-import.js'
export * from './shared-owner.js'
export * from './agent-appearance.js'
export * from './scopes.js'
export { normalizeCapabilities, hasOperation } from './capabilities.js'
export { REJECTION_CODES, isDefinitiveReceiptRejection } from './receipts.js'
export const VERSION = 1
export const LIMITS = Object.freeze({
  frame: 262144,
  message: 4194304,
  pending: 64,
  bytes: 8388608,
  controlPending: 2,
  controlBytes: 65536,
  file: 26214400
})
export const METHODS = Object.freeze([
  'catalog.get',
  'agent.list',
  'agent.history',
  'agent.message.send',
  'code.list',
  'code.history',
  'code.create',
  'code.turn.start',
  'execution.stop',
  'request.get',
  'approval.list',
  'approval.prepare',
  'approval.resolve',
  'input.resolve',
  'attachment.receive',
  'attachment.export',
  ...OPERATION_METHODS
])
export const READ_METHODS = new Set([
  'catalog.get',
  'agent.list',
  'agent.history',
  'code.list',
  'code.history',
  'request.get',
  'approval.list',
  ...OPERATION_READ_METHODS
])
export const KINDS = new Set([
  'hello',
  'link.open',
  'invoke',
  'result',
  'subscribe',
  'event',
  'ack',
  'resync_required',
  'fragment',
  'error',
  'ping',
  'pong'
])
export function utf8Size(value) {
  let size = 0
  for (const char of value) {
    const n = char.codePointAt(0)
    size += n <= 0x7f ? 1 : n <= 0x7ff ? 2 : n <= 0xffff ? 3 : 4
  }
  return size
}
export function canonical(value) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean')
    return JSON.stringify(value)
  if (typeof value === 'number' && Number.isFinite(value))
    return JSON.stringify(value)
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']'
  if (value && typeof value === 'object')
    return (
      '{' +
      Object.keys(value)
        .sort()
        .map((k) => JSON.stringify(k) + ':' + canonical(value[k]))
        .join(',') +
      '}'
    )
  throw new Error('INVALID_VALUE')
}
export function parseFrame(raw) {
  if (typeof raw !== 'string' || utf8Size(raw) > LIMITS.frame)
    throw new Error('FRAME_LIMIT')
  const f = JSON.parse(raw)
  if (
    !f ||
    f.v !== VERSION ||
    !KINDS.has(f.kind) ||
    (f.id !== undefined && !validId(f.id)) ||
    (f.dst !== undefined && !validId(f.dst)) ||
    (f.src !== undefined && !validId(f.src))
  )
    throw new Error('PROTOCOL_ERROR')
  return f
}
export function validId(id) {
  return typeof id === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(id)
}
export function validateCall(call) {
  if (
    !call ||
    !METHODS.includes(call.method) ||
    !validId(call.requestId) ||
    !Number.isSafeInteger(call.expiresAt) ||
    !call.params ||
    typeof call.params !== 'object' ||
    Array.isArray(call.params)
  )
    throw new Error('INVALID_CALL')
  if (OPERATION_METHODS.includes(call.method)) validateOperationParams(call.method, call.params)
  if (call.method === 'attachment.export' && Object.hasOwn(call.params, 'avatarRevision')) validateAvatarExport(call.params)
  if (call.method === 'attachment.export' && ['projectId', 'fileRef', 'revision'].some((key) => Object.hasOwn(call.params, key)))
    validateProjectExport(call.params)
  if (utf8Size(canonical(call)) > LIMITS.message)
    throw new Error('MESSAGE_LIMIT')
  return call
}
export function encodeFrames(frame) {
  const raw = JSON.stringify(frame)
  if (utf8Size(raw) <= LIMITS.frame) return [raw]
  if (utf8Size(raw) > LIMITS.message || !validId(frame.id))
    throw new Error('MESSAGE_LIMIT')
  // Split by code points, never split surrogate pairs; account for JSON escaping.
  const parts = []
  let part = '',
    size = 0
  for (const char of raw) {
    const n = utf8Size(JSON.stringify(char)) - 2
    if (size + n > 192000) {
      parts.push(part)
      part = ''
      size = 0
    }
    part += char
    size += n
  }
  if (part) parts.push(part)
  return parts.map((data, index) =>
    JSON.stringify({
      v: VERSION,
      kind: 'fragment',
      id: frame.id,
      dst: frame.dst,
      src: frame.src,
      payload: { index, total: parts.length, data }
    })
  )
}
export class Reassembler {
  constructor(now = Date.now, budget) {
    this.now = now
    this.budget = budget
    this.entries = new Map()
    this.bytes = 0
  }
  clear() {
    for (const e of this.entries.values()) e.reservation?.release()
    this.entries.clear()
    this.bytes = 0
  }
  prune() {
    for (const [key, e] of this.entries)
      if (this.now() - e.at > 30000) {
        e.reservation?.release()
        this.bytes -= e.bytes
        this.entries.delete(key)
      }
  }
  accept(frame) {
    this.prune()
    if (frame.kind !== 'fragment') return frame
    const p = frame.payload,
      key = frame.src + ':' + frame.id
    if (
      !p ||
      !Number.isInteger(p.index) ||
      !Number.isInteger(p.total) ||
      p.total < 1 ||
      p.total > 128 ||
      p.index < 0 ||
      p.index >= p.total ||
      typeof p.data !== 'string'
    )
      throw new Error('BAD_FRAGMENT')
    let e = this.entries.get(key)
    if (!e) {
      if (this.entries.size >= 64) throw new Error('BACKPRESSURE')
      e = { parts: new Map(), bytes: 0, total: p.total, at: this.now(), reservation: this.budget?.beginAssembly(frame.src ?? '') }
      this.entries.set(key, e)
    }
    if (e.total !== p.total) throw new Error('BAD_FRAGMENT')
    if (e.parts.has(p.index)) {
      if (e.parts.get(p.index) !== p.data) throw new Error('BAD_FRAGMENT')
      return null
    }
    const size = utf8Size(p.data)
    if (e.bytes + size > LIMITS.message || this.bytes + size > LIMITS.bytes)
      throw new Error('BACKPRESSURE')
    try { e.reservation?.add(size) }
    catch (error) {
      e.reservation?.release(); this.bytes -= e.bytes; this.entries.delete(key)
      throw error
    }
    e.parts.set(p.index, p.data)
    e.bytes += size
    this.bytes += size
    if (e.parts.size !== e.total) return null
    const raw = Array.from({ length: e.total }, (_, i) => e.parts.get(i)).join(
      ''
    )
    this.bytes -= e.bytes
    e.reservation?.release()
    this.entries.delete(key)
    const result = JSON.parse(raw)
    if (
      result.v !== VERSION ||
      !KINDS.has(result.kind) ||
      result.kind === 'fragment' ||
      result.id !== frame.id ||
      result.dst !== frame.dst
    )
      throw new Error('BAD_FRAGMENT')
    // The authenticated relay source wins over any source in the inner frame.
    result.src = frame.src
    return result
  }
}
export class RemoteError extends Error {
  constructor(code, uncertain = false) {
    super(code)
    this.code = code
    this.uncertain = uncertain
  }
}
export { RemoteClient } from './client.js'
export { RemoteApi } from './api.js'
export { ShareClient, SharedReassembler, validateShareLease, SHARED_READ_METHODS, SHARED_WRITE_METHODS } from './shared-client.js'
export { RequestBudget } from './request-budget.js'
export { validateSharedOwnerParams } from './shared-owner.js'
export { validSourceTurnId, validateSourceContentParams } from './source-content.js'
