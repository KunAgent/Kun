import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface SearchCoverage {
  native: 'scanning' | 'complete' | 'unavailable'
  source: 'not_applicable' | 'pending' | 'scanning' | 'complete' | 'disabled' | 'missing' | 'changed' | 'partial' | 'unavailable'
  referenceId?: string
}
export interface MessageMatch {
  resource: ResourceRef
  messageId: string
  turnId?: string
  sourceHistoryOrder?: { referenceId: string; turnIndex: number; itemIndex: number }
  historyVersion: string
  kind: string
  snippet: string
  role?: string
  createdAt: string
}
export interface MessageContent {
  field: string
  text: string
  offset: number
  nextOffset?: number
  totalChars: number
}
export interface MessageResult {
  resource: ResourceRef
  messageId: string
  turnId?: string
  historyVersion: string
  message?: Record<string, unknown>
  content?: MessageContent
}
export interface MessageParams {
  'message.search': PageParams & { resource: ResourceRef; query: string }
  'message.get': ({ resource: { kind: 'code'; id: string }; turnId: string } |
    { resource: { kind: 'agent'; id: string }; turnId?: never }) & {
    messageId: string
    historyVersion: string
    contentOffset?: number
    maxChars?: number
  }
}
export interface MessageResults {
  'message.search': RemotePage<MessageMatch, 'messages'> & { complete?: boolean; coverage?: SearchCoverage }
  'message.get': MessageResult
}
export const MESSAGE_METHODS: readonly (keyof MessageParams)[]
export const MESSAGE_READ_METHODS: ReadonlySet<keyof MessageParams>
export function validateMessageParams<M extends keyof MessageParams>(method: M, params: unknown): MessageParams[M]
