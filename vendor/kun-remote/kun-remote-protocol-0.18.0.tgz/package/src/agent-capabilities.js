import { check, object, id, page } from './validation.js'

export const AGENT_CAPABILITY_METHODS = Object.freeze(['agent.skills.list', 'agent.connections.list'])
export const AGENT_CAPABILITY_READ_METHODS = new Set(AGENT_CAPABILITY_METHODS)
export function validateAgentCapabilityParams(method, p) {
  check(AGENT_CAPABILITY_METHODS.includes(method))
  object(p, ['agentId'], ['cursor', 'limit']); page(p, 20); id(p.agentId)
}
