import { canonical, Reassembler } from './index.js'
import { validateSharedFrame } from './shared-validation.js'

/** A shared envelope is relay-authored for every fragment, including the first one. */
export class SharedReassembler {
  constructor(lease, now = Date.now, budget) { this.lease = lease; this.now = now; this.inner = new Reassembler(now, budget); this.claims = new Map() }
  clear() { this.inner.clear(); this.claims.clear() }
  accept(frame) {
    const now = this.now()
    for (const [key, value] of this.claims) if (now - value.at > 30000) this.claims.delete(key)
    if (!frame.src && !frame.shared && ['hello', 'pong', 'error'].includes(frame.kind)) return frame
    const shared = validateSharedFrame(frame, this.lease())
    if (frame.kind !== 'fragment') return { ...frame, shared }
    const key = frame.src + ':' + frame.id, fingerprint = canonical({ shared, dst: frame.dst }), existing = this.claims.get(key)
    if (existing && existing.fingerprint !== fingerprint) throw new Error('MIXED_SHARED_FRAGMENT_AUTHORITY')
    if (!existing) {
      if (this.claims.size >= 64) throw new Error('BACKPRESSURE')
      this.claims.set(key, { fingerprint, at: now })
    }
    const completed = this.inner.accept(frame)
    if (!completed) return null
    this.claims.delete(key)
    // Never trust inner.src/shared, even when all other inner fields were signed by nobody.
    completed.src = frame.src; completed.dst = frame.dst; completed.shared = shared
    validateSharedFrame(completed, this.lease())
    return completed
  }
}
