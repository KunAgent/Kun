import type { RemoteCapabilities } from './capabilities.js'
import type { RemoteModelInfo } from './model-info.js'
export type RemoteCredentialMode = 'native-login' | 'provider' | 'kun-gateway'
export type RemoteReasoningEffort = 'auto' | 'off' | 'low' | 'medium' | 'high' | 'max'
export interface RemoteModelRoute {
  model: string
  harnessId?: string
  credentialMode?: RemoteCredentialMode
  providerId?: string
  /** Echoes the chosen agent route's `routeKey` exactly; never constructed by a controller. */
  routeKey?: string
  /** Sent only to a host advertising `REASONING_EFFORT_CAPABILITY`; absent means the host default. */
  reasoningEffort?: RemoteReasoningEffort
}
/** Reasoning levels one model accepts on one route; `defaultEffort` is one of `efforts`. */
export interface RemoteModelProfile {
  efforts: RemoteReasoningEffort[]
  defaultEffort?: RemoteReasoningEffort
  note?: string
}
export interface RemoteAgentRoute {
  credentialMode?: RemoteCredentialMode
  providerId?: string
  /**
   * Opaque host identity for a route the other fields cannot name, such as a Kun gateway alias. Absent on
   * routes matched by `credentialMode`/`providerId`. Never a gateway binding, connection list or credential.
   */
  routeKey?: string
  label: string
  models: string[]
  defaultModel?: string
  /** Keyed by a listed model; meaningful only with `REASONING_EFFORT_CAPABILITY`. */
  profiles?: Record<string, RemoteModelProfile>
  /** Keyed by a listed model; meaningful only with `MODEL_INFO_CAPABILITY`. */
  modelInfo?: Record<string, RemoteModelInfo>
}
export interface RemoteCodeAgent { id: string; name: string; routes: RemoteAgentRoute[] }
export const REASONING_EFFORTS: readonly RemoteReasoningEffort[]
export const REASONING_EFFORT_CAPABILITY: 'code.reasoningEffort'
export function hasReasoningEffort(catalog: RemoteCapabilities | null | undefined): boolean | undefined
export function validateRouteKey(value: unknown): string
export function validateModelRoute(value: unknown): RemoteModelRoute
export function validateModelProfiles<T extends RemoteAgentRoute>(route: T): T
