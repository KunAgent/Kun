import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export type CommitmentStatus = 'open' | 'in_progress' | 'waiting' | 'blocked' | 'completed' | 'cancelled'
export type AcceptanceEvidence = { summary: string; reference?: string }
export type CommitmentFields = { objective?: string; acceptance?: string; deadline?: string | null; nextCheckAt?: string | null; waitingOn?: string | null }
export type CommitmentAct = { agentId: string } & (
  ({ action: 'create'; roomId: string; sourceMessageId: string; objective: string; acceptance: string } & CommitmentFields) |
  ({ action: 'update'; commitmentId: string; expectedRevision: number } & AtLeastOne<CommitmentFields & {
    status?: CommitmentStatus; acceptanceEvidence?: AcceptanceEvidence[]
  }>) |
  { action: 'cancel'; commitmentId: string; expectedRevision: number }
)
export interface AgentCommitment {
  schemaVersion: 1
  id: string
  participantAgentId: string
  revision: number
  sourceRoomId: string
  sourceMessageId: string
  objective: string
  acceptance: string
  deadline: string | null
  nextCheckAt: string | null
  waitingOn: string | null
  status: CommitmentStatus
  links: { kind: 'thread' | 'goal' | 'handoff' | 'task' | 'workbench_link'; id: string }[]
  acceptanceEvidence: AcceptanceEvidence[]
  results: { summary: string; artifactId?: string; version?: number }[]
  authorization: { kind: 'user_message'; messageRevision: number; text: string; capturedAt: string }
  createdAt: string
  updatedAt: string
  finishedAt?: string
}
export interface AgentCommitmentParams {
  'agent.commitments.list': PageParams & { agentId: string; status?: CommitmentStatus; search?: string }
  'agent.commitments.act': CommitmentAct
}
export interface AgentCommitmentResults {
  'agent.commitments.list': RemotePage<AgentCommitment, 'commitments'>
  'agent.commitments.act': { commitment: AgentCommitment }
}
export const AGENT_COMMITMENT_METHODS: readonly (keyof AgentCommitmentParams)[]
export const AGENT_COMMITMENT_READ_METHODS: ReadonlySet<keyof AgentCommitmentParams>
export function validateAgentCommitmentParams<M extends keyof AgentCommitmentParams>(method: M, params: unknown): AgentCommitmentParams[M]
