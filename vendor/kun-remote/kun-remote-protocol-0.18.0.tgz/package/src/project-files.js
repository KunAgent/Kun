import { object, id, oneOf, optional, page, revision, string } from './validation.js'

export const PROJECT_FILES_METHODS = Object.freeze(["project.files.list", "project.files.search", "file.preview"])
export const PROJECT_FILES_READ_METHODS = new Set(["project.files.list", "project.files.search", "file.preview"])
export function validateProjectFilesParams(method, p) {
  switch (method) {
    case 'project.files.list':
      object(p, ['projectId'], ['parentRef', 'cursor', 'limit']); id(p.projectId); optional(p, 'parentRef', id); page(p); break
    case 'project.files.search':
      object(p, ['projectId', 'query'], ['mode', 'cursor', 'limit']); id(p.projectId); string(p.query, 200)
      optional(p, 'mode', (v) => oneOf(v, ['name', 'content'])); page(p); break
    case 'file.preview':
      object(p, ['projectId', 'fileRef', 'expectedRevision']); id(p.projectId); id(p.fileRef); revision(p.expectedRevision, 'file'); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}

export function validateProjectExport(params) {
  object(params, ['projectId', 'fileRef', 'revision'])
  id(params.projectId); id(params.fileRef); revision(params.revision, 'file')
  return params
}
