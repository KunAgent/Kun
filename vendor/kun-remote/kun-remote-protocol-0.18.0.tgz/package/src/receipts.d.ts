export type RejectionCode = 'REVISION_CONFLICT' | 'MODEL_NOT_AVAILABLE' | 'AGENT_NOT_AVAILABLE' |
  'NOT_FOUND' | 'TASK_BUSY' | 'INVALID_REQUEST' | 'NOT_A_CODE_TASK' | 'ATTACHMENT_NOT_CONFIRMED'
export const REJECTION_CODES: readonly RejectionCode[]
export interface RemoteReceipt {
  requestId: string
  method: string
  fingerprint: string
  params?: Record<string, unknown>
  status: 'accepted' | 'applied' | 'reconciliation_required'
  result?: unknown
  createdAt: number
  error?: { code: RejectionCode; definitive: true }
}
export function isDefinitiveReceiptRejection(receipt: unknown): receipt is {
  status: 'reconciliation_required'
  error: { code: RejectionCode; definitive: true }
}
