import { check, object, id, integer, oneOf } from './validation.js'
export const AVATAR_BUILTINS = Object.freeze(['coordinator', 'coder', 'reviewer', 'detective', 'designer', 'architect', 'scientist', 'security', 'writer', 'researcher', 'data', 'operations', 'astronaut', 'pilot', 'navigator', 'librarian', 'musician', 'gardener', 'chef', 'medic', 'photographer', 'athlete', 'explorer', 'storyteller', 'magician', 'night-thinker', 'barista', 'maker', 'courier', 'strategist'])

export const AGENT_AVATAR_METHODS = Object.freeze(['agent.avatar.get', 'agent.avatar.update'])
export const AGENT_AVATAR_READ_METHODS = new Set(['agent.avatar.get'])
export function validateAgentAvatarParams(method, p) {
  check(AGENT_AVATAR_METHODS.includes(method))
  if (method === 'agent.avatar.get') object(p, ['agentId'])
  else {
    object(p, ['agentId', 'expectedRevision', 'source']); integer(p.expectedRevision)
    oneOf(p.source?.kind, ['builtin', 'received', 'clear'])
    object(p.source, ['kind', ...(p.source.kind === 'builtin' ? ['id'] : p.source.kind === 'received' ? ['attachmentId'] : [])])
    if (p.source.kind === 'builtin') oneOf(p.source.id, AVATAR_BUILTINS)
    if (p.source.kind === 'received') check(typeof p.source.attachmentId === 'string' && /^att_[a-f0-9]{24}$/.test(p.source.attachmentId))
  }
  id(p.agentId)
}
export function validateAvatarExport(p) {
  object(p, ['agentId', 'avatarRevision']); id(p.agentId); integer(p.avatarRevision)
  return p
}
