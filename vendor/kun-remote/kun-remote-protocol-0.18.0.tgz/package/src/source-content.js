import { check, object, id, string, optional, integer } from './validation.js'
export function validSourceTurnId(value) {
  return typeof value === 'string' && value.length <= 800 && /^(?:codex|claude-code|opencode):[A-Za-z0-9_-]{1,256}:[A-Za-z0-9_.:-]{1,512}$/.test(value)
}
export function validateSourceContentParams(p) {
  object(p, ['resource', 'referenceId', 'historyVersion', 'turnId', 'messageId'], ['cursor', 'maxChars'])
  object(p.resource, ['kind', 'id']); check(p.resource.kind === 'code'); id(p.resource.id)
  id(p.referenceId); string(p.historyVersion, 256)
  check(validSourceTurnId(p.turnId))
  check(typeof p.messageId === 'string' && p.messageId.length <= 832 && p.messageId.startsWith(p.turnId + ':item:') &&
    /^(0|[1-9][0-9]{0,14})$/.test(p.messageId.slice(p.turnId.length + 6)))
  optional(p, 'cursor', value => string(value, 2048)); optional(p, 'maxChars', value => integer(value, 1, 16384))
  return p
}

export const SOURCE_CONTENT_METHODS = Object.freeze(['message.source.get'])
export const SOURCE_CONTENT_READ_METHODS = new Set(SOURCE_CONTENT_METHODS)
