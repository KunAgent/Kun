import { check, object, id, integer, oneOf, optional, revision, string } from './validation.js'

export const GOAL_METHODS = Object.freeze(["goal.get", "goal.clear", "goal.update"])
export const GOAL_READ_METHODS = new Set(["goal.get"])
export function validateGoalParams(method, p) {
  switch (method) {
    case 'goal.get':
      object(p, ['threadId']); id(p.threadId); break
    case 'goal.clear':
      object(p, ['threadId', 'expectedRevision']); id(p.threadId); revision(p.expectedRevision, 'goal'); break
    case 'goal.update':
      object(p, ['threadId', 'expectedRevision'], ['objective', 'status', 'tokenBudget'])
      id(p.threadId); revision(p.expectedRevision, 'goal')
      check(['objective', 'status', 'tokenBudget'].some((key) => Object.hasOwn(p, key)))
      optional(p, 'objective', (v) => string(v, 4000))
      optional(p, 'status', (v) => oneOf(v, ['active', 'paused', 'complete']))
      optional(p, 'tokenBudget', (v) => { if (v !== null) integer(v, 1) }); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
