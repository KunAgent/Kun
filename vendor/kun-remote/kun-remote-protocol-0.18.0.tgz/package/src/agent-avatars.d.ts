import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export const AVATAR_BUILTINS: readonly ['coordinator', 'coder', 'reviewer', 'detective', 'designer', 'architect', 'scientist', 'security', 'writer', 'researcher', 'data', 'operations', 'astronaut', 'pilot', 'navigator', 'librarian', 'musician', 'gardener', 'chef', 'medic', 'photographer', 'athlete', 'explorer', 'storyteller', 'magician', 'night-thinker', 'barista', 'maker', 'courier', 'strategist']
export type BuiltinAvatarId = typeof AVATAR_BUILTINS[number]
export type RemoteAgentAvatar = { kind: 'builtin'; id: BuiltinAvatarId } | { kind: 'uploaded'; attachmentId: string } |
  { kind: 'harness'; harnessId: 'codex' | 'claude-code' | 'opencode' | 'codemaker' } |
  { kind: 'composed'; version: 1; parts: { color: string; face: string; bg: string; headwear?: string; glasses?: string; outfit?: string; prop?: string } }
export interface AvatarState { agentId: string; revision: number; avatar: RemoteAgentAvatar | null }
export interface AgentAvatarResult extends AvatarState {
  builtinChoices: BuiltinAvatarId[]
  editable: boolean
  uploadAvailable: boolean
  rendering: 'unsupported_composed' | 'image' | 'unavailable' | 'reference'
  uploadedImage?: { mimeType: 'image/jpeg'; size: number; sha256: string; width: 128; height: 128 }
}
export type AvatarExportParams = { agentId: string; avatarRevision: number }
export function validateAvatarExport<T extends AvatarExportParams>(params: T): T
export interface AgentAvatarParams {
  'agent.avatar.get': { agentId: string }
  'agent.avatar.update': { agentId: string; expectedRevision: number; source:
    { kind: 'builtin'; id: BuiltinAvatarId } | { kind: 'received'; attachmentId: string } | { kind: 'clear' } }
}
export interface AgentAvatarResults {
  'agent.avatar.get': AgentAvatarResult
  'agent.avatar.update': AvatarState
}
export const AGENT_AVATAR_METHODS: readonly (keyof AgentAvatarParams)[]
export const AGENT_AVATAR_READ_METHODS: ReadonlySet<keyof AgentAvatarParams>
export function validateAgentAvatarParams<M extends keyof AgentAvatarParams>(method: M, params: unknown): void
