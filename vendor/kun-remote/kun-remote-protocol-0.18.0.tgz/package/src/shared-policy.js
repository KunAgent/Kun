import { RemoteError, validId, validateCall } from './index.js'
import { SharedReassembler } from './shared-frames.js'
import { sharedAuthorityKey, validateShareLease, validateSharedFrame } from './shared-validation.js'
export const SHARED_READ_METHODS = new Set(['catalog.get', 'code.history', 'message.get', 'message.source.get', 'message.search', 'execution.queue.list', 'goal.get', 'request.get', 'artifact.list', 'attachment.export'])
export const SHARED_WRITE_METHODS = new Set(['code.turn.start', 'execution.queue.enqueue', 'execution.queue.update', 'execution.queue.remove', 'execution.stop', 'attachment.receive'])
export class SharedPolicy {
  constructor(deps) {
    const e = deps.expected
    if (!e || !['host', 'guest'].includes(e.role) || !['shareId', 'accountId', 'deviceId', 'hostDeviceId', 'resourceHandle'].every(key => validId(e[key])) ||
      e.role === 'guest' && (!validId(e.memberId) || !Number.isSafeInteger(e.memberVersion) || e.memberVersion < 1)) throw new Error('INVALID_SHARED_BINDING')
    this.deps = deps; this.expected = Object.freeze({ ...deps.expected }); this.current = null
    this.shareVersion = deps.expected.shareVersion ?? 1; this.memberVersion = deps.expected.memberVersion ?? 1
    this.assembly = new SharedReassembler(() => this.current, Date.now, deps.budget)
    const origin = new URL(deps.origin)
    if (origin.username || origin.password || !['https:', 'http:'].includes(origin.protocol) || origin.pathname !== '/' || origin.search || origin.hash)
      throw new Error('INVALID_SHARED_ORIGIN')
    this.origin = origin
  }
  ticket(ticket) {
    const url = new URL(ticket.url)
    if (url.protocol !== (this.origin.protocol === 'https:' ? 'wss:' : 'ws:') || url.host !== this.origin.host ||
      url.pathname !== '/api/remote/v1/shares/' + this.expected.shareId + '/ws' || url.search || url.hash || url.username || url.password)
      throw new Error('INVALID_SHARED_TICKET_URL')
  }
  part(frame) {
    if (['hello', 'pong'].includes(frame.kind) || frame.kind === 'error' && !frame.src) {
      if (frame.src !== undefined || frame.dst !== undefined || frame.shared !== undefined || frame.kind === 'hello' && this.current)
        throw new Error('INVALID_SHARED_CONTROL')
      return
    }
    validateSharedFrame(frame, this.current)
  }
  frame(frame) { this.part(frame) }
  lease(value) {
    const lease = validateShareLease(value, { ...this.expected, shareVersion: this.shareVersion, memberVersion: this.memberVersion })
    this.shareVersion = Math.max(this.shareVersion, lease.shareVersion)
    if (lease.memberVersion) this.memberVersion = Math.max(this.memberVersion, lease.memberVersion)
    return lease
  }
  notify(value) { try { this.deps.lease?.(value) } catch { try { this.deps.diagnostic?.('APPLICATION_CALLBACK_FAILED') } catch {} } }
  hello(frame) {
    if (frame.payload?.version !== 1 || frame.payload.leaseExpiresAt !== frame.payload.share?.expiresAt) throw new RemoteError('INVALID_SHARED_LEASE')
    this.current = this.lease(frame.payload.share)
    this.notify(this.current)
    return this.current.expiresAt
  }
  renew(value) {
    if (value?.ok !== true) throw new RemoteError('INVALID_SHARED_LEASE')
    const next = this.lease(value.share)
    if (!this.current || sharedAuthorityKey(next) !== sharedAuthorityKey(this.current)) throw new RemoteError('SHARED_AUTHORITY_CHANGED')
    this.current = next; this.notify(next)
    return next.expiresAt
  }
  disconnected() { if (this.current) { this.current = null; this.notify(null) } }
  outgoing(frame) {
    const lease = this.current
    if (!lease || lease.expiresAt <= Date.now()) throw new RemoteError('DEVICE_OFFLINE')
    if (['ack', 'ping'].includes(frame.kind)) return { kind: frame.kind }
    if (!validId(frame.dst) || !lease.peers.some(peer => peer.deviceId === frame.dst)) throw new RemoteError('SHARED_PEER_UNAVAILABLE')
    const allowed = lease.role === 'guest' ? ['invoke', 'subscribe'] : ['result', 'error', 'event', 'resync_required']
    if (!allowed.includes(frame.kind)) throw new RemoteError('SHARED_OPERATION_FORBIDDEN')
    if (frame.kind === 'invoke') this.call(frame.dst, frame.payload)
    // All authority is added by ShareRelayDO; callers cannot send their own shared envelope.
    return { kind: frame.kind, ...(frame.id ? { id: frame.id } : {}), dst: frame.dst, payload: frame.payload }
  }
  call(dst, call) {
    const lease = this.current
    if (!lease) throw new RemoteError('DEVICE_OFFLINE')
    if (lease.role !== 'guest' || dst !== lease.hostDeviceId || !SHARED_READ_METHODS.has(call?.method) &&
      !(lease.mode === 'write' && SHARED_WRITE_METHODS.has(call?.method))) throw new RemoteError('SHARED_OPERATION_FORBIDDEN')
    validateCall(call)
  }
}
