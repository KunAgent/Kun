import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface RemoteArtifact {
  id: string
  resource: ResourceRef
  name: string
  mimeType: string
  size: number
  available: boolean
  version?: number
  threadId?: string
}
export interface ArtifactParams {
  'artifact.list': PageParams & { resource: ResourceRef }
}
export interface ArtifactResults {
  'artifact.list': RemotePage<RemoteArtifact, 'artifacts'>
}
export const ARTIFACT_METHODS: readonly (keyof ArtifactParams)[]
export const ARTIFACT_READ_METHODS: ReadonlySet<keyof ArtifactParams>
export function validateArtifactParams<M extends keyof ArtifactParams>(method: M, params: unknown): ArtifactParams[M]
