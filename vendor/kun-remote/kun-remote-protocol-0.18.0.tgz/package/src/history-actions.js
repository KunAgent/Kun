import { check, id, integer, object, optional, string } from './validation.js'
export const HISTORY_METHODS = ['code.fork', 'code.rewind.preview', 'code.rewind.commit']
// Preview persists a device-bound token and is reconciled through the ordinary receipt path.
export function validateHistoryParams(method, p) {
  if (method === 'code.rewind.commit') {
    object(p, ['threadId', 'token']); id(p.threadId)
    check(typeof p.token === 'string' && /^[a-f0-9]{64}$/.test(p.token))
    return p
  }
  check(method === 'code.fork' || method === 'code.rewind.preview')
  object(p, ['threadId', 'turnId', 'expectedRevision', 'historyVersion'], method === 'code.fork' ? ['title', 'beforeTurn'] : [])
  id(p.threadId); id(p.turnId); string(p.historyVersion, 256)
  check(typeof p.expectedRevision === 'string' && /^thread-v1:(0|[1-9][0-9]*)$/.test(p.expectedRevision))
  integer(Number(p.expectedRevision.slice(10)))
  optional(p, 'title', v => string(v, 160))
  optional(p, 'beforeTurn', v => check(typeof v === 'boolean'))
  return p
}
