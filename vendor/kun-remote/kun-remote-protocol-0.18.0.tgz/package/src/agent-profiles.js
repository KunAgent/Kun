import { check, object, id, integer } from './validation.js'
import { profile, PROFILE_FIELDS } from './profile-validation.js'

export const AGENT_PROFILE_METHODS = Object.freeze(["agent.get", "agent.create", "agent.update", "agent.archive", "agent.restore"])
export const AGENT_PROFILE_READ_METHODS = new Set(["agent.get"])
export function validateAgentProfileParams(method, p) {
  switch (method) {
    case 'agent.get':
      object(p, ['agentId']); id(p.agentId); break
    case 'agent.create':
      object(p, ['name'], PROFILE_FIELDS.filter((field) => field !== 'name')); profile(p); break
    case 'agent.update':
      object(p, ['agentId', 'expectedRevision'], PROFILE_FIELDS)
      id(p.agentId); integer(p.expectedRevision); profile(p)
      check(PROFILE_FIELDS.some((key) => Object.hasOwn(p, key))); break
    case 'agent.archive':
    case 'agent.restore':
      object(p, ['agentId', 'expectedRevision']); id(p.agentId); integer(p.expectedRevision); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
