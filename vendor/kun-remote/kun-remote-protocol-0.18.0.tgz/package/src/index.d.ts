import type { OperationCall, RemoteMethod, RemoteResults } from './operations.js'
export * from './tasks.js'
export * from './task-settings.js'
export * from './messages.js'
export * from './attention.js'
export * from './artifacts.js'
export * from './agent-directory.js'
export * from './execution.js'
export * from './goals.js'
export * from './agent-profiles.js'
export * from './agent-memory.js'
export * from './agent-commitments.js'
export * from './project-files.js'
export * from './groups.js'
export * from './collaboration.js'
export * from './plugins.js'
export * from './schedules.js'
export * from './agent-avatars.js'
export * from './agent-capabilities.js'
export * from './history-actions.js'
export * from './agent-memory-review.js'
export * from './agent-library.js'
export * from './agent-reminders.js'
export * from './agent-lifecycle.js'
export * from './agent-import.js'
export * from './shared-owner.js'
export * from './agent-appearance.js'
export * from './values.js'
export * from './models.js'
export * from './model-info.js'
export * from './scopes.js'
export * from './operations.js'
export * from './attachments.js'
export * from './capabilities.js'
export * from './receipts.js'
export * from './shared-client.js'
export * from './shared-owner.js'
export * from './source-content.js'
export const VERSION: 1
export const LIMITS: Readonly<{
  frame: number
  message: number
  pending: number
  bytes: number
  controlPending: number
  controlBytes: number
  file: number
}>
export const METHODS: readonly string[]
export const READ_METHODS: Set<string>
export const KINDS: Set<string>
export interface Frame {
  v?: number
  kind: string
  id?: string
  src?: string
  dst?: string
  payload?: any
}
export interface Call {
  method: string
  requestId: string
  expiresAt: number
  params: Record<string, unknown>
}
export interface Socket {
  onopen: (() => void) | null
  onmessage: ((event: { data: unknown }) => void) | null
  onerror: ((error: unknown) => void) | null
  onclose: ((event?: { code?: number }) => void) | null
  bufferedAmount?: number
  send(data: string): void
  close(): void
}
export interface ClientDependencies {
  budget?: RequestBudget
  ticket(signal?: AbortSignal): Promise<{ url: string; ticket: string }>
  renew(signal?: AbortSignal): Promise<unknown>
  socket(url: string, headers: Record<string, string>): Socket
  state?(online: boolean, reason?: string): void
  diagnostic?(code: string, details?: { attempt?: number; elapsedMs?: number }): void
  frame?(frame: Frame): void
}
export function canonical(value: unknown): string
export function utf8Size(value: string): number
export function parseFrame(raw: string): Frame
export function validId(id: unknown): id is string
export function validateCall(call: unknown): Call
export function encodeFrames(frame: Frame): string[]
export class Reassembler {
  constructor(now?: () => number, budget?: RequestBudget)
  clear(): void
  accept(frame: Frame): Frame | null
}
export class RemoteError extends Error {
  code: string
  uncertain: boolean
  constructor(code: string, uncertain?: boolean)
}
export class RemoteClient {
  online: boolean
  constructor(deps: ClientDependencies)
  start(): void
  reconnect(): void
  stop(): void
  send(frame: Frame): void
  invoke<M extends RemoteMethod>(dst: string, call: OperationCall<M>, timeout?: number): Promise<RemoteResults[M]>
  invoke<T = any>(dst: string, call: Call, timeout?: number): Promise<T>
}
export interface DeviceIdentity {
  id: string
  credential: string
}
export interface Device {
  id: string
  name: string
  role: 'host' | 'controller'
  platform: string
  enabled: boolean
  online: boolean | null
  version: number
}
export class RemoteApi {
  constructor(deps: {
    origin: string
    token(): Promise<string | null>
    identity(): Promise<DeviceIdentity>
    fetch?: typeof fetch
  })
  request<T = any>(
    path: string,
    method?: string,
    body?: any,
    raw?: boolean,
    signal?: AbortSignal
  ): Promise<T>
  ticket(signal?: AbortSignal): Promise<{ url: string; ticket: string }>
  renew(signal?: AbortSignal): Promise<unknown>
}
export class RequestBudget {
  reserve(host: string, bytes: number, control?: boolean): () => void
  beginAssembly(host: string): { add(bytes: number): void; release(): void }
}
