export interface SourceContentParams {
  resource: { kind: 'code'; id: string }; referenceId: string; historyVersion: string
  turnId: string; messageId: string; cursor?: string; maxChars?: number
}
export interface SourceContentResult {
  resource: { kind: 'code'; id: string }; referenceId: string; historyVersion: string; turnId: string; messageId: string
  content: { field: 'text' | 'arguments' | 'output'; text: string; offset: number; totalChars: number; nextOffset?: number }
  hasMore: boolean; nextCursor?: string
}
export function validSourceTurnId(value: unknown): value is string
export function validateSourceContentParams(params: unknown): SourceContentParams

export interface SourceContentOperationParams { 'message.source.get': SourceContentParams }
export interface SourceContentOperationResults { 'message.source.get': SourceContentResult }
export const SOURCE_CONTENT_METHODS: readonly (keyof SourceContentOperationParams)[]
export const SOURCE_CONTENT_READ_METHODS: ReadonlySet<keyof SourceContentOperationParams>
