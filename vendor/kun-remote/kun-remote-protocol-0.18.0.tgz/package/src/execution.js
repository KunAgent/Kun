import { object, id, page, revision, string, attachments } from './validation.js'

export const EXECUTION_METHODS = Object.freeze(["execution.queue.list", "execution.queue.enqueue", "execution.steer", "execution.queue.update", "execution.queue.remove", "execution.resume"])
export const EXECUTION_READ_METHODS = new Set(["execution.queue.list"])
export function validateExecutionParams(method, p) {
  switch (method) {
    case 'execution.queue.list':
      object(p, ['threadId'], ['cursor', 'limit']); id(p.threadId); page(p, 20); break
    case 'execution.queue.enqueue':
    case 'execution.steer':
      object(p, method === 'execution.steer' ? ['threadId', 'turnId', 'text'] : ['threadId', 'text'], ['attachmentIds'])
      id(p.threadId); if (method === 'execution.steer') id(p.turnId)
      string(p.text, 64000); attachments(p); break
    case 'execution.queue.update':
      object(p, ['threadId', 'turnId', 'expectedRevision', 'text'], ['attachmentIds'])
      id(p.threadId); id(p.turnId); revision(p.expectedRevision, 'queue'); string(p.text, 64000); attachments(p); break
    case 'execution.queue.remove':
      object(p, ['threadId', 'turnId', 'expectedRevision'])
      id(p.threadId); id(p.turnId); revision(p.expectedRevision, 'queue'); break
    case 'execution.resume':
      object(p, ['threadId', 'expectedRevision']); id(p.threadId); revision(p.expectedRevision, 'queue'); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
