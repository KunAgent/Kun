import { optional, object, string } from './validation.js'
export function modelRef(value) {
  if (value === null) return
  object(value, ['providerId', 'model'])
  string(value.providerId, 128); string(value.model, 256)
}
export function profile(value) {
  optional(value, 'name', (v) => string(v, 80))
  optional(value, 'title', (v) => string(v, 160, 0))
  optional(value, 'instructions', (v) => string(v, 8000, 0))
  optional(value, 'modelRef', modelRef); optional(value, 'fastModelRef', modelRef)
}
export const PROFILE_FIELDS = ['name', 'title', 'instructions', 'modelRef', 'fastModelRef']
