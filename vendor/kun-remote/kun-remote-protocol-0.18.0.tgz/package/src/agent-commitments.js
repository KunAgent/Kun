import { check, object, id, integer, oneOf, optional, page, string } from './validation.js'
import { work, evidence, WORK_FIELDS, WORK_STATUS } from './commitment-validation.js'

export const AGENT_COMMITMENT_METHODS = Object.freeze(["agent.commitments.list", "agent.commitments.act"])
export const AGENT_COMMITMENT_READ_METHODS = new Set(["agent.commitments.list"])
export function validateAgentCommitmentParams(method, p) {
  switch (method) {
    case 'agent.commitments.list':
      object(p, ['agentId'], ['cursor', 'limit', 'status', 'search']); id(p.agentId); page(p)
      optional(p, 'status', (v) => oneOf(v, WORK_STATUS)); optional(p, 'search', (v) => string(v, 200, 0)); break
    case 'agent.commitments.act':
      if (p?.action === 'create') {
        object(p, ['agentId', 'action', 'roomId', 'sourceMessageId', 'objective', 'acceptance'], WORK_FIELDS.filter((f) => !['objective', 'acceptance'].includes(f)))
        id(p.roomId); id(p.sourceMessageId)
      } else {
        object(p, ['agentId', 'action', 'commitmentId', 'expectedRevision'], p?.action === 'update' ? [...WORK_FIELDS, 'status', 'acceptanceEvidence'] : [])
        id(p.commitmentId); integer(p.expectedRevision); oneOf(p.action, ['update', 'cancel'])
        if (p.action === 'update') {
          check([...WORK_FIELDS, 'status', 'acceptanceEvidence'].some((key) => Object.hasOwn(p, key)))
          optional(p, 'status', (v) => oneOf(v, WORK_STATUS)); optional(p, 'acceptanceEvidence', evidence)
        }
      }
      id(p.agentId); work(p); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
