import type { RemoteCapabilities } from './capabilities.js'
import type { RemoteAgentRoute } from './models.js'
export type RemoteInputModality = 'text' | 'image'
/** `supported` lets the toggle turn on; `unknown` means the host never learned; `unsupported` means it does not. */
export type RemoteFastModeState = 'supported' | 'unknown' | 'unsupported'
export type RemoteServiceTier = 'priority'
/** What a host knows about one model on one route; an absent field is unknown, never a denial. */
export interface RemoteModelInfo {
  /** The model's own name as the desktop picker shows it; the model id stays the identity. */
  displayName?: string
  /** Known input kinds, distinct; `image` means the model reads images. */
  inputModalities?: RemoteInputModality[]
  /** Fast mode (the `priority` service tier) on this route; absent hides the toggle. */
  fastMode?: RemoteFastModeState
}
export const INPUT_MODALITIES: readonly RemoteInputModality[]
export const FAST_MODE_STATES: readonly RemoteFastModeState[]
export const SERVICE_TIERS: readonly RemoteServiceTier[]
export const MODEL_INFO_CAPABILITY: 'code.modelInfo'
export function hasModelInfo(catalog: RemoteCapabilities | null | undefined): boolean | undefined
export function validateServiceTier(value: unknown): RemoteServiceTier
export function validateModelInfo<T extends RemoteAgentRoute>(route: T): T
