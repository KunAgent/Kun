import { check, object, id, integer, optional, text as string, textPage as page, resource } from './validation.js'

export const MESSAGE_METHODS = Object.freeze(["message.search", "message.get"])
export const MESSAGE_READ_METHODS = new Set(["message.search", "message.get"])
export function validateMessageParams(method, params) {
  switch (method) {
    case 'message.search':
      object(params, ['resource', 'query'], ['cursor', 'limit'])
      resource(params.resource)
      string(params.query, 200)
      check(params.query.trim().length > 0)
      page(params)
      break
    case 'message.get':
      object(params, ['resource', 'messageId', 'historyVersion'], ['turnId', 'contentOffset', 'maxChars'])
      resource(params.resource)
      id(params.messageId)
      string(params.historyVersion, 256)
      if (params.resource.kind === 'code') id(params.turnId)
      else check(params.turnId === undefined)
      optional(params, 'contentOffset', (value) => integer(value, 0, Number.MAX_SAFE_INTEGER))
      optional(params, 'maxChars', (value) => integer(value, 1, 32000))
      break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return params
}
