export interface ShareMetadata {
  id: string; ownerAccountId: string; hostDeviceId: string; resourceHandle: string; version: number
  state: 'active' | 'closed' | 'expired'; expiresAt: number
}
export interface ShareMemberMetadata { id: string; accountId: string; mode: 'read' | 'write'; version: number; state: 'active' | 'revoked' }
export interface SharedTaskSummary { share: ShareMetadata; threadId: string; title: string; members?: ShareMemberMetadata[] }
export type SharedOwnerMutation =
  | { action: 'create'; threadId: string; expiresAt?: number }
  | { action: 'invite'; shareId: string; expectedVersion: number; invitationHash: string; mode: 'read' | 'write'; expiresAt?: number }
  | { action: 'member.update'; shareId: string; memberId: string; expectedVersion: number; mode: 'read' | 'write' }
  | { action: 'revoke'; shareId: string; memberId: string; expectedVersion: number }
  | { action: 'close'; shareId: string; expectedVersion: number }
export type SharedOwnerResult = { share: ShareMetadata; members?: ShareMemberMetadata[]; inviteId?: string; mode?: 'read' | 'write'; expiresAt?: number }
export function validateSharedOwnerParams(method: string, params: unknown): unknown

import type { PageParams } from './values.js'
export interface SharedOwnerParams { 'shares.list': PageParams & { threadId?: string }; 'shares.manage': SharedOwnerMutation }
export interface SharedOwnerResults { 'shares.list': { shares: SharedTaskSummary[]; hasMore: boolean; nextCursor?: string }; 'shares.manage': SharedOwnerResult }
export const SHARED_OWNER_METHODS: readonly (keyof SharedOwnerParams)[]
export const SHARED_OWNER_READ_METHODS: ReadonlySet<keyof SharedOwnerParams>
