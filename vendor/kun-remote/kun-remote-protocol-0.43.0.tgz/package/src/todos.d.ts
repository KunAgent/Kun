export type RemoteTodoStatus = 'pending' | 'in_progress' | 'completed'
export type RemoteTodoTaskStatus =
  | 'pending'
  | 'running'
  | 'waiting'
  | 'blocked'
  | 'paused'
  | 'succeeded'
  | 'failed'
  | 'cancelled'

export interface RemoteTodoEvidence {
  summary: string
  reference?: string
}

export interface RemoteTodoPlanSource {
  kind: 'plan'
  planId: string
  relativePath: string
  ordinal: number
}

export interface RemoteTodoItem {
  id: string
  content: string
  status: RemoteTodoStatus
  taskStatus?: RemoteTodoTaskStatus
  taskRevision?: number
  ownerThreadId?: string
  ownerLabel?: string
  dependsOn?: string[]
  acceptance?: string
  reason?: string
  evidence?: RemoteTodoEvidence[]
  source?: RemoteTodoPlanSource
  createdAt: string
  updatedAt: string
}

export interface RemoteTodoProgress {
  completed: number
  total: number
  blocked?: number
  inProgressText?: string
}

export interface ThreadTodoSnapshot {
  threadId: string
  revision: string
  /** True when an active task graph owns execution progress for this session. */
  outlineOnly: boolean
  planPath?: string
  projectId?: string
  items: RemoteTodoItem[]
  updatedAt?: string
}

export interface TodoParams {
  'todo.thread.get': { threadId: string }
}

export interface TodoResults {
  'todo.thread.get': ThreadTodoSnapshot
}

export const TODO_METHODS: readonly (keyof TodoParams)[]
export const TODO_READ_METHODS: ReadonlySet<keyof TodoParams>
export const TODO_STATUSES: readonly RemoteTodoStatus[]
export const TODO_TASK_STATUSES: readonly RemoteTodoTaskStatus[]
export function validateTodoParams<M extends keyof TodoParams>(method: M, params: unknown): TodoParams[M]
