import type { AtLeastOne } from './values.js'

export type ProjectBoardStatus = 'pending' | 'in_progress' | 'completed'
export type ProjectBoardPriority = 'P0' | 'P1' | 'P2' | null
export type ProjectBoardCategory =
  | 'feature'
  | 'bug'
  | 'refactor'
  | 'tech_debt'
  | 'docs'
  | 'test'
  | 'api'
  | 'sync'
  | 'ui'
  | 'interaction'
  | 'chore'
  | 'other'

export interface RemoteProjectBoardCardSource {
  label: 'Manual' | 'Plan'
  threadId?: string
  todoId?: string
  threadTitle?: string
  planId?: string
  planRelativePath?: string
  sectionTitle?: string
  ordinal?: number
}

export interface RemoteProjectBoardCard {
  id: string
  kind: 'manual' | 'thread_todo'
  projectId: string
  title: string
  description: string
  status: ProjectBoardStatus
  category: ProjectBoardCategory | 'plan'
  priority: ProjectBoardPriority
  archived: boolean
  updatedAt: string
  source: RemoteProjectBoardCardSource
}

export interface RemoteProjectBoardCounts {
  pending: number
  inProgress: number
  completed: number
  archived: number
  total: number
}

export interface RemoteProjectBoardSnapshot {
  projectId: string
  revision: string
  cards: RemoteProjectBoardCard[]
  counts: RemoteProjectBoardCounts
  truncated: boolean
  nextCursor?: string
  warning?: string
}

export interface RemoteProjectBoardSummary {
  projectId: string
  total: number
  pending: number
  inProgress: number
  completed: number
  progress: number
  updatedAt: string | null
}

export interface RemoteProjectBoardStatusDelta {
  id: string
  status: ProjectBoardStatus
  updatedAt: string
}

export interface RemoteProjectBoardMoveFailure {
  cardId: string
  code: 'write_failed' | 'source_missing' | 'stale_status' | 'skipped'
  message: string
}

export interface RemoteProjectBoardMoveResult {
  projectId: string
  revision: string
  counts: RemoteProjectBoardCounts
  updatedCards: RemoteProjectBoardStatusDelta[]
  failures: RemoteProjectBoardMoveFailure[]
}

export interface ProjectBoardParams {
  'project.board.get': {
    projectId: string
    includeArchived?: boolean
    cursor?: string
  }
  'project.board.summary': {
    projectId: string
  }
  'project.board.create': {
    projectId: string
    expectedRevision: string
    title: string
    description?: string
    status: ProjectBoardStatus
    category?: ProjectBoardCategory
    priority?: ProjectBoardPriority
  }
  'project.board.update': {
    projectId: string
    cardId: string
    expectedRevision: string
  } & AtLeastOne<{
    title?: string
    description?: string
    status?: ProjectBoardStatus
    category?: ProjectBoardCategory | null
    priority?: ProjectBoardPriority
    archived?: boolean
  }>
  'project.board.move': {
    projectId: string
    expectedRevision: string
    cardIds: string[]
    fromStatus: ProjectBoardStatus
    status: ProjectBoardStatus
  }
  'project.board.delete': {
    projectId: string
    cardId: string
    expectedRevision: string
  }
}

export interface ProjectBoardResults {
  'project.board.get': RemoteProjectBoardSnapshot
  'project.board.summary': RemoteProjectBoardSummary
  'project.board.create': RemoteProjectBoardSnapshot
  'project.board.update': RemoteProjectBoardSnapshot
  'project.board.move': RemoteProjectBoardMoveResult
  'project.board.delete': RemoteProjectBoardSnapshot
}

export const PROJECT_BOARD_METHODS: readonly (keyof ProjectBoardParams)[]
export const PROJECT_BOARD_READ_METHODS: ReadonlySet<keyof ProjectBoardParams>
export const PROJECT_BOARD_STATUSES: readonly ProjectBoardStatus[]
export const PROJECT_BOARD_PRIORITIES: readonly ('P0' | 'P1' | 'P2')[]
export const PROJECT_BOARD_CATEGORIES: readonly ProjectBoardCategory[]
export function validateProjectBoardParams<M extends keyof ProjectBoardParams>(method: M, params: unknown): ProjectBoardParams[M]
