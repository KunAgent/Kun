import { id, object } from './validation.js'

export const TODO_METHODS = Object.freeze(['todo.thread.get'])
export const TODO_READ_METHODS = new Set(['todo.thread.get'])
export const TODO_STATUSES = Object.freeze(['pending', 'in_progress', 'completed'])
export const TODO_TASK_STATUSES = Object.freeze([
  'pending', 'running', 'waiting', 'blocked', 'paused', 'succeeded', 'failed', 'cancelled'
])

export function validateTodoParams(method, params) {
  if (method !== 'todo.thread.get') throw new Error('UNSUPPORTED_OPERATION')
  object(params, ['threadId'])
  id(params.threadId)
  return params
}
