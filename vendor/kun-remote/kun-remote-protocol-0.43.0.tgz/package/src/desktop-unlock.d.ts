export const DESKTOP_UNLOCK_CAPABILITY: 'desktop.unlock.v1'
export type DesktopLockState = 'unlocked' | 'locked' | 'inactive'
export const DESKTOP_LOCK_STATES: readonly DesktopLockState[]
export type DesktopUnlockStatus = {
  lockState: DesktopLockState
  unlockAllowed: boolean
  inputReady: boolean
}
export type DesktopUnlockChallenge = {
  challengeId: string
  publicKey: string
  expiresInMs: number
}
export type DesktopUnlockBox = {
  challengeId: string
  publicKey: string
  nonce: string
  ciphertext: string
}
export function x25519(scalarBytes: Uint8Array, uBytes: Uint8Array): Uint8Array
export function x25519PublicKey(secretBytes: Uint8Array): Uint8Array
export function validateDesktopUnlockBox(value: unknown): DesktopUnlockBox
export function validateDesktopUnlockStatus(value: unknown): DesktopUnlockStatus
export function validateDesktopUnlockChallenge(value: unknown): DesktopUnlockChallenge
export function sealDesktopUnlockPassword(input: {
  challengeId: string
  hostId: string
  hostPublicKey: string
  password: string
  secretKey: Uint8Array
  nonce: Uint8Array
}): DesktopUnlockBox
export function openDesktopUnlockPassword(input: {
  challengeId: string
  hostId: string
  hostSecretKey: Uint8Array
  box: DesktopUnlockBox
}): string
