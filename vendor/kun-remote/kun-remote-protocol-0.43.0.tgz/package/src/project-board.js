import { check, id, integer, object, oneOf, optional, string, text } from './validation.js'

export const PROJECT_BOARD_METHODS = Object.freeze([
  'project.board.get',
  'project.board.summary',
  'project.board.create',
  'project.board.update',
  'project.board.move',
  'project.board.delete'
])
export const PROJECT_BOARD_READ_METHODS = new Set(['project.board.get', 'project.board.summary'])
export const PROJECT_BOARD_STATUSES = Object.freeze(['pending', 'in_progress', 'completed'])
export const PROJECT_BOARD_PRIORITIES = Object.freeze(['P0', 'P1', 'P2'])
export const PROJECT_BOARD_CATEGORIES = Object.freeze([
  'feature', 'bug', 'refactor', 'tech_debt', 'docs', 'test',
  'api', 'sync', 'ui', 'interaction', 'chore', 'other'
])

const FORBIDDEN_KEYS = new Set(['__proto__', 'constructor', 'prototype'])

function boardRevision(value) {
  text(value, 64)
  check(/^board-v1:(0|[1-9][0-9]*)$/.test(value))
  integer(Number(value.slice(9)), 0, Number.MAX_SAFE_INTEGER)
}

function cardId(value) {
  string(value, 512, 8)
  if (value.startsWith('manual:')) {
    const manualId = value.slice(7)
    check(!FORBIDDEN_KEYS.has(manualId))
    id(manualId)
    return
  }
  check(value.startsWith('todo:'))
  const sep = value.indexOf(':', 5)
  check(sep > 5 && sep < value.length - 1)
  id(value.slice(5, sep))
  string(value.slice(sep + 1), 256, 1)
}

export function validateProjectBoardParams(method, p) {
  switch (method) {
    case 'project.board.get':
      object(p, ['projectId'], ['includeArchived', 'cursor'])
      id(p.projectId)
      optional(p, 'includeArchived', (v) => check(typeof v === 'boolean'))
      optional(p, 'cursor', (v) => string(v, 2048))
      break
    case 'project.board.summary':
      object(p, ['projectId'])
      id(p.projectId)
      break
    case 'project.board.create':
      object(p, ['projectId', 'expectedRevision', 'title', 'status'], ['description', 'category', 'priority'])
      id(p.projectId)
      boardRevision(p.expectedRevision)
      string(p.title, 300)
      oneOf(p.status, PROJECT_BOARD_STATUSES)
      optional(p, 'description', (v) => text(v, 2000, 0))
      optional(p, 'category', (v) => oneOf(v, PROJECT_BOARD_CATEGORIES))
      optional(p, 'priority', (v) => { if (v !== null) oneOf(v, PROJECT_BOARD_PRIORITIES) })
      break
    case 'project.board.update':
      object(p, ['projectId', 'cardId', 'expectedRevision'], ['title', 'description', 'status', 'category', 'priority', 'archived'])
      id(p.projectId)
      cardId(p.cardId)
      boardRevision(p.expectedRevision)
      check(['title', 'description', 'status', 'category', 'priority', 'archived'].some((key) => Object.hasOwn(p, key)))
      if (p.cardId.startsWith('todo:')) check(p.title === undefined)
      if (p.cardId.startsWith('manual:') && Object.hasOwn(p, 'category')) check(p.category !== null)
      optional(p, 'title', (v) => string(v, 300))
      optional(p, 'description', (v) => text(v, 2000, 0))
      optional(p, 'status', (v) => oneOf(v, PROJECT_BOARD_STATUSES))
      optional(p, 'category', (v) => { if (v !== null) oneOf(v, PROJECT_BOARD_CATEGORIES) })
      optional(p, 'priority', (v) => { if (v !== null) oneOf(v, PROJECT_BOARD_PRIORITIES) })
      optional(p, 'archived', (v) => check(typeof v === 'boolean'))
      break
    case 'project.board.move':
      object(p, ['projectId', 'expectedRevision', 'cardIds', 'fromStatus', 'status'])
      id(p.projectId)
      boardRevision(p.expectedRevision)
      check(Array.isArray(p.cardIds) && p.cardIds.length >= 1 && p.cardIds.length <= 500)
      p.cardIds.forEach(cardId)
      check(new Set(p.cardIds).size === p.cardIds.length)
      oneOf(p.fromStatus, PROJECT_BOARD_STATUSES)
      oneOf(p.status, PROJECT_BOARD_STATUSES)
      break
    case 'project.board.delete':
      object(p, ['projectId', 'cardId', 'expectedRevision'])
      id(p.projectId)
      cardId(p.cardId)
      check(p.cardId.startsWith('manual:'))
      boardRevision(p.expectedRevision)
      break
    default:
      throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
