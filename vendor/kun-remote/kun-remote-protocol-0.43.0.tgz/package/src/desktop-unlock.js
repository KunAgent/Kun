import { xchacha20poly1305 } from '@noble/ciphers/chacha.js'
import { hkdf } from '@noble/hashes/hkdf.js'
import { sha256 } from '@noble/hashes/sha2.js'
import { directBase64, directBytes } from './direct-codec.js'
import { check, id, object, oneOf, boolean } from './desktop-validation.js'

export const DESKTOP_UNLOCK_CAPABILITY = 'desktop.unlock.v1'
export const DESKTOP_LOCK_STATES = Object.freeze(['unlocked', 'locked', 'inactive'])

const P = (1n << 255n) - 19n
const A24 = 121665n
const PASSWORD_MAX_BYTES = 256
const PADDED_PLAINTEXT_BYTES = PASSWORD_MAX_BYTES + 4
const SEALED_CIPHERTEXT_BYTES = PADDED_PLAINTEXT_BYTES + 16
const encoder = new TextEncoder(), decoder = new TextDecoder()

function mod(a) { const r = a % P; return r < 0n ? r + P : r }
function powMod(base, exp) {
  let result = 1n, cur = mod(base), e = exp
  while (e > 0n) {
    if (e & 1n) result = mod(result * cur)
    cur = mod(cur * cur)
    e >>= 1n
  }
  return result
}
function clampScalar(secret) {
  check(secret instanceof Uint8Array && secret.length === 32)
  const clamped = Uint8Array.from(secret)
  clamped[0] &= 248
  clamped[31] &= 127
  clamped[31] |= 64
  let k = 0n
  for (let i = 0; i < 32; i++) k |= BigInt(clamped[i]) << BigInt(8 * i)
  clamped.fill(0)
  return k
}
function decodeU(bytes) {
  check(bytes instanceof Uint8Array && bytes.length === 32)
  const copy = Uint8Array.from(bytes)
  copy[31] &= 127
  let u = 0n
  for (let i = 0; i < 32; i++) u |= BigInt(copy[i]) << BigInt(8 * i)
  return mod(u)
}
function encodeU(value) {
  const out = new Uint8Array(32)
  let v = mod(value)
  for (let i = 0; i < 32; i++) { out[i] = Number(v & 0xffn); v >>= 8n }
  return out
}
function cswap(swap, a, b) {
  const mask = swap ? a ^ b : 0n
  return [a ^ mask, b ^ mask]
}
/** RFC 7748 X25519 Montgomery ladder. Rejects all-zero low-order shared secrets. */
export function x25519(scalarBytes, uBytes) {
  const k = clampScalar(scalarBytes), x1 = decodeU(uBytes)
  let x2 = 1n, z2 = 0n, x3 = x1, z3 = 1n, swap = 0n
  for (let t = 254n; t >= 0n; t--) {
    const kt = (k >> t) & 1n
    swap ^= kt
    ;[x2, x3] = cswap(swap === 1n, x2, x3)
    ;[z2, z3] = cswap(swap === 1n, z2, z3)
    swap = kt
    const A = mod(x2 + z2), AA = mod(A * A)
    const B = mod(x2 - z2), BB = mod(B * B)
    const E = mod(AA - BB)
    const C = mod(x3 + z3), D = mod(x3 - z3)
    const DA = mod(D * A), CB = mod(C * B)
    const dacbAdd = mod(DA + CB), dacbSub = mod(DA - CB)
    x3 = mod(dacbAdd * dacbAdd)
    z3 = mod(x1 * mod(dacbSub * dacbSub))
    x2 = mod(AA * BB)
    z2 = mod(E * mod(AA + mod(A24 * E)))
  }
  ;[x2, x3] = cswap(swap === 1n, x2, x3)
  ;[z2, z3] = cswap(swap === 1n, z2, z3)
  const out = encodeU(mod(x2 * powMod(z2, P - 2n)))
  let nonZero = 0
  for (const byte of out) nonZero |= byte
  check(nonZero !== 0)
  return out
}
const BASE_POINT = (() => { const u = new Uint8Array(32); u[0] = 9; return u })()
export function x25519PublicKey(secretBytes) {
  return x25519(secretBytes, BASE_POINT)
}
function unlockKey(shared, challengeId, hostId) {
  return hkdf(sha256, shared, encoder.encode(challengeId), encoder.encode(`kun-desktop-unlock-v1/${hostId}`), 32)
}
function unlockAad(challengeId, hostId) {
  return encoder.encode(`${challengeId}:${hostId}`)
}

function base64Exact(value, length) {
  const chars = Math.ceil(length / 3) * 4
  check(typeof value === 'string' && value.length === chars && /^[A-Za-z0-9+/]*={0,2}$/.test(value))
  let bytes
  try { bytes = directBytes(value, length) } catch { check(false) }
  check(bytes.length === length)
  return bytes
}

export function validateDesktopUnlockBox(value) {
  object(value, ['challengeId', 'publicKey', 'nonce', 'ciphertext'])
  id(value.challengeId)
  base64Exact(value.publicKey, 32)
  base64Exact(value.nonce, 24)
  base64Exact(value.ciphertext, SEALED_CIPHERTEXT_BYTES)
  return value
}

export function validateDesktopUnlockStatus(value) {
  object(value, ['lockState', 'unlockAllowed', 'inputReady'])
  oneOf(value.lockState, DESKTOP_LOCK_STATES)
  boolean(value.unlockAllowed); boolean(value.inputReady)
  return value
}

export function validateDesktopUnlockChallenge(value) {
  object(value, ['challengeId', 'publicKey', 'expiresInMs'])
  id(value.challengeId)
  base64Exact(value.publicKey, 32)
  check(Number.isSafeInteger(value.expiresInMs) && value.expiresInMs >= 1 && value.expiresInMs <= 120000)
  return value
}

export function sealDesktopUnlockPassword({ challengeId, hostId, hostPublicKey, password, secretKey, nonce }) {
  id(challengeId); id(hostId)
  check(typeof password === 'string' && password.length >= 1 && !password.includes('\0'))
  const utf8 = encoder.encode(password)
  check(utf8.length >= 1 && utf8.length <= PASSWORD_MAX_BYTES)
  check(nonce instanceof Uint8Array && nonce.length === 24)
  const peerPublic = directBytes(hostPublicKey, 32)
  check(peerPublic.length === 32)
  const publicKey = x25519PublicKey(secretKey)
  const shared = x25519(secretKey, peerPublic)
  const key = unlockKey(shared, challengeId, hostId)
  const padded = new Uint8Array(PADDED_PLAINTEXT_BYTES)
  try {
    padded[0] = 1
    padded[1] = 0
    padded[2] = (utf8.length >> 8) & 0xff
    padded[3] = utf8.length & 0xff
    padded.set(utf8, 4)
    const ciphertext = xchacha20poly1305(key, nonce, unlockAad(challengeId, hostId)).encrypt(padded)
    return { challengeId, publicKey: directBase64(publicKey), nonce: directBase64(nonce), ciphertext: directBase64(ciphertext) }
  } finally {
    utf8.fill(0); padded.fill(0); shared.fill(0); key.fill(0)
  }
}

export function openDesktopUnlockPassword({ challengeId, hostId, hostSecretKey, box }) {
  id(challengeId); id(hostId)
  validateDesktopUnlockBox(box)
  check(box.challengeId === challengeId)
  const peerPublic = directBytes(box.publicKey, 32)
  const nonce = directBytes(box.nonce, 24)
  const ciphertext = directBytes(box.ciphertext, SEALED_CIPHERTEXT_BYTES)
  const shared = x25519(hostSecretKey, peerPublic)
  const key = unlockKey(shared, challengeId, hostId)
  let plain
  try {
    plain = xchacha20poly1305(key, nonce, unlockAad(challengeId, hostId)).decrypt(ciphertext)
    check(plain.length === PADDED_PLAINTEXT_BYTES && plain[0] === 1 && plain[1] === 0)
    const length = (plain[2] << 8) | plain[3]
    check(length >= 1 && length <= PASSWORD_MAX_BYTES)
    for (let i = 4 + length; i < PADDED_PLAINTEXT_BYTES; i++) check(plain[i] === 0)
    const password = decoder.decode(plain.subarray(4, 4 + length))
    check(password.length >= 1 && !password.includes('\0'))
    return password
  } finally {
    shared.fill(0); key.fill(0); plain?.fill(0)
  }
}
