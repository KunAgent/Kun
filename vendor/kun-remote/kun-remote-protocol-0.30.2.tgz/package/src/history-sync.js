import { applyHistoryDelta } from './live-history.js'

export const CODE_HISTORY_SYNC_CAPABILITY = 'history.code.sync.v2'
export const FILE_IDENTITY_CAPABILITY = 'file.identity.v1'
export const HISTORY_SYNC_MAX_SNAPSHOT_BYTES = 256 * 1024
export const HISTORY_SYNC_MAX_PATCH_BYTES = 64 * 1024
const record = (v) => v !== null && typeof v === 'object' && !Array.isArray(v)
const id = (v) => typeof v === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(v)
const entityId = (v) => typeof v === 'string' && v.length > 0 && v.length <= 2048 && !['__proto__', 'constructor', 'prototype'].includes(v)
const seq = (v) => Number.isSafeInteger(v) && v >= 0
const only = (v, keys) => record(v) && Object.keys(v).every((key) => keys.includes(key))

export function validateHistorySyncSubscription(value) {
  if (!only(value, ['version', 'subscriptionId', 'view', 'after']) || value.version !== 2 ||
      !id(value.subscriptionId) || value.view !== 'conversation' ||
      (value.after !== undefined && (!only(value.after, ['epoch', 'seq']) ||
        !id(value.after.epoch) || !seq(value.after.seq)))) throw new Error('INVALID_HISTORY_SYNC')
  return value
}

/** Keep entity metadata authoritative while sending only the growth of long assistant text. */
export function compactHistorySyncDelta(previous, delta) {
  const textAppends = [], items = {}
  for (const [turnId, change] of Object.entries(delta.items ?? {})) {
    const old = new Map((previous.turns?.find(turn => turn.id === turnId)?.items ?? []).map(item => [item.id, item]))
    items[turnId] = { ...change, ...(change.upsert ? { upsert: change.upsert.map(item => {
      const before = old.get(item.id)
      if (!entityId(turnId) || !entityId(item.id) || !['assistant_text', 'assistant_reasoning'].includes(item.kind) ||
          before?.kind !== item.kind || typeof before?.text !== 'string' ||
          before.text.length < 256 || typeof item.text !== 'string' || !item.text.startsWith(before.text) ||
          item.text.length === before.text.length) return item
      textAppends.push({ turnId, itemId: item.id, offset: before.text.length, text: item.text.slice(before.text.length) })
      const { text: _text, ...metadata } = item
      return metadata
    }) } : {}) }
  }
  return { delta: delta.items ? { ...delta, items } : delta, ...(textAppends.length ? { textAppends } : {}) }
}

function expandTextAppends(previous, frame) {
  if (frame.textAppends === undefined) return frame.delta
  if (!Array.isArray(frame.textAppends) || frame.textAppends.length > 500 || !record(frame.delta?.items))
    throw new Error('INVALID_HISTORY_SYNC')
  const items = { ...frame.delta.items }, seen = new Set()
  for (const append of frame.textAppends) {
    if (!only(append, ['turnId', 'itemId', 'offset', 'text']) || !entityId(append.turnId) || !entityId(append.itemId) ||
        !seq(append.offset) || typeof append.text !== 'string') throw new Error('INVALID_HISTORY_SYNC')
    const key = JSON.stringify([append.turnId, append.itemId])
    if (seen.has(key)) throw new Error('INVALID_HISTORY_SYNC')
    seen.add(key)
    const previousItem = previous.turns?.find(turn => turn.id === append.turnId)?.items?.find(item => item.id === append.itemId)
    const change = items[append.turnId]
    const meta = change?.upsert?.find(item => item.id === append.itemId)
    if (!meta || Object.hasOwn(meta, 'text') || !['assistant_text', 'assistant_reasoning'].includes(meta.kind) ||
        previousItem?.kind !== meta.kind || typeof previousItem?.text !== 'string' || previousItem.text.length !== append.offset)
      throw new Error('HISTORY_SYNC_GAP')
    items[append.turnId] = { ...change, upsert: change.upsert.map(item => item.id === append.itemId
      ? { ...item, text: previousItem.text + append.text } : item) }
  }
  return { ...frame.delta, items }
}

/** Never advance a cursor until the corresponding data has been applied successfully. */
export function applyHistorySync(state, frame) {
  if (!record(frame) || !id(frame.subscriptionId)) throw new Error('INVALID_HISTORY_SYNC')
  if (frame.kind === 'reset') {
    if (typeof frame.reason !== 'string') throw new Error('INVALID_HISTORY_SYNC')
    return { ...state, cursor: undefined, ready: false }
  }
  if (!id(frame.epoch) || !seq(frame.seq)) throw new Error('INVALID_HISTORY_SYNC')
  if (frame.kind === 'snapshot') {
    if (!record(frame.data) || !id(frame.data.id) || !Array.isArray(frame.data.turns)) throw new Error('INVALID_HISTORY_SYNC')
    if (state.cursor?.epoch === frame.epoch && frame.seq <= state.cursor.seq) return state
    return { data: frame.data, cursor: { epoch: frame.epoch, seq: frame.seq }, ready: false }
  }
  if (!state.cursor || frame.epoch !== state.cursor.epoch || !state.data) throw new Error('HISTORY_SYNC_GAP')
  if (frame.kind === 'ready') {
    if (frame.seq !== state.cursor.seq) throw new Error('HISTORY_SYNC_GAP')
    return { ...state, ready: true }
  }
  if (frame.kind !== 'patch' || !seq(frame.baseSeq) || frame.seq <= frame.baseSeq) throw new Error('INVALID_HISTORY_SYNC')
  if (frame.seq <= state.cursor.seq) return state
  if (frame.baseSeq !== state.cursor.seq) throw new Error('HISTORY_SYNC_GAP')
  return { data: applyHistoryDelta('code', state.data, expandTextAppends(state.data, frame)),
    cursor: { epoch: frame.epoch, seq: frame.seq }, ready: state.ready }
}

/** The data and resume cursor occupy one cache row, including after a crash during a stream. */
export function historySyncCache(state) {
  return { historySyncSchema: 2, data: state.data, cursor: state.cursor }
}
export function restoreHistorySync(value) {
  if (!record(value) || value.historySyncSchema !== 2 || !record(value.data) || !id(value.data.id) || !Array.isArray(value.data.turns) ||
      !only(value.cursor, ['epoch', 'seq']) || !id(value.cursor.epoch) || !seq(value.cursor.seq)) return undefined
  return { data: value.data, cursor: value.cursor, ready: false }
}
