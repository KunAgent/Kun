import { RemoteError } from './index.js'
import { directCipher } from './direct-codec.js'
import { directAddresses } from './direct-address.js'
import { REMOTE_SCOPES } from './scopes.js'

/** An encrypted adapter; RemoteClient remains the sole owner of reconnect and business requests. */
export class DirectSocket {
  onopen = null
  onmessage = null
  onerror = null
  onclose = null
  readyState = 0
  pending = new Map()
  serial = 0
  constructor(raw, credential, deviceId, hooks = {}) {
    this.raw = raw
    this.credential = credential
    this.deviceId = deviceId
    this.hooks = hooks
    this.timer = setTimeout(() => this.fail('DIRECT_CONNECT_TIMEOUT'), 7000)
    raw.onopen = () => {}
    raw.onerror = () => this.fail('DIRECT_UNREACHABLE')
    raw.onclose = event => {
      if (this.readyState === 0) this.hooks.failed?.(event?.code === 4403 ? 'DIRECT_AUTH_FAILED' : 'DIRECT_UNREACHABLE')
      this.finish(event?.code ?? 1006)
    }
    raw.onmessage = event => {
      try {
        if (String(event.data).length > 720000) throw Error('DIRECT_PACKET_LIMIT')
        const message = JSON.parse(String(event.data))
        if (!this.cipher) {
          if (message.type !== 'challenge' || message.v !== 1 || message.hostId !== credential.hostId) throw Error('DIRECT_HOST_MISMATCH')
          if (!/^[a-f0-9]{64}$/.test(message.nonce)) throw Error('DIRECT_AUTH_FAILED')
          const bytes = hooks.random ? hooks.random(32) : globalThis.crypto.getRandomValues(new Uint8Array(32))
          if (!(bytes instanceof Uint8Array) || bytes.length !== 32) throw Error('DIRECT_RANDOM_UNAVAILABLE')
          const nonce = Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('')
          this.cipher = directCipher(credential.secret, message.nonce + nonce, credential.hostId, 'phone')
          raw.send(JSON.stringify({ type: 'authenticate', id: credential.id, nonce, pairing: hooks.pairing === true,
            packet: this.cipher.seal({ hostId: credential.hostId, id: credential.id, deviceId, name: hooks.name ?? 'Phone' }) }))
          return
        }
        const value = this.cipher.open(message)
        if (this.readyState === 0) {
          if (value.type !== 'ready' || value.hostId !== credential.hostId || value.deviceId !== deviceId) throw Error('DIRECT_AUTH_FAILED')
          this.readyState = 1
          clearTimeout(this.timer)
          this.hooks.ready?.(value)
          this.onopen?.()
          return
        }
        if (value.type === 'api-result') {
          const pending = this.pending.get(value.id)
          if (!pending) return
          this.pending.delete(value.id); pending.cleanup()
          if (value.error) pending.reject(new RemoteError(value.error))
          else pending.resolve(value.value)
        } else if (value.type === 'frame' && typeof value.data === 'string') {
          const frame = JSON.parse(value.data)
          if (frame?.src !== credential.hostId || frame.dst !== deviceId) throw Error('DIRECT_HOST_MISMATCH')
          this.onmessage?.({ data: value.data })
        }
        else throw Error('DIRECT_PROTOCOL_ERROR')
      } catch (error) { this.fail(error?.message === 'DIRECT_HOST_MISMATCH' ? error.message : 'DIRECT_AUTH_FAILED') }
    }
  }
  get bufferedAmount() { return this.raw.bufferedAmount ?? 0 }
  send(data) {
    const frame = JSON.parse(data)
    if (!frame || frame.src !== undefined || frame.dst !== undefined && frame.dst !== this.credential.hostId) throw new RemoteError('DIRECT_HOST_MISMATCH')
    this.sendPacket({ type: 'frame', data })
  }
  sendPacket(value) {
    if (this.readyState !== 1 || !this.cipher) throw new RemoteError('DEVICE_OFFLINE')
    if (this.bufferedAmount > 2 * 1024 * 1024) throw new RemoteError('BACKPRESSURE')
    this.raw.send(JSON.stringify(this.cipher.seal(value)))
  }
  request(path, method = 'GET', body, signal) {
    if (signal?.aborted) return Promise.reject(new RemoteError('REQUEST_CANCELLED'))
    if (this.pending.size >= 8) return Promise.reject(new RemoteError('BACKPRESSURE'))
    return new Promise((resolve, reject) => {
      const id = String(++this.serial)
      const abort = () => { this.pending.delete(id); cleanup(); reject(new RemoteError('REQUEST_CANCELLED')) }
      const timeout = setTimeout(() => { this.pending.delete(id); cleanup(); reject(new RemoteError('REQUEST_TIMEOUT')) }, 15000)
      const cleanup = () => { clearTimeout(timeout); signal?.removeEventListener('abort', abort) }
      this.pending.set(id, { resolve, reject, cleanup })
      signal?.addEventListener('abort', abort, { once: true })
      try { this.sendPacket({ type: 'api', id, path, method, body }) }
      catch (error) { this.pending.delete(id); cleanup(); reject(error) }
    })
  }
  fail(code) {
    if (this.readyState === 3) return
    this.hooks.failed?.(code)
    this.finish(1006)
    try { this.raw.close() } catch {}
  }
  finish(code) {
    if (this.readyState === 3) return
    this.readyState = 3
    clearTimeout(this.timer)
    this.cipher?.close()
    for (const pending of this.pending.values()) { pending.cleanup(); pending.reject(new RemoteError('DEVICE_OFFLINE')) }
    this.pending.clear()
    this.onclose?.({ code })
  }
  close() { this.finish(1000); this.raw.onmessage = null; try { this.raw.close() } catch {} }
}

export function pairDirect(input, deviceId, socket, options = {}) {
  const addresses = directAddresses(input.addresses)
  return new Promise((resolve, reject) => {
    let connection, index = 0, done = false
    const finish = (error, value) => {
      if (done) return
      done = true; options.signal?.removeEventListener('abort', abort); connection?.close()
      if (error) reject(error); else resolve(value)
    }
    const abort = () => finish(new RemoteError('REQUEST_CANCELLED'))
    const next = () => {
      if (done) return
      if (index >= addresses.length) { finish(new RemoteError('DIRECT_UNREACHABLE')); return }
      const address = addresses[index++]
      try {
        connection = new DirectSocket(socket(address, {}), input, deviceId, {
          pairing: true, name: options.name, random: options.random,
          ready(value) {
            if (!value.credential || !/^[a-f0-9]{64}$/.test(value.credential.secret) || !/^[a-f0-9-]{36}$/.test(value.credential.id) ||
                !Number.isSafeInteger(value.credential.expiresAt) || value.credential.expiresAt <= Date.now() ||
                value.device?.id !== input.hostId || typeof value.device?.name !== 'string' || value.device.name.length > 180 ||
                typeof value.device?.platform !== 'string' || value.device.platform.length > 32 || !Array.isArray(value.scopes) || value.scopes.length > 64) {
              finish(new RemoteError('DIRECT_AUTH_FAILED')); return
            }
            finish(null, { ...input, id: value.credential.id, secret: value.credential.secret,
              addresses: [address, ...addresses.filter(item => item !== address)], deviceId,
              device: { id: input.hostId, name: value.device.name, platform: value.device.platform, role: 'host', enabled: true, online: true, version: 1 },
              scopes: value.scopes.filter(scope => REMOTE_SCOPES.includes(scope)), expiresAt: value.credential.expiresAt })
          },
          failed(code) {
            if (code === 'DIRECT_UNREACHABLE' || code === 'DIRECT_CONNECT_TIMEOUT') queueMicrotask(next)
            else finish(new RemoteError(code))
          }
        })
      } catch { next() }
    }
    if (options.signal?.aborted) { abort(); return }
    options.signal?.addEventListener('abort', abort, { once: true }); next()
  })
}
