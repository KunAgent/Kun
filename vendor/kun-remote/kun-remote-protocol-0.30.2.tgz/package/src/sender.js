import { LIMITS, RemoteError, utf8Size } from './index.js'
import { DESKTOP_STOP_METHODS } from './desktop-session.js'
import { FrameQueue } from './frame-queue.js'

/** Pace replay and fragments below the relay's 256 frames/s, including ACKs. */
export class Sender {
  constructor(socket, failed, sent = () => {}, sending = () => {}) {
    this.socket = socket
    this.failed = failed
    this.sent = sent
    this.sending = sending
    this.data = new FrameQueue()
    this.interactive = new FrameQueue()
    this.control = []
    this.desktopControl = []
    this.desktopControlBytes = 0
    this.bytes = 0
    this.controlBytes = 0
    this.last = -Infinity
    this.lastData = -Infinity
    this.interactiveStreak = 0
    this.closed = false
  }
  enqueue(frame, frames, options) {
    const desktopPriority = frame.kind === 'invoke' && DESKTOP_STOP_METHODS.has(frame.payload?.method)
    const priority = ['ack', 'ping', 'resync_required'].includes(frame.kind) ||
      (frame.kind === 'invoke' && frame.payload?.method === 'execution.stop')
    if (['ack', 'ping'].includes(frame.kind) && this.control.some((part) => part.kind === frame.kind)) return
    const size = frames.reduce((n, raw) => n + utf8Size(raw), 0)
    const buffered = this.socket.bufferedAmount ?? 0
    if (this.closed || this.bytes + size + buffered > LIMITS.bytes ||
      (desktopPriority
        ? this.desktopControlBytes + size > LIMITS.desktopControlBytes || this.desktopControl.length + frames.length > 2
        : priority
        ? this.controlBytes + size > LIMITS.controlBytes || this.control.length + frames.length > 64
        : this.bytes - this.controlBytes - this.desktopControlBytes + size + buffered > LIMITS.bytes - LIMITS.controlBytes - LIMITS.desktopControlBytes ||
          this.data.length + this.interactive.length + frames.length > 256))
      throw new RemoteError('BACKPRESSURE')
    const parts = frames.map(raw => ({ raw, size: utf8Size(raw), id: frame.id, kind: frame.kind }))
    if (desktopPriority) { this.desktopControl.push(...parts); this.desktopControlBytes += size }
    else if (priority) { this.control.push(...parts); this.controlBytes += size }
    else (frame.kind === 'invoke' && options?.priority !== 'background' ? this.interactive : this.data).enqueue(frame, parts)
    this.bytes += size
    this.pump()
  }
  cancel(id) {
    this.bytes -= this.data.cancel(id) + this.interactive.cancel(id)
    for (let i = this.desktopControl.length - 1; i >= 0; i--) {
      if (this.desktopControl[i].id !== id) continue
      const [part] = this.desktopControl.splice(i, 1)
      this.bytes -= part.size; this.desktopControlBytes -= part.size
    }
    for (let i = this.control.length - 1; i >= 0; i--) {
      if (this.control[i].id !== id) continue
      const [part] = this.control.splice(i, 1)
      this.bytes -= part.size
      this.controlBytes -= part.size
    }
  }
  pump() {
    if (this.closed) return
    clearTimeout(this.timer)
    const executionPriority = this.control.length > 0
    const desktopPriority = !executionPriority && this.desktopControl.length > 0
    const priority = executionPriority || desktopPriority
    if (!priority && !this.data.length && !this.interactive.length) return
    const now = Date.now(), wait = Math.max(0, this.last + 5 - now,
      priority ? 0 : this.lastData + 13 - now)
    if (wait > 0) { this.timer = setTimeout(() => this.pump(), wait); return }
    const interactive = this.interactive.length && (!this.data.length || this.interactiveStreak < 4)
    const part = executionPriority ? this.control.shift() : desktopPriority ? this.desktopControl.shift() : (interactive ? this.interactive : this.data).shift()
    this.bytes -= part.size
    if (desktopPriority) this.desktopControlBytes -= part.size
    else if (priority) this.controlBytes -= part.size
    else this.interactiveStreak = interactive ? this.interactiveStreak + 1 : 0
    this.last = now
    if (!priority) this.lastData = now
    // Once a socket send is attempted, a disconnect must conservatively report uncertainty.
    try {
      if (this.sending(part.kind, part.id) === false) { this.pump(); return }
      this.socket.send(part.raw)
    }
    catch { this.failed(); return }
    try { this.sent(part.kind, part.id) } catch {}
    this.pump()
  }
  close() {
    this.closed = true
    clearTimeout(this.timer)
    this.data.clear(); this.interactive.clear(); this.control.length = 0; this.desktopControl.length = 0
    this.bytes = this.controlBytes = this.desktopControlBytes = 0
  }
}
