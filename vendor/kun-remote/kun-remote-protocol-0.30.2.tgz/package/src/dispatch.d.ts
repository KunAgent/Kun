import type { RemoteCodeAgent } from './models.js'

export type DispatchState = 'pending_confirmation' | 'reviewing' | 'countdown' | 'paused' | 'queued' |
  'starting' | 'uncertain' | 'running' | 'awaiting_parent' | 'completed' | 'failed' | 'cancelled' | 'stopping'
export interface DispatchRoute {
  agentId: string
  profileId?: string
  model?: string
  providerId?: string
  credentialMode?: 'native-login' | 'provider' | 'kun-gateway'
  reasoningEffort?: 'auto' | 'off' | 'low' | 'medium' | 'high' | 'xhigh' | 'max'
}
export interface DispatchAssignment extends DispatchRoute {
  label: string
  agentName?: string
  workspaceIsolation?: 'local' | 'worktree'
}
/** Presentation only: execution payload, prompt excerpts and request ledger stay on the host. */
export interface DispatchIntent {
  intentId: string
  kind: 'worker' | 'workbench'
  revision: number
  state: DispatchState
  source: { threadId: string; turnId: string; toolCallId: string }
  recommendation: {
    title: string
    agentId: string
    agentName?: string
    model?: string
    permissionMode: 'ask-for-approval' | 'approve-for-me' | 'full-access'
    assignments?: DispatchAssignment[]
  }
  deadline?: string
  target?: { threadId?: string; workerIds?: string[] }
  error?: string
  resultSummary?: string
  updatedAt: string
}
export type DispatchAction = 'start_now' | 'pause' | 'resume' | 'cancel' | 'update'
export interface DispatchParams {
  'dispatch.list': { threadId: string }
  'dispatch.catalog': { threadId: string }
  'dispatch.act': {
    threadId: string
    intentId: string
    expectedRevision: number
    action: DispatchAction
    assignments?: DispatchRoute[]
  }
}
export interface DispatchResults {
  'dispatch.list': { intents: DispatchIntent[]; serverNow: number; hasMore: boolean }
  'dispatch.catalog': { agents: RemoteCodeAgent[] }
  'dispatch.act': { intent: DispatchIntent; serverNow: number }
}
export const DISPATCH_METHODS: readonly (keyof DispatchParams)[]
export const DISPATCH_READ_METHODS: ReadonlySet<keyof DispatchParams>
export function validateDispatchParams<M extends keyof DispatchParams>(method: M, params: unknown): DispatchParams[M]
