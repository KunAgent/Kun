import { check, object, optional, string } from './validation.js'
const localId = value => check(typeof value === 'string' && /^[a-z][a-z0-9-]{0,63}$/.test(value))
/** Validate inert plugin-authored content again at the phone boundary. No executable effects are permitted. */
export function parseMobilePluginContent(value) {
  try {
    object(value, ['version', 'blocks'], ['description'])
    check(value.version === 1)
    optional(value, 'description', item => string(item, 1000, 0))
    check(Array.isArray(value.blocks) && value.blocks.length > 0 && value.blocks.length <= 24)
    const ids = new Set()
    const blocks = value.blocks.map(block => {
      const fields = { text: ['text'], stat: ['label', 'value'], toggle: ['label', 'initial'], choice: ['label', 'options', 'initial'] }[block?.type]
      check(fields)
      object(block, ['id', 'type', ...fields]); localId(block.id)
      check(!ids.has(block.id)); ids.add(block.id)
      if (block.type === 'text') string(block.text, 2000)
      else string(block.label, 128)
      if (block.type === 'stat') string(block.value, 256, 0)
      if (block.type === 'toggle') check(typeof block.initial === 'boolean')
      if (block.type === 'choice') {
        check(Array.isArray(block.options) && block.options.length > 0 && block.options.length <= 12)
        const options = new Set()
        for (const option of block.options) {
          object(option, ['value', 'label']); localId(option.value); string(option.label, 128)
          check(!options.has(option.value)); options.add(option.value)
        }
        localId(block.initial); check(options.has(block.initial))
      }
      return { ...block, ...(block.type === 'choice' ? { options: block.options.map(option => ({ ...option })) } : {}) }
    })
    return { version: 1, ...(value.description !== undefined ? { description: value.description } : {}), blocks }
  } catch { return null }
}
