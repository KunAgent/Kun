import { xchacha20poly1305 } from '@noble/ciphers/chacha.js'
import { hkdf } from '@noble/hashes/hkdf.js'
import { sha256 } from '@noble/hashes/sha2.js'
import { hexToBytes } from '@noble/hashes/utils.js'

const encoder = new TextEncoder(), decoder = new TextDecoder()
export const DIRECT_PACKET_BYTES = 512 * 1024 + 256
export function directBase64(bytes) {
  let value = ''
  for (let at = 0; at < bytes.length; at += 8192) value += String.fromCharCode(...bytes.subarray(at, at + 8192))
  return btoa(value)
}
export function directBytes(value, max = DIRECT_PACKET_BYTES) {
  if (typeof value !== 'string' || value.length > Math.ceil(max / 3) * 4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(value)) throw Error('DIRECT_PACKET_INVALID')
  const binary = atob(value)
  if (binary.length > max) throw Error('DIRECT_PACKET_LIMIT')
  return Uint8Array.from(binary, ch => ch.charCodeAt(0))
}
/** Independent direction keys and counters bind every packet to one authenticated socket. */
export function directCipher(secret, challenge, hostId, side) {
  if (!/^[a-f0-9]{64}$/.test(secret) || !/^[a-f0-9]{128}$/.test(challenge) || !['host', 'phone'].includes(side)) throw Error('DIRECT_AUTH_FAILED')
  const key = direction => hkdf(sha256, hexToBytes(secret), hexToBytes(challenge), encoder.encode(`kun-direct-v1/${hostId}/${direction}`), 32)
  const outbound = key(side), inbound = key(side === 'host' ? 'phone' : 'host')
  let sent = 0, received = 0, closed = false
  function nonce(n) {
    const bytes = new Uint8Array(24)
    const view = new DataView(bytes.buffer)
    view.setUint32(16, Math.floor(n / 4294967296), false)
    view.setUint32(20, n >>> 0, false)
    return bytes
  }
  return {
    seal(value) {
      if (closed || !Number.isSafeInteger(sent + 1)) throw Error('DIRECT_CHANNEL_CLOSED')
      const bytes = encoder.encode(JSON.stringify(value))
      if (bytes.length > DIRECT_PACKET_BYTES - 16) throw Error('DIRECT_PACKET_LIMIT')
      const n = sent++
      return { n, c: directBase64(xchacha20poly1305(outbound, nonce(n)).encrypt(bytes)) }
    },
    open(packet) {
      if (closed || packet?.n !== received || !Number.isSafeInteger(packet.n)) throw Error('DIRECT_REPLAY_REJECTED')
      const bytes = xchacha20poly1305(inbound, nonce(received)).decrypt(directBytes(packet.c))
      const result = JSON.parse(decoder.decode(bytes))
      received++
      return result
    },
    close() { closed = true; outbound.fill(0); inbound.fill(0) }
  }
}
