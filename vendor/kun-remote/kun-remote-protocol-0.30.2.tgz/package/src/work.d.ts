import type { PageParams, RemotePage } from './values.js'
export interface WorkSpace {
  /** Also the `projectId` of `project.files.*` for this space. */
  id: string
  name: string
  sessionCount: number
  isDefault?: boolean
}
export interface WorkSessionSummary {
  id: string
  title: string
  status: string
  pinned: boolean
  archived: boolean
  revision: string
  createdAt: string
  updatedAt: string
  activityAt?: string
  harnessId?: string
  model?: string
  projectId?: string
  /** The space-relative file this session works on, for display and matching only. */
  anchorPath?: string
}
export interface WorkParams {
  'work.spaces.list': Record<string, never>
  'work.sessions.list': PageParams & { spaceId: string; query?: string; status?: 'all' | 'archived' }
}
export interface WorkResults {
  'work.spaces.list': { spaces: WorkSpace[] }
  'work.sessions.list': RemotePage<WorkSessionSummary, 'threads'>
}
export const WORK_METHODS: readonly (keyof WorkParams)[]
export const WORK_READ_METHODS: ReadonlySet<keyof WorkParams>
export function validateWorkParams<M extends keyof WorkParams>(method: M, params: unknown): WorkParams[M]
