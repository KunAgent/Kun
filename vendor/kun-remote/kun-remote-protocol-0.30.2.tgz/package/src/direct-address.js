export const DIRECT_PATH = '/kun/direct'
export function directAddress(input) {
  if (typeof input !== 'string' || input.length > 2048) throw Error('INVALID_DIRECT_ADDRESS')
  let url
  try { url = new URL(input.trim()) } catch { throw Error('INVALID_DIRECT_ADDRESS') }
  if (url.username || url.password || url.search || url.hash) throw Error('INVALID_DIRECT_ADDRESS')
  if (url.protocol === 'https:') url.protocol = 'wss:'
  if (url.protocol === 'http:') url.protocol = 'ws:'
  const host = url.hostname.replace(/^\[|\]$/g, '').toLowerCase()
  const ip = host.split('.').map(Number)
  const privateIp = ip.length === 4 && ip.every(n => Number.isInteger(n) && n >= 0 && n <= 255) &&
    (ip[0] === 10 || ip[0] === 127 || ip[0] === 192 && ip[1] === 168 || ip[0] === 172 && ip[1] >= 16 && ip[1] <= 31 ||
      ip[0] === 100 && ip[1] >= 64 && ip[1] <= 127 || ip[0] === 169 && ip[1] === 254)
  const local = privateIp || host === 'localhost' || host === '::1' || /^(fc|fd)[a-f0-9:]+$/.test(host) || host.endsWith('.local') || host.endsWith('.ts.net')
  if (url.protocol !== 'wss:' && !(url.protocol === 'ws:' && local)) throw Error('DIRECT_TLS_REQUIRED')
  if (!url.pathname.endsWith(DIRECT_PATH)) url.pathname = url.pathname.replace(/\/$/, '') + DIRECT_PATH
  return url.toString()
}
export function directAddresses(values) {
  if (!Array.isArray(values) || !values.length || values.length > 6) throw Error('INVALID_DIRECT_ADDRESS')
  return [...new Set(values.map(directAddress))]
}
export function parseDirectPairing(input, now = Date.now()) {
  if (typeof input !== 'string' || input.length > 16384) throw Error('INVALID_DIRECT_PAIRING')
  const prefix = 'kunapp://connect#'
  if (!input.trim().startsWith(prefix)) throw Error('INVALID_DIRECT_PAIRING')
  let value
  try { value = JSON.parse(decodeURIComponent(input.trim().slice(prefix.length))) } catch { throw Error('INVALID_DIRECT_PAIRING') }
  if (value?.v !== 1 || typeof value.hostId !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(value.hostId) || !/^[a-f0-9-]{36}$/.test(value.id) ||
      !/^[a-f0-9]{64}$/.test(value.secret) || !Number.isSafeInteger(value.expiresAt) || value.expiresAt <= now ||
      typeof value.name !== 'string' || value.name.length > 180) throw Error('DIRECT_PAIRING_EXPIRED')
  return { v: 1, hostId: value.hostId, id: value.id, secret: value.secret, expiresAt: value.expiresAt,
    name: value.name, addresses: directAddresses(value.addresses) }
}
export function encodeDirectPairing(value) {
  const result = 'kunapp://connect#' + encodeURIComponent(JSON.stringify(value))
  parseDirectPairing(result)
  return result
}
