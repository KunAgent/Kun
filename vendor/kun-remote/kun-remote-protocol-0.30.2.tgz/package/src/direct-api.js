import { RemoteApi } from './api.js'
import { RemoteError } from './index.js'
import { DirectSocket } from './direct-socket.js'
import { directAddresses } from './direct-address.js'
import { directBase64, directBytes } from './direct-codec.js'

const CHUNK = 64 * 1024
/** Same typed mobile API, backed by the paired computer instead of a cloud account token. */
export class DirectApi extends RemoteApi {
  constructor(profile, options) {
    super({ origin: 'https://direct.invalid', token: async () => null, identity: async () => ({ id: profile.deviceId, credential: '' }) })
    this.profile = { ...profile, addresses: directAddresses(profile.addresses) }
    this.options = options
    this.routeIndex = 0
    this.rejectedRoutes = new Set()
  }
  ticket() {
    this.options.current?.()
    const routes = this.profile.addresses.filter(url => !this.rejectedRoutes.has(url))
    if (this.profile.expiresAt <= Date.now() || !routes.length) return Promise.reject(new RemoteError('UNAUTHORIZED'))
    const url = routes[this.routeIndex++ % routes.length]
    return Promise.resolve({ url, ticket: this.profile.id })
  }
  open(url) {
    const channel = new DirectSocket(this.options.socket(url, {}), this.profile, this.profile.deviceId, {
      random: this.options.random,
      ready: value => {
        if (channel !== this.channel) return
        this.device = value.device
        this.profile.scopes = value.scopes
        this.routeIndex = this.profile.addresses.indexOf(url)
        this.options.connected?.(url)
      },
      failed: code => {
        if (['DIRECT_AUTH_FAILED', 'DIRECT_HOST_MISMATCH'].includes(code)) this.rejectedRoutes.add(url)
        this.options.diagnostic?.(code)
      }
    })
    this.channel = channel
    return channel
  }
  metadata() {
    const profile = this.profile
    const online = this.channel?.readyState === 1
    return { devices: [{ ...profile.device, ...(this.device ?? {}), id: profile.hostId, role: 'host', enabled: true, online,
      name: profile.device?.name ?? profile.name, platform: profile.device?.platform ?? 'macos', version: 1 },
      { id: profile.deviceId, name: 'Phone', role: 'controller', platform: 'ios', enabled: true, online, version: 1 }],
      grants: [{ id: profile.id, hostId: profile.hostId, controllerId: profile.deviceId }] }
  }
  async bootstrap() { return { ...this.metadata(), deviceId: this.profile.deviceId, enabled: true, relay: await this.ticket() } }
  async renew(signal) { return this.channelRequest('/relay-lease', 'POST', undefined, signal) }
  async channelRequest(path, method, body, signal) {
    this.options.current?.()
    if (!this.channel || this.channel.readyState !== 1) throw new RemoteError('DEVICE_OFFLINE')
    return this.channel.request(path, method, body, signal)
  }
  async request(path, method = 'GET', body, raw = false, signal) {
    this.options.current?.()
    if (signal?.aborted) throw new RemoteError('REQUEST_CANCELLED')
    if (path === '/devices' && method === 'POST') return { deviceId: this.profile.deviceId, enabled: true }
    if ((path === '/devices' || path === '/grants') && method === 'GET') {
      // A direct credential names exactly one host. A remote listing must never add or impersonate another saved computer.
      const value = this.metadata()
      return path === '/devices' ? { devices: value.devices } : { grants: value.grants }
    }
    if (/^\/transfers\/[a-f0-9-]{36}\/content$/.test(path) && raw && ['PUT', 'GET'].includes(method))
      return this.content(path.slice(0, -8), method, body, signal)
    return this.channelRequest(path, method, body, signal)
  }
  entitlements() { return Promise.reject(new RemoteError('DIRECT_MEMBERSHIP_NOT_REQUIRED')) }
  async content(path, method, body, signal) {
    const end = Date.now() + 120000
    const read = async (suffix, verb = 'GET', value) => {
      for (;;) {
        if (signal?.aborted) throw new RemoteError('REQUEST_CANCELLED')
        if (Date.now() >= end) throw new RemoteError('REQUEST_TIMEOUT')
        try { return await this.channelRequest(path + suffix, verb, value, signal) }
        catch (error) {
          if (!['DEVICE_OFFLINE', 'REQUEST_TIMEOUT'].includes(error?.code)) throw error
          await new Promise(resolve => setTimeout(resolve, 200))
        }
      }
    }
    const meta = await read('')
    if (!Number.isSafeInteger(meta.size) || meta.size < 1 || meta.size > 25 * 1024 * 1024) throw new RemoteError('FILE_LIMIT')
    if (method === 'PUT') {
      if (!(body instanceof Uint8Array) || body.length !== meta.size) throw new RemoteError('FILE_INTEGRITY')
      let offset = meta.offset
      if (!Number.isSafeInteger(offset) || offset < 0 || offset > body.length) throw new RemoteError('FILE_INTEGRITY')
      while (offset < body.length) {
        const result = await read('/chunk', 'PUT', { offset, data: directBase64(body.subarray(offset, offset + CHUNK)) })
        if (!Number.isSafeInteger(result.offset) || result.offset <= offset || result.offset > body.length) throw new RemoteError('FILE_INTEGRITY')
        offset = result.offset
      }
      await read('/complete', 'POST')
      return new Response(null, { status: 204 })
    }
    const bytes = new Uint8Array(meta.size)
    let offset = 0
    while (offset < bytes.length) {
      const result = await read('/chunk', 'POST', { offset })
      const part = directBytes(result.data, CHUNK)
      if (!part.length || part.length + offset > bytes.length) throw new RemoteError('FILE_INTEGRITY')
      bytes.set(part, offset); offset += part.length
    }
    return new Response(bytes, { headers: { 'Content-Length': String(bytes.length) } })
  }
}
