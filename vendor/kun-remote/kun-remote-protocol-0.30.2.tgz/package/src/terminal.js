import { check, object, string, id, integer, oneOf, resource, optional } from './validation.js'

/** Remote PTYs use the controller's existing desktop.control grant. */
export const TERMINAL_CAPABILITY = 'terminal.v1'
export const TERMINAL_METHODS = Object.freeze([
  'terminal.list', 'terminal.open', 'terminal.attach', 'terminal.write', 'terminal.resize', 'terminal.close'
])
export const TERMINAL_READ_METHODS = Object.freeze([])
export const TERMINAL_CONTROL_METHODS = Object.freeze([
  'terminal.open', 'terminal.attach', 'terminal.write', 'terminal.resize', 'terminal.close'
])
export const TERMINAL_LIMITS = Object.freeze({
  sessionsPerPeer: 4,
  sessions: 8,
  tombstones: 32,
  defaultCols: 80,
  defaultRows: 24,
  maxCols: 500,
  maxRows: 200,
  writeBytes: 8192,
  outputChunkBytes: 8192,
  outputBacklog: 64,
  outputBytes: 262144,
  snapshotBytes: 262144,
  sequence: 2147483647,
  cwdBytes: 4096,
  reasonBytes: 80,
  retentionMs: 300000,
  startTimeoutMs: 20000,
  closeTimeoutMs: 5000
})
export const TERMINAL_EVENTS = Object.freeze(['terminal.output', 'terminal.exited'])

function bytes(value) {
  let size = 0
  for (const char of value) {
    const code = char.codePointAt(0)
    size += code <= 0x7f ? 1 : code <= 0x7ff ? 2 : code <= 0xffff ? 3 : 4
  }
  return size
}
function epoch(value) { integer(value, 1, TERMINAL_LIMITS.sequence) }
function terminalData(value, max) { check(typeof value === 'string' && value.length <= max && bytes(value) <= max) }
function reason(value) { string(value, TERMINAL_LIMITS.reasonBytes); check(bytes(value) <= TERMINAL_LIMITS.reasonBytes) }
function uncPath(value) {
  const [server, share] = value.split('/')
  return Boolean(server && share && !['.', '..', '?'].includes(server) && !['.', '..'].includes(share))
}

/** Portable filesystem cwd validation shared by hosts and controllers. */
export function isAbsoluteTerminalCwd(value) {
  if (typeof value !== 'string' || !value || value.length > TERMINAL_LIMITS.cwdBytes ||
      value.includes('\0') || bytes(value) > TERMINAL_LIMITS.cwdBytes) return false
  if (value.startsWith('/') || /^[A-Za-z]:[\\/]/.test(value)) return true
  const path = value.replaceAll('\\', '/')
  if (!path.startsWith('//')) return false
  if (path.startsWith('//?/') || path.startsWith('//./')) {
    const target = path.slice(4)
    return /^(?:[A-Za-z]:\/|Volume\{[0-9a-f-]+\}\/)/i.test(target) ||
      (/^UNC\//i.test(target) && uncPath(target.slice(4)))
  }
  return uncPath(path.slice(2))
}
function cwd(value) { check(isAbsoluteTerminalCwd(value)) }
function sequence(value) { integer(value, 1, TERMINAL_LIMITS.sequence) }
function counter(value) { integer(value, 0, TERMINAL_LIMITS.sequence) }

export function validateTerminalSession(value) {
  object(value, ['schemaVersion', 'startId', 'sessionId', 'epoch', 'origin', 'cwd', 'cols', 'rows', 'state'], ['exitCode', 'signal'])
  check(value.schemaVersion === 1)
  id(value.startId); id(value.sessionId); epoch(value.epoch); resource(value.origin)
  cwd(value.cwd)
  integer(value.cols, 1, TERMINAL_LIMITS.maxCols); integer(value.rows, 1, TERMINAL_LIMITS.maxRows)
  oneOf(value.state, ['running', 'exited'])
  if (value.state === 'exited') {
    integer(value.exitCode, -2147483648, 2147483647)
    optional(value, 'signal', (signal) => string(signal, 32))
  } else check(value.exitCode === undefined && value.signal === undefined)
  return value
}

export function validateTerminalParams(method, value) {
  switch (method) {
    case 'terminal.list':
      object(value, [])
      break
    case 'terminal.open':
      object(value, ['startId', 'origin'], ['cols', 'rows'])
      id(value.startId); resource(value.origin)
      optional(value, 'cols', (cols) => integer(cols, 1, TERMINAL_LIMITS.maxCols))
      optional(value, 'rows', (rows) => integer(rows, 1, TERMINAL_LIMITS.maxRows))
      break
    case 'terminal.attach':
      object(value, ['sessionId'])
      break
    case 'terminal.write':
      object(value, ['sessionId', 'epoch', 'sequence', 'data'])
      epoch(value.epoch); sequence(value.sequence); terminalData(value.data, TERMINAL_LIMITS.writeBytes)
      break
    case 'terminal.resize':
      object(value, ['sessionId', 'cols', 'rows'])
      integer(value.cols, 1, TERMINAL_LIMITS.maxCols); integer(value.rows, 1, TERMINAL_LIMITS.maxRows)
      break
    case 'terminal.close':
      object(value, ['sessionId', 'reason'])
      reason(value.reason)
      break
    default:
      throw new Error('UNSUPPORTED_OPERATION')
  }
  if (value.sessionId !== undefined) id(value.sessionId)
  return value
}

function snapshotResult(value) {
  object(value, ['state', 'session', 'snapshot', 'sequence', 'inputSequence', 'epoch'])
  oneOf(value.state, ['running', 'exited'])
  validateTerminalSession(value.session)
  check(value.session.state === value.state)
  terminalData(value.snapshot, TERMINAL_LIMITS.snapshotBytes)
  counter(value.sequence); counter(value.inputSequence); epoch(value.epoch)
  check(value.epoch === value.session.epoch)
  return value
}

export function validateTerminalResult(method, value) {
  if (method === 'terminal.list') {
    object(value, ['sessions'])
    check(Array.isArray(value.sessions) && value.sessions.length <= TERMINAL_LIMITS.sessionsPerPeer)
    value.sessions.forEach(validateTerminalSession)
    check(new Set(value.sessions.map((session) => session.sessionId)).size === value.sessions.length)
  } else if (method === 'terminal.open' || method === 'terminal.attach') {
    if (value !== null && typeof value === 'object' && !Array.isArray(value) && value.state === 'missing') {
      check(method === 'terminal.attach')
      object(value, ['state'])
    } else snapshotResult(value)
  } else if (method === 'terminal.write') {
    object(value, ['accepted', 'sequence'])
    check(value.accepted === true)
    sequence(value.sequence)
  } else if (method === 'terminal.resize') {
    object(value, ['accepted', 'cols', 'rows'])
    check(value.accepted === true)
    integer(value.cols, 1, TERMINAL_LIMITS.maxCols); integer(value.rows, 1, TERMINAL_LIMITS.maxRows)
  } else if (method === 'terminal.close') {
    if (value !== null && typeof value === 'object' && !Array.isArray(value) && value.state === 'missing') object(value, ['state'])
    else {
      object(value, ['state', 'sessionId', 'reason', 'confirmed'])
      check(value.state === 'closed' && value.confirmed === true)
      id(value.sessionId); reason(value.reason)
    }
  } else throw new Error('UNSUPPORTED_OPERATION')
  return value
}

/** Output may be shed by the relay; exit delivery remains reliable. */
export function validateTerminalEvent(value) {
  object(value, ['event', 'sessionId', 'epoch', 'sequence'], ['data', 'lossy', 'exitCode', 'signal'])
  oneOf(value.event, TERMINAL_EVENTS)
  id(value.sessionId); epoch(value.epoch); sequence(value.sequence)
  if (value.event === 'terminal.output') {
    object(value, ['event', 'sessionId', 'epoch', 'sequence', 'data', 'lossy'])
    terminalData(value.data, TERMINAL_LIMITS.outputChunkBytes)
    check(value.lossy === true)
  } else if (value.event === 'terminal.exited') {
    object(value, ['event', 'sessionId', 'epoch', 'sequence', 'exitCode'], ['signal'])
    integer(value.exitCode, -2147483648, 2147483647)
    optional(value, 'signal', (signal) => string(signal, 32))
  } else throw new Error('UNSUPPORTED_OPERATION')
  return value
}
