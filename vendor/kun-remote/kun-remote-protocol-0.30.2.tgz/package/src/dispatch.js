import { object, id, integer, string, optional, oneOf, check } from './validation.js'

export const DISPATCH_METHODS = Object.freeze(['dispatch.list', 'dispatch.catalog', 'dispatch.act'])
export const DISPATCH_READ_METHODS = new Set(['dispatch.list', 'dispatch.catalog'])
function route(value) {
  object(value, ['agentId'], ['profileId', 'model', 'providerId', 'credentialMode', 'reasoningEffort'])
  string(value.agentId, 512)
  optional(value, 'profileId', v => string(v, 128))
  optional(value, 'model', v => string(v, 512, 0))
  optional(value, 'providerId', v => string(v, 128))
  optional(value, 'credentialMode', v => oneOf(v, ['native-login', 'provider', 'kun-gateway']))
  optional(value, 'reasoningEffort', v => oneOf(v, ['auto', 'off', 'low', 'medium', 'high', 'xhigh', 'max']))
}
export function validateDispatchParams(method, params) {
  if (DISPATCH_READ_METHODS.has(method)) object(params, ['threadId'])
  else if (method === 'dispatch.act') {
    object(params, ['threadId', 'intentId', 'expectedRevision', 'action'], ['assignments'])
    id(params.intentId)
    integer(params.expectedRevision, 1)
    oneOf(params.action, ['start_now', 'pause', 'resume', 'cancel', 'update'])
    if (params.action === 'update') {
      check(Array.isArray(params.assignments) && params.assignments.length >= 1 && params.assignments.length <= 16)
      params.assignments.forEach(route)
    } else check(params.assignments === undefined)
  } else throw new Error('UNSUPPORTED_OPERATION')
  id(params.threadId)
  return params
}
