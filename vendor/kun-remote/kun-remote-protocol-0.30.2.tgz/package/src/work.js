import { object, id, oneOf, optional, page, string } from './validation.js'

export const WORK_METHODS = Object.freeze(['work.spaces.list', 'work.sessions.list'])
export const WORK_READ_METHODS = new Set(WORK_METHODS)
export function validateWorkParams(method, p) {
  switch (method) {
    case 'work.spaces.list':
      object(p, []); break
    case 'work.sessions.list':
      object(p, ['spaceId'], ['query', 'status', 'cursor', 'limit']); id(p.spaceId)
      optional(p, 'query', (v) => string(v, 200, 0)); optional(p, 'status', (v) => oneOf(v, ['all', 'archived'])); page(p); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
