import type { Device, Socket, RemoteApi } from './index.js'
export interface DirectPairing { v: 1; hostId: string; id: string; secret: string; name: string; addresses: string[]; expiresAt: number }
export interface DirectProfile extends DirectPairing { deviceId: string; device: Device; scopes: string[] }
export const DIRECT_PATH: string
export const DIRECT_PACKET_BYTES: number
export function directAddress(input: unknown): string
export function directAddresses(input: unknown): string[]
export function encodeDirectPairing(input: DirectPairing): string
export function parseDirectPairing(input: string, now?: number): DirectPairing
export function directBase64(input: Uint8Array): string
export function directBytes(input: string, max?: number): Uint8Array
export function directCipher(secret: string, challenge: string, hostId: string, side: 'phone' | 'host'): {
  seal(value: unknown): { n: number; c: string }; open(packet: unknown): any; close(): void
}
export class DirectSocket implements Socket {
  readyState: number; bufferedAmount: number
  onopen: Socket['onopen']; onmessage: Socket['onmessage']; onerror: Socket['onerror']; onclose: Socket['onclose']
  constructor(raw: Socket, credential: DirectPairing, deviceId: string, hooks?: { random?(size: number): Uint8Array; pairing?: boolean; name?: string; ready?(value: any): void; failed?(code: string): void })
  send(data: string): void; close(): void
  request(path: string, method?: string, body?: unknown, signal?: AbortSignal): Promise<any>
}
export function pairDirect(input: DirectPairing, deviceId: string, socket: (url: string, headers: Record<string, string>) => Socket,
  options?: { signal?: AbortSignal; name?: string; random?(size: number): Uint8Array }): Promise<DirectProfile>
export class DirectApi extends RemoteApi {
  constructor(profile: DirectProfile, options: { socket(url: string, headers: Record<string, string>): Socket; random?(size: number): Uint8Array; current?(): void; connected?(url: string): void; diagnostic?(code: string): void })
  open(url: string): DirectSocket
}
