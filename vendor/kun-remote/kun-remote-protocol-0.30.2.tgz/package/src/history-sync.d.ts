import type { LiveHistoryDelta } from './live-history.js'
export const CODE_HISTORY_SYNC_CAPABILITY: 'history.code.sync.v2'
export const FILE_IDENTITY_CAPABILITY: 'file.identity.v1'
export const HISTORY_SYNC_MAX_SNAPSHOT_BYTES: number
export const HISTORY_SYNC_MAX_PATCH_BYTES: number
export interface HistorySyncCursor { epoch: string; seq: number }
export interface HistorySyncSubscription {
  version: 2
  subscriptionId: string
  view: 'conversation'
  after?: HistorySyncCursor
}
export type HistorySyncFrame = { subscriptionId: string } & (
  | { kind: 'snapshot'; epoch: string; seq: number; data: Record<string, unknown> }
  | { kind: 'patch'; epoch: string; baseSeq: number; seq: number; delta: LiveHistoryDelta; textAppends?: HistoryTextAppend[] }
  | { kind: 'ready'; epoch: string; seq: number }
  | { kind: 'reset'; reason: string }
)
export interface HistorySyncState {
  data?: Record<string, any>
  cursor?: HistorySyncCursor
  ready: boolean
}
export interface HistoryTextAppend { turnId: string; itemId: string; offset: number; text: string }
export function compactHistorySyncDelta(previous: Record<string, any>, delta: LiveHistoryDelta): { delta: LiveHistoryDelta; textAppends?: HistoryTextAppend[] }
export function validateHistorySyncSubscription(value: unknown): HistorySyncSubscription
export function applyHistorySync(state: HistorySyncState, frame: unknown): HistorySyncState
export function historySyncCache(state: HistorySyncState): unknown
export function restoreHistorySync(value: unknown): HistorySyncState | undefined
