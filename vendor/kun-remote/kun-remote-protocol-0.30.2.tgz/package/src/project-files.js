import { check, object, id, oneOf, optional, page, revision, string } from './validation.js'

export const PROJECT_FILES_METHODS = Object.freeze(["project.files.list", "project.files.search", "file.preview", "project.files.resolve"])
export const PROJECT_FILES_READ_METHODS = new Set(["project.files.list", "project.files.search", "file.preview", "project.files.resolve"])
export function validateProjectFilesParams(method, p) {
  switch (method) {
    case 'project.files.list':
      object(p, ['projectId'], ['parentRef', 'cursor', 'limit']); id(p.projectId); optional(p, 'parentRef', id); page(p); break
    case 'project.files.search':
      object(p, ['projectId', 'query'], ['mode', 'cursor', 'limit']); id(p.projectId); string(p.query, 200)
      optional(p, 'mode', (v) => oneOf(v, ['name', 'content'])); page(p); break
    case 'file.preview':
      object(p, ['projectId', 'fileRef', 'expectedRevision']); id(p.projectId); id(p.fileRef); revision(p.expectedRevision, 'file'); break
    case 'project.files.resolve':
      // A display-relative hint inside an authorized root; the host re-checks containment and every protected path.
      object(p, ['projectId', 'relativePath'], ['baseRef']); id(p.projectId); optional(p, 'baseRef', id); string(p.relativePath, 1024)
      check(!/^[\\/]/.test(p.relativePath) && !/^[a-zA-Z]:/.test(p.relativePath) && !p.relativePath.includes('\0')); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}

export function validateProjectExport(params) {
  object(params, ['projectId', 'fileRef', 'revision'])
  id(params.projectId); id(params.fileRef); revision(params.revision, 'file')
  return params
}
