export { parseMobilePluginContent } from './plugin-mobile.js'
import { check, object, optional, page, string } from './validation.js'
function pluginId(value) { check(typeof value === 'string' && /^[a-z0-9][a-z0-9-]{0,63}\.[a-z0-9][a-z0-9-]{0,63}$/.test(value)) }

export const PLUGIN_METHODS = Object.freeze(["plugin.catalog", "plugin.view", "plugin.setEnabled"])
export const PLUGIN_READ_METHODS = new Set(["plugin.catalog", "plugin.view"])
export function validatePluginParams(method, p) {
  switch (method) {
    case 'plugin.catalog':
      object(p, [], ['cursor', 'limit']); page(p, 50); optional(p, 'cursor', pluginId); break
    case 'plugin.view':
      object(p, ['pluginId', 'contributionId']); pluginId(p.pluginId); string(p.contributionId, 128); break
    case 'plugin.setEnabled':
      object(p, ['pluginId', 'expectedRevision', 'enabled']); pluginId(p.pluginId)
      check(typeof p.expectedRevision === 'string' && /^plugin-v1:[a-f0-9]{64}$/.test(p.expectedRevision))
      check(typeof p.enabled === 'boolean'); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}
