import { check, string, object, id, oneOf } from './validation.js'
export { check, object, string, id, integer, optional, oneOf } from './validation.js'
/** Device origins are only admitted by hosts advertising the scoped desktop capability. */
export function resource(value) {
  object(value, ['kind', 'id']); oneOf(value.kind, ['code', 'agent', 'device']); id(value.id)
}
// Kept independent from index.js so the desktop validators do not introduce an import cycle.
export function byteSize(value) {
  let size = 0
  for (const char of value) {
    const code = char.codePointAt(0)
    size += code <= 0x7f ? 1 : code <= 0x7ff ? 2 : code <= 0xffff ? 3 : 4
  }
  return size
}
export function byteString(value, max, min = 1) { string(value, max, min); check(byteSize(value) <= max) }
export function boolean(value) { check(typeof value === 'boolean') }
export function epoch(value) { check(Number.isSafeInteger(value) && value >= 1) }
export function displayRevision(value) { byteString(value, 128); check(/^[A-Za-z0-9_.:-]+$/.test(value)) }
export function mode(value) { check(value === 'view' || value === 'control') }
export function quality(value) { check(['smooth', 'balanced', 'sharp'].includes(value)) }
