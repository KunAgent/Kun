import { DESKTOP_LIMITS } from './desktop-limits.js'
import { object, byteString, check, optional, integer, id, epoch, boolean, mode, byteSize, oneOf } from './desktop-validation.js'
export function validateDesktopSdp(value, type) {
  object(value, ['type', 'sdp'])
  oneOf(value.type, type ? [type] : ['offer', 'answer'])
  byteString(value.sdp, DESKTOP_LIMITS.sdpBytes)
  check(value.sdp.startsWith('v=0'))
  return value
}
export function validateDesktopCandidate(value) {
  object(value, ['candidate'], ['sdpMid', 'sdpMLineIndex', 'usernameFragment'])
  byteString(value.candidate, DESKTOP_LIMITS.candidateBytes, 0)
  check(!/[\r\n]/.test(value.candidate))
  optional(value, 'sdpMid', v => { if (v !== null) byteString(v, 128, 0) })
  optional(value, 'sdpMLineIndex', v => { if (v !== null) integer(v, 0, 255) })
  optional(value, 'usernameFragment', v => { if (v !== null) byteString(v, 256, 0) })
  return value
}
export function validateDesktopCandidateBatch(value) {
  check(Array.isArray(value) && value.length <= DESKTOP_LIMITS.candidateBatch)
  value.forEach(validateDesktopCandidate)
  check(byteSize(JSON.stringify(value)) <= DESKTOP_LIMITS.candidateBatchBytes)
  return value
}
export function validateDesktopEvent(value) {
  check(value !== null && typeof value === 'object')
  if (value.event === 'desktop.signal.ice') {
    object(value, ['event', 'sessionId', 'epoch', 'candidates', 'complete'])
    validateDesktopCandidateBatch(value.candidates); boolean(value.complete)
  } else if (value.event === 'desktop.session.state') {
    object(value, ['event', 'sessionId', 'epoch', 'state', 'mode'], ['controlEpoch', 'reason'])
    oneOf(value.state, ['negotiating', 'viewing', 'controlling', 'reconnecting', 'closing'])
    mode(value.mode); optional(value, 'controlEpoch', epoch); optional(value, 'reason', v => byteString(v, 80))
  } else if (value.event === 'desktop.session.ended') {
    object(value, ['event', 'sessionId', 'epoch', 'startId', 'reason', 'confirmed'])
    id(value.startId); byteString(value.reason, 80); check(value.confirmed === true)
  } else throw new Error('INVALID_DESKTOP_EVENT')
  id(value.sessionId); epoch(value.epoch)
  return value
}

/** One instance per receive direction and media epoch; failed batches never consume capacity. */
export class DesktopIceAccumulator {
  constructor() { this.entries = new Set(); this.bytes = 0 }
  get count() { return this.entries.size }
  add(candidates) {
    validateDesktopCandidateBatch(candidates)
    const additions = new Map()
    for (const candidate of candidates) {
      const key = JSON.stringify([candidate.candidate, candidate.sdpMid ?? null, candidate.sdpMLineIndex ?? null, candidate.usernameFragment ?? null])
      if (!this.entries.has(key)) additions.set(key, candidate)
    }
    const bytes = [...additions.keys()].reduce((n, key) => n + byteSize(key), 0)
    check(this.count + additions.size <= DESKTOP_LIMITS.candidatesPerEpoch && this.bytes + bytes <= DESKTOP_LIMITS.candidatesEpochBytes)
    for (const key of additions.keys()) this.entries.add(key)
    this.bytes += bytes
    return [...additions.values()]
  }
  clear() { this.entries.clear(); this.bytes = 0 }
}
