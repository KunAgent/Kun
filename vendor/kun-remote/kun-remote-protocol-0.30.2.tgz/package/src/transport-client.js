import {
  VERSION, LIMITS, RemoteError, parseFrame, encodeFrames, Reassembler,
  utf8Size, validateCall
} from './index.js'
import { requestControlLane } from './desktop-session.js'
import { vipRequirement } from './entitlements.js'
import { bounded } from './deadline.js'
import { Sender } from './sender.js'
import { RequestBudget } from './request-budget.js'
import { schedulerFor } from './invoke-scheduler.js'
import { MAX_LEASE_MS, RELAY_FEATURES, RELAY_FEATURES_HEADER, relayFeatures, relayNotice } from './relay-control.js'
const LEASE = 60000, HEARTBEAT = 10000, FOREGROUND_PONG = 15000, STABLE_CONNECTION = 60000
/** Renew a third of the way through the lease (twenty seconds of sixty), within these bounds. */
const MIN_RENEW = 5000, MAX_RENEW = 100000
/** One acknowledgement covers every frame received before it is sent; the relay resets its window on any. */
const ACK_DELAY = 50, ACK_FRAMES = 16, ACK_BYTES = 1024 * 1024
const renewEvery = (span) => Math.max(MIN_RENEW, Math.min(MAX_RENEW, Math.floor(span / 3)))
const AUTH_FAILURES = new Set([
  'LOGIN_REQUIRED', 'UNAUTHORIZED', 'FORBIDDEN', 'unauthorized', 'forbidden',
  'HTTP_401', 'HTTP_403', 'INSTALLATION_REVOKED', 'DEVICE_REVOKED'
])
const authorizationDenied = (error) => AUTH_FAILURES.has(error?.code) || [401, 403].includes(error?.status)
/** Transport only. Retries connection/authorization, never a business invocation. */
export class TransportClient {
  constructor(deps, protocol) {
    this.protocol = protocol
    this.deps = deps
    this.budget = deps.budget ?? new RequestBudget()
    this.scheduler = schedulerFor(this.budget)
    this.pending = new Map()
    this.bytes = 0
    this.generation = 0
    this.assembly = protocol?.assembly ?? new Reassembler(Date.now, this.budget)
    this.online = false
    this.stopped = true
    this.terminal = false
    this.failures = 0
    this.renewEvery = renewEvery(LEASE)
    this.features = new Set()
    this.resetAck()
  }
  /** Relay behaviours the current connection's hello confirmed; empty for older relays. */
  get relayFeatures() { return this.features }
  resetAck() {
    clearTimeout(this.ackTimer)
    this.ackTimer = undefined
    this.ackQueued = false
    this.unacked = 0
    this.unackedBytes = 0
  }
  acknowledge(bytes) {
    if (this.ackQueued) return
    this.unacked++
    this.unackedBytes += bytes
    const flush = () => {
      clearTimeout(this.ackTimer)
      this.ackTimer = undefined
      if (this.ackQueued || !this.unacked) return
      this.ackQueued = true
      try { this.send({ kind: 'ack' }) } catch { this.ackQueued = false }
    }
    if (this.unacked >= ACK_FRAMES || this.unackedBytes >= ACK_BYTES) flush()
    else this.ackTimer ??= setTimeout(flush, ACK_DELAY)
  }
  sent(kind) {
    if (kind !== 'ack') return
    this.ackQueued = false
    this.unacked = 0
    this.unackedBytes = 0
  }
  notifyLease() { try { this.deps.leaseChanged?.(this.leaseUntil) } catch { this.diagnostic('APPLICATION_CALLBACK_FAILED') } }
  diagnostic(code, details) { try { this.deps.diagnostic?.(code, details) } catch {} }
  state(online, reason, force = false) {
    if (this.online === online && !force) return
    this.online = online
    try { this.deps.state?.(online, reason) } catch { this.diagnostic('APPLICATION_CALLBACK_FAILED') }
  }
  start() {
    if (!this.stopped) return
    this.failures = 0
    this.terminal = false
    this.stopped = false
    void this.connect()
  }
  /** Foreground wake keeps healthy connections, probes half-open sockets and wakes parked retries.
   * Terminal authorization/replacement stops still require the explicit start() repair path. */
  resume() {
    if (this.terminal) return
    if (this.stopped) { this.start(); return }
    if (this.online) { this.probe(this.generation, FOREGROUND_PONG); return }
    if (this.deps.networkAvailable?.() === false) { this.diagnostic('NETWORK_OFFLINE'); return }
    if (this.waitingForNetwork) { this.waitingForNetwork = false; void this.connect(); return }
    if (this.retry !== undefined) {
      clearTimeout(this.retry)
      this.retry = undefined
      void this.connect()
    }
    // A ticket or hello handshake already in progress owns its own bounded deadline.
  }
  /** A user's retry is a single new attempt, including when an OS reachability hint is wrong. */
  retryNow() {
    this.terminal = false
    this.stopped = false
    this.waitingForNetwork = false
    this.disconnect('RECOVERING')
    void this.connect(true)
  }
  /** Network recovery preserves device authorization but fences all old callbacks. */
  reconnect() {
    if (this.stopped) return
    this.disconnect('RECOVERING')
    this.retry = setTimeout(() => void this.connect(), 0)
  }
  stop() {
    this.stopped = true
    this.waitingForNetwork = false
    this.disconnect('STOPPED')
  }
  disconnect(reason, notify = false) {
    ++this.generation
    this.operation?.abort()
    this.operation = undefined
    for (const timer of ['retry', 'renewal', 'heartbeat', 'pong', 'hello', 'expiry']) {
      clearTimeout(this[timer])
      this[timer] = undefined
    }
    this.resetAck()
    this.features = new Set()
    this.sender?.close()
    this.sender = undefined
    const ws = this.ws
    this.ws = undefined
    if (ws) {
      ws.onopen = ws.onmessage = ws.onerror = ws.onclose = null
      try { ws.close() } catch {}
    }
    this.assembly.clear()
    this.renewFailures = 0
    this.protocol?.disconnected()
    const pending = [...this.pending.values()]
    this.pending.clear()
    for (const p of pending) {
      clearTimeout(p.timer)
      p.release()
      p.reject(new RemoteError(p.sent ? 'RESULT_UNKNOWN' : 'DEVICE_OFFLINE', p.sent))
    }
    this.pending.clear()
    this.bytes = 0
    this.state(false, reason, notify)
  }
  fail(generation, reason, terminal = false, immediate = false) {
    if (generation !== this.generation || this.stopped) return
    // Brief successful handshakes must not erase the backoff during a flapping outage.
    if (this.online && Date.now() - this.connectedAt >= STABLE_CONNECTION) this.failures = 0
    if (terminal) { this.stopped = true; this.terminal = true }
    // Application callbacks may restart synchronously. Fence and release the old connection
    // before notifying them, and never schedule old-generation work after they return.
    this.disconnect(reason, terminal)
    if (this.generation !== generation + 1) return
    this.diagnostic(reason)
    if (this.stopped || this.generation !== generation + 1) return
    if (this.deps.networkAvailable?.() === false) {
      this.waitingForNetwork = true
      this.diagnostic('NETWORK_OFFLINE')
      return
    }
    const delay = Math.round((immediate ? 0 : Math.min(30000, 1000 * 2 ** Math.min(this.failures++, 5))) * (0.8 + Math.random() * 0.4))
    this.diagnostic('RETRY_SCHEDULED', { attempt: this.failures + 1, delayMs: delay, retryAt: Date.now() + delay })
    if (this.stopped || this.generation !== generation + 1) return
    this.retry = setTimeout(() => void this.connect(), delay)
  }
  async connect(force = false) {
    if (this.stopped) return
    clearTimeout(this.retry)
    this.retry = undefined
    if (!force && this.deps.networkAvailable?.() === false) {
      this.waitingForNetwork = true
      this.diagnostic('NETWORK_OFFLINE')
      return
    }
    this.waitingForNetwork = false
    const generation = ++this.generation
    this.connectStarted = Date.now()
    this.diagnostic('CONNECTING', { attempt: this.failures + 1 })
    if (this.stopped || generation !== this.generation) return
    this.operation = new AbortController()
    try {
      const ticket = await bounded((signal) => this.deps.ticket(signal), 15000, this.operation.signal, 'CONNECT_TIMEOUT')
      if (this.stopped || generation !== this.generation) return
      this.diagnostic('TICKET_READY', { elapsedMs: Math.max(0, Date.now() - this.connectStarted) })
      if (this.stopped || generation !== this.generation) return
      this.protocol?.ticket(ticket)
      // Shared-task relays authorize their own envelope; only the personal relay takes options.
      const ws = this.deps.socket(ticket.url, { Authorization: 'Ticket ' + ticket.ticket,
        ...(this.protocol ? {} : { [RELAY_FEATURES_HEADER]: RELAY_FEATURES.join(',') }) })
      this.ws = ws
      this.sender = new Sender(ws, () => this.fail(generation, 'SEND_FAILED'), (kind) => {
        if (generation === this.generation) this.sent(kind)
      }, (kind, id) => {
        const pending = kind === 'invoke' && this.pending.get(id)
        if (pending) {
          if (Date.now() >= pending.deadline) { this.expire(id, pending); return false }
          pending.sent = true
        }
        return true
      })
      this.hello = setTimeout(() => this.fail(generation, 'HELLO_TIMEOUT'), 10000)
      ws.onopen = () => {}
      ws.onmessage = (event) => {
        if (generation !== this.generation || this.stopped) return
        try {
          const part = parseFrame(String(event.data))
          this.protocol?.part(part)
          if (!this.protocol && Object.hasOwn(part, 'shared')) throw new Error('SHARED_FRAME_ON_PERSONAL_CONNECTION')
          if (part.kind !== 'hello' && part.kind !== 'pong') this.acknowledge(String(event.data).length)
          const frame = this.assembly.accept(part)
          if (!frame) return
          try { this.deps.received?.() } catch { this.diagnostic('APPLICATION_CALLBACK_FAILED') }
          if (!this.protocol && Object.hasOwn(frame, 'shared')) throw new Error('SHARED_FRAME_ON_PERSONAL_CONNECTION')
          this.protocol?.frame(frame)
          if (frame.kind === 'hello') {
            if (this.online) return
            clearTimeout(this.hello)
            this.connectedAt = Date.now()
            const now = Date.now()
            this.leaseUntil = this.protocol ? this.protocol.hello(frame) : Number.isSafeInteger(frame.payload?.leaseExpiresAt)
              ? Math.min(frame.payload.leaseExpiresAt, now + MAX_LEASE_MS) : now + LEASE
            this.renewEvery = renewEvery(this.leaseUntil - now)
            this.features = this.protocol ? new Set() : relayFeatures(frame.payload?.features)
            if (generation !== this.generation || this.stopped || this.ws !== ws) return
            this.state(true)
            if (generation !== this.generation || this.stopped || this.ws !== ws) return
            this.notifyLease()
            if (generation !== this.generation || this.stopped || this.ws !== ws) return
            this.diagnostic('CONNECTED', { elapsedMs: Math.max(0, Date.now() - this.connectStarted) })
            if (generation !== this.generation || this.stopped || this.ws !== ws) return
            this.scheduleExpiry(generation)
            this.scheduleRenewal(generation)
            this.scheduleHeartbeat(generation)
            const peers = this.features.has('presence') ? relayNotice({ kind: 'event', payload: { relay: 'presence', peers: frame.payload?.presence } }) : null
            if (peers) this.relay(peers)
          } else if (frame.kind === 'pong') {
            clearTimeout(this.pong)
            this.pong = undefined
          } else if (frame.kind === 'result' || frame.kind === 'error') {
            const p = this.pending.get(frame.id)
            if (!p || (frame.kind === 'result' && frame.src !== p.dst)) return
            const error = frame.kind === 'error' || frame.payload?.error
              ? new RemoteError(frame.payload?.error?.code ?? frame.payload?.code ?? 'REMOTE_ERROR', !!frame.payload?.error?.uncertain) : undefined
            this.settle(frame.id, p, error, frame.payload)
          } else if (!this.protocol && frame.kind === 'event' && frame.src === undefined) {
            // Relay-authored notice. Never confused with a device frame, which always carries src.
            const notice = relayNotice(frame)
            if (notice) this.relay(notice)
          } else {
            try { this.deps.frame?.(frame) } catch { this.diagnostic('APPLICATION_CALLBACK_FAILED') }
          }
        } catch { this.fail(generation, 'PROTOCOL_ERROR') }
      }
      ws.onerror = () => this.fail(generation, 'SOCKET_ERROR')
      // 4401 is lease expiry; 4403 also covers grants changing for another device. Both need
      // a fresh ticket, whose HTTP response decides whether authorization is actually gone.
      // 4409 means a newer connection replaced us: retrying would evict it in a reconnect loop.
      ws.onclose = (event) => this.fail(generation, Number.isInteger(event?.code) ? 'SOCKET_CLOSED_' + event.code : 'SOCKET_CLOSED', event?.code === 4409)
    } catch (error) {
      if (vipRequirement(error?.code)) this.fail(generation, 'VIP_REQUIRED', true)
      else if (authorizationDenied(error)) this.fail(generation, 'AUTHORIZATION_REJECTED', true)
      else this.fail(generation, error?.code === 'CONNECT_TIMEOUT' ? error.code : 'CONNECT_FAILED')
    }
  }
  relay(notice) { try { this.deps.relay?.(notice) } catch { this.diagnostic('APPLICATION_CALLBACK_FAILED') } }
  scheduleExpiry(generation) {
    clearTimeout(this.expiry)
    this.expiry = setTimeout(() => this.fail(generation, 'LEASE_EXPIRED'), Math.max(0, this.leaseUntil - Date.now()))
  }
  scheduleRenewal(generation, delay = this.renewEvery) {
    clearTimeout(this.renewal)
    this.renewal = setTimeout(async () => {
      const started = Date.now()
      try {
        const remaining = this.leaseUntil - started
        if (remaining <= 0) { this.fail(generation, 'LEASE_EXPIRED'); return }
        const result = await bounded((signal) => this.deps.renew(signal), Math.min(12000, remaining), this.operation.signal, 'RENEW_TIMEOUT')
        if (generation !== this.generation || this.stopped) return
        this.leaseUntil = this.protocol ? this.protocol.renew(result) : Number.isSafeInteger(result?.expiresAt)
          ? Math.min(result.expiresAt, started + MAX_LEASE_MS) : started + LEASE
        this.renewEvery = renewEvery(this.leaseUntil - started)
        if (generation !== this.generation || this.stopped) return
        this.renewFailures = 0
        this.notifyLease()
        if (generation !== this.generation || this.stopped) return
        this.diagnostic('RENEWED', { elapsedMs: Math.max(0, Date.now() - started) })
        if (generation !== this.generation || this.stopped) return
        this.scheduleExpiry(generation)
        this.scheduleRenewal(generation, Math.max(0, started + this.renewEvery - Date.now()))
      } catch (error) {
        if (generation !== this.generation || this.stopped) return
        if (vipRequirement(error?.code)) { this.fail(generation, 'VIP_REQUIRED', true); return }
        if (authorizationDenied(error)) { this.fail(generation, 'AUTHORIZATION_REJECTED', true); return }
        // The relay no longer owns this lease: another renewal cannot restore its socket.
        // Reconnect with a new one-use ticket, settling in-flight calls without replaying them.
        if (error?.status === 409 && error?.code === 'reconnect_required') {
          this.fail(generation, 'RECONNECT_REQUIRED', false, true); return
        }
        if (['SHARED_AUTHORITY_CHANGED', 'INVALID_SHARED_LEASE'].includes(error?.code)) { this.fail(generation, 'AUTHORIZATION_REJECTED'); return }
        this.diagnostic('RENEW_RETRY', { attempt: (this.renewFailures ?? 0) + 1, elapsedMs: Math.max(0, Date.now() - started) })
        if (generation !== this.generation || this.stopped) return
        const delay = Math.min(8000, 1000 * 2 ** Math.min(this.renewFailures ?? 0, 3))
        this.renewFailures = (this.renewFailures ?? 0) + 1
        this.scheduleRenewal(generation, Math.min(delay, Math.max(0, this.leaseUntil - Date.now())))
      }
    }, delay)
  }
  probe(generation, timeout = HEARTBEAT) {
    if (generation !== this.generation || this.stopped || !this.online || this.pong !== undefined) return
    // Arm before send so even a synchronously delivered pong clears the right deadline.
    // Repeated foreground notifications never extend an outstanding probe's timeout.
    this.pong = setTimeout(() => this.fail(generation, 'PONG_TIMEOUT'), timeout)
    try { this.send({ kind: 'ping' }) }
    catch { this.fail(generation, 'HEARTBEAT_FAILED') }
  }
  scheduleHeartbeat(generation) {
    this.heartbeat = setTimeout(() => {
      if (generation !== this.generation || this.stopped) return
      this.probe(generation)
      if (generation === this.generation && !this.stopped) this.scheduleHeartbeat(generation)
    }, HEARTBEAT)
  }
  send(frame, options) {
    if (!this.online || !this.ws || !this.sender) throw new RemoteError('DEVICE_OFFLINE')
    frame = this.protocol ? this.protocol.outgoing(frame) : frame
    this.sender.enqueue(frame, encodeFrames({ v: VERSION, ...frame }), options)
  }
  settle(id, p, error, value) {
    if (this.pending.get(id) !== p) return
    this.pending.delete(id)
    clearTimeout(p.timer)
    this.sender?.cancel(id)
    this.bytes -= p.size
    p.release()
    if (error) p.reject(error)
    else p.resolve(value)
  }
  expire(id, p) {
    this.settle(id, p, new RemoteError(p.sent ? 'RESULT_UNKNOWN' : 'REQUEST_TIMEOUT', p.sent))
  }
  invoke(dst, call, timeout = 30000, options = {}) {
    if (this.protocol) this.protocol.call(dst, call)
    else validateCall(call)
    if (!this.online) return Promise.reject(new RemoteError('DEVICE_OFFLINE'))
    const size = utf8Size(JSON.stringify(call)), control = requestControlLane(call.method)
    if (this.pending.has(call.requestId)) return Promise.reject(new RemoteError('REQUEST_IN_FLIGHT'))
    const lane = [...this.pending.values()].filter((p) => p.control === control)
    const countLimit = control === 'desktop' ? LIMITS.desktopControlPending : control ? LIMITS.controlPending : LIMITS.pending - LIMITS.controlPending - LIMITS.desktopControlPending
    const byteLimit = control === 'desktop' ? LIMITS.desktopControlBytes : control ? LIMITS.controlBytes : LIMITS.bytes - LIMITS.controlBytes - LIMITS.desktopControlBytes
    if (lane.length >= countLimit ||
      lane.reduce((n, p) => n + p.size, 0) + size > byteLimit ||
      this.pending.size >= LIMITS.pending || this.bytes + size > LIMITS.bytes) return Promise.reject(new RemoteError('BACKPRESSURE'))
    const releaseBudget = this.budget.reserve(dst, size, control)
    return new Promise((resolve, reject) => {
      const deadline = Math.min(Date.now() + Math.max(0, timeout), call.expiresAt)
      const p = { dst, resolve, reject, size, control, deadline, sent: false,
        release: () => { releaseBudget(); p.cancelAdmission?.() } }
      p.timer = setTimeout(() => this.expire(call.requestId, p), Math.max(0, deadline - Date.now()))
      this.pending.set(call.requestId, p)
      this.bytes += size
      const start = (release) => {
        p.cancelAdmission = release
        if (this.pending.get(call.requestId) !== p) { release?.(); return }
        if (Date.now() >= deadline) { this.expire(call.requestId, p); return }
        try { this.send({ kind: 'invoke', id: call.requestId, dst, payload: call }, options) }
        catch (error) { this.settle(call.requestId, p, error) }
      }
      if (control) start()
      else p.cancelAdmission = this.scheduler.schedule(dst, options.priority, start)
    })
  }
}
