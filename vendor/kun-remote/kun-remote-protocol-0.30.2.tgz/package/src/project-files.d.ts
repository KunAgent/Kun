import type { PageParams, RemotePage, ResourceRef, AtLeastOne } from './values.js'
export interface ProjectFileEntry {
  fileRef: string
  /** Stable cache identity only; fileRef still authorizes each read. */
  fileId?: string
  name: string
  kind: 'file' | 'directory'
  revision: string
  available: boolean
  size?: number
  mimeType?: string
  parentRef?: string
  displayPath?: string
  /** Epoch milliseconds of the file's last change, for display only. */
  modifiedAt?: number
  /** Content search only: a short excerpt around the first match. */
  snippet?: string
}
export interface ProjectFilesPage extends RemotePage<ProjectFileEntry, 'entries'> {
  projectId: string
  rootRef: string
  parentRef?: string
  complete?: boolean
  searchScope?: string
}
export type ProjectExportParams = { projectId: string; fileRef: string; revision: string }
export function validateProjectExport(params: unknown): ProjectExportParams
export interface ProjectFilesParams {
  'project.files.list': PageParams & { projectId: string; parentRef?: string }
  'project.files.search': PageParams & { projectId: string; query: string; mode?: 'name' | 'content' }
  'file.preview': { projectId: string; fileRef: string; expectedRevision: string }
  'project.files.resolve': { projectId: string; relativePath: string; baseRef?: string }
}
export interface ProjectFilesResults {
  'project.files.list': ProjectFilesPage
  'project.files.search': ProjectFilesPage
  'file.preview': { file: ProjectFileEntry; export: ProjectExportParams }
  'project.files.resolve': { file: ProjectFileEntry }
}
export const PROJECT_FILES_METHODS: readonly (keyof ProjectFilesParams)[]
export const PROJECT_FILES_READ_METHODS: ReadonlySet<keyof ProjectFilesParams>
export function validateProjectFilesParams<M extends keyof ProjectFilesParams>(method: M, params: unknown): ProjectFilesParams[M]
