export type DesktopChannel = 'kun.desktop.control.v1' | 'kun.desktop.input.v1' | 'kun.desktop.pointer.v1'
export const DESKTOP_CHANNELS: Readonly<{ control: 'kun.desktop.control.v1'; input: 'kun.desktop.input.v1'; pointer: 'kun.desktop.pointer.v1' }>
export interface DesktopDataBase { v: 1; sessionId: string; epoch: number; type: string; seq: number }
export interface DesktopInputBase extends DesktopDataBase { controlEpoch: number; displayRevision: string; challenge: string }
/** Counter values are cumulative within an epoch. null means unavailable, never a synthetic zero. */
export interface DesktopMediaHealthSample {
  sampleId: number
  trackState: 'live' | 'ended'
  muted: boolean
  sourceFrames: number | null
  framesEncoded: number | null
  framesSent: number | null
}
export type DesktopDataMessage =
  | (DesktopDataBase & { type: 'hello' | 'input.releaseAll' })
  | (DesktopDataBase & { type: 'ready'; mode: 'view' | 'control'; controlEpoch?: number })
  | (DesktopDataBase & { type: 'probe' | 'probe.ack'; challenge: string })
  | (DesktopDataBase & { type: 'media.health' } & DesktopMediaHealthSample)
  | (DesktopDataBase & { type: 'session.stop'; reason: string })
  | (DesktopInputBase & { type: 'pointer.move' | 'pointer.drag'; x: number; y: number })
  | (DesktopInputBase & { type: 'pointer.button'; button: 'left' | 'middle' | 'right'; pressed: boolean; x: number; y: number })
  | (DesktopInputBase & { type: 'pointer.wheel'; deltaX: number; deltaY: number })
  | (DesktopInputBase & { type: 'key'; code: string; pressed: boolean })
  | (DesktopInputBase & { type: 'text.commit'; text: string })
export function validateDesktopDataMessage(value: unknown, channel?: DesktopChannel, source?: 'host' | 'controller'): DesktopDataMessage
export function desktopDataChannel(type: string): DesktopChannel
