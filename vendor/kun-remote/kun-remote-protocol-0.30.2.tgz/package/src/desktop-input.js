import { DESKTOP_LIMITS } from './desktop-limits.js'
import { object, id, epoch, integer, byteString, byteSize, check, boolean, oneOf, mode, optional, displayRevision } from './desktop-validation.js'
export const DESKTOP_CHANNELS = Object.freeze({
  control: 'kun.desktop.control.v1', input: 'kun.desktop.input.v1', pointer: 'kun.desktop.pointer.v1'
})
const CONTROL_TYPES = new Set(['hello', 'ready', 'probe', 'probe.ack', 'media.health', 'input.releaseAll', 'session.stop'])
const INPUT_TYPES = new Set(['pointer.drag', 'pointer.button', 'pointer.wheel', 'key', 'text.commit'])
const KEYS = new Set(['Enter', 'Tab', 'Escape', 'Backspace', 'Delete', 'Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft',
  'ArrowRight', 'Home', 'End', 'PageUp', 'PageDown', 'Insert', 'CapsLock', 'ShiftLeft', 'ShiftRight',
  'ControlLeft', 'ControlRight', 'AltLeft', 'AltRight', 'MetaLeft', 'MetaRight', 'Minus', 'Equal',
  'BracketLeft', 'BracketRight', 'Backslash', 'Semicolon', 'Quote', 'Backquote', 'Comma', 'Period', 'Slash',
  'NumpadAdd', 'NumpadSubtract', 'NumpadMultiply', 'NumpadDivide', 'NumpadDecimal', 'NumpadEnter'])
export function desktopDataChannel(type) {
  if (type === 'pointer.move') return DESKTOP_CHANNELS.pointer
  if (CONTROL_TYPES.has(type)) return DESKTOP_CHANNELS.control
  if (INPUT_TYPES.has(type)) return DESKTOP_CHANNELS.input
  throw new Error('INVALID_DESKTOP_MESSAGE')
}
function point(value) { check(Number.isFinite(value) && value >= 0 && value <= 1) }
function delta(value) { check(Number.isFinite(value) && Math.abs(value) <= 1200) }
function key(value) {
  check(typeof value === 'string' && (KEYS.has(value) || /^(Key[A-Z]|Digit[0-9]|Numpad[0-9]|F([1-9]|1[0-9]|2[0-4]))$/.test(value)))
}
export function validateDesktopDataMessage(value, channel, source) {
  check(value !== null && typeof value === 'object' && !Array.isArray(value))
  const target = desktopDataChannel(value.type)
  if (source !== undefined) {
    oneOf(source, ['host', 'controller'])
    check(source === (['ready', 'probe', 'media.health'].includes(value.type) ? 'host' : 'controller'))
  }
  if (channel !== undefined) check(channel === target)
  const required = ['v', 'sessionId', 'epoch', 'type', 'seq']
  if (target !== DESKTOP_CHANNELS.control) required.push('controlEpoch', 'displayRevision', 'challenge')
  const fields = {
    hello: [], ready: ['mode'], probe: ['challenge'], 'probe.ack': ['challenge'],
    'media.health': ['sampleId', 'trackState', 'muted', 'sourceFrames', 'framesEncoded', 'framesSent'],
    'input.releaseAll': [], 'session.stop': ['reason'],
    'pointer.move': ['x', 'y'], 'pointer.drag': ['x', 'y'],
    'pointer.button': ['x', 'y', 'button', 'pressed'], 'pointer.wheel': ['deltaX', 'deltaY'],
    key: ['code', 'pressed'], 'text.commit': ['text']
  }
  object(value, [...required, ...fields[value.type]], value.type === 'ready' ? ['controlEpoch'] : [])
  check(value.v === 1); id(value.sessionId); epoch(value.epoch); integer(value.seq)
  if (target !== DESKTOP_CHANNELS.control) {
    epoch(value.controlEpoch); displayRevision(value.displayRevision); id(value.challenge)
  }
  switch (value.type) {
    case 'ready': mode(value.mode); optional(value, 'controlEpoch', epoch); check(value.mode !== 'control' || value.controlEpoch !== undefined); break
    case 'probe': case 'probe.ack': id(value.challenge); break
    case 'media.health':
      epoch(value.sampleId); oneOf(value.trackState, ['live', 'ended']); boolean(value.muted)
      for (const name of ['sourceFrames', 'framesEncoded', 'framesSent']) if (value[name] !== null) integer(value[name])
      break
    case 'session.stop': byteString(value.reason, 80); break
    case 'pointer.move': case 'pointer.drag': point(value.x); point(value.y); break
    case 'pointer.button': point(value.x); point(value.y); oneOf(value.button, ['left', 'middle', 'right']); boolean(value.pressed); break
    case 'pointer.wheel': delta(value.deltaX); delta(value.deltaY); break
    case 'key': key(value.code); boolean(value.pressed); break
    case 'text.commit': byteString(value.text, DESKTOP_LIMITS.textBytes); break
  }
  check(byteSize(JSON.stringify(value)) <= DESKTOP_LIMITS.dataBytes)
  return value
}
