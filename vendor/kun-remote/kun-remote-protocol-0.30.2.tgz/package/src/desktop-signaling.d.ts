import type { DesktopActiveState, DesktopIceCandidate, DesktopMode, DesktopSdp } from './desktop-session.js'
export type DesktopEvent =
  | { event: 'desktop.signal.ice'; sessionId: string; epoch: number; candidates: DesktopIceCandidate[]; complete: boolean }
  | { event: 'desktop.session.state'; sessionId: string; epoch: number; state: DesktopActiveState | 'closing'; mode: DesktopMode; controlEpoch?: number; reason?: string }
  | { event: 'desktop.session.ended'; sessionId: string; epoch: number; startId: string; reason: string; confirmed: true }
export function validateDesktopSdp(value: unknown, type?: 'offer' | 'answer'): DesktopSdp
export function validateDesktopCandidate(value: unknown): DesktopIceCandidate
export function validateDesktopCandidateBatch(value: unknown): DesktopIceCandidate[]
export function validateDesktopEvent(value: unknown): DesktopEvent
export class DesktopIceAccumulator {
  readonly count: number
  readonly bytes: number
  add(candidates: unknown): DesktopIceCandidate[]
  clear(): void
}
