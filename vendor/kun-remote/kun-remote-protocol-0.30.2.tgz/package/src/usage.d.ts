/** Optional code.history.mobileUsage. Absent means unavailable, never zero. */
export interface MobileUsage {
  inputTokens?: number
  outputTokens?: number
  totalTokens?: number
  context?: { usedTokens: number; windowTokens?: number; source: 'estimate' | 'agent' }
}
