# Remote protocol modules

Wire version, methods, limits and receipt identity are unchanged. The package root exposes typed `RemoteParams`, `RemoteResults`, `RemoteMethod` and `OperationCall<M>`. `validateOperationParams` validates an explicit business method; `validateCall` keeps the legacy wire behavior and dispatches recognized operations through feature-owned validators. Discovery and cached descriptors never grant authority.

`operations.js` composes fixed method registration only. `scopes.js` owns required permissions, while each business module owns its own exact request keys and validation. No module represents an implementation phase. Private source paths may change; consumers import the package root.

| Responsibility | Modules |
| --- | --- |
| Task metadata and routing | `tasks`, `task-settings`, `models`, `model-info`, `history-actions` |
| Public content | `messages`, `source-content`, `attention`, `artifacts` |
| Personal Agent configuration | `agent-profiles`, `agent-directory`, `agent-avatars`, `agent-capabilities`, `agent-lifecycle`, `agent-import` |
| Personal Agent retained data | `agent-memory`, `agent-memory-review`, `agent-library`, `agent-reminders`, `agent-commitments` |
| Execution and bounded files | `execution`, `goals`, `project-files`, `attachments` |
| Explicit advanced scopes | `groups`, `group-mutations`, `collaboration`, `plugins`, `schedules`, `shared-owner` |
| Transport and discovery | `index`, `operations`, `scopes`, `capabilities`, `receipts`, `transport-client`, `relay-control`, `shared-*` |
| Live history | `live-history` |

Functional `*-contract.md` documents describe product boundaries. Feature fixtures cover each fixed method, `operation-registry.json` freezes method/read order, and Rust fixture tests verify only the opaque relay envelope. Run `npm run test:protocol` from the repository root and compile all `test/*.ts` fixtures with TypeScript strict mode. Every code file remains below 700 physical lines.

## Versioned distribution

Version 0.19.0 adds optional behaviour that older peers never see. Personal connections send
`X-Kun-Relay-Features` (presence, authorization, lossy); a relay that understands it echoes the
accepted names in hello and then sends relay notices (`event` frames without `src`) to
`deps.relay`. The lease length now comes from the relay, capped at five minutes, and renewal runs a
third of the way through it, so a sixty-second lease still renews every twenty seconds. One
acknowledgement covers every frame received before it is sent (sixteen frames, 1 MiB or 50 ms).
`Call.ifVersion` asks a desktop that lists `read.conditional` to answer `{ readUnchanged, readVersion }`
for an unchanged read. `live-history` defines the page deltas of `history.live` subscriptions. See
[relay-control-contract.md](relay-control-contract.md) and [live-history-contract.md](live-history-contract.md).
`utf8Size` and fragment splitting return the same results as before, without per-character allocation.

Version 0.18.2 stops automatic connection attempts after HTTP 401/403, explicit login/device
revocation failures, or socket replacement (4409). `state(false, reason)` reports the stop even
if no connection succeeded. After repairing authorization, call `start()` explicitly; network
`reconnect()` does not resume a stopped client. Lease expiry (4401) and authorization changes
(4403) request a fresh ticket; only a definitive HTTP rejection stops that recovery. Network
errors, timeouts, 429 and 5xx retain jittered exponential backoff. A successful hello resets the
backoff only after the connection has stayed online for 60 seconds. Business calls are never
automatically replayed. `RemoteError.status` preserves the HTTP status alongside its error code.
Disconnect also clears heartbeat state, so recovery and authorization repair retain pong
deadlines. Diagnostic callbacks run after the failed connection is fenced and released;
synchronous stop/restart callbacks cannot leave old sockets or timers alive.

Create the archive with `npm pack` from this directory, using a temporary output directory. Consumers pin its versioned filename and integrity in their package manifests and lockfiles. Do not overwrite an archive with different contents under the same version.

Each consumer's `vendor` directory keeps only the archive required by its current manifests and lockfiles. When updating, install and verify the new package in every affected consumer before removing superseded archives. Check scripts and tests for old paths as well; do not delete a still-referenced archive merely because its version is older. Keep any necessary historical artifacts outside the source checkout, rather than accumulating release copies in `vendor`.
