export const VERSION = 1
export const LIMITS = Object.freeze({
  frame: 262144,
  message: 4194304,
  pending: 64,
  bytes: 8388608,
  controlPending: 2,
  controlBytes: 65536,
  file: 26214400
})
export const METHODS = Object.freeze([
  'catalog.get',
  'agent.list',
  'agent.history',
  'agent.message.send',
  'code.list',
  'code.history',
  'code.create',
  'code.turn.start',
  'execution.stop',
  'request.get',
  'approval.list',
  'approval.prepare',
  'approval.resolve',
  'input.resolve',
  'attachment.receive',
  'attachment.export'
])
export const READ_METHODS = new Set([
  'catalog.get',
  'agent.list',
  'agent.history',
  'code.list',
  'code.history',
  'request.get',
  'approval.list'
])
export const KINDS = new Set([
  'hello',
  'link.open',
  'invoke',
  'result',
  'subscribe',
  'event',
  'ack',
  'resync_required',
  'fragment',
  'error',
  'ping',
  'pong'
])
export function utf8Size(value) {
  let size = 0
  for (const char of value) {
    const n = char.codePointAt(0)
    size += n <= 0x7f ? 1 : n <= 0x7ff ? 2 : n <= 0xffff ? 3 : 4
  }
  return size
}
export function canonical(value) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean')
    return JSON.stringify(value)
  if (typeof value === 'number' && Number.isFinite(value))
    return JSON.stringify(value)
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']'
  if (value && typeof value === 'object')
    return (
      '{' +
      Object.keys(value)
        .sort()
        .map((k) => JSON.stringify(k) + ':' + canonical(value[k]))
        .join(',') +
      '}'
    )
  throw new Error('INVALID_VALUE')
}
export function parseFrame(raw) {
  if (typeof raw !== 'string' || utf8Size(raw) > LIMITS.frame)
    throw new Error('FRAME_LIMIT')
  const f = JSON.parse(raw)
  if (
    !f ||
    f.v !== VERSION ||
    !KINDS.has(f.kind) ||
    (f.id !== undefined && !validId(f.id)) ||
    (f.dst !== undefined && !validId(f.dst)) ||
    (f.src !== undefined && !validId(f.src))
  )
    throw new Error('PROTOCOL_ERROR')
  return f
}
export function validId(id) {
  return typeof id === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(id)
}
export function validateCall(call) {
  if (
    !call ||
    !METHODS.includes(call.method) ||
    !validId(call.requestId) ||
    !Number.isSafeInteger(call.expiresAt) ||
    !call.params ||
    typeof call.params !== 'object' ||
    Array.isArray(call.params)
  )
    throw new Error('INVALID_CALL')
  if (utf8Size(canonical(call)) > LIMITS.message)
    throw new Error('MESSAGE_LIMIT')
  return call
}
export function encodeFrames(frame) {
  const raw = JSON.stringify(frame)
  if (utf8Size(raw) <= LIMITS.frame) return [raw]
  if (utf8Size(raw) > LIMITS.message || !validId(frame.id))
    throw new Error('MESSAGE_LIMIT')
  // Split by code points, never split surrogate pairs; account for JSON escaping.
  const parts = []
  let part = '',
    size = 0
  for (const char of raw) {
    const n = utf8Size(JSON.stringify(char)) - 2
    if (size + n > 192000) {
      parts.push(part)
      part = ''
      size = 0
    }
    part += char
    size += n
  }
  if (part) parts.push(part)
  return parts.map((data, index) =>
    JSON.stringify({
      v: VERSION,
      kind: 'fragment',
      id: frame.id,
      dst: frame.dst,
      src: frame.src,
      payload: { index, total: parts.length, data }
    })
  )
}
export class Reassembler {
  constructor(now = Date.now) {
    this.now = now
    this.entries = new Map()
    this.bytes = 0
  }
  clear() {
    this.entries.clear()
    this.bytes = 0
  }
  prune() {
    for (const [key, e] of this.entries)
      if (this.now() - e.at > 30000) {
        this.bytes -= e.bytes
        this.entries.delete(key)
      }
  }
  accept(frame) {
    this.prune()
    if (frame.kind !== 'fragment') return frame
    const p = frame.payload,
      key = frame.src + ':' + frame.id
    if (
      !p ||
      !Number.isInteger(p.index) ||
      !Number.isInteger(p.total) ||
      p.total < 1 ||
      p.total > 128 ||
      p.index < 0 ||
      p.index >= p.total ||
      typeof p.data !== 'string'
    )
      throw new Error('BAD_FRAGMENT')
    let e = this.entries.get(key)
    if (!e) {
      if (this.entries.size >= 64) throw new Error('BACKPRESSURE')
      e = { parts: new Map(), bytes: 0, total: p.total, at: this.now() }
      this.entries.set(key, e)
    }
    if (e.total !== p.total) throw new Error('BAD_FRAGMENT')
    if (e.parts.has(p.index)) {
      if (e.parts.get(p.index) !== p.data) throw new Error('BAD_FRAGMENT')
      return null
    }
    const size = utf8Size(p.data)
    if (e.bytes + size > LIMITS.message || this.bytes + size > LIMITS.bytes)
      throw new Error('BACKPRESSURE')
    e.parts.set(p.index, p.data)
    e.bytes += size
    this.bytes += size
    if (e.parts.size !== e.total) return null
    const raw = Array.from({ length: e.total }, (_, i) => e.parts.get(i)).join(
      ''
    )
    this.bytes -= e.bytes
    this.entries.delete(key)
    const result = JSON.parse(raw)
    if (
      result.v !== VERSION ||
      !KINDS.has(result.kind) ||
      result.kind === 'fragment' ||
      result.id !== frame.id ||
      result.dst !== frame.dst
    )
      throw new Error('BAD_FRAGMENT')
    // The authenticated relay source wins over any source in the inner frame.
    result.src = frame.src
    return result
  }
}
export class RemoteError extends Error {
  constructor(code, uncertain = false) {
    super(code)
    this.code = code
    this.uncertain = uncertain
  }
}
export { RemoteClient } from './client.js'
export { RemoteApi } from './api.js'
