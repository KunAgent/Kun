export const VERSION: 1
export const LIMITS: Readonly<{
  frame: number
  message: number
  pending: number
  bytes: number
  controlPending: number
  controlBytes: number
  file: number
}>
export const METHODS: readonly string[]
export const READ_METHODS: Set<string>
export const KINDS: Set<string>
export interface Frame {
  v?: number
  kind: string
  id?: string
  src?: string
  dst?: string
  payload?: any
}
export interface Call {
  method: string
  requestId: string
  expiresAt: number
  params: Record<string, unknown>
}
export interface Socket {
  onopen: (() => void) | null
  onmessage: ((event: { data: unknown }) => void) | null
  onerror: ((error: unknown) => void) | null
  onclose: (() => void) | null
  bufferedAmount?: number
  send(data: string): void
  close(): void
}
export interface ClientDependencies {
  ticket(): Promise<{ url: string; ticket: string }>
  renew(): Promise<unknown>
  socket(url: string, headers: Record<string, string>): Socket
  state?(online: boolean): void
  frame?(frame: Frame): void
}
export function canonical(value: unknown): string
export function utf8Size(value: string): number
export function parseFrame(raw: string): Frame
export function validId(id: unknown): id is string
export function validateCall(call: unknown): Call
export function encodeFrames(frame: Frame): string[]
export class Reassembler {
  constructor(now?: () => number)
  clear(): void
  accept(frame: Frame): Frame | null
}
export class RemoteError extends Error {
  code: string
  uncertain: boolean
  constructor(code: string, uncertain?: boolean)
}
export class RemoteClient {
  online: boolean
  constructor(deps: ClientDependencies)
  start(): void
  stop(): void
  send(frame: Frame): void
  invoke<T = any>(dst: string, call: Call, timeout?: number): Promise<T>
}
export interface DeviceIdentity {
  id: string
  credential: string
}
export interface Device {
  id: string
  name: string
  role: 'host' | 'controller'
  platform: string
  enabled: boolean
  online: boolean | null
  version: number
}
export class RemoteApi {
  constructor(deps: {
    origin: string
    token(): Promise<string | null>
    identity(): Promise<DeviceIdentity>
    fetch?: typeof fetch
  })
  request<T = any>(
    path: string,
    method?: string,
    body?: any,
    raw?: boolean,
    signal?: AbortSignal
  ): Promise<T>
  ticket(): Promise<{ url: string; ticket: string }>
  renew(): Promise<unknown>
}
