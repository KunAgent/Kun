import { RemoteError } from './index.js'
export class RemoteApi {
  constructor({ origin, token, identity, fetch: fetcher = globalThis.fetch }) {
    const url = new URL(origin)
    if (
      url.protocol !== 'https:' &&
      !(
        url.protocol === 'http:' &&
        ['localhost', '127.0.0.1'].includes(url.hostname)
      )
    )
      throw new Error('UNTRUSTED_ORIGIN')
    this.origin = url.origin
    this.token = token
    this.identity = identity
    this.fetch = fetcher
  }
  async request(path, method = 'GET', body, raw = false, signal) {
    if (!/^\/[a-z0-9/-]+$/.test(path)) throw new Error('INVALID_PATH')
    const identity = await this.identity(),
      token = await this.token()
    if (!token) throw new RemoteError('LOGIN_REQUIRED')
    const controller = new AbortController()
    const abort = () => controller.abort()
    if(signal?.aborted)abort()
    signal?.addEventListener('abort',abort,{once:true})
    const timeout = setTimeout(() => controller.abort(), raw ? 120000 : 15000)
    try {
      const headers = {
        Authorization: 'Bearer ' + token,
        'X-Kun-Device': identity.id,
        'X-Kun-Device-Credential': identity.credential
      }
      if (body !== undefined)
        headers['Content-Type'] = raw
          ? 'application/octet-stream'
          : 'application/json'
      const r = await this.fetch(this.origin + '/api/remote/v1' + path, {
        method,
        headers,
        body:
          body === undefined ? undefined : raw ? body : JSON.stringify(body),
        redirect: 'error',
        signal: controller.signal
      })
      if (!r.ok) {
        let code = 'HTTP_' + r.status
        try {
          const v = await r.json()
          if (typeof v.error === 'string') code = v.error
        } catch {}
        throw new RemoteError(code)
      }
      return raw ? r : await r.json()
    } finally {
      signal?.removeEventListener('abort',abort)
      clearTimeout(timeout)
    }
  }
  ticket() {
    return this.request('/relay-tickets', 'POST')
  }
  renew() {
    return this.request('/relay-lease', 'POST')
  }
}
