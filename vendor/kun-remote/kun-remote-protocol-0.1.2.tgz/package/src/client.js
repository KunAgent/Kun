import {
  VERSION,
  LIMITS,
  RemoteError,
  parseFrame,
  encodeFrames,
  Reassembler,
  utf8Size,
  validateCall
} from './index.js'
/** Transport only. Host owns auth, durable request receipts, history and retry decisions. */
export class RemoteClient {
  constructor(deps) {
    this.deps = deps
    this.pending = new Map()
    this.bytes = 0
    this.generation = 0
    this.assembly = new Reassembler()
    this.online = false
    this.stopped = true
    this.failures = 0
  }
  start() {
    if (!this.stopped) return
    this.stopped = false
    void this.connect()
  }
  stop() {
    this.stopped = true
    ++this.generation
    clearTimeout(this.retry)
    clearTimeout(this.renewal)
    this.ws?.close()
    this.disconnect()
  }
  disconnect() {
    this.online = false
    this.assembly.clear()
    for (const p of this.pending.values()) {
      clearTimeout(p.timer)
      p.reject(new RemoteError('RESULT_UNKNOWN', true))
    }
    this.pending.clear()
    this.bytes = 0
    this.deps.state?.(false)
  }
  async connect() {
    const generation = ++this.generation
    try {
      const ticket = await this.deps.ticket()
      if (this.stopped || generation !== this.generation) return
      const ws = this.deps.socket(ticket.url, {
        Authorization: 'Ticket ' + ticket.ticket
      })
      this.ws = ws
      let helloTimer = setTimeout(() => ws.close(), 10000)
      ws.onopen = () => {}
      ws.onmessage = (event) => {
        if (generation !== this.generation || this.stopped) return
        try {
          const part = parseFrame(String(event.data))
          if (part.kind !== 'hello' && part.kind !== 'pong')
            ws.send(JSON.stringify({ v: VERSION, kind: 'ack' }))
          const f = this.assembly.accept(part)
          if (!f) return
          if (f.kind === 'hello') {
            clearTimeout(helloTimer)
            this.online = true
            this.failures = 0
            this.deps.state?.(true)
            this.scheduleRenewal(generation)
          } else if (f.kind === 'result' || f.kind === 'error') {
            const p = this.pending.get(f.id)
            if (!p || (f.kind === 'result' && f.src !== p.dst)) return
            clearTimeout(p.timer)
            this.pending.delete(f.id)
            this.bytes -= p.size
            if (f.kind === 'error' || f.payload?.error)
              p.reject(
                new RemoteError(
                  f.payload?.error?.code ?? f.payload?.code ?? 'REMOTE_ERROR',
                  !!f.payload?.error?.uncertain
                )
              )
            else p.resolve(f.payload)
          } else this.deps.frame?.(f)
        } catch {
          ws.close()
        }
      }
      ws.onerror = () => ws.close()
      ws.onclose = () => {
        clearTimeout(helloTimer)
        if (generation !== this.generation) return
        clearTimeout(this.renewal)
        this.disconnect()
        this.reconnect()
      }
    } catch {
      if (generation === this.generation) {
        this.disconnect()
        this.reconnect()
      }
    }
  }
  reconnect() {
    if (this.stopped) return
    clearTimeout(this.retry)
    const delay = Math.min(30000, 1000 * 2 ** Math.min(this.failures++, 5))
    this.retry = setTimeout(
      () => void this.connect(),
      delay * (0.8 + Math.random() * 0.4)
    )
  }
  scheduleRenewal(generation) {
    clearTimeout(this.renewal)
    this.renewal = setTimeout(async () => {
      try {
        this.send({ kind: 'ping' })
        await this.deps.renew()
        if (generation === this.generation && !this.stopped)
          this.scheduleRenewal(generation)
      } catch {
        if (generation === this.generation) this.ws?.close()
      }
    }, 30000)
  }
  send(frame) {
    if (!this.online || !this.ws) throw new RemoteError('DEVICE_OFFLINE')
    const frames = encodeFrames({ v: VERSION, ...frame })
    const control = frame.kind === 'invoke' && frame.payload?.method === 'execution.stop'
    if (
      (this.ws.bufferedAmount ?? 0) +
        frames.reduce((n, f) => n + utf8Size(f), 0) >
      (control ? LIMITS.bytes : LIMITS.bytes - LIMITS.controlBytes)
    )
      throw new RemoteError('BACKPRESSURE')
    for (const raw of frames) this.ws.send(raw)
  }
  invoke(dst, call, timeout = 30000) {
    validateCall(call)
    if (!this.online) return Promise.reject(new RemoteError('DEVICE_OFFLINE'))
    const size = utf8Size(JSON.stringify(call))
    const control = call.method === 'execution.stop'
    if (this.pending.has(call.requestId))
      return Promise.reject(new RemoteError('REQUEST_IN_FLIGHT'))
    const lane = [...this.pending.values()].filter((p) => p.control === control)
    const laneBytes = lane.reduce((n, p) => n + p.size, 0)
    if (lane.length >= (control ? LIMITS.controlPending : LIMITS.pending - LIMITS.controlPending) ||
      laneBytes + size > (control ? LIMITS.controlBytes : LIMITS.bytes - LIMITS.controlBytes) ||
      this.pending.size >= LIMITS.pending || this.bytes + size > LIMITS.bytes)
      return Promise.reject(new RemoteError('BACKPRESSURE'))
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        if (!this.pending.delete(call.requestId)) return
        this.bytes -= size
        reject(new RemoteError('RESULT_UNKNOWN', true))
      }, timeout)
      this.pending.set(call.requestId, { dst, resolve, reject, timer, size, control })
      this.bytes += size
      try {
        this.send({ kind: 'invoke', id: call.requestId, dst, payload: call })
      } catch (error) {
        clearTimeout(timer)
        this.pending.delete(call.requestId)
        this.bytes -= size
        reject(error)
      }
    })
  }
}
