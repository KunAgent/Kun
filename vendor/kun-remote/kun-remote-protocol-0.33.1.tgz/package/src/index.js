import { OPERATION_METHODS, OPERATION_READ_METHODS, validateOperationParams } from './operations.js'
export * from './direct-address.js'
export * from './direct-codec.js'
export * from './direct-socket.js'
export * from './direct-api.js'
export { Sender } from './sender.js'
import { validateProjectExport } from './project-files.js'
import { validateArtifactPreviewExport } from './artifact-preview.js'
import { EPHEMERAL_METHODS } from './desktop-session.js'
import { validateAvatarExport } from './agent-avatars.js'
export { OPERATION_METHODS, OPERATION_READ_METHODS, validateOperationParams } from './operations.js'
export * from './dispatch.js'
export * from './usage-summary.js'
export * from './provider-quotas.js'
export * from './tasks.js'
export * from './task-settings.js'
export * from './models.js'
export * from './model-info.js'
export * from './messages.js'
export * from './attention.js'
export * from './artifacts.js'
export * from './artifact-preview.js'
export * from './attachment-preview.js'
export * from './agent-directory.js'
export * from './execution.js'
export * from './goals.js'
export * from './agent-profiles.js'
export * from './agent-memory.js'
export * from './agent-commitments.js'
export * from './project-files.js'
export * from './work.js'
export * from './groups.js'
export * from './collaboration.js'
export * from './plugins.js'
export * from './schedules.js'
export * from './agent-avatars.js'
export * from './agent-capabilities.js'
export * from './history-actions.js'
export * from './agent-memory-review.js'
export * from './agent-library.js'
export * from './agent-reminders.js'
export * from './agent-lifecycle.js'
export * from './agent-import.js'
export * from './shared-owner.js'
export * from './agent-appearance.js'
export * from './scopes.js'
export { normalizeCapabilities, hasOperation } from './capabilities.js'
export { REJECTION_CODES, isDefinitiveReceiptRejection } from './receipts.js'
export const VERSION = 1
export const LIMITS = Object.freeze({
  frame: 262144,
  message: 4194304,
  pending: 64,
  bytes: 8388608,
  controlPending: 2,
  controlBytes: 65536,
  desktopControlPending: 2,
  desktopControlBytes: 16384,
  file: 26214400
})
export const METHODS = Object.freeze([
  'catalog.get',
  'agent.list',
  'agent.history',
  'agent.message.send',
  'code.list',
  'code.history',
  'code.create',
  'code.turn.start',
  'execution.stop',
  'request.get',
  'approval.list',
  'approval.prepare',
  'approval.resolve',
  'input.resolve',
  'attachment.receive',
  'attachment.export',
  ...OPERATION_METHODS
])
export const READ_METHODS = new Set([
  'catalog.get',
  'agent.list',
  'agent.history',
  'code.list',
  'code.history',
  'request.get',
  'approval.list',
  ...OPERATION_READ_METHODS
])
export const KINDS = new Set([
  'hello',
  'link.open',
  'invoke',
  'result',
  'subscribe',
  'event',
  'ack',
  'resync_required',
  'fragment',
  'error',
  'ping',
  'pong'
])
/** UTF-8 bytes of a JS string; a lone surrogate counts as its 3-byte replacement, as before. */
export function utf8Size(value) {
  let size = 0
  for (let index = 0; index < value.length; index++) {
    const code = value.charCodeAt(index)
    if (code < 0x80) size += 1
    else if (code < 0x800) size += 2
    else if (code >= 0xd800 && code <= 0xdbff && index + 1 < value.length) {
      const low = value.charCodeAt(index + 1)
      if (low >= 0xdc00 && low <= 0xdfff) { size += 4; index++ } else size += 3
    } else size += 3
  }
  return size
}
/** Bytes one code unit (or surrogate pair) adds inside a JSON string, matching JSON.stringify. */
function escapedSize(code, low) {
  if (code === 0x22 || code === 0x5c) return 2
  if (code < 0x20) return [0x08, 0x09, 0x0a, 0x0c, 0x0d].includes(code) ? 2 : 6
  if (code < 0x80) return 1
  if (code < 0x800) return 2
  if (code >= 0xd800 && code <= 0xdbff) return low >= 0xdc00 && low <= 0xdfff ? 4 : 6
  if (code >= 0xdc00 && code <= 0xdfff) return 6
  return 3
}
export function canonical(value) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean')
    return JSON.stringify(value)
  if (typeof value === 'number' && Number.isFinite(value))
    return JSON.stringify(value)
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']'
  if (value && typeof value === 'object')
    return (
      '{' +
      Object.keys(value)
        .sort()
        .map((k) => JSON.stringify(k) + ':' + canonical(value[k]))
        .join(',') +
      '}'
    )
  throw new Error('INVALID_VALUE')
}
export function parseFrame(raw) {
  if (typeof raw !== 'string' || utf8Size(raw) > LIMITS.frame)
    throw new Error('FRAME_LIMIT')
  const f = JSON.parse(raw)
  if (
    !f ||
    f.v !== VERSION ||
    !KINDS.has(f.kind) ||
    (f.id !== undefined && !validId(f.id)) ||
    (f.dst !== undefined && !validId(f.dst)) ||
    (f.src !== undefined && !validId(f.src))
  )
    throw new Error('PROTOCOL_ERROR')
  return f
}
export function validId(id) {
  return typeof id === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(id)
}
/** Opaque read version from a desktop answer; empty means "no cached copy, send one". */
export function validVersion(value) {
  return typeof value === 'string' && /^[a-zA-Z0-9_-]{0,64}$/.test(value)
}
export function validateCall(call) {
  if (
    !call ||
    !METHODS.includes(call.method) ||
    !validId(call.requestId) ||
    !Number.isSafeInteger(call.expiresAt) ||
    !call.params ||
    typeof call.params !== 'object' ||
    Array.isArray(call.params) ||
    (call.ifVersion !== undefined && (EPHEMERAL_METHODS.has(call.method) || !READ_METHODS.has(call.method) || !validVersion(call.ifVersion)))
  )
    throw new Error('INVALID_CALL')
  if (OPERATION_METHODS.includes(call.method)) validateOperationParams(call.method, call.params)
  if (call.method === 'attachment.export' && ['previewResource', 'previewId', 'previewRevision', 'previewAssetId'].some((key) => Object.hasOwn(call.params, key)))
    validateArtifactPreviewExport(call.params)
  if (call.method === 'attachment.export' && Object.hasOwn(call.params, 'avatarRevision')) validateAvatarExport(call.params)
  if (call.method === 'attachment.export' && ['projectId', 'fileRef', 'revision'].some((key) => Object.hasOwn(call.params, key)))
    validateProjectExport(call.params)
  if (utf8Size(canonical(call)) > LIMITS.message)
    throw new Error('MESSAGE_LIMIT')
  return call
}
export function encodeFrames(frame) {
  const raw = JSON.stringify(frame)
  if (utf8Size(raw) <= LIMITS.frame) return [raw]
  if (utf8Size(raw) > LIMITS.message || !validId(frame.id))
    throw new Error('MESSAGE_LIMIT')
  // Split by code points, never split surrogate pairs; account for JSON escaping.
  const parts = []
  let start = 0,
    size = 0
  for (let index = 0; index < raw.length; ) {
    const code = raw.charCodeAt(index), low = raw.charCodeAt(index + 1)
    const width = code >= 0xd800 && code <= 0xdbff && low >= 0xdc00 && low <= 0xdfff ? 2 : 1
    const n = escapedSize(code, low)
    if (size + n > 192000) {
      parts.push(raw.slice(start, index))
      start = index
      size = 0
    }
    size += n
    index += width
  }
  if (start < raw.length) parts.push(raw.slice(start))
  return parts.map((data, index) =>
    JSON.stringify({
      v: VERSION,
      kind: 'fragment',
      id: frame.id,
      dst: frame.dst,
      src: frame.src,
      payload: { index, total: parts.length, data }
    })
  )
}
export class Reassembler {
  constructor(now = Date.now, budget) {
    this.now = now
    this.budget = budget
    this.entries = new Map()
    this.bytes = 0
  }
  clear() {
    for (const e of this.entries.values()) e.reservation?.release()
    this.entries.clear()
    this.bytes = 0
  }
  prune() {
    for (const [key, e] of this.entries)
      if (this.now() - e.at > 30000) {
        e.reservation?.release()
        this.bytes -= e.bytes
        this.entries.delete(key)
      }
  }
  accept(frame) {
    this.prune()
    if (frame.kind !== 'fragment') return frame
    const p = frame.payload,
      key = frame.src + ':' + frame.id
    if (
      !p ||
      !Number.isInteger(p.index) ||
      !Number.isInteger(p.total) ||
      p.total < 1 ||
      p.total > 128 ||
      p.index < 0 ||
      p.index >= p.total ||
      typeof p.data !== 'string'
    )
      throw new Error('BAD_FRAGMENT')
    let e = this.entries.get(key)
    if (!e) {
      if (this.entries.size >= 64) throw new Error('BACKPRESSURE')
      e = { parts: new Map(), bytes: 0, total: p.total, at: this.now(), reservation: this.budget?.beginAssembly(frame.src ?? '') }
      this.entries.set(key, e)
    }
    if (e.total !== p.total) throw new Error('BAD_FRAGMENT')
    if (e.parts.has(p.index)) {
      if (e.parts.get(p.index) !== p.data) throw new Error('BAD_FRAGMENT')
      return null
    }
    const size = utf8Size(p.data)
    if (e.bytes + size > LIMITS.message || this.bytes + size > LIMITS.bytes)
      throw new Error('BACKPRESSURE')
    try { e.reservation?.add(size) }
    catch (error) {
      e.reservation?.release(); this.bytes -= e.bytes; this.entries.delete(key)
      throw error
    }
    e.parts.set(p.index, p.data)
    e.bytes += size
    this.bytes += size
    if (e.parts.size !== e.total) return null
    const raw = Array.from({ length: e.total }, (_, i) => e.parts.get(i)).join(
      ''
    )
    this.bytes -= e.bytes
    e.reservation?.release()
    this.entries.delete(key)
    const result = JSON.parse(raw)
    if (
      result.v !== VERSION ||
      !KINDS.has(result.kind) ||
      result.kind === 'fragment' ||
      result.id !== frame.id ||
      result.dst !== frame.dst
    )
      throw new Error('BAD_FRAGMENT')
    // The authenticated relay source wins over any source in the inner frame.
    result.src = frame.src
    return result
  }
}
export class RemoteError extends Error {
  constructor(code, uncertain = false) {
    super(code)
    this.code = code
    this.uncertain = uncertain
  }
}
export { RemoteClient } from './client.js'
export * from './relay-control.js'
export * from './live-history.js'
export * from './history-sync.js'
export { RemoteApi } from './api.js'
export { ShareClient, SharedReassembler, validateShareLease, SHARED_READ_METHODS, SHARED_WRITE_METHODS } from './shared-client.js'
export { RequestBudget } from './request-budget.js'
export { validateSharedOwnerParams } from './shared-owner.js'
export { validSourceTurnId, validateSourceContentParams } from './source-content.js'

export * from './live-directory.js'

export { VIP_TIERS, vipRequirement, parseEntitlements } from './entitlements.js'

export * from './desktop-session.js'
export * from './desktop-signaling.js'
export * from './desktop-input.js'
export * from './terminal.js'
