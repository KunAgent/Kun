const LEGACY_FEATURES = Object.freeze({
  'catalog.get': [],
  'agent.list': ['agent'], 'agent.history': ['agent'], 'agent.message.send': ['agent'],
  'code.list': ['code'], 'code.history': ['code'], 'code.create': ['code'], 'code.turn.start': ['code'],
  'execution.stop': ['code', 'agent'], 'request.get': ['code', 'agent'],
  'approval.list': ['approvals'], 'approval.prepare': ['approvals'],
  'approval.resolve': ['approvals'], 'input.resolve': ['approvals'],
  'attachment.receive': ['attachments'], 'attachment.export': ['attachments']
})
const RESOURCE_KINDS = new Set(['catalog', 'code', 'agent', 'message', 'attention', 'artifact', 'project', 'file', 'group', 'collaboration', 'schedule', 'plugin', 'share', 'desktop', 'terminal', 'simulator'])
function record(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}
function name(value) {
  return typeof value === 'string' && /^[a-z][a-zA-Z0-9_.-]{0,127}$/.test(value)
}
function validDescriptor(value) {
  return record(value) && name(value.operation) && value.schemaVersion === 1 &&
    RESOURCE_KINDS.has(value.resourceKind) && Array.isArray(value.allowedActions) &&
    value.allowedActions.length <= 32 && value.allowedActions.every(name) &&
    ['supported', 'enabled', 'authorized', 'online'].every((key) => typeof value[key] === 'boolean') &&
    (value.limits === undefined || (record(value.limits) && Object.keys(value.limits).length <= 32 &&
      Object.entries(value.limits).every(([key, limit]) => name(key) && Number.isSafeInteger(limit) && limit >= 0)))
}

/** Normalize capability hints only; neither this result nor a cached hint grants access. */
export function normalizeCapabilities(value) {
  const source = record(value) ? value : {}
  const capabilities = Array.isArray(source.capabilities)
    ? [...new Set(source.capabilities.filter(name))].slice(0, 128) : []
  if (source.capabilityDescriptors === undefined) return { capabilities }
  if (!Array.isArray(source.capabilityDescriptors) || source.capabilityDescriptors.length > 128)
    return { capabilities: [], capabilityDescriptors: [] }
  const capabilityDescriptors = source.capabilityDescriptors.slice(0, 128)
    .filter((descriptor) => record(descriptor) && name(descriptor.operation))
    .map((descriptor) => validDescriptor(descriptor)
      ? { operation: descriptor.operation, schemaVersion: 1, resourceKind: descriptor.resourceKind,
          supported: descriptor.supported, enabled: descriptor.enabled,
          authorized: descriptor.authorized, online: descriptor.online,
          allowedActions: [...descriptor.allowedActions],
          ...(descriptor.limits === undefined ? {} : { limits: { ...descriptor.limits } }) }
      // Keep an explicit denial so a malformed/future descriptor cannot fall back to a legacy string.
      : { operation: descriptor.operation, schemaVersion: 1, resourceKind: 'catalog',
          allowedActions: [], supported: false, enabled: false, authorized: false, online: false })
  return { capabilities, capabilityDescriptors }
}

/** Undefined means no catalog. New operations are never inferred from an old broad feature. */
export function hasOperation(catalog, operation, resourceKind) {
  if (catalog === undefined || catalog === null) return undefined
  const normalized = normalizeCapabilities(catalog)
  const descriptors = normalized.capabilityDescriptors?.filter((value) => value.operation === operation)
  if (descriptors?.length) {
    const matching = resourceKind ? descriptors.filter((value) => value.resourceKind === resourceKind) : descriptors
    // Ambiguous or denied projections fail closed until a fresh, unambiguous catalog is available.
    return matching.length > 0 && matching.every((value) =>
      value.supported && value.enabled && value.authorized && value.online)
  }
  if (normalized.capabilities.includes(operation)) return true
  if (operation === 'catalog.get') return true
  return (LEGACY_FEATURES[operation] ?? []).some((feature) => normalized.capabilities.includes(feature))
}
