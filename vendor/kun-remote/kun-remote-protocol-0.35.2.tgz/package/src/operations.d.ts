import type { DispatchParams, DispatchResults } from './dispatch.js'
import type { SimulatorParams, SimulatorResults } from './simulator.js'
import type { CodeChangesParams, CodeChangesResults } from './code-changes.js'
import type { UsageSummaryParams, UsageSummaryResults } from './usage-summary.js'
import type { ProviderQuotaParams, ProviderQuotaResults } from './provider-quotas.js'
import type { DesktopParams, DesktopResults } from './desktop-session.js'
import type { TerminalParams, TerminalResults } from './terminal.js'
import type { Call } from './index.js'
import type { TaskParams, TaskResults } from './tasks.js'
import type { TaskSettingsParams, TaskSettingsResults } from './task-settings.js'
import type { MessageParams, MessageResults } from './messages.js'
import type { AttentionParams, AttentionResults } from './attention.js'
import type { ArtifactParams, ArtifactResults } from './artifacts.js'
import type { ArtifactPreviewParams, ArtifactPreviewResults } from './artifact-preview.js'
import type { AgentDirectoryParams, AgentDirectoryResults } from './agent-directory.js'
import type { ExecutionParams, ExecutionResults } from './execution.js'
import type { GoalParams, GoalResults } from './goals.js'
import type { AgentProfileParams, AgentProfileResults } from './agent-profiles.js'
import type { AgentMemoryParams, AgentMemoryResults } from './agent-memory.js'
import type { AgentCommitmentParams, AgentCommitmentResults } from './agent-commitments.js'
import type { ProjectFilesParams, ProjectFilesResults } from './project-files.js'
import type { WorkParams, WorkResults } from './work.js'
import type { GroupParams, GroupResults } from './groups.js'
import type { CollaborationParams, CollaborationResults } from './collaboration.js'
import type { PluginParams, PluginResults } from './plugins.js'
import type { ScheduleParams, ScheduleResults } from './schedules.js'
import type { AgentAvatarParams, AgentAvatarResults } from './agent-avatars.js'
import type { AgentCapabilityParams, AgentCapabilityResults } from './agent-capabilities.js'
import type { HistoryActionParams, HistoryActionResults } from './history-actions.js'
import type { AgentHistoryParams, AgentHistoryResults } from './agent-memory-review.js'
import type { AgentLibraryParams, AgentLibraryResults } from './agent-library.js'
import type { ReminderParams, ReminderResults } from './agent-reminders.js'
import type { AgentLifecycleParams, AgentLifecycleResults } from './agent-lifecycle.js'
import type { AgentImportParams, AgentImportResults } from './agent-import.js'
import type { SharedOwnerParams, SharedOwnerResults } from './shared-owner.js'
import type { SourceContentOperationParams, SourceContentOperationResults } from './source-content.js'
import type { AttachmentPreviewParams, AttachmentPreviewResults } from './attachment-preview.js'

export interface RemoteParams extends
  SimulatorParams, CodeChangesParams,
  UsageSummaryParams, ProviderQuotaParams,
  AttachmentPreviewParams,
  DispatchParams,
  DesktopParams,
  TerminalParams,
  TaskParams,
  TaskSettingsParams,
  MessageParams,
  AttentionParams,
  ArtifactParams,
  ArtifactPreviewParams,
  AgentDirectoryParams,
  ExecutionParams,
  GoalParams,
  AgentProfileParams,
  AgentMemoryParams,
  AgentCommitmentParams,
  ProjectFilesParams,
  WorkParams,
  GroupParams,
  CollaborationParams,
  PluginParams,
  ScheduleParams,
  AgentAvatarParams,
  AgentCapabilityParams,
  HistoryActionParams,
  AgentHistoryParams,
  AgentLibraryParams,
  ReminderParams,
  AgentLifecycleParams,
  AgentImportParams,
  SharedOwnerParams,
  SourceContentOperationParams {}
export interface RemoteResults extends
  SimulatorResults, CodeChangesResults,
  UsageSummaryResults, ProviderQuotaResults,
  AttachmentPreviewResults,
  DispatchResults,
  DesktopResults,
  TerminalResults,
  TaskResults,
  TaskSettingsResults,
  MessageResults,
  AttentionResults,
  ArtifactResults,
  ArtifactPreviewResults,
  AgentDirectoryResults,
  ExecutionResults,
  GoalResults,
  AgentProfileResults,
  AgentMemoryResults,
  AgentCommitmentResults,
  ProjectFilesResults,
  WorkResults,
  GroupResults,
  CollaborationResults,
  PluginResults,
  ScheduleResults,
  AgentAvatarResults,
  AgentCapabilityResults,
  HistoryActionResults,
  AgentHistoryResults,
  AgentLibraryResults,
  ReminderResults,
  AgentLifecycleResults,
  AgentImportResults,
  SharedOwnerResults,
  SourceContentOperationResults {}
export type RemoteMethod = keyof RemoteParams
export type OperationCall<M extends RemoteMethod> = Omit<Call, 'method' | 'params'> & { method: M; params: RemoteParams[M] }
export const OPERATION_METHODS: readonly RemoteMethod[]
export const OPERATION_READ_METHODS: ReadonlySet<RemoteMethod>
export function validateOperationParams<M extends RemoteMethod>(method: M, params: unknown): RemoteParams[M]
