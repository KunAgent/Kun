import { check } from './validation.js'
import { GROUP_WRITE_METHODS } from './group-mutations.js'
export const REMOTE_SCOPES = Object.freeze(['personal', 'groups.read', 'groups.write', 'collaboration.read',
  'collaboration.control', 'schedules.read', 'extensions.read', 'extensions.control', 'shares.manage', 'desktop.view', 'desktop.control'])
export const OPERATION_REQUIRED_SCOPES = Object.freeze({
  'simulator.list': ['personal', 'desktop.view'],
  'simulator.start': ['personal', 'desktop.view', 'desktop.control'],
  'simulator.frame': ['personal', 'desktop.view'],
  'simulator.input': ['personal', 'desktop.view', 'desktop.control'],
  'simulator.stop': ['personal', 'desktop.view'],
  'usage.summary.get': ['personal'], 'usage.quotas.list': ['personal'],
  'attachment.preview': ['personal'],
  'dispatch.list': ['personal'], 'dispatch.catalog': ['personal'], 'dispatch.act': ['personal'],
  'desktop.displays.list': ['desktop.view'], 'desktop.session.start': ['desktop.view'],
  'desktop.session.answer': ['desktop.view'], 'desktop.signal.ice': ['desktop.view'],
  'desktop.session.reconnect': ['desktop.view'], 'desktop.session.quality': ['desktop.view'],
  'desktop.control.acquire': ['desktop.view', 'desktop.control'],
  'terminal.list': ['desktop.view', 'desktop.control'],
  'terminal.open': ['desktop.view', 'desktop.control'],
  'terminal.attach': ['desktop.view', 'desktop.control'],
  'terminal.write': ['desktop.view', 'desktop.control'],
  'terminal.resize': ['desktop.view', 'desktop.control'],
  'terminal.close': ['desktop.view', 'desktop.control'],
  'agent.directory.list': ['personal'],
  'group.list': ['groups.read'], 'group.history': ['groups.read'], 'group.message.send': ['groups.read', 'groups.write'],
  'group.get': ['groups.read'], ...Object.fromEntries(GROUP_WRITE_METHODS.map((method) => [method, ['groups.read', 'groups.write']])),
  'collaboration.runs.list': ['groups.read', 'collaboration.read'], 'collaboration.tasks.list': ['groups.read', 'collaboration.read'],
  'schedule.list': ['schedules.read'], 'schedule.runs.list': ['schedules.read'],
  'plugin.catalog': ['extensions.read'], 'plugin.view': ['extensions.read'], 'plugin.setEnabled': ['extensions.read', 'extensions.control'],
  'desktop.schedule.list': ['schedules.read'], 'desktop.schedule.runs.list': ['schedules.read'],
  'shares.list': ['shares.manage'], 'shares.manage': ['shares.manage']
})
export function normalizeRemoteScopes(value) {
  if (value === undefined) return ['personal']
  check(Array.isArray(value) && value.length <= REMOTE_SCOPES.length && new Set(value).size === value.length)
  check(value.every((scope) => REMOTE_SCOPES.includes(scope)))
  const scopes = REMOTE_SCOPES.filter((scope) => scope === 'personal' || value.includes(scope))
  check(!scopes.some((scope) => ['groups.write', 'collaboration.read', 'collaboration.control'].includes(scope)) || scopes.includes('groups.read'))
  check(!scopes.includes('collaboration.control') || scopes.includes('collaboration.read'))
  check(!scopes.includes('extensions.control') || scopes.includes('extensions.read'))
  check(!scopes.includes('desktop.control') || scopes.includes('desktop.view'))
  return scopes
}
export function hasRemoteOperationScope(method, scopes, receiptRead = false) {
  const required = OPERATION_REQUIRED_SCOPES[method]
  if (!required) return true
  const values = normalizeRemoteScopes(scopes)
  return required.filter((scope) => !receiptRead || !scope.endsWith('.write') && !scope.endsWith('.control')).every((scope) => values.includes(scope))
}
