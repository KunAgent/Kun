import { DESKTOP_LIMITS } from './desktop-limits.js'
import { TERMINAL_METHODS } from './terminal.js'
import { SIMULATOR_METHODS } from './simulator.js'
import { validateDesktopSdp, validateDesktopCandidateBatch } from './desktop-signaling.js'
import { object, id, optional, resource, integer, oneOf, check, epoch, boolean, byteString, displayRevision, quality, mode } from './desktop-validation.js'
export { DESKTOP_LIMITS } from './desktop-limits.js'
export const DESKTOP_CAPABILITY = 'desktop.session.v1'
export const DESKTOP_DEVICE_CAPABILITY = 'desktop.origin.device.v1'
export const DESKTOP_SCOPED_CAPABILITY = 'desktop.authorization.scoped.v1'
export const DESKTOP_METHODS = Object.freeze([
  'desktop.access.get',
  'desktop.displays.list', 'desktop.session.start', 'desktop.session.answer', 'desktop.signal.ice',
  'desktop.session.get', 'desktop.session.reconnect', 'desktop.session.cancel', 'desktop.session.stop',
  'desktop.control.acquire', 'desktop.control.release', 'desktop.session.quality'
])
export const DESKTOP_READ_METHODS = Object.freeze(['desktop.access.get', 'desktop.displays.list', 'desktop.session.get'])
export const DESKTOP_EPHEMERAL_METHODS = new Set(DESKTOP_METHODS)
export const EPHEMERAL_METHODS = new Set([...DESKTOP_METHODS, ...TERMINAL_METHODS, ...SIMULATOR_METHODS])
export const DESKTOP_STOP_METHODS = new Set(['desktop.session.stop', 'desktop.session.cancel'])
export function validateDesktopParams(method, value) {
  switch (method) {
    case 'desktop.access.get':
    case 'desktop.displays.list': object(value, []); break
    case 'desktop.session.start':
      object(value, ['startId', 'origin', 'displayToken', 'displayRevision', 'quality'])
      id(value.startId); resource(value.origin); id(value.displayToken); displayRevision(value.displayRevision); quality(value.quality)
      break
    case 'desktop.session.answer':
      object(value, ['sessionId', 'epoch', 'answer']); validateDesktopSdp(value.answer, 'answer'); break
    case 'desktop.signal.ice':
      object(value, ['sessionId', 'epoch', 'candidates', 'complete'])
      validateDesktopCandidateBatch(value.candidates); boolean(value.complete); break
    case 'desktop.session.get':
      object(value, [], ['startId', 'sessionId'])
      check(Number(Object.hasOwn(value, 'startId')) + Number(Object.hasOwn(value, 'sessionId')) === 1)
      if (value.startId !== undefined) id(value.startId)
      break
    case 'desktop.session.reconnect':
      object(value, ['sessionId', 'epoch', 'attemptId']); id(value.attemptId); break
    case 'desktop.session.cancel':
      object(value, ['startId', 'reason']); id(value.startId); byteString(value.reason, 80); break
    case 'desktop.session.stop':
      object(value, ['sessionId', 'observedEpoch', 'reason']); epoch(value.observedEpoch); byteString(value.reason, 80); break
    case 'desktop.control.acquire':
    case 'desktop.control.release': object(value, ['sessionId', 'epoch']); break
    case 'desktop.session.quality':
      object(value, ['sessionId', 'epoch', 'quality']); quality(value.quality); break
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  if (value.sessionId !== undefined) id(value.sessionId)
  if (value.epoch !== undefined) epoch(value.epoch)
  return value
}
export function validateDesktopDisplay(value) {
  object(value, ['token', 'revision', 'pixelWidth', 'pixelHeight', 'rotation'], ['label'])
  id(value.token); displayRevision(value.revision); optional(value, 'label', v => { byteString(v, 320); check(v.length <= 80) })
  integer(value.pixelWidth, 1, 32768); integer(value.pixelHeight, 1, 32768); oneOf(value.rotation, [0, 90, 180, 270])
  return value
}
export function validateDesktopSession(value) {
  object(value, ['schemaVersion', 'startId', 'sessionId', 'epoch', 'authorizationId', 'origin', 'display',
    'mode', 'controlAllowed', 'heartbeatMs', 'setupTimeoutMs', 'expiresInMs'])
  check(value.schemaVersion === 1)
  id(value.startId); id(value.sessionId); epoch(value.epoch); id(value.authorizationId); resource(value.origin)
  validateDesktopDisplay(value.display); mode(value.mode); boolean(value.controlAllowed)
  check(value.mode !== 'control' || value.controlAllowed)
  integer(value.heartbeatMs, 250, 10000); integer(value.setupTimeoutMs, 1, 30000); integer(value.expiresInMs, 0, 30000)
  return value
}
function sessionResult(value) {
  check(value !== null && typeof value === 'object')
  if (value.state === 'missing') object(value, ['state'])
  else if (value.state === 'ended') {
    object(value, ['state', 'startId', 'reason', 'confirmed'], ['sessionId'])
    id(value.startId); optional(value, 'sessionId', id); byteString(value.reason, 80); check(value.confirmed === true)
  } else {
    object(value, ['state', 'session'], ['offer'])
    oneOf(value.state, ['negotiating', 'viewing', 'controlling', 'reconnecting'])
    validateDesktopSession(value.session); optional(value, 'offer', v => validateDesktopSdp(v, 'offer'))
  }
  return value
}
export function validateDesktopResult(method, value) {
  if (method === 'desktop.access.get') {
    object(value, ['capabilities', 'supported', 'enabled', 'viewAllowed', 'controlAllowed', 'busy'])
    check(Array.isArray(value.capabilities) && value.capabilities.length <= 8)
    value.capabilities.forEach(item => byteString(item, 128))
    for (const field of ['supported', 'enabled', 'viewAllowed', 'controlAllowed', 'busy']) boolean(value[field])
    check(!value.controlAllowed || value.viewAllowed)
  } else if (method === 'desktop.displays.list') {
    object(value, ['displays']); check(Array.isArray(value.displays) && value.displays.length <= DESKTOP_LIMITS.displays)
    value.displays.forEach(validateDesktopDisplay)
    check(new Set(value.displays.map(d => d.token)).size === value.displays.length)
  } else if (['desktop.session.start', 'desktop.session.get', 'desktop.session.reconnect', 'desktop.session.stop', 'desktop.session.cancel'].includes(method)) {
    sessionResult(value)
    if (method === 'desktop.session.stop' || method === 'desktop.session.cancel') check(value.state === 'ended' || value.state === 'missing')
    if (value.state === 'negotiating' || value.state === 'reconnecting') check(value.offer !== undefined)
  }
  else if (method === 'desktop.session.answer' || method === 'desktop.signal.ice') {
    object(value, ['accepted']); check(value.accepted === true)
  } else if (method === 'desktop.control.acquire' || method === 'desktop.control.release') {
    object(value, ['mode', 'controlEpoch']); mode(value.mode); epoch(value.controlEpoch)
    check(value.mode === (method === 'desktop.control.acquire' ? 'control' : 'view'))
  } else if (method === 'desktop.session.quality') { object(value, ['quality']); quality(value.quality) }
  else throw new Error('UNSUPPORTED_OPERATION')
  return value
}

/** Safety lanes retain a boolean API for existing execution.stop callers. */
export function requestControlLane(method) {
  return DESKTOP_STOP_METHODS.has(method) || method === 'terminal.close' || method === 'simulator.stop' ? 'desktop' : method === 'execution.stop'
}
