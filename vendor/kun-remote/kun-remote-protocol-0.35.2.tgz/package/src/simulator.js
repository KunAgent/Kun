import { check, object, id, integer, oneOf, resource, optional, string } from './validation.js'

export const SIMULATOR_METHODS = Object.freeze([
  'simulator.list', 'simulator.start', 'simulator.frame', 'simulator.input', 'simulator.stop'
])
export const SIMULATOR_READ_METHODS = Object.freeze(['simulator.list', 'simulator.frame'])
export const SIMULATOR_LIMITS = Object.freeze({ frameBytes: 196608, imageWidth: 720, idleMs: 30000, inputText: 1000 })
export const SIMULATOR_BUTTONS = Object.freeze(['home', 'lock', 'siri'])
const udid = value => check(typeof value === 'string' && /^[A-Fa-f0-9]{8}(?:-[A-Fa-f0-9]{4}){3}-[A-Fa-f0-9]{12}$/.test(value))
const coordinate = value => check(typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1)

export function validateSimulatorParams(method, p) {
  switch (method) {
    case 'simulator.list': object(p, ['origin']); resource(p.origin); break
    case 'simulator.start':
      object(p, ['origin', 'udid', 'startId']); resource(p.origin); udid(p.udid); id(p.startId); break
    case 'simulator.frame': object(p, ['sessionId']); id(p.sessionId); break
    case 'simulator.stop': object(p, ['sessionId']); id(p.sessionId); break
    case 'simulator.input': {
      object(p, ['sessionId', 'sequence', 'input']); id(p.sessionId); integer(p.sequence, 1, 2147483647)
      const v = p.input
      check(v && typeof v === 'object')
      if (v.kind === 'tap') {
        object(v, ['kind', 'x', 'y'], ['holdMs']); coordinate(v.x); coordinate(v.y)
        optional(v, 'holdMs', n => integer(n, 0, 2000))
      } else if (v.kind === 'swipe') {
        object(v, ['kind', 'x', 'y', 'endX', 'endY', 'durationMs'])
        ;[v.x, v.y, v.endX, v.endY].forEach(coordinate); integer(v.durationMs, 100, 2000)
      } else if (v.kind === 'button') {
        object(v, ['kind', 'button']); oneOf(v.button, SIMULATOR_BUTTONS)
      } else if (v.kind === 'text') {
        object(v, ['kind', 'text']); string(v.text, SIMULATOR_LIMITS.inputText)
        check(/^[\x20-\x7e\n\t]*$/.test(v.text))
      } else throw new Error('INVALID_REQUEST')
      break
    }
    default: throw new Error('UNSUPPORTED_OPERATION')
  }
  return p
}

export function validateSimulatorResult(method, p) {
  if (method === 'simulator.list') {
    object(p, ['devices', 'inputAvailable'])
    check(typeof p.inputAvailable === 'boolean' && Array.isArray(p.devices) && p.devices.length <= 64)
    p.devices.forEach(v => { object(v, ['udid', 'name', 'runtime', 'state']); udid(v.udid); string(v.name, 200); string(v.runtime, 200); oneOf(v.state, ['Booted', 'Shutdown']) })
  } else if (method === 'simulator.start') {
    object(p, ['sessionId', 'udid', 'name', 'inputAvailable']); id(p.sessionId); udid(p.udid); string(p.name, 200); check(typeof p.inputAvailable === 'boolean')
  } else if (method === 'simulator.frame') {
    object(p, ['sessionId', 'image', 'width', 'height', 'capturedAt'])
    id(p.sessionId); integer(p.width, 1, 4096); integer(p.height, 1, 4096); integer(p.capturedAt, 1, Number.MAX_SAFE_INTEGER)
    check(typeof p.image === 'string' && p.image.length <= SIMULATOR_LIMITS.frameBytes && /^data:image\/jpeg;base64,[A-Za-z0-9+/]+=*$/.test(p.image))
  } else if (method === 'simulator.input') {
    object(p, ['accepted', 'sequence']); check(p.accepted === true); integer(p.sequence, 1, 2147483647)
  } else if (method === 'simulator.stop') {
    object(p, ['closed']); check(p.closed === true)
  } else throw new Error('UNSUPPORTED_OPERATION')
  return p
}
