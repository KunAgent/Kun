export interface CodeChange { path: string; status: string; added: number; removed: number; binary: boolean }
export interface CodeChanges { repository: boolean; revision: string; files: CodeChange[]; truncated: boolean }
export interface CodeChangePatch { path: string; revision: string; patch: string; binary: boolean; truncated: boolean }
export interface CodeChangesParams {
  'code.changes.list': { threadId: string }
  'code.changes.get': { threadId: string; path: string; revision: string }
}
export interface CodeChangesResults {
  'code.changes.list': CodeChanges
  'code.changes.get': CodeChangePatch
}
export const CODE_CHANGES_METHODS: readonly (keyof CodeChangesParams)[]
export function validateCodeChangesParams<M extends keyof CodeChangesParams>(method: M, params: unknown): CodeChangesParams[M]
export function validateCodeChangesResult<M extends keyof CodeChangesParams>(method: M, value: unknown): CodeChangesResults[M]
