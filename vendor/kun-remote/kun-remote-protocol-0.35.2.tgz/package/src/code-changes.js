import { check, object, id, string, integer } from './validation.js'

export const CODE_CHANGES_METHODS = Object.freeze(['code.changes.list', 'code.changes.get'])
export function validateCodeChangesParams(method, p) {
  if (method === 'code.changes.list') object(p, ['threadId'])
  else if (method === 'code.changes.get') {
    object(p, ['threadId', 'path', 'revision'])
    string(p.path, 4096)
    check(!p.path.startsWith('/') && !p.path.includes('\\') && !p.path.includes('\0') && !p.path.split('/').some(s => s === '..' || s === '.' || s.toLowerCase() === '.git' || !s))
    check(/^changes-v1:[a-f0-9]{64}$/.test(p.revision))
  } else throw new Error('UNSUPPORTED_OPERATION')
  id(p.threadId)
  return p
}
export function validateCodeChangesResult(method, p) {
  if (method === 'code.changes.list') {
    object(p, ['repository', 'revision', 'files', 'truncated'])
    check(typeof p.repository === 'boolean' && typeof p.truncated === 'boolean')
    check(/^changes-v1:[a-f0-9]{64}$/.test(p.revision) && Array.isArray(p.files) && p.files.length <= 200)
    p.files.forEach(f => {
      object(f, ['path', 'status', 'added', 'removed', 'binary'])
      string(f.path, 4096); string(f.status, 2); integer(f.added, 0, 100000000); integer(f.removed, 0, 100000000); check(typeof f.binary === 'boolean')
    })
  } else if (method === 'code.changes.get') {
    object(p, ['path', 'revision', 'patch', 'binary', 'truncated'])
    string(p.path, 4096); string(p.patch, 131072, 0); check(/^changes-v1:[a-f0-9]{64}$/.test(p.revision))
    check(typeof p.binary === 'boolean' && typeof p.truncated === 'boolean')
  } else throw new Error('UNSUPPORTED_OPERATION')
  return p
}
