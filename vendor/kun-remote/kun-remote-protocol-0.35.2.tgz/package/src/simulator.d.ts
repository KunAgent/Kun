import type { ResourceRef } from './values.js'
export interface SimulatorDevice { udid: string; name: string; runtime: string; state: 'Booted' | 'Shutdown' }
export interface SimulatorSession { sessionId: string; udid: string; name: string; inputAvailable: boolean }
export interface SimulatorFrame { sessionId: string; image: string; width: number; height: number; capturedAt: number }
export type SimulatorButton = 'home' | 'lock' | 'siri'
export type SimulatorInput =
  | { kind: 'tap'; x: number; y: number; holdMs?: number }
  | { kind: 'swipe'; x: number; y: number; endX: number; endY: number; durationMs: number }
  | { kind: 'button'; button: SimulatorButton }
  | { kind: 'text'; text: string }
export interface SimulatorParams {
  'simulator.list': { origin: ResourceRef }
  'simulator.start': { origin: ResourceRef; udid: string; startId: string }
  'simulator.frame': { sessionId: string }
  'simulator.input': { sessionId: string; sequence: number; input: SimulatorInput }
  'simulator.stop': { sessionId: string }
}
export interface SimulatorResults {
  'simulator.list': { devices: SimulatorDevice[]; inputAvailable: boolean }
  'simulator.start': SimulatorSession
  'simulator.frame': SimulatorFrame
  'simulator.input': { accepted: true; sequence: number }
  'simulator.stop': { closed: true }
}
export type SimulatorMethod = keyof SimulatorParams
export const SIMULATOR_METHODS: readonly SimulatorMethod[]
export const SIMULATOR_READ_METHODS: readonly SimulatorMethod[]
export const SIMULATOR_BUTTONS: readonly SimulatorButton[]
export const SIMULATOR_LIMITS: Readonly<{ frameBytes: number; imageWidth: number; idleMs: number; inputText: number }>
export function validateSimulatorParams<M extends SimulatorMethod>(method: M, params: unknown): SimulatorParams[M]
export function validateSimulatorResult<M extends SimulatorMethod>(method: M, value: unknown): SimulatorResults[M]
