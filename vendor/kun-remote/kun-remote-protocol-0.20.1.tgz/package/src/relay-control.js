/**
 * Optional personal-relay behaviours a client asks for in its WebSocket upgrade. A relay that does
 * not know the header ignores it, and a client never receives a notice it did not ask for.
 */
export const RELAY_FEATURES_HEADER = 'X-Kun-Relay-Features'
export const RELAY_FEATURES = Object.freeze(['presence', 'authorization', 'lossy'])
/** Desktop catalog capabilities a phone checks before sending the matching optional fields. */
export const READ_CONDITIONAL_CAPABILITY = 'read.conditional'
export const HISTORY_LIVE_CAPABILITY = 'history.live'
/** A personal lease may last this long; older relays keep issuing sixty seconds. */
export const MAX_LEASE_MS = 300000

/** Parse the relay's echo of accepted features from hello; anything unknown is dropped. */
export function relayFeatures(value) {
  return new Set(Array.isArray(value) ? value.filter((name) => RELAY_FEATURES.includes(name)) : [])
}

/**
 * Relay-authored notices are event frames without a source device. Presence reports one device or,
 * from hello, the full peer set; authorization says this device's peer set changed; shed says the
 * relay dropped lossy frames for this receiver while it was behind on acknowledgements.
 */
export function relayNotice(frame) {
  if (frame?.kind !== 'event' || frame.src !== undefined) return null
  const payload = frame.payload
  if (!payload || typeof payload.relay !== 'string') return null
  if (payload.relay === 'presence') {
    const peers = Array.isArray(payload.peers) ? payload.peers : [payload]
    const valid = peers.filter((peer) => typeof peer?.deviceId === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(peer.deviceId) &&
      typeof peer.online === 'boolean').slice(0, 32).map(({ deviceId, online }) => ({ deviceId, online }))
    return valid.length ? { relay: 'presence', snapshot: Array.isArray(payload.peers), peers: valid } : null
  }
  if (payload.relay === 'authorization' || payload.relay === 'shed') return { relay: payload.relay }
  return null
}
