import { DISPATCH_METHODS, DISPATCH_READ_METHODS, validateDispatchParams } from './dispatch.js'
import { TASK_METHODS, validateTaskParams } from './tasks.js'
import { TASK_SETTINGS_METHODS, validateTaskSettingsParams } from './task-settings.js'
import { MESSAGE_METHODS, validateMessageParams } from './messages.js'
import { ATTENTION_METHODS, validateAttentionParams } from './attention.js'
import { ARTIFACT_METHODS, validateArtifactParams } from './artifacts.js'
import { ARTIFACT_PREVIEW_METHODS, ARTIFACT_PREVIEW_READ_METHODS, validateArtifactPreviewParams } from './artifact-preview.js'
import { AGENT_DIRECTORY_METHODS, validateAgentDirectoryParams } from './agent-directory.js'
import { EXECUTION_METHODS, validateExecutionParams } from './execution.js'
import { GOAL_METHODS, validateGoalParams } from './goals.js'
import { AGENT_PROFILE_METHODS, validateAgentProfileParams } from './agent-profiles.js'
import { AGENT_MEMORY_METHODS, validateAgentMemoryParams } from './agent-memory.js'
import { AGENT_COMMITMENT_METHODS, validateAgentCommitmentParams } from './agent-commitments.js'
import { PROJECT_FILES_METHODS, validateProjectFilesParams } from './project-files.js'
import { WORK_METHODS, validateWorkParams } from './work.js'
import { GROUP_METHODS, validateGroupParams } from './groups.js'
import { COLLABORATION_METHODS, validateCollaborationParams } from './collaboration.js'
import { PLUGIN_METHODS, validatePluginParams } from './plugins.js'
import { SCHEDULE_METHODS, validateScheduleParams } from './schedules.js'
import { AGENT_AVATAR_METHODS, validateAgentAvatarParams } from './agent-avatars.js'
import { AGENT_CAPABILITY_METHODS, validateAgentCapabilityParams } from './agent-capabilities.js'
import { HISTORY_METHODS, validateHistoryParams } from './history-actions.js'
import { AGENT_HISTORY_METHODS, validateAgentHistoryParams } from './agent-memory-review.js'
import { AGENT_LIBRARY_METHODS, validateAgentLibraryParams } from './agent-library.js'
import { REMINDER_METHODS, validateReminderParams } from './agent-reminders.js'
import { AGENT_LIFECYCLE_METHODS, validateAgentLifecycleParams } from './agent-lifecycle.js'
import { AGENT_IMPORT_METHODS, validateAgentImportParams } from './agent-import.js'
import { SHARED_OWNER_METHODS, validateSharedOwnerParams } from './shared-owner.js'
import { DESKTOP_METHODS, DESKTOP_READ_METHODS, validateDesktopParams } from './desktop-session.js'
import { TERMINAL_METHODS, validateTerminalParams } from './terminal.js'
import { validateSourceContentParams } from './source-content.js'

export const OPERATION_METHODS = Object.freeze([
  ...DISPATCH_METHODS,
  ...ARTIFACT_PREVIEW_METHODS,
  "code.search",
  "code.rename",
  "code.pin",
  "code.archive",
  "code.restore",
  "code.delete",
  "code.settings.get",
  "code.settings.update",
  "message.search",
  "message.get",
  "attention.list",
  "artifact.list",
  "message.source.get",
  "agent.search",
  "execution.queue.list",
  "execution.queue.enqueue",
  "execution.queue.update",
  "execution.queue.remove",
  "execution.resume",
  "execution.steer",
  "goal.get",
  "goal.update",
  "goal.clear",
  "agent.get",
  "agent.create",
  "agent.update",
  "agent.archive",
  "agent.restore",
  "agent.memory.list",
  "agent.memory.update",
  "agent.commitments.list",
  "agent.commitments.act",
  "project.files.list",
  "project.files.search",
  "file.preview",
  "project.files.resolve",
  "work.spaces.list",
  "work.sessions.list",
  "code.fork",
  "code.rewind.preview",
  "code.rewind.commit",
  "agent.memory.candidates.list",
  "agent.memory.candidates.get",
  "agent.memory.candidates.decide",
  "agent.memory.history.list",
  "agent.memory.history.get",
  "agent.runs.list",
  "agent.runs.get",
  "agent.artifacts.list",
  "agent.artifacts.get",
  "agent.artifacts.versions",
  "agent.reminders.list",
  "agent.reminders.act",
  "agent.lifecycle.get",
  "agent.restart",
  "agent.import.preview",
  "agent.import.commit",
  "agent.avatar.get",
  "agent.avatar.update",
  "agent.skills.list",
  "agent.connections.list",
  "group.list",
  "group.history",
  "group.message.send",
  "collaboration.runs.list",
  "collaboration.tasks.list",
  "schedule.list",
  "schedule.runs.list",
  "plugin.catalog",
  "plugin.view",
  "agent.directory.list",
  "group.get",
  "group.create",
  "group.update",
  "group.archive",
  "group.restore",
  "group.member.add",
  "group.member.update",
  "group.member.remove",
  "plugin.setEnabled",
  "desktop.schedule.list",
  "desktop.schedule.runs.list",
  "shares.list",
  "shares.manage",
  ...DESKTOP_METHODS,
  ...TERMINAL_METHODS
])
export const OPERATION_READ_METHODS = new Set([
  ...DISPATCH_READ_METHODS,
  ...ARTIFACT_PREVIEW_READ_METHODS,
  "code.search",
  "code.settings.get",
  "message.search",
  "message.get",
  "attention.list",
  "artifact.list",
  "message.source.get",
  "agent.search",
  "execution.queue.list",
  "goal.get",
  "agent.get",
  "agent.memory.list",
  "agent.commitments.list",
  "project.files.list",
  "project.files.search",
  "file.preview",
  "project.files.resolve",
  "work.spaces.list",
  "work.sessions.list",
  "agent.memory.candidates.list",
  "agent.memory.candidates.get",
  "agent.memory.history.list",
  "agent.memory.history.get",
  "agent.runs.list",
  "agent.runs.get",
  "agent.artifacts.list",
  "agent.artifacts.get",
  "agent.artifacts.versions",
  "agent.reminders.list",
  "agent.lifecycle.get",
  "agent.avatar.get",
  "agent.skills.list",
  "agent.connections.list",
  "group.list",
  "group.history",
  "collaboration.runs.list",
  "collaboration.tasks.list",
  "schedule.list",
  "schedule.runs.list",
  "plugin.catalog",
  "plugin.view",
  "agent.directory.list",
  "group.get",
  "desktop.schedule.list",
  "desktop.schedule.runs.list",
  "shares.list",
  ...DESKTOP_READ_METHODS
])
const validators = new Map()
for (const method of DISPATCH_METHODS) validators.set(method, validateDispatchParams)
for (const method of DESKTOP_METHODS) validators.set(method, validateDesktopParams)
for (const method of TERMINAL_METHODS) validators.set(method, validateTerminalParams)
for (const method of TASK_METHODS) validators.set(method, validateTaskParams)
for (const method of TASK_SETTINGS_METHODS) validators.set(method, validateTaskSettingsParams)
for (const method of MESSAGE_METHODS) validators.set(method, validateMessageParams)
for (const method of ATTENTION_METHODS) validators.set(method, validateAttentionParams)
for (const method of ARTIFACT_METHODS) validators.set(method, validateArtifactParams)
for (const method of ARTIFACT_PREVIEW_METHODS) validators.set(method, validateArtifactPreviewParams)
for (const method of AGENT_DIRECTORY_METHODS) validators.set(method, validateAgentDirectoryParams)
for (const method of EXECUTION_METHODS) validators.set(method, validateExecutionParams)
for (const method of GOAL_METHODS) validators.set(method, validateGoalParams)
for (const method of AGENT_PROFILE_METHODS) validators.set(method, validateAgentProfileParams)
for (const method of AGENT_MEMORY_METHODS) validators.set(method, validateAgentMemoryParams)
for (const method of AGENT_COMMITMENT_METHODS) validators.set(method, validateAgentCommitmentParams)
for (const method of PROJECT_FILES_METHODS) validators.set(method, validateProjectFilesParams)
for (const method of WORK_METHODS) validators.set(method, validateWorkParams)
for (const method of GROUP_METHODS) validators.set(method, validateGroupParams)
for (const method of COLLABORATION_METHODS) validators.set(method, validateCollaborationParams)
for (const method of PLUGIN_METHODS) validators.set(method, validatePluginParams)
for (const method of SCHEDULE_METHODS) validators.set(method, validateScheduleParams)
for (const method of AGENT_AVATAR_METHODS) validators.set(method, validateAgentAvatarParams)
for (const method of AGENT_CAPABILITY_METHODS) validators.set(method, validateAgentCapabilityParams)
for (const method of HISTORY_METHODS) validators.set(method, validateHistoryParams)
for (const method of AGENT_HISTORY_METHODS) validators.set(method, validateAgentHistoryParams)
for (const method of AGENT_LIBRARY_METHODS) validators.set(method, validateAgentLibraryParams)
for (const method of REMINDER_METHODS) validators.set(method, validateReminderParams)
for (const method of AGENT_LIFECYCLE_METHODS) validators.set(method, validateAgentLifecycleParams)
for (const method of AGENT_IMPORT_METHODS) validators.set(method, validateAgentImportParams)
for (const method of SHARED_OWNER_METHODS) validators.set(method, validateSharedOwnerParams)
validators.set('message.source.get', (_method, params) => validateSourceContentParams(params))

export function validateOperationParams(method, params) {
  const validate = validators.get(method)
  if (!validate) throw new Error('UNSUPPORTED_OPERATION')
  validate(method, params)
  return params
}
